<?xml version="1.0" encoding="UTF-8"?>
<fpmd:simulation xmlns:fpmd="http://www.quantum-simulation.org/ns/fpmd/fpmd-1.0">
<uuid> 383716e6-0a5b-11e6-93f1-002590748400 </uuid>

                   ============================
                   I qbox 1.63.2              I
                   I                          I
                   I                          I
                   I                          I
                   I                          I
                   I                          I
                   I                          I
                   I                          I
                   I                          I
                   I                          I
                   I                          I
                   I                          I
                   I http://qboxcode.org      I
                   ============================


<release> 1.63.2 presto </release>
<sysname> Linux </sysname>
<nodename> c12.local </nodename>
<start_time> 2016-04-24T20:29:18Z </start_time>
<mpi_processes count="144">
<process id="0"> c12.local </process>
<process id="1"> c12.local </process>
<process id="2"> c12.local </process>
<process id="3"> c12.local </process>
<process id="4"> c12.local </process>
<process id="5"> c12.local </process>
<process id="6"> c12.local </process>
<process id="7"> c12.local </process>
<process id="8"> c33.local </process>
<process id="9"> c33.local </process>
<process id="10"> c33.local </process>
<process id="11"> c33.local </process>
<process id="12"> c33.local </process>
<process id="13"> c33.local </process>
<process id="14"> c33.local </process>
<process id="15"> c33.local </process>
<process id="16"> c28.local </process>
<process id="17"> c28.local </process>
<process id="18"> c28.local </process>
<process id="19"> c28.local </process>
<process id="20"> c28.local </process>
<process id="21"> c28.local </process>
<process id="22"> c28.local </process>
<process id="23"> c28.local </process>
<process id="24"> c35.local </process>
<process id="25"> c35.local </process>
<process id="26"> c35.local </process>
<process id="27"> c35.local </process>
<process id="28"> c35.local </process>
<process id="29"> c35.local </process>
<process id="30"> c35.local </process>
<process id="31"> c35.local </process>
<process id="32"> c11.local </process>
<process id="33"> c11.local </process>
<process id="34"> c11.local </process>
<process id="35"> c11.local </process>
<process id="36"> c11.local </process>
<process id="37"> c11.local </process>
<process id="38"> c11.local </process>
<process id="39"> c11.local </process>
<process id="40"> c19.local </process>
<process id="41"> c19.local </process>
<process id="42"> c19.local </process>
<process id="43"> c19.local </process>
<process id="44"> c19.local </process>
<process id="45"> c19.local </process>
<process id="46"> c19.local </process>
<process id="47"> c19.local </process>
<process id="48"> c07.local </process>
<process id="49"> c07.local </process>
<process id="50"> c07.local </process>
<process id="51"> c07.local </process>
<process id="52"> c07.local </process>
<process id="53"> c07.local </process>
<process id="54"> c07.local </process>
<process id="55"> c07.local </process>
<process id="56"> c38.local </process>
<process id="57"> c38.local </process>
<process id="58"> c38.local </process>
<process id="59"> c38.local </process>
<process id="60"> c38.local </process>
<process id="61"> c38.local </process>
<process id="62"> c38.local </process>
<process id="63"> c38.local </process>
<process id="64"> c31.local </process>
<process id="65"> c31.local </process>
<process id="66"> c31.local </process>
<process id="67"> c31.local </process>
<process id="68"> c31.local </process>
<process id="69"> c31.local </process>
<process id="70"> c31.local </process>
<process id="71"> c31.local </process>
<process id="72"> c37.local </process>
<process id="73"> c37.local </process>
<process id="74"> c37.local </process>
<process id="75"> c37.local </process>
<process id="76"> c37.local </process>
<process id="77"> c37.local </process>
<process id="78"> c37.local </process>
<process id="79"> c37.local </process>
<process id="80"> c10.local </process>
<process id="81"> c10.local </process>
<process id="82"> c10.local </process>
<process id="83"> c10.local </process>
<process id="84"> c10.local </process>
<process id="85"> c10.local </process>
<process id="86"> c10.local </process>
<process id="87"> c10.local </process>
<process id="88"> c25.local </process>
<process id="89"> c25.local </process>
<process id="90"> c25.local </process>
<process id="91"> c25.local </process>
<process id="92"> c25.local </process>
<process id="93"> c25.local </process>
<process id="94"> c25.local </process>
<process id="95"> c25.local </process>
<process id="96"> c05.local </process>
<process id="97"> c05.local </process>
<process id="98"> c05.local </process>
<process id="99"> c05.local </process>
<process id="100"> c05.local </process>
<process id="101"> c05.local </process>
<process id="102"> c05.local </process>
<process id="103"> c05.local </process>
<process id="104"> c39.local </process>
<process id="105"> c39.local </process>
<process id="106"> c39.local </process>
<process id="107"> c39.local </process>
<process id="108"> c39.local </process>
<process id="109"> c39.local </process>
<process id="110"> c39.local </process>
<process id="111"> c39.local </process>
<process id="112"> c08.local </process>
<process id="113"> c08.local </process>
<process id="114"> c08.local </process>
<process id="115"> c08.local </process>
<process id="116"> c08.local </process>
<process id="117"> c08.local </process>
<process id="118"> c08.local </process>
<process id="119"> c08.local </process>
<process id="120"> c46.local </process>
<process id="121"> c46.local </process>
<process id="122"> c46.local </process>
<process id="123"> c46.local </process>
<process id="124"> c46.local </process>
<process id="125"> c46.local </process>
<process id="126"> c46.local </process>
<process id="127"> c46.local </process>
<process id="128"> c00.local </process>
<process id="129"> c00.local </process>
<process id="130"> c00.local </process>
<process id="131"> c00.local </process>
<process id="132"> c00.local </process>
<process id="133"> c00.local </process>
<process id="134"> c00.local </process>
<process id="135"> c00.local </process>
<process id="136"> c14.local </process>
<process id="137"> c14.local </process>
<process id="138"> c14.local </process>
<process id="139"> c14.local </process>
<process id="140"> c14.local </process>
<process id="141"> c14.local </process>
<process id="142"> c14.local </process>
<process id="143"> c14.local </process>
</mpi_processes>
[qbox] <cmd>set nrowmax 72 </cmd>
[qbox] <cmd>h2o64.i</cmd>
[qbox][h2o64.i] <cmd># H2O64 - from PBE400-s0000-md120.xml</cmd>
[qbox][h2o64.i] <cmd>set cell  23.46000000   0.00000000   0.00000000   0.00000000  23.46000000   0.00000000   0.00000000   0.00000000  23.46000000</cmd>
<unit_cell 
    a="23.46000000  0.00000000   0.00000000  "
    b="0.00000000   23.46000000  0.00000000  "
    c="0.00000000   0.00000000   23.46000000 " />
[qbox][h2o64.i] <cmd>species oxygen O_HSCV_PBE-1.0.xml</cmd>
  SpeciesCmd: defining species oxygen as O_HSCV_PBE-1.0.xml

 species oxygen:
<species name="oxygen">
 <description>
 PSGen-1.6.0 pseudopotential: HSCV O xc=PBE
 Generated by PSGen-1.6.0 on 2009-02-15T02:25:11Z
 psgen arguments:
 -element O -xc PBE -smooth_v -bound l=0:rc=0.8 -bound l=1:rc=0.8
 </description>
 <symbol>O</symbol>
 <atomic_number>8</atomic_number>
 <mass>15.99940000</mass>
 <norm_conserving_pseudopotential>
 <valence_charge>6</valence_charge>
 <lmax>1</lmax>
 <llocal>1</llocal>
 <nquad>0</nquad>
 <rquad>0.00000000</rquad>
 <mesh_spacing>0.01000000</mesh_spacing>
 </norm_conserving_pseudopotential>
</species>
 Kleinman-Bylander potential
 rcps_ =   1.50000000
[qbox][h2o64.i] <cmd>species hydrogen D_HSCV_PBE-1.0.xml</cmd>
  SpeciesCmd: defining species hydrogen as D_HSCV_PBE-1.0.xml

 species hydrogen:
<species name="hydrogen">
 <description>
 HSCV PBE Deuterium 
 PSGen-1.6.0 pseudopotential: HSCV H xc=PBE
 Generated by PSGen-1.6.0 on 2009-02-15T02:24:50Z
 psgen arguments:
 -element H -xc PBE -smooth_v -bound l=0:rc=0.5
 </description>
 <symbol>D</symbol>
 <atomic_number>1</atomic_number>
 <mass>2.01400000</mass>
 <norm_conserving_pseudopotential>
 <valence_charge>1</valence_charge>
 <lmax>0</lmax>
 <llocal>0</llocal>
 <nquad>0</nquad>
 <rquad>0.00000000</rquad>
 <mesh_spacing>0.01000000</mesh_spacing>
 </norm_conserving_pseudopotential>
</species>
 local potential
 rcps_ =   1.50000000
[qbox][h2o64.i] <cmd>atom O1 oxygen  -6.48337908 6.01757097 12.37774040   -0.00018626 -0.00020031 0.00028804  </cmd>
[qbox][h2o64.i] <cmd>atom O2 oxygen  23.13620027 2.61155301 25.49658173   -0.00000852 0.00006359 -0.00023066  </cmd>
[qbox][h2o64.i] <cmd>atom O3 oxygen  -28.79530384 23.73288427 -33.09468503   -0.00018165 0.00012688 -0.00011929  </cmd>
[qbox][h2o64.i] <cmd>atom O4 oxygen  13.16352729 -9.21037044 -0.60382285   0.00007618 -0.00022711 0.00007599  </cmd>
[qbox][h2o64.i] <cmd>atom O5 oxygen  6.66609866 -22.47163884 -5.68002479   0.00027201 -0.00000949 -0.00049678  </cmd>
[qbox][h2o64.i] <cmd>atom O6 oxygen  8.01875291 16.93359926 5.23223206   0.00009179 -0.00023123 0.00036264  </cmd>
[qbox][h2o64.i] <cmd>atom O7 oxygen  -4.61485622 -29.13618554 -18.04026819   -0.00001565 0.00043375 -0.00028638  </cmd>
[qbox][h2o64.i] <cmd>atom O8 oxygen  2.78492012 -14.69141749 13.53605350   -0.00007130 -0.00043688 0.00022492  </cmd>
[qbox][h2o64.i] <cmd>atom O9 oxygen  2.61394758 4.40059778 -6.43900309   -0.00032157 -0.00002571 -0.00039207  </cmd>
[qbox][h2o64.i] <cmd>atom O10 oxygen  0.40775540 7.98484209 8.11656754   0.00015325 0.00024751 0.00020699  </cmd>
[qbox][h2o64.i] <cmd>atom O11 oxygen  13.17840362 -14.44054701 10.99567824   -0.00006651 0.00010000 0.00000287  </cmd>
[qbox][h2o64.i] <cmd>atom O12 oxygen  -13.19795332 -2.55545972 13.06971282   0.00027796 -0.00012941 -0.00010469  </cmd>
[qbox][h2o64.i] <cmd>atom O13 oxygen  2.32510797 -9.79822461 -21.54192141   -0.00010638 0.00039477 0.00012161  </cmd>
[qbox][h2o64.i] <cmd>atom O14 oxygen  -5.30059909 -9.16828243 -2.45729976   -0.00018228 0.00002969 -0.00033938  </cmd>
[qbox][h2o64.i] <cmd>atom O15 oxygen  13.31859014 -11.98842145 4.14310527   -0.00049884 -0.00028788 0.00021702  </cmd>
[qbox][h2o64.i] <cmd>atom O16 oxygen  -6.98789469 9.49975207 -7.01876185   -0.00006689 0.00025139 -0.00007766  </cmd>
[qbox][h2o64.i] <cmd>atom O17 oxygen  -13.79139500 -14.61687960 -27.73505694   -0.00000053 0.00010530 0.00021683  </cmd>
[qbox][h2o64.i] <cmd>atom O18 oxygen  -19.92421666 -2.75646034 14.85311542   -0.00020692 -0.00014864 0.00011536  </cmd>
[qbox][h2o64.i] <cmd>atom O19 oxygen  7.38139414 -16.22328712 0.19736442   -0.00035119 -0.00035204 0.00005071  </cmd>
[qbox][h2o64.i] <cmd>atom O20 oxygen  5.89714230 17.68761400 -22.94967014   0.00008105 -0.00013530 -0.00001100  </cmd>
[qbox][h2o64.i] <cmd>atom O21 oxygen  2.46316311 1.82036862 12.74557389   -0.00020684 0.00029185 -0.00013774  </cmd>
[qbox][h2o64.i] <cmd>atom O22 oxygen  -9.90361701 -4.95177700 2.29604219   0.00033193 0.00010942 -0.00030831  </cmd>
[qbox][h2o64.i] <cmd>atom O23 oxygen  -13.81353707 -10.70559375 7.67834275   0.00015296 0.00000252 -0.00036292  </cmd>
[qbox][h2o64.i] <cmd>atom O24 oxygen  18.58913749 -13.36809869 4.52489240   0.00035211 -0.00015072 -0.00004291  </cmd>
[qbox][h2o64.i] <cmd>atom O25 oxygen  20.48569855 14.38870676 2.07716713   0.00003420 -0.00049658 -0.00044290  </cmd>
[qbox][h2o64.i] <cmd>atom O26 oxygen  6.68722761 13.02072680 -30.12532703   -0.00001791 0.00019979 0.00016304  </cmd>
[qbox][h2o64.i] <cmd>atom O27 oxygen  12.81727313 -21.72429916 -10.28086853   0.00010093 -0.00027268 0.00013013  </cmd>
[qbox][h2o64.i] <cmd>atom O28 oxygen  10.66103836 3.70706566 -14.52621439   0.00006731 0.00033141 -0.00025626  </cmd>
[qbox][h2o64.i] <cmd>atom O29 oxygen  -4.81856258 6.48017453 -3.65040043   0.00005855 -0.00005019 0.00018356  </cmd>
[qbox][h2o64.i] <cmd>atom O30 oxygen  -10.80303056 -0.60212400 22.05932398   0.00033800 0.00005618 -0.00014052  </cmd>
[qbox][h2o64.i] <cmd>atom O31 oxygen  4.41605858 -1.01635028 0.91257900   0.00018235 0.00004108 0.00025551  </cmd>
[qbox][h2o64.i] <cmd>atom O32 oxygen  22.69748710 -0.71004283 -1.96930837   -0.00010054 0.00005055 0.00037268  </cmd>
[qbox][h2o64.i] <cmd>atom O33 oxygen  -1.15007142 23.06255209 9.74205238   0.00001609 0.00012439 0.00005821  </cmd>
[qbox][h2o64.i] <cmd>atom O34 oxygen  -13.41851173 -2.82191889 18.12783535   -0.00026696 0.00004178 0.00015451  </cmd>
[qbox][h2o64.i] <cmd>atom O35 oxygen  4.05007591 -2.42035208 -17.77633502   -0.00001804 -0.00009302 0.00004897  </cmd>
[qbox][h2o64.i] <cmd>atom O36 oxygen  7.54178722 6.72558992 -40.39453176   -0.00035241 -0.00007099 -0.00007025  </cmd>
[qbox][h2o64.i] <cmd>atom O37 oxygen  -10.78855453 -1.22034715 5.74284370   -0.00027409 0.00005169 0.00001517  </cmd>
[qbox][h2o64.i] <cmd>atom O38 oxygen  1.47903850 11.74909104 17.40097322   -0.00015906 0.00013073 0.00011325  </cmd>
[qbox][h2o64.i] <cmd>atom O39 oxygen  7.69059164 9.92671767 -11.65453590   0.00017031 0.00006109 0.00006728  </cmd>
[qbox][h2o64.i] <cmd>atom O40 oxygen  -16.38066533 -7.53270112 12.47868118   0.00037297 0.00023394 0.00013230  </cmd>
[qbox][h2o64.i] <cmd>atom O41 oxygen  14.22221123 4.03353796 -2.29022304   -0.00015833 0.00008894 0.00014509  </cmd>
[qbox][h2o64.i] <cmd>atom O42 oxygen  -9.68549415 16.85604700 16.00473905   -0.00014806 -0.00007353 0.00021483  </cmd>
[qbox][h2o64.i] <cmd>atom O43 oxygen  -5.15430331 -4.69429230 -8.35319749   0.00001299 0.00019975 -0.00014625  </cmd>
[qbox][h2o64.i] <cmd>atom O44 oxygen  -11.06340740 -11.35184974 15.71345993   -0.00017955 0.00031798 0.00033635  </cmd>
[qbox][h2o64.i] <cmd>atom O45 oxygen  -7.57465605 26.43728094 4.59889070   0.00037902 -0.00028111 -0.00048220  </cmd>
[qbox][h2o64.i] <cmd>atom O46 oxygen  12.87827708 -5.28482258 -14.60822266   -0.00038806 -0.00010446 0.00016424  </cmd>
[qbox][h2o64.i] <cmd>atom O47 oxygen  -3.74089534 -0.89664731 3.38569457   0.00036579 -0.00023889 -0.00027776  </cmd>
[qbox][h2o64.i] <cmd>atom O48 oxygen  -20.14280677 -18.80013515 -17.70249944   -0.00012395 0.00026479 0.00009351  </cmd>
[qbox][h2o64.i] <cmd>atom O49 oxygen  -39.01876685 2.28943452 -24.17094618   -0.00017543 0.00029185 -0.00011293  </cmd>
[qbox][h2o64.i] <cmd>atom O50 oxygen  32.37097510 16.01546964 -3.14319745   0.00009554 -0.00009792 -0.00011087  </cmd>
[qbox][h2o64.i] <cmd>atom O51 oxygen  11.41950774 4.03963238 -6.13532490   -0.00027745 -0.00013783 0.00003076  </cmd>
[qbox][h2o64.i] <cmd>atom O52 oxygen  -2.00726609 2.73881292 18.12641735   0.00009723 -0.00028508 0.00009961  </cmd>
[qbox][h2o64.i] <cmd>atom O53 oxygen  19.90791953 -10.34381207 -6.94163309   0.00004223 0.00030052 -0.00023282  </cmd>
[qbox][h2o64.i] <cmd>atom O54 oxygen  0.07293669 -8.55813391 12.56383693   -0.00023401 -0.00002456 -0.00019448  </cmd>
[qbox][h2o64.i] <cmd>atom O55 oxygen  18.01942075 -3.35004874 -0.57174591   0.00000293 -0.00010904 -0.00000677  </cmd>
[qbox][h2o64.i] <cmd>atom O56 oxygen  23.49990051 -5.35547828 17.34451837   0.00026962 -0.00031541 0.00000800  </cmd>
[qbox][h2o64.i] <cmd>atom O57 oxygen  2.67738475 32.49137080 -24.49757479   0.00008795 -0.00017993 0.00007550  </cmd>
[qbox][h2o64.i] <cmd>atom O58 oxygen  5.18902487 1.41220069 -14.61484799   -0.00016095 0.00007984 0.00011208  </cmd>
[qbox][h2o64.i] <cmd>atom O59 oxygen  -2.11586701 -15.85396428 -22.91990179   0.00019782 -0.00012659 -0.00002937  </cmd>
[qbox][h2o64.i] <cmd>atom O60 oxygen  -27.36656162 -13.21227906 10.47519120   -0.00023023 -0.00021802 0.00005182  </cmd>
[qbox][h2o64.i] <cmd>atom O61 oxygen  -3.86617346 4.42003900 -15.45610732   -0.00016347 0.00014160 -0.00031048  </cmd>
[qbox][h2o64.i] <cmd>atom O62 oxygen  -6.02892743 -7.12590651 33.47308208   0.00022958 -0.00012832 -0.00006150  </cmd>
[qbox][h2o64.i] <cmd>atom O63 oxygen  -20.88273593 -8.14238763 31.67424996   -0.00028552 0.00003562 0.00025271  </cmd>
[qbox][h2o64.i] <cmd>atom O64 oxygen  12.28394914 6.56642081 25.70189546   0.00029154 -0.00003579 0.00033402  </cmd>
[qbox][h2o64.i] <cmd>atom H1 hydrogen  -5.91447931 7.18957751 13.81423572   -0.00024140 0.00072771 0.00044863  </cmd>
[qbox][h2o64.i] <cmd>atom H2 hydrogen  -8.14493074 6.55296185 11.86788898   0.00064690 -0.00073089 0.00044222  </cmd>
[qbox][h2o64.i] <cmd>atom H3 hydrogen  24.65643943 2.70115163 26.58544242   0.00075463 0.00056977 -0.00079308  </cmd>
[qbox][h2o64.i] <cmd>atom H4 hydrogen  22.03898946 1.40094598 26.47816242   -0.00065831 0.00014518 -0.00019044  </cmd>
[qbox][h2o64.i] <cmd>atom H5 hydrogen  -27.57462232 24.54186544 -31.89121949   -0.00074327 -0.00078928 0.00051190  </cmd>
[qbox][h2o64.i] <cmd>atom H6 hydrogen  -27.79753272 23.84455906 -34.73322301   -0.00019825 -0.00018837 0.00062626  </cmd>
[qbox][h2o64.i] <cmd>atom H7 hydrogen  12.64884566 -10.31410854 0.93678639   -0.00038598 -0.00010662 0.00136083  </cmd>
[qbox][h2o64.i] <cmd>atom H8 hydrogen  11.72930182 -8.79258066 -1.71155072   0.00015667 0.00034373 -0.00030316  </cmd>
[qbox][h2o64.i] <cmd>atom H9 hydrogen  5.48562314 -21.02770733 -6.16489387   0.00033679 -0.00034083 0.00016348  </cmd>
[qbox][h2o64.i] <cmd>atom H10 hydrogen  6.92493700 -22.22960865 -3.78607531   0.00021459 -0.00060907 0.00088114  </cmd>
[qbox][h2o64.i] <cmd>atom H11 hydrogen  7.16520394 17.02103776 3.51240924   -0.00038590 0.00055522 -0.00085378  </cmd>
[qbox][h2o64.i] <cmd>atom H12 hydrogen  9.69143156 17.76257175 5.01240802   -0.00086278 0.00003916 0.00043855  </cmd>
[qbox][h2o64.i] <cmd>atom H13 hydrogen  -4.26104823 -27.36835214 -18.74080232   0.00082940 -0.00016694 0.00070767  </cmd>
[qbox][h2o64.i] <cmd>atom H14 hydrogen  -3.99638978 -30.10169188 -19.45111249   0.00025077 0.00052655 0.00009609  </cmd>
[qbox][h2o64.i] <cmd>atom H15 hydrogen  1.58724758 -14.52689069 12.09015359   -0.00072610 -0.00034599 0.00077478  </cmd>
[qbox][h2o64.i] <cmd>atom H16 hydrogen  4.52936081 -14.44419643 12.74825950   -0.00047540 0.00014468 0.00031527  </cmd>
[qbox][h2o64.i] <cmd>atom H17 hydrogen  2.42435127 5.99388691 -7.42171100   -0.00003012 0.00044468 0.00018965  </cmd>
[qbox][h2o64.i] <cmd>atom H18 hydrogen  0.93414815 3.81263784 -5.74792554   0.00049747 0.00225019 -0.00106027  </cmd>
[qbox][h2o64.i] <cmd>atom H19 hydrogen  -0.81117381 6.62526733 8.30614388   -0.00034381 0.00054706 0.00019400  </cmd>
[qbox][h2o64.i] <cmd>atom H20 hydrogen  -0.80854693 9.46485563 8.24675890   0.00017840 -0.00011316 0.00008044  </cmd>
[qbox][h2o64.i] <cmd>atom H21 hydrogen  11.53195341 -15.14387185 10.57818920   -0.00004266 0.00025871 0.00002025  </cmd>
[qbox][h2o64.i] <cmd>atom H22 hydrogen  12.74545359 -13.12115693 12.18030671   -0.00024822 -0.00036266 0.00057134  </cmd>
[qbox][h2o64.i] <cmd>atom H23 hydrogen  -12.41540942 -1.53426315 11.76894698   0.00093394 -0.00089457 0.00072464  </cmd>
[qbox][h2o64.i] <cmd>atom H24 hydrogen  -12.37045864 -1.95264697 14.56062011   0.00056756 -0.00023990 -0.00025721  </cmd>
[qbox][h2o64.i] <cmd>atom H25 hydrogen  0.50369434 -9.37585033 -21.33324048   0.00028115 0.00006922 0.00024456  </cmd>
[qbox][h2o64.i] <cmd>atom H26 hydrogen  3.11721043 -8.31883349 -22.29283368   -0.00068918 0.00035330 -0.00039450  </cmd>
[qbox][h2o64.i] <cmd>atom H27 hydrogen  -7.07345500 -9.59252235 -2.48384439   0.00106755 0.00041214 0.00020668  </cmd>
[qbox][h2o64.i] <cmd>atom H28 hydrogen  -4.59390205 -9.32847641 -4.20232701   0.00056297 -0.00034459 0.00000272  </cmd>
[qbox][h2o64.i] <cmd>atom H29 hydrogen  12.60523863 -13.64256452 3.62352383   0.00050311 -0.00078851 -0.00073836  </cmd>
[qbox][h2o64.i] <cmd>atom H30 hydrogen  12.22002427 -11.49863912 5.52521789   0.00129565 -0.00019353 -0.00080537  </cmd>
[qbox][h2o64.i] <cmd>atom H31 hydrogen  -5.69110583 10.83471193 -7.18122204   -0.00002502 -0.00004988 -0.00138717  </cmd>
[qbox][h2o64.i] <cmd>atom H32 hydrogen  -8.60548598 10.37355057 -7.33291893   -0.00069163 0.00082788 -0.00048941  </cmd>
[qbox][h2o64.i] <cmd>atom H33 hydrogen  -14.98288344 -13.87983709 -28.97714675   -0.00096840 0.00067438 0.00050091  </cmd>
[qbox][h2o64.i] <cmd>atom H34 hydrogen  -13.04375918 -15.95314012 -28.78088943   0.00023155 0.00043332 -0.00093211  </cmd>
[qbox][h2o64.i] <cmd>atom H35 hydrogen  -20.43651888 -0.94737412 14.67766005   -0.00005201 -0.00016472 0.00025548  </cmd>
[qbox][h2o64.i] <cmd>atom H36 hydrogen  -18.16091112 -2.61569613 14.49051169   -0.00030188 0.00027085 0.00024125  </cmd>
[qbox][h2o64.i] <cmd>atom H37 hydrogen  5.62361560 -15.55377580 0.42212440   -0.00015482 0.00036927 0.00163267  </cmd>
[qbox][h2o64.i] <cmd>atom H38 hydrogen  8.15683514 -15.38385777 -1.33569517   -0.00021748 -0.00033537 -0.00028759  </cmd>
[qbox][h2o64.i] <cmd>atom H39 hydrogen  5.53910294 19.57226294 -23.08897847   -0.00011073 -0.00010790 -0.00001688  </cmd>
[qbox][h2o64.i] <cmd>atom H40 hydrogen  6.90249521 17.33838827 -24.47963969   -0.00046478 -0.00017479 0.00012970  </cmd>
[qbox][h2o64.i] <cmd>atom H41 hydrogen  3.78325696 1.89144155 11.41608074   0.00056206 0.00015033 0.00001392  </cmd>
[qbox][h2o64.i] <cmd>atom H42 hydrogen  3.02745724 2.87169806 14.19563640   -0.00065067 -0.00033612 -0.00026732  </cmd>
[qbox][h2o64.i] <cmd>atom H43 hydrogen  -8.60976592 -5.43897069 3.42761752   -0.00009624 -0.00077139 0.00044117  </cmd>
[qbox][h2o64.i] <cmd>atom H44 hydrogen  -9.89217553 -6.48300506 1.08576987   0.00110387 0.00147249 0.00029265  </cmd>
[qbox][h2o64.i] <cmd>atom H45 hydrogen  -12.85585017 -9.32093381 8.48207578   0.00066013 0.00023332 -0.00026657  </cmd>
[qbox][h2o64.i] <cmd>atom H46 hydrogen  -14.71198394 -9.56918686 6.42449159   0.00058156 -0.00015546 0.00032883  </cmd>
[qbox][h2o64.i] <cmd>atom H47 hydrogen  16.74085439 -13.08513591 4.55898096   0.00015134 -0.00098673 0.00050394  </cmd>
[qbox][h2o64.i] <cmd>atom H48 hydrogen  18.61101843 -14.70723375 5.72786009   0.00070902 0.00003540 -0.00062171  </cmd>
[qbox][h2o64.i] <cmd>atom H49 hydrogen  19.91184136 12.97667107 3.17771092   -0.00025095 0.00074047 -0.00065020  </cmd>
[qbox][h2o64.i] <cmd>atom H50 hydrogen  19.35184572 14.26510405 0.54421621   0.00023183 -0.00023694 -0.00002681  </cmd>
[qbox][h2o64.i] <cmd>atom H51 hydrogen  6.79320496 14.28698620 -31.55948428   0.00058713 0.00061718 0.00008165  </cmd>
[qbox][h2o64.i] <cmd>atom H52 hydrogen  4.87799561 12.86332698 -29.85992047   -0.00045742 0.00068346 -0.00077269  </cmd>
[qbox][h2o64.i] <cmd>atom H53 hydrogen  14.70155048 -22.31231538 -10.23719974   -0.00033569 0.00000735 0.00030499  </cmd>
[qbox][h2o64.i] <cmd>atom H54 hydrogen  12.57596922 -20.67008572 -8.70368661   0.00104859 -0.00015706 0.00057293  </cmd>
[qbox][h2o64.i] <cmd>atom H55 hydrogen  11.28120727 2.73528402 -15.92362402   -0.00061268 0.00097185 -0.00071021  </cmd>
[qbox][h2o64.i] <cmd>atom H56 hydrogen  12.02660285 3.26654270 -13.26326951   0.00018617 -0.00080190 0.00002990  </cmd>
[qbox][h2o64.i] <cmd>atom H57 hydrogen  -4.01757718 7.08006264 -2.12681334   -0.00074947 -0.00061919 -0.00076618  </cmd>
[qbox][h2o64.i] <cmd>atom H58 hydrogen  -6.14041577 7.61443277 -4.45071154   -0.00060216 -0.00029397 -0.00054680  </cmd>
[qbox][h2o64.i] <cmd>atom H59 hydrogen  -10.39944745 -1.62856982 23.49625080   0.00056460 0.00032499 -0.00069126  </cmd>
[qbox][h2o64.i] <cmd>atom H60 hydrogen  -9.36563370 0.72913764 22.03064492   0.00028013 0.00016054 -0.00041940  </cmd>
[qbox][h2o64.i] <cmd>atom H61 hydrogen  5.45340356 0.45161719 0.69284161   0.00134888 0.00044889 0.00009110  </cmd>
[qbox][h2o64.i] <cmd>atom H62 hydrogen  4.13675126 -1.16554486 2.82747420   -0.00039199 0.00048006 -0.00004757  </cmd>
[qbox][h2o64.i] <cmd>atom H63 hydrogen  23.70034463 -0.33537572 -0.29579026   -0.00014370 0.00043335 -0.00024334  </cmd>
[qbox][h2o64.i] <cmd>atom H64 hydrogen  23.60518482 -2.09974407 -2.57568706   -0.00068294 0.00088764 -0.00034160  </cmd>
[qbox][h2o64.i] <cmd>atom H65 hydrogen  -0.43808049 21.66057269 8.81035520   0.00056833 -0.00015865 0.00012205  </cmd>
[qbox][h2o64.i] <cmd>atom H66 hydrogen  0.14766059 23.52020757 10.78233150   0.00056671 -0.00030170 0.00018600  </cmd>
[qbox][h2o64.i] <cmd>atom H67 hydrogen  -12.43619901 -1.82282651 19.30737941   -0.00024139 -0.00016762 0.00053166  </cmd>
[qbox][h2o64.i] <cmd>atom H68 hydrogen  -14.85898522 -1.69632187 17.82118350   0.00006270 0.00036873 -0.00092565  </cmd>
[qbox][h2o64.i] <cmd>atom H69 hydrogen  4.64215792 -1.22709463 -16.23148489   0.00012187 -0.00096863 0.00078395  </cmd>
[qbox][h2o64.i] <cmd>atom H70 hydrogen  5.29093480 -3.79927488 -17.33699994   0.00040325 0.00041899 0.00041819  </cmd>
[qbox][h2o64.i] <cmd>atom H71 hydrogen  8.00997000 8.52095054 -40.40807316   -0.00071974 -0.00044051 0.00029963  </cmd>
[qbox][h2o64.i] <cmd>atom H72 hydrogen  8.52690673 5.89979913 -39.06462244   0.00035104 -0.00057269 -0.00073789  </cmd>
[qbox][h2o64.i] <cmd>atom H73 hydrogen  -10.42027998 -2.64877934 7.06182524   -0.00069479 0.00064778 0.00056402  </cmd>
[qbox][h2o64.i] <cmd>atom H74 hydrogen  -10.90338036 -2.22055218 4.06179567   -0.00007384 0.00010332 -0.00036800  </cmd>
[qbox][h2o64.i] <cmd>atom H75 hydrogen  2.02015200 10.79072208 18.91998133   0.00008702 0.00010501 -0.00103000  </cmd>
[qbox][h2o64.i] <cmd>atom H76 hydrogen  2.04302697 10.52191009 16.04204024   0.00008751 -0.00023963 0.00123263  </cmd>
[qbox][h2o64.i] <cmd>atom H77 hydrogen  8.46660439 10.55774201 -10.10408002   -0.00049730 0.00006563 0.00044831  </cmd>
[qbox][h2o64.i] <cmd>atom H78 hydrogen  7.91526689 11.13650314 -13.06681967   -0.00177280 -0.00135844 0.00069172  </cmd>
[qbox][h2o64.i] <cmd>atom H79 hydrogen  -17.64747609 -7.65097127 11.16177746   0.00110281 0.00054296 0.00055849  </cmd>
[qbox][h2o64.i] <cmd>atom H80 hydrogen  -15.86018597 -5.72254143 12.60130187   -0.00122700 -0.00080725 -0.00079587  </cmd>
[qbox][h2o64.i] <cmd>atom H81 hydrogen  15.97310032 4.79118021 -2.71831409   0.00051306 0.00028071 -0.00010256  </cmd>
[qbox][h2o64.i] <cmd>atom H82 hydrogen  13.70247688 5.01233954 -0.81648811   0.00004640 0.00122859 0.00057187  </cmd>
[qbox][h2o64.i] <cmd>atom H83 hydrogen  -7.90950564 17.27031618 15.74797919   0.00071705 0.00162855 0.00000365  </cmd>
[qbox][h2o64.i] <cmd>atom H84 hydrogen  -10.51835845 18.20636713 16.95075603   -0.00002617 -0.00083689 -0.00029598  </cmd>
[qbox][h2o64.i] <cmd>atom H85 hydrogen  -4.93911783 -3.08874449 -9.14679497   -0.00000197 -0.00004888 -0.00019892  </cmd>
[qbox][h2o64.i] <cmd>atom H86 hydrogen  -3.73055690 -4.76249337 -7.20095760   0.00026531 0.00018921 0.00065246  </cmd>
[qbox][h2o64.i] <cmd>atom H87 hydrogen  -12.20828174 -11.40338500 17.10136200   0.00067761 0.00048991 -0.00076298  </cmd>
[qbox][h2o64.i] <cmd>atom H88 hydrogen  -10.33036498 -9.52678895 15.56689654   0.00059398 0.00084253 -0.00024453  </cmd>
[qbox][h2o64.i] <cmd>atom H89 hydrogen  -8.59524183 25.04916846 5.30680500   -0.00015596 -0.00033329 -0.00023351  </cmd>
[qbox][h2o64.i] <cmd>atom H90 hydrogen  -6.38105489 26.97664002 6.10577174   -0.00079081 -0.00122077 0.00090289  </cmd>
[qbox][h2o64.i] <cmd>atom H91 hydrogen  11.95227280 -4.94190828 -12.88706910   -0.00031474 0.00042153 0.00039527  </cmd>
[qbox][h2o64.i] <cmd>atom H92 hydrogen  14.51021273 -6.34934303 -14.04971110   0.00021867 -0.00040510 -0.00032348  </cmd>
[qbox][h2o64.i] <cmd>atom H93 hydrogen  -3.95971241 -2.24398649 2.05733945   -0.00059532 -0.00071473 0.00000982  </cmd>
[qbox][h2o64.i] <cmd>atom H94 hydrogen  -5.30267405 -0.06246776 3.49513546   0.00056853 -0.00175446 0.00001738  </cmd>
[qbox][h2o64.i] <cmd>atom H95 hydrogen  -18.52597436 -18.02852721 -18.01912361   -0.00039723 0.00063781 0.00061088  </cmd>
[qbox][h2o64.i] <cmd>atom H96 hydrogen  -21.02543881 -17.41417341 -16.89064928   0.00034857 -0.00043654 -0.00036430  </cmd>
[qbox][h2o64.i] <cmd>atom H97 hydrogen  -38.78017138 4.07964056 -23.58506126   -0.00029660 0.00047442 -0.00021542  </cmd>
[qbox][h2o64.i] <cmd>atom H98 hydrogen  -37.37980059 1.48879525 -23.99525624   0.00018011 0.00062469 -0.00075884  </cmd>
[qbox][h2o64.i] <cmd>atom H99 hydrogen  32.74780671 17.66742021 -4.09792450   0.00006579 -0.00000632 0.00102256  </cmd>
[qbox][h2o64.i] <cmd>atom H100 hydrogen  31.18581071 15.01837400 -4.27963380   0.00047519 -0.00055181 0.00018592  </cmd>
[qbox][h2o64.i] <cmd>atom H101 hydrogen  9.85216995 3.27035576 -5.89334649   -0.00013421 0.00078971 -0.00073500  </cmd>
[qbox][h2o64.i] <cmd>atom H102 hydrogen  12.16263462 3.83269640 -4.36607173   0.00119463 0.00034049 -0.00099489  </cmd>
[qbox][h2o64.i] <cmd>atom H103 hydrogen  -3.40216586 3.85417904 18.63450765   -0.00038775 -0.00085842 0.00027130  </cmd>
[qbox][h2o64.i] <cmd>atom H104 hydrogen  -1.50883342 1.66525248 19.55701942   0.00027779 0.00067500 -0.00091760  </cmd>
[qbox][h2o64.i] <cmd>atom H105 hydrogen  21.74795593 -10.89039859 -6.92476059   0.00043446 0.00068952 -0.00019504  </cmd>
[qbox][h2o64.i] <cmd>atom H106 hydrogen  19.80613193 -9.19259620 -8.53621950   0.00057256 -0.00024902 0.00066310  </cmd>
[qbox][h2o64.i] <cmd>atom H107 hydrogen  0.95541023 -8.55447412 10.97624186   -0.00059152 0.00069491 -0.00026271  </cmd>
[qbox][h2o64.i] <cmd>atom H108 hydrogen  0.74652922 -7.45788280 13.84293998   0.00066740 -0.00041866 -0.00011709  </cmd>
[qbox][h2o64.i] <cmd>atom H109 hydrogen  18.14027342 -5.06160555 -1.19991223   -0.00008846 -0.00030056 -0.00020972  </cmd>
[qbox][h2o64.i] <cmd>atom H110 hydrogen  19.16961258 -2.39653472 -1.58623027   -0.00025121 -0.00039894 -0.00017470  </cmd>
[qbox][h2o64.i] <cmd>atom H111 hydrogen  24.00582934 -6.69532660 18.48099823   -0.00050496 -0.00066724 0.00052774  </cmd>
[qbox][h2o64.i] <cmd>atom H112 hydrogen  25.02719209 -4.25424795 17.13595051   0.00022658 0.00056994 0.00043846  </cmd>
[qbox][h2o64.i] <cmd>atom H113 hydrogen  2.29814799 34.12224248 -23.58542290   0.00017258 0.00020532 -0.00009820  </cmd>
[qbox][h2o64.i] <cmd>atom H114 hydrogen  1.14589081 31.61645711 -24.08591172   0.00013954 -0.00017231 -0.00022024  </cmd>
[qbox][h2o64.i] <cmd>atom H115 hydrogen  6.93923370 1.88589423 -13.85235100   0.00063530 -0.00018698 0.00007727  </cmd>
[qbox][h2o64.i] <cmd>atom H116 hydrogen  4.72527821 2.91858615 -15.74161677   0.00014331 -0.00059402 0.00061150  </cmd>
[qbox][h2o64.i] <cmd>atom H117 hydrogen  -3.35303171 -14.76763330 -21.97199395   0.00053356 0.00054726 0.00092332  </cmd>
[qbox][h2o64.i] <cmd>atom H118 hydrogen  -1.95706600 -17.39117432 -22.06537274   -0.00052558 -0.00113224 0.00035272  </cmd>
[qbox][h2o64.i] <cmd>atom H119 hydrogen  -29.02538156 -14.00122520 10.83780723   0.00050000 0.00008905 -0.00123278  </cmd>
[qbox][h2o64.i] <cmd>atom H120 hydrogen  -28.01083459 -11.51263848 10.10641428   0.00082968 0.00024335 0.00089519  </cmd>
[qbox][h2o64.i] <cmd>atom H121 hydrogen  -4.59401330 4.82690305 -13.74027336   -0.00069396 0.00041343 -0.00042736  </cmd>
[qbox][h2o64.i] <cmd>atom H122 hydrogen  -2.97676556 2.79958225 -15.15242131   -0.00029211 0.00013047 0.00009876  </cmd>
[qbox][h2o64.i] <cmd>atom H123 hydrogen  -5.15572374 -7.00605891 31.86757078   -0.00063952 0.00050087 0.00089072  </cmd>
[qbox][h2o64.i] <cmd>atom H124 hydrogen  -5.05290438 -6.41532092 34.79708666   0.00001550 0.00089459 0.00003204  </cmd>
[qbox][h2o64.i] <cmd>atom H125 hydrogen  -20.96841133 -9.19424008 30.20285393   0.00017290 -0.00082368 0.00041753  </cmd>
[qbox][h2o64.i] <cmd>atom H126 hydrogen  -20.87675474 -6.50676693 30.82998792   0.00031461 0.00020682 0.00045224  </cmd>
[qbox][h2o64.i] <cmd>atom H127 hydrogen  10.47882455 6.05775179 25.15091228   0.00083789 -0.00094988 -0.00050568  </cmd>
[qbox][h2o64.i] <cmd>atom H128 hydrogen  13.27521667 5.38710374 26.82880631   0.00070282 -0.00041994 -0.00065710  </cmd>
[qbox][h2o64.i]  End of command stream 
[qbox] <cmd>set ecut 85</cmd>
[qbox] <cmd>set xc PBE</cmd>
[qbox] <cmd>set wf_dyn PSDA</cmd>
[qbox] <cmd>set ecutprec 4</cmd>
[qbox] <cmd>set scf_tol 1.e-8</cmd>
[qbox] <cmd>run 0 200</cmd>
  EnergyFunctional: np0v,np1v,np2v: 144 144 144
  EnergyFunctional: vft->np012(): 2985984
<wavefunction ecut="42.50000000" nspin="1" nel="512" nempty="0">
<cell a="23.460000 0.000000 0.000000"
      b="0.000000 23.460000 0.000000"
      c="0.000000 0.000000 23.460000"/>
 reciprocal lattice vectors
 0.267825 0.000000 0.000000
 0.000000 0.267825 0.000000
 0.000000 0.000000 0.267825
<refcell a="0.000000 0.000000 0.000000"
         b="0.000000 0.000000 0.000000"
         c="0.000000 0.000000 0.000000"/>
<grid nx="70" ny="70" nz="70"/>
 kpoint: 0.000000 0.000000 0.000000 weight: 1.000000
<slater_determinant kpoint="0.000000 0.000000 0.000000" size="256">
 sdcontext: 72x2
 basis size: 85355
 c dimensions: 87840x256   (1220x128 blocks)
 <density_matrix form="diagonal" size="256">
 </density_matrix>
</slater_determinant>
</wavefunction>
<iteration count="1">
  total_electronic_charge: 512.00000000
  <eigenvalue_sum>  -26.29725271 </eigenvalue_sum>
  <etotal_int>    -330.12932452 </etotal_int>
  total_electronic_charge: 512.00001978
  <eigenvalue_sum>  -113.86148672 </eigenvalue_sum>
  Anderson extrapolation: theta=-0.40947873 (-0.40947873)
  <etotal_int>    -560.13753971 </etotal_int>
  total_electronic_charge: 512.00000000
  <eigenvalue_sum>  -164.25973459 </eigenvalue_sum>
  Anderson extrapolation: theta=-0.31865356 (-0.31865356)
  <etotal_int>    -669.07991434 </etotal_int>
  total_electronic_charge: 512.00000000
  <eigenvalue_sum>  -192.68725980 </eigenvalue_sum>
  Anderson extrapolation: theta=-0.08153388 (-0.08153388)
  <etotal_int>    -779.69091738 </etotal_int>
  total_electronic_charge: 512.00000000
  <eigenvalue_sum>  -207.04962642 </eigenvalue_sum>
  Anderson extrapolation: theta=-0.19370112 (-0.19370112)
  <etotal_int>    -855.76279801 </etotal_int>
  total_electronic_charge: 512.00000000
  <eigenvalue_sum>  -207.93072821 </eigenvalue_sum>
  Anderson extrapolation: theta=-0.23165561 (-0.23165561)
  <etotal_int>    -903.00238081 </etotal_int>
  total_electronic_charge: 512.00000000
  <eigenvalue_sum>  -210.20165259 </eigenvalue_sum>
  Anderson extrapolation: theta=-0.01278540 (-0.01278540)
  <etotal_int>    -939.64150507 </etotal_int>
  total_electronic_charge: 512.00000000
  <eigenvalue_sum>  -206.26763047 </eigenvalue_sum>
  Anderson extrapolation: theta=0.23892900 (0.23892900)
  <etotal_int>    -973.70964074 </etotal_int>
  total_electronic_charge: 512.00000000
  <eigenvalue_sum>  -201.36193246 </eigenvalue_sum>
  Anderson extrapolation: theta=0.22420016 (0.22420016)
  <etotal_int>   -1005.08262719 </etotal_int>
  total_electronic_charge: 512.00000000
  <eigenvalue_sum>  -194.12920409 </eigenvalue_sum>
  Anderson extrapolation: theta=0.27150966 (0.27150966)
  <etotal_int>   -1027.75591567 </etotal_int>
  total_electronic_charge: 512.00000000
  <eigenvalue_sum>  -188.62192137 </eigenvalue_sum>
  Anderson extrapolation: theta=0.56017609 (0.56017609)
  <etotal_int>   -1044.13427945 </etotal_int>
  total_electronic_charge: 512.00000000
  <eigenvalue_sum>  -181.51915337 </eigenvalue_sum>
  Anderson extrapolation: theta=0.80651222 (0.80651222)
  <etotal_int>   -1058.33038809 </etotal_int>
  total_electronic_charge: 512.00000000
  <eigenvalue_sum>  -174.64956347 </eigenvalue_sum>
  Anderson extrapolation: theta=0.66261605 (0.66261605)
  <etotal_int>   -1070.26943710 </etotal_int>
  total_electronic_charge: 512.00000000
  <eigenvalue_sum>  -170.25467532 </eigenvalue_sum>
  Anderson extrapolation: theta=0.53604316 (0.53604316)
  <etotal_int>   -1077.66069165 </etotal_int>
  total_electronic_charge: 512.00000000
  <eigenvalue_sum>  -168.64947027 </eigenvalue_sum>
  Anderson extrapolation: theta=0.72341179 (0.72341179)
  <etotal_int>   -1082.03522519 </etotal_int>
  total_electronic_charge: 512.00000000
  <eigenvalue_sum>  -167.97090527 </eigenvalue_sum>
  Anderson extrapolation: theta=0.69963276 (0.69963276)
  <etotal_int>   -1085.66260836 </etotal_int>
  total_electronic_charge: 512.00000000
  <eigenvalue_sum>  -167.66875930 </eigenvalue_sum>
  Anderson extrapolation: theta=0.71960506 (0.71960506)
  <etotal_int>   -1088.54796747 </etotal_int>
  total_electronic_charge: 512.00000000
  <eigenvalue_sum>  -167.42689669 </eigenvalue_sum>
  Anderson extrapolation: theta=0.71080446 (0.71080446)
  <etotal_int>   -1090.86746665 </etotal_int>
  total_electronic_charge: 512.00000000
  <eigenvalue_sum>  -167.13689991 </eigenvalue_sum>
  Anderson extrapolation: theta=0.73763708 (0.73763708)
  <etotal_int>   -1092.70020002 </etotal_int>
  total_electronic_charge: 512.00000000
  <eigenvalue_sum>  -166.77905561 </eigenvalue_sum>
  Anderson extrapolation: theta=0.74537358 (0.74537358)
  <etotal_int>   -1094.18489801 </etotal_int>
  total_electronic_charge: 512.00000000
  <eigenvalue_sum>  -166.37305960 </eigenvalue_sum>
  Anderson extrapolation: theta=0.75464072 (0.75464072)
  <etotal_int>   -1095.38291504 </etotal_int>
  total_electronic_charge: 512.00000000
  <eigenvalue_sum>  -165.94592817 </eigenvalue_sum>
  Anderson extrapolation: theta=0.75577615 (0.75577615)
  <etotal_int>   -1096.34685773 </etotal_int>
  total_electronic_charge: 512.00000000
  <eigenvalue_sum>  -165.52600981 </eigenvalue_sum>
  Anderson extrapolation: theta=0.76606563 (0.76606563)
  <etotal_int>   -1097.11515325 </etotal_int>
  total_electronic_charge: 512.00000000
  <eigenvalue_sum>  -165.13412169 </eigenvalue_sum>
  Anderson extrapolation: theta=0.77505588 (0.77505588)
  <etotal_int>   -1097.72909020 </etotal_int>
  total_electronic_charge: 512.00000000
  <eigenvalue_sum>  -164.78555412 </eigenvalue_sum>
  Anderson extrapolation: theta=0.77821403 (0.77821403)
  <etotal_int>   -1098.21936412 </etotal_int>
  total_electronic_charge: 512.00000000
  <eigenvalue_sum>  -164.48732519 </eigenvalue_sum>
  Anderson extrapolation: theta=0.77441766 (0.77441766)
  <etotal_int>   -1098.60854083 </etotal_int>
  total_electronic_charge: 512.00000000
  <eigenvalue_sum>  -164.23735804 </eigenvalue_sum>
  Anderson extrapolation: theta=0.77222677 (0.77222677)
  <etotal_int>   -1098.91543253 </etotal_int>
  total_electronic_charge: 512.00000000
  <eigenvalue_sum>  -164.02655863 </eigenvalue_sum>
  Anderson extrapolation: theta=0.77031211 (0.77031211)
  <etotal_int>   -1099.15872731 </etotal_int>
  total_electronic_charge: 512.00000000
  <eigenvalue_sum>  -163.84446595 </eigenvalue_sum>
  Anderson extrapolation: theta=0.76463304 (0.76463304)
  <etotal_int>   -1099.35455679 </etotal_int>
  total_electronic_charge: 512.00000000
  <eigenvalue_sum>  -163.68206297 </eigenvalue_sum>
  Anderson extrapolation: theta=0.75588121 (0.75588121)
  <etotal_int>   -1099.51544969 </etotal_int>
  total_electronic_charge: 512.00000000
  <eigenvalue_sum>  -163.53240611 </eigenvalue_sum>
  Anderson extrapolation: theta=0.75017759 (0.75017759)
  <etotal_int>   -1099.65102376 </etotal_int>
  total_electronic_charge: 512.00000000
  <eigenvalue_sum>  -163.39072328 </eigenvalue_sum>
  Anderson extrapolation: theta=0.75578506 (0.75578506)
  <etotal_int>   -1099.76879445 </etotal_int>
  total_electronic_charge: 512.00000000
  <eigenvalue_sum>  -163.25408065 </eigenvalue_sum>
  Anderson extrapolation: theta=0.78604909 (0.78604909)
  <etotal_int>   -1099.87463807 </etotal_int>
  total_electronic_charge: 512.00000000
  <eigenvalue_sum>  -163.12009513 </eigenvalue_sum>
  Anderson extrapolation: theta=0.84615688 (0.84615688)
  <etotal_int>   -1099.97359204 </etotal_int>
  total_electronic_charge: 512.00000000
  <eigenvalue_sum>  -162.98695327 </eigenvalue_sum>
  Anderson extrapolation: theta=0.90629499 (0.90629499)
  <etotal_int>   -1100.06971089 </etotal_int>
  total_electronic_charge: 512.00000000
  <eigenvalue_sum>  -162.85743956 </eigenvalue_sum>
  Anderson extrapolation: theta=0.89867770 (0.89867770)
  <etotal_int>   -1100.16345780 </etotal_int>
  total_electronic_charge: 512.00000000
  <eigenvalue_sum>  -162.74316712 </eigenvalue_sum>
  Anderson extrapolation: theta=0.81393004 (0.81393004)
  <etotal_int>   -1100.24816036 </etotal_int>
  total_electronic_charge: 512.00000000
  <eigenvalue_sum>  -162.65373617 </eigenvalue_sum>
  Anderson extrapolation: theta=0.77474412 (0.77474412)
  <etotal_int>   -1100.31518111 </etotal_int>
  total_electronic_charge: 512.00000000
  <eigenvalue_sum>  -162.58312376 </eigenvalue_sum>
  Anderson extrapolation: theta=0.85459975 (0.85459975)
  <etotal_int>   -1100.36595714 </etotal_int>
  total_electronic_charge: 512.00000000
  <eigenvalue_sum>  -162.52283769 </eigenvalue_sum>
  Anderson extrapolation: theta=0.92848571 (0.92848571)
  <etotal_int>   -1100.40768560 </etotal_int>
  total_electronic_charge: 512.00000000
  <eigenvalue_sum>  -162.47413263 </eigenvalue_sum>
  Anderson extrapolation: theta=0.91638632 (0.91638632)
  <etotal_int>   -1100.44245527 </etotal_int>
  total_electronic_charge: 512.00000000
  <eigenvalue_sum>  -162.44163566 </eigenvalue_sum>
  Anderson extrapolation: theta=0.82668073 (0.82668073)
  <etotal_int>   -1100.46829825 </etotal_int>
  total_electronic_charge: 512.00000000
  <eigenvalue_sum>  -162.42237095 </eigenvalue_sum>
  Anderson extrapolation: theta=0.77253688 (0.77253688)
  <etotal_int>   -1100.48425561 </etotal_int>
  total_electronic_charge: 512.00000000
  <eigenvalue_sum>  -162.40748835 </eigenvalue_sum>
  Anderson extrapolation: theta=0.79964826 (0.79964826)
  <etotal_int>   -1100.49336791 </etotal_int>
  total_electronic_charge: 512.00000000
  <eigenvalue_sum>  -162.39323729 </eigenvalue_sum>
  Anderson extrapolation: theta=0.82196668 (0.82196668)
  <etotal_int>   -1100.49899839 </etotal_int>
  total_electronic_charge: 512.00000000
  <eigenvalue_sum>  -162.38001173 </eigenvalue_sum>
  Anderson extrapolation: theta=0.85625534 (0.85625534)
  <etotal_int>   -1100.50283210 </etotal_int>
  total_electronic_charge: 512.00000000
  <eigenvalue_sum>  -162.36874373 </eigenvalue_sum>
  Anderson extrapolation: theta=0.86227395 (0.86227395)
  <etotal_int>   -1100.50570342 </etotal_int>
  total_electronic_charge: 512.00000000
  <eigenvalue_sum>  -162.35984351 </eigenvalue_sum>
  Anderson extrapolation: theta=0.87521391 (0.87521391)
  <etotal_int>   -1100.50795889 </etotal_int>
  total_electronic_charge: 512.00000000
  <eigenvalue_sum>  -162.35302835 </eigenvalue_sum>
  Anderson extrapolation: theta=0.86310920 (0.86310920)
  <etotal_int>   -1100.50979291 </etotal_int>
  total_electronic_charge: 512.00000000
  <eigenvalue_sum>  -162.34788029 </eigenvalue_sum>
  Anderson extrapolation: theta=0.87161021 (0.87161021)
  <etotal_int>   -1100.51130924 </etotal_int>
  total_electronic_charge: 512.00000000
  <eigenvalue_sum>  -162.34394198 </eigenvalue_sum>
  Anderson extrapolation: theta=0.86981996 (0.86981996)
  <etotal_int>   -1100.51261295 </etotal_int>
  total_electronic_charge: 512.00000000
  <eigenvalue_sum>  -162.34095095 </eigenvalue_sum>
  Anderson extrapolation: theta=0.89377612 (0.89377612)
  <etotal_int>   -1100.51377067 </etotal_int>
  total_electronic_charge: 512.00000000
  <eigenvalue_sum>  -162.33870767 </eigenvalue_sum>
  Anderson extrapolation: theta=0.90237946 (0.90237946)
  <etotal_int>   -1100.51483746 </etotal_int>
  total_electronic_charge: 512.00000000
  <eigenvalue_sum>  -162.33709551 </eigenvalue_sum>
  Anderson extrapolation: theta=0.92529806 (0.92529806)
  <etotal_int>   -1100.51582563 </etotal_int>
  total_electronic_charge: 512.00000000
  <eigenvalue_sum>  -162.33599217 </eigenvalue_sum>
  Anderson extrapolation: theta=0.92212520 (0.92212520)
  <etotal_int>   -1100.51673921 </etotal_int>
  total_electronic_charge: 512.00000000
  <eigenvalue_sum>  -162.33528487 </eigenvalue_sum>
  Anderson extrapolation: theta=0.92769739 (0.92769739)
  <etotal_int>   -1100.51755699 </etotal_int>
  total_electronic_charge: 512.00000000
  <eigenvalue_sum>  -162.33485314 </eigenvalue_sum>
  Anderson extrapolation: theta=0.91010089 (0.91010089)
  <etotal_int>   -1100.51826854 </etotal_int>
  total_electronic_charge: 512.00000000
  <eigenvalue_sum>  -162.33457694 </eigenvalue_sum>
  Anderson extrapolation: theta=0.90723103 (0.90723103)
  <etotal_int>   -1100.51886143 </etotal_int>
  total_electronic_charge: 512.00000000
  <eigenvalue_sum>  -162.33436345 </eigenvalue_sum>
  Anderson extrapolation: theta=0.88972034 (0.88972034)
  <etotal_int>   -1100.51934372 </etotal_int>
  total_electronic_charge: 512.00000000
  <eigenvalue_sum>  -162.33414594 </eigenvalue_sum>
  Anderson extrapolation: theta=0.89006751 (0.89006751)
  <etotal_int>   -1100.51972567 </etotal_int>
  total_electronic_charge: 512.00000000
  <eigenvalue_sum>  -162.33390104 </eigenvalue_sum>
  Anderson extrapolation: theta=0.87690690 (0.87690690)
  <etotal_int>   -1100.52002701 </etotal_int>
  total_electronic_charge: 512.00000000
  <eigenvalue_sum>  -162.33362494 </eigenvalue_sum>
  Anderson extrapolation: theta=0.88076764 (0.88076764)
  <etotal_int>   -1100.52026331 </etotal_int>
  total_electronic_charge: 512.00000000
  <eigenvalue_sum>  -162.33333184 </eigenvalue_sum>
  Anderson extrapolation: theta=0.87142387 (0.87142387)
  <etotal_int>   -1100.52045144 </etotal_int>
  total_electronic_charge: 512.00000000
  <eigenvalue_sum>  -162.33303792 </eigenvalue_sum>
  Anderson extrapolation: theta=0.88044069 (0.88044069)
  <etotal_int>   -1100.52060324 </etotal_int>
  total_electronic_charge: 512.00000000
  <eigenvalue_sum>  -162.33275868 </eigenvalue_sum>
  Anderson extrapolation: theta=0.87727960 (0.87727960)
  <etotal_int>   -1100.52072970 </etotal_int>
  total_electronic_charge: 512.00000000
  <eigenvalue_sum>  -162.33250584 </eigenvalue_sum>
  Anderson extrapolation: theta=0.89269180 (0.89269180)
  <etotal_int>   -1100.52083759 </etotal_int>
  total_electronic_charge: 512.00000000
  <eigenvalue_sum>  -162.33228505 </eigenvalue_sum>
  Anderson extrapolation: theta=0.89374107 (0.89374107)
  <etotal_int>   -1100.52093257 </etotal_int>
  total_electronic_charge: 512.00000000
  <eigenvalue_sum>  -162.33209886 </eigenvalue_sum>
  Anderson extrapolation: theta=0.91048121 (0.91048121)
  <etotal_int>   -1100.52101720 </etotal_int>
  total_electronic_charge: 512.00000000
  <eigenvalue_sum>  -162.33194512 </eigenvalue_sum>
  Anderson extrapolation: theta=0.90906991 (0.90906991)
  <etotal_int>   -1100.52109359 </etotal_int>
  total_electronic_charge: 512.00000000
  <eigenvalue_sum>  -162.33182074 </eigenvalue_sum>
  Anderson extrapolation: theta=0.92061068 (0.92061068)
  <etotal_int>   -1100.52116194 </etotal_int>
  total_electronic_charge: 512.00000000
  <eigenvalue_sum>  -162.33172061 </eigenvalue_sum>
  Anderson extrapolation: theta=0.91274074 (0.91274074)
  <etotal_int>   -1100.52122278 </etotal_int>
  total_electronic_charge: 512.00000000
  <eigenvalue_sum>  -162.33163987 </eigenvalue_sum>
  Anderson extrapolation: theta=0.91771707 (0.91771707)
  <etotal_int>   -1100.52127574 </etotal_int>
  total_electronic_charge: 512.00000000
  <eigenvalue_sum>  -162.33157357 </eigenvalue_sum>
  Anderson extrapolation: theta=0.90510386 (0.90510386)
  <etotal_int>   -1100.52132123 </etotal_int>
  total_electronic_charge: 512.00000000
  <eigenvalue_sum>  -162.33151766 </eigenvalue_sum>
  Anderson extrapolation: theta=0.90684529 (0.90684529)
  <etotal_int>   -1100.52135934 </etotal_int>
  total_electronic_charge: 512.00000000
  <eigenvalue_sum>  -162.33146913 </eigenvalue_sum>
  Anderson extrapolation: theta=0.89348828 (0.89348828)
  <etotal_int>   -1100.52139094 </etotal_int>
  total_electronic_charge: 512.00000000
  <eigenvalue_sum>  -162.33142610 </eigenvalue_sum>
  Anderson extrapolation: theta=0.89594414 (0.89594414)
  <etotal_int>   -1100.52141671 </etotal_int>
  total_electronic_charge: 512.00000000
  <eigenvalue_sum>  -162.33138759 </eigenvalue_sum>
  Anderson extrapolation: theta=0.88505730 (0.88505730)
  <etotal_int>   -1100.52143774 </etotal_int>
  total_electronic_charge: 512.00000000
  <eigenvalue_sum>  -162.33135319 </eigenvalue_sum>
  Anderson extrapolation: theta=0.89099884 (0.89099884)
  <etotal_int>   -1100.52145487 </etotal_int>
  total_electronic_charge: 512.00000000
  <eigenvalue_sum>  -162.33132266 </eigenvalue_sum>
  Anderson extrapolation: theta=0.88424085 (0.88424085)
  <etotal_int>   -1100.52146904 </etotal_int>
  total_electronic_charge: 512.00000000
  <eigenvalue_sum>  -162.33129573 </eigenvalue_sum>
  Anderson extrapolation: theta=0.89445165 (0.89445165)
  <etotal_int>   -1100.52148088 </etotal_int>
  total_electronic_charge: 512.00000000
  <eigenvalue_sum>  -162.33127188 </eigenvalue_sum>
  Anderson extrapolation: theta=0.89112664 (0.89112664)
  <etotal_int>   -1100.52149099 </etotal_int>
  total_electronic_charge: 512.00000000
  <eigenvalue_sum>  -162.33125051 </eigenvalue_sum>
  Anderson extrapolation: theta=0.90375500 (0.90375500)
  <etotal_int>   -1100.52149974 </etotal_int>
  total_electronic_charge: 512.00000000
  <eigenvalue_sum>  -162.33123082 </eigenvalue_sum>
  Anderson extrapolation: theta=0.90104202 (0.90104202)
  <etotal_int>   -1100.52150742 </etotal_int>
  total_electronic_charge: 512.00000000
  <eigenvalue_sum>  -162.33121216 </eigenvalue_sum>
  Anderson extrapolation: theta=0.91281102 (0.91281102)
  <etotal_int>   -1100.52151419 </etotal_int>
  total_electronic_charge: 512.00000000
  <eigenvalue_sum>  -162.33119390 </eigenvalue_sum>
  Anderson extrapolation: theta=0.90781033 (0.90781033)
  <etotal_int>   -1100.52152019 </etotal_int>
  total_electronic_charge: 512.00000000
  <eigenvalue_sum>  -162.33117576 </eigenvalue_sum>
  Anderson extrapolation: theta=0.91640725 (0.91640725)
  <etotal_int>   -1100.52152547 </etotal_int>
  total_electronic_charge: 512.00000000
  <eigenvalue_sum>  -162.33115757 </eigenvalue_sum>
  Anderson extrapolation: theta=0.90809989 (0.90809989)
  <etotal_int>   -1100.52153009 </etotal_int>
  total_electronic_charge: 512.00000000
  <eigenvalue_sum>  -162.33113960 </eigenvalue_sum>
  Anderson extrapolation: theta=0.91349062 (0.91349062)
  <etotal_int>   -1100.52153409 </etotal_int>
  total_electronic_charge: 512.00000000
  <eigenvalue_sum>  -162.33112216 </eigenvalue_sum>
  Anderson extrapolation: theta=0.90297331 (0.90297331)
  <etotal_int>   -1100.52153753 </etotal_int>
  total_electronic_charge: 512.00000000
  <eigenvalue_sum>  -162.33110591 </eigenvalue_sum>
  Anderson extrapolation: theta=0.90691985 (0.90691985)
  <etotal_int>   -1100.52154044 </etotal_int>
  total_electronic_charge: 512.00000000
  <eigenvalue_sum>  -162.33109139 </eigenvalue_sum>
  Anderson extrapolation: theta=0.89632299 (0.89632299)
  <etotal_int>   -1100.52154289 </etotal_int>
  total_electronic_charge: 512.00000000
  <eigenvalue_sum>  -162.33107927 </eigenvalue_sum>
  Anderson extrapolation: theta=0.90107121 (0.90107121)
  <etotal_int>   -1100.52154493 </etotal_int>
  total_electronic_charge: 512.00000000
  <eigenvalue_sum>  -162.33106995 </eigenvalue_sum>
  Anderson extrapolation: theta=0.89225924 (0.89225924)
  <etotal_int>   -1100.52154664 </etotal_int>
  total_electronic_charge: 512.00000000
  <eigenvalue_sum>  -162.33106378 </eigenvalue_sum>
  Anderson extrapolation: theta=0.89929604 (0.89929604)
  <etotal_int>   -1100.52154806 </etotal_int>
  total_electronic_charge: 512.00000000
  <eigenvalue_sum>  -162.33106081 </eigenvalue_sum>
  Anderson extrapolation: theta=0.89292077 (0.89292077)
  <etotal_int>   -1100.52154926 </etotal_int>
  total_electronic_charge: 512.00000000
  <eigenvalue_sum>  -162.33106095 </eigenvalue_sum>
  Anderson extrapolation: theta=0.90225411 (0.90225411)
  <etotal_int>   -1100.52155027 </etotal_int>
  total_electronic_charge: 512.00000000
  <eigenvalue_sum>  -162.33106389 </eigenvalue_sum>
  Anderson extrapolation: theta=0.89751012 (0.89751012)
  <etotal_int>   -1100.52155114 </etotal_int>
  total_electronic_charge: 512.00000000
  <eigenvalue_sum>  -162.33106920 </eigenvalue_sum>
  Anderson extrapolation: theta=0.90780042 (0.90780042)
  <etotal_int>   -1100.52155189 </etotal_int>
  total_electronic_charge: 512.00000000
  <eigenvalue_sum>  -162.33107636 </eigenvalue_sum>
  Anderson extrapolation: theta=0.90302131 (0.90302131)
  <etotal_int>   -1100.52155255 </etotal_int>
  total_electronic_charge: 512.00000000
  <eigenvalue_sum>  -162.33108474 </eigenvalue_sum>
  Anderson extrapolation: theta=0.91249551 (0.91249551)
  <etotal_int>   -1100.52155312 </etotal_int>
  total_electronic_charge: 512.00000000
  <eigenvalue_sum>  -162.33109377 </eigenvalue_sum>
  Anderson extrapolation: theta=0.90623466 (0.90623466)
  <etotal_int>   -1100.52155362 </etotal_int>
  total_electronic_charge: 512.00000000
  <eigenvalue_sum>  -162.33110279 </eigenvalue_sum>
  Anderson extrapolation: theta=0.91381332 (0.91381332)
  <etotal_int>   -1100.52155406 </etotal_int>
  total_electronic_charge: 512.00000000
  <eigenvalue_sum>  -162.33111130 </eigenvalue_sum>
  Anderson extrapolation: theta=0.90571962 (0.90571962)
  <etotal_int>   -1100.52155444 </etotal_int>
  total_electronic_charge: 512.00000000
  <eigenvalue_sum>  -162.33111878 </eigenvalue_sum>
  Anderson extrapolation: theta=0.91161998 (0.91161998)
  <etotal_int>   -1100.52155477 </etotal_int>
  total_electronic_charge: 512.00000000
  <eigenvalue_sum>  -162.33112493 </eigenvalue_sum>
  Anderson extrapolation: theta=0.90253287 (0.90253287)
  <etotal_int>   -1100.52155506 </etotal_int>
  total_electronic_charge: 512.00000000
  <eigenvalue_sum>  -162.33112945 </eigenvalue_sum>
  Anderson extrapolation: theta=0.90796225 (0.90796225)
  <etotal_int>   -1100.52155531 </etotal_int>
  total_electronic_charge: 512.00000000
  <eigenvalue_sum>  -162.33113230 </eigenvalue_sum>
  Anderson extrapolation: theta=0.89920917 (0.89920917)
  <etotal_int>   -1100.52155551 </etotal_int>
  total_electronic_charge: 512.00000000
  <eigenvalue_sum>  -162.33113346 </eigenvalue_sum>
  Anderson extrapolation: theta=0.90544129 (0.90544129)
  <etotal_int>   -1100.52155569 </etotal_int>
  total_electronic_charge: 512.00000000
  <eigenvalue_sum>  -162.33113305 </eigenvalue_sum>
  Anderson extrapolation: theta=0.89790777 (0.89790777)
  <etotal_int>   -1100.52155584 </etotal_int>
  total_electronic_charge: 512.00000000
  <eigenvalue_sum>  -162.33113128 </eigenvalue_sum>
  Anderson extrapolation: theta=0.90545598 (0.90545598)
  <etotal_int>   -1100.52155596 </etotal_int>
  total_electronic_charge: 512.00000000
  <eigenvalue_sum>  -162.33112839 </eigenvalue_sum>
  Anderson extrapolation: theta=0.89909428 (0.89909428)
  <etotal_int>   -1100.52155607 </etotal_int>
  total_electronic_charge: 512.00000000
  <eigenvalue_sum>  -162.33112465 </eigenvalue_sum>
  Anderson extrapolation: theta=0.90752500 (0.90752500)
  <etotal_int>   -1100.52155616 </etotal_int>
  total_electronic_charge: 512.00000000
  <eigenvalue_sum>  -162.33112033 </eigenvalue_sum>
  Anderson extrapolation: theta=0.90156667 (0.90156667)
  <etotal_int>   -1100.52155624 </etotal_int>
  total_electronic_charge: 512.00000000
  <eigenvalue_sum>  -162.33111572 </eigenvalue_sum>
  Anderson extrapolation: theta=0.90998217 (0.90998217)
  <etotal_int>   -1100.52155631 </etotal_int>
  total_electronic_charge: 512.00000000
  <eigenvalue_sum>  -162.33111105 </eigenvalue_sum>
  Anderson extrapolation: theta=0.90360891 (0.90360891)
  <etotal_int>   -1100.52155637 </etotal_int>
  total_electronic_charge: 512.00000000
  <eigenvalue_sum>  -162.33110656 </eigenvalue_sum>
  Anderson extrapolation: theta=0.91136805 (0.91136805)
  <etotal_int>   -1100.52155642 </etotal_int>
  total_electronic_charge: 512.00000000
  <eigenvalue_sum>  -162.33110240 </eigenvalue_sum>
  Anderson extrapolation: theta=0.90429427 (0.90429427)
  <etotal_int>   -1100.52155646 </etotal_int>
  total_electronic_charge: 512.00000000
  <eigenvalue_sum>  -162.33109876 </eigenvalue_sum>
  Anderson extrapolation: theta=0.91139765 (0.91139765)
  <etotal_int>   -1100.52155650 </etotal_int>
  total_electronic_charge: 512.00000000
  <eigenvalue_sum>  -162.33109571 </eigenvalue_sum>
  Anderson extrapolation: theta=0.90392449 (0.90392449)
  <etotal_int>   -1100.52155654 </etotal_int>
  total_electronic_charge: 512.00000000
  <eigenvalue_sum>  -162.33109334 </eigenvalue_sum>
  Anderson extrapolation: theta=0.91080859 (0.91080859)
  <etotal_int>   -1100.52155656 </etotal_int>
  total_electronic_charge: 512.00000000
  <eigenvalue_sum>  -162.33109165 </eigenvalue_sum>
  Anderson extrapolation: theta=0.90339435 (0.90339435)
  <etotal_int>   -1100.52155659 </etotal_int>
  total_electronic_charge: 512.00000000
  <eigenvalue_sum>  -162.33109066 </eigenvalue_sum>
  Anderson extrapolation: theta=0.91042129 (0.91042129)
  <etotal_int>   -1100.52155661 </etotal_int>
  total_electronic_charge: 512.00000000
  <eigenvalue_sum>  -162.33109030 </eigenvalue_sum>
  Anderson extrapolation: theta=0.90323525 (0.90323525)
  <etotal_int>   -1100.52155663 </etotal_int>
  total_electronic_charge: 512.00000000
  <eigenvalue_sum>  -162.33109053 </eigenvalue_sum>
  Anderson extrapolation: theta=0.91039561 (0.91039561)
  <etotal_int>   -1100.52155665 </etotal_int>
  total_electronic_charge: 512.00000000
  <eigenvalue_sum>  -162.33109125 </eigenvalue_sum>
  Anderson extrapolation: theta=0.90326530 (0.90326530)
  <etotal_int>   -1100.52155666 </etotal_int>
  total_electronic_charge: 512.00000000
  <eigenvalue_sum>  -162.33109237 </eigenvalue_sum>
  Anderson extrapolation: theta=0.91033129 (0.91033129)
  <etotal_int>   -1100.52155667 </etotal_int>
  total_electronic_charge: 512.00000000
  <eigenvalue_sum>  -162.33109379 </eigenvalue_sum>
  Anderson extrapolation: theta=0.90306205 (0.90306205)
  <etotal_int>   -1100.52155668 </etotal_int>
  total_electronic_charge: 512.00000000
  <eigenvalue_sum>  -162.33109541 </eigenvalue_sum>
  Anderson extrapolation: theta=0.90996176 (0.90996176)
  <etotal_int>   -1100.52155669 </etotal_int>
  total_electronic_charge: 512.00000000
  <eigenvalue_sum>  -162.33109713 </eigenvalue_sum>
  Anderson extrapolation: theta=0.90264383 (0.90264383)
  <etotal_int>   -1100.52155670 </etotal_int>
  total_electronic_charge: 512.00000000
  <eigenvalue_sum>  -162.33109885 </eigenvalue_sum>
  Anderson extrapolation: theta=0.90962419 (0.90962419)
  <etotal_int>   -1100.52155670 </etotal_int>
  total_electronic_charge: 512.00000000
  <eigenvalue_sum>  -162.33110051 </eigenvalue_sum>
  Anderson extrapolation: theta=0.90258321 (0.90258321)
  <etotal_int>   -1100.52155671 </etotal_int>
  total_electronic_charge: 512.00000000
  <eigenvalue_sum>  -162.33110202 </eigenvalue_sum>
  Anderson extrapolation: theta=0.90997444 (0.90997444)
  <etotal_int>   -1100.52155671 </etotal_int>
  total_electronic_charge: 512.00000000
  <eigenvalue_sum>  -162.33110335 </eigenvalue_sum>
  Anderson extrapolation: theta=0.90341323 (0.90341323)
  <etotal_int>   -1100.52155672 </etotal_int>
  total_electronic_charge: 512.00000000
  <ekin>       807.89218588 </ekin>
  <econf>        0.00000000 </econf>
  <eps>      -1308.33345983 </eps>
  <enl>        124.89965807 </enl>
  <ecoul>     -454.10204859 </ecoul>
  <exc>       -270.87789225 </exc>
  <esr>         92.85158837 </esr>
  <eself>      646.81841729 </eself>
  <ets>          0.00000000 </ets>
  <eexf>         0.00000000 </eexf>
  <etotal>   -1100.52155672 </etotal>
  <epv>          0.00000000 </epv>
  <eefield>      0.00000000 </eefield>
  <enthalpy> -1100.52155672 </enthalpy>
<atomset>
<unit_cell 
    a=" 23.46000000   0.00000000   0.00000000"
    b="  0.00000000  23.46000000   0.00000000"
    c="  0.00000000   0.00000000  23.46000000" />
  <atom name="O1" species="oxygen">
    <position> -6.48337908 6.01757097 12.37774040 </position>
    <velocity> -0.00018626 -0.00020031 0.00028804 </velocity>
    <force> 0.04230527 -0.00186082 0.01796086 </force>
  </atom>
  <atom name="O2" species="oxygen">
    <position> 23.13620027 2.61155301 25.49658173 </position>
    <velocity> -0.00000852 0.00006359 -0.00023066 </velocity>
    <force> 0.00297044 -0.00978401 0.01889566 </force>
  </atom>
  <atom name="O3" species="oxygen">
    <position> -28.79530384 23.73288427 -33.09468503 </position>
    <velocity> -0.00018165 0.00012688 -0.00011929 </velocity>
    <force> 0.03093720 0.00488675 -0.02167258 </force>
  </atom>
  <atom name="O4" species="oxygen">
    <position> 13.16352729 -9.21037044 -0.60382285 </position>
    <velocity> 0.00007618 -0.00022711 0.00007599 </velocity>
    <force> 0.00608149 -0.01569617 0.03031434 </force>
  </atom>
  <atom name="O5" species="oxygen">
    <position> 6.66609866 -22.47163884 -5.68002479 </position>
    <velocity> 0.00027201 -0.00000949 -0.00049678 </velocity>
    <force> -0.00322111 0.02296236 0.01745667 </force>
  </atom>
  <atom name="O6" species="oxygen">
    <position> 8.01875291 16.93359926 5.23223206 </position>
    <velocity> 0.00009179 -0.00023123 0.00036264 </velocity>
    <force> 0.00133517 0.00409385 -0.00858716 </force>
  </atom>
  <atom name="O7" species="oxygen">
    <position> -4.61485622 -29.13618554 -18.04026819 </position>
    <velocity> -0.00001565 0.00043375 -0.00028638 </velocity>
    <force> -0.00497993 0.03989147 -0.00012529 </force>
  </atom>
  <atom name="O8" species="oxygen">
    <position> 2.78492012 -14.69141749 13.53605350 </position>
    <velocity> -0.00007130 -0.00043688 0.00022492 </velocity>
    <force> 0.00968166 -0.00163967 -0.01704547 </force>
  </atom>
  <atom name="O9" species="oxygen">
    <position> 2.61394758 4.40059778 -6.43900309 </position>
    <velocity> -0.00032157 -0.00002571 -0.00039207 </velocity>
    <force> 0.01329824 0.00850532 -0.00094773 </force>
  </atom>
  <atom name="O10" species="oxygen">
    <position> 0.40775540 7.98484209 8.11656754 </position>
    <velocity> 0.00015325 0.00024751 0.00020699 </velocity>
    <force> -0.01442013 0.03333931 0.00703983 </force>
  </atom>
  <atom name="O11" species="oxygen">
    <position> 13.17840362 -14.44054701 10.99567824 </position>
    <velocity> -0.00006651 0.00010000 0.00000287 </velocity>
    <force> 0.00042492 -0.00580589 -0.01150981 </force>
  </atom>
  <atom name="O12" species="oxygen">
    <position> -13.19795332 -2.55545972 13.06971282 </position>
    <velocity> 0.00027796 -0.00012941 -0.00010469 </velocity>
    <force> -0.01776085 -0.02255012 -0.02693816 </force>
  </atom>
  <atom name="O13" species="oxygen">
    <position> 2.32510797 -9.79822461 -21.54192141 </position>
    <velocity> -0.00010638 0.00039477 0.00012161 </velocity>
    <force> -0.01118932 -0.00917834 0.00754324 </force>
  </atom>
  <atom name="O14" species="oxygen">
    <position> -5.30059909 -9.16828243 -2.45729976 </position>
    <velocity> -0.00018228 0.00002969 -0.00033938 </velocity>
    <force> 0.01361293 0.01201255 0.00661317 </force>
  </atom>
  <atom name="O15" species="oxygen">
    <position> 13.31859014 -11.98842145 4.14310527 </position>
    <velocity> -0.00049884 -0.00028788 0.00021702 </velocity>
    <force> 0.00927929 -0.01008965 -0.01905283 </force>
  </atom>
  <atom name="O16" species="oxygen">
    <position> -6.98789469 9.49975207 -7.01876185 </position>
    <velocity> -0.00006689 0.00025139 -0.00007766 </velocity>
    <force> 0.00992048 -0.01611408 -0.00033732 </force>
  </atom>
  <atom name="O17" species="oxygen">
    <position> -13.79139500 -14.61687960 -27.73505694 </position>
    <velocity> -0.00000053 0.00010530 0.00021683 </velocity>
    <force> -0.01056616 0.01031505 -0.01529449 </force>
  </atom>
  <atom name="O18" species="oxygen">
    <position> -19.92421666 -2.75646034 14.85311542 </position>
    <velocity> -0.00020692 -0.00014864 0.00011536 </velocity>
    <force> -0.01679677 0.00440912 0.00485475 </force>
  </atom>
  <atom name="O19" species="oxygen">
    <position> 7.38139414 -16.22328712 0.19736442 </position>
    <velocity> -0.00035119 -0.00035204 0.00005071 </velocity>
    <force> 0.01364636 0.00732001 -0.00273055 </force>
  </atom>
  <atom name="O20" species="oxygen">
    <position> 5.89714230 17.68761400 -22.94967014 </position>
    <velocity> 0.00008105 -0.00013530 -0.00001100 </velocity>
    <force> -0.01021097 0.01253314 0.00453496 </force>
  </atom>
  <atom name="O21" species="oxygen">
    <position> 2.46316311 1.82036862 12.74557389 </position>
    <velocity> -0.00020684 0.00029185 -0.00013774 </velocity>
    <force> -0.00091713 -0.00011931 0.01238321 </force>
  </atom>
  <atom name="O22" species="oxygen">
    <position> -9.90361701 -4.95177700 2.29604219 </position>
    <velocity> 0.00033193 0.00010942 -0.00030831 </velocity>
    <force> -0.02294082 -0.01307199 -0.03022479 </force>
  </atom>
  <atom name="O23" species="oxygen">
    <position> -13.81353707 -10.70559375 7.67834275 </position>
    <velocity> 0.00015296 0.00000252 -0.00036292 </velocity>
    <force> -0.00173571 0.01596184 -0.00894305 </force>
  </atom>
  <atom name="O24" species="oxygen">
    <position> 18.58913749 -13.36809869 4.52489240 </position>
    <velocity> 0.00035211 -0.00015072 -0.00004291 </velocity>
    <force> -0.01479890 0.00766376 -0.01356601 </force>
  </atom>
  <atom name="O25" species="oxygen">
    <position> 20.48569855 14.38870676 2.07716713 </position>
    <velocity> 0.00003420 -0.00049658 -0.00044290 </velocity>
    <force> -0.01004334 -0.00837744 0.00105704 </force>
  </atom>
  <atom name="O26" species="oxygen">
    <position> 6.68722761 13.02072680 -30.12532703 </position>
    <velocity> -0.00001791 0.00019979 0.00016304 </velocity>
    <force> 0.01293985 0.01504538 -0.00891683 </force>
  </atom>
  <atom name="O27" species="oxygen">
    <position> 12.81727313 -21.72429916 -10.28086853 </position>
    <velocity> 0.00010093 -0.00027268 0.00013013 </velocity>
    <force> 0.04729534 -0.00847667 -0.00544593 </force>
  </atom>
  <atom name="O28" species="oxygen">
    <position> 10.66103836 3.70706566 -14.52621439 </position>
    <velocity> 0.00006731 0.00033141 -0.00025626 </velocity>
    <force> 0.01406838 -0.00242690 0.01992928 </force>
  </atom>
  <atom name="O29" species="oxygen">
    <position> -4.81856258 6.48017453 -3.65040043 </position>
    <velocity> 0.00005855 -0.00005019 0.00018356 </velocity>
    <force> -0.03601696 -0.01751665 -0.02446145 </force>
  </atom>
  <atom name="O30" species="oxygen">
    <position> -10.80303056 -0.60212400 22.05932398 </position>
    <velocity> 0.00033800 0.00005618 -0.00014052 </velocity>
    <force> 0.01821376 0.03453104 -0.00729572 </force>
  </atom>
  <atom name="O31" species="oxygen">
    <position> 4.41605858 -1.01635028 0.91257900 </position>
    <velocity> 0.00018235 0.00004108 0.00025551 </velocity>
    <force> -0.02569830 -0.01886161 0.02296565 </force>
  </atom>
  <atom name="O32" species="oxygen">
    <position> 22.69748710 -0.71004283 -1.96930837 </position>
    <velocity> -0.00010054 0.00005055 0.00037268 </velocity>
    <force> 0.00512137 0.02628567 0.05544265 </force>
  </atom>
  <atom name="O33" species="oxygen">
    <position> -1.15007142 23.06255209 9.74205238 </position>
    <velocity> 0.00001609 0.00012439 0.00005821 </velocity>
    <force> -0.06012347 -0.01736230 -0.04454549 </force>
  </atom>
  <atom name="O34" species="oxygen">
    <position> -13.41851173 -2.82191889 18.12783535 </position>
    <velocity> -0.00026696 0.00004178 0.00015451 </velocity>
    <force> -0.00049709 -0.01144834 -0.00454004 </force>
  </atom>
  <atom name="O35" species="oxygen">
    <position> 4.05007591 -2.42035208 -17.77633502 </position>
    <velocity> -0.00001804 -0.00009302 0.00004897 </velocity>
    <force> 0.02674747 0.00140924 0.06225211 </force>
  </atom>
  <atom name="O36" species="oxygen">
    <position> 7.54178722 6.72558992 -40.39453176 </position>
    <velocity> -0.00035241 -0.00007099 -0.00007025 </velocity>
    <force> 0.00275044 0.02040290 -0.00707475 </force>
  </atom>
  <atom name="O37" species="oxygen">
    <position> -10.78855453 -1.22034715 5.74284370 </position>
    <velocity> -0.00027409 0.00005169 0.00001517 </velocity>
    <force> 0.00341876 -0.02718880 -0.00937197 </force>
  </atom>
  <atom name="O38" species="oxygen">
    <position> 1.47903850 11.74909104 17.40097322 </position>
    <velocity> -0.00015906 0.00013073 0.00011325 </velocity>
    <force> 0.01554516 -0.01301166 0.00349242 </force>
  </atom>
  <atom name="O39" species="oxygen">
    <position> 7.69059164 9.92671767 -11.65453590 </position>
    <velocity> 0.00017031 0.00006109 0.00006728 </velocity>
    <force> -0.00735903 -0.01362754 -0.00236965 </force>
  </atom>
  <atom name="O40" species="oxygen">
    <position> -16.38066533 -7.53270112 12.47868118 </position>
    <velocity> 0.00037297 0.00023394 0.00013230 </velocity>
    <force> 0.01211138 0.01645051 0.00988764 </force>
  </atom>
  <atom name="O41" species="oxygen">
    <position> 14.22221123 4.03353796 -2.29022304 </position>
    <velocity> -0.00015833 0.00008894 0.00014509 </velocity>
    <force> 0.03275897 0.00391967 0.00193627 </force>
  </atom>
  <atom name="O42" species="oxygen">
    <position> -9.68549415 16.85604700 16.00473905 </position>
    <velocity> -0.00014806 -0.00007353 0.00021483 </velocity>
    <force> -0.01264801 -0.01174486 -0.00094603 </force>
  </atom>
  <atom name="O43" species="oxygen">
    <position> -5.15430331 -4.69429230 -8.35319749 </position>
    <velocity> 0.00001299 0.00019975 -0.00014625 </velocity>
    <force> 0.00171697 -0.03292398 0.00685563 </force>
  </atom>
  <atom name="O44" species="oxygen">
    <position> -11.06340740 -11.35184974 15.71345993 </position>
    <velocity> -0.00017955 0.00031798 0.00033635 </velocity>
    <force> 0.02205051 0.01822790 -0.03544188 </force>
  </atom>
  <atom name="O45" species="oxygen">
    <position> -7.57465605 26.43728094 4.59889070 </position>
    <velocity> 0.00037902 -0.00028111 -0.00048220 </velocity>
    <force> 0.01836271 0.01269886 0.02874386 </force>
  </atom>
  <atom name="O46" species="oxygen">
    <position> 12.87827708 -5.28482258 -14.60822266 </position>
    <velocity> -0.00038806 -0.00010446 0.00016424 </velocity>
    <force> 0.00084807 -0.02032025 0.05071617 </force>
  </atom>
  <atom name="O47" species="oxygen">
    <position> -3.74089534 -0.89664731 3.38569457 </position>
    <velocity> 0.00036579 -0.00023889 -0.00027776 </velocity>
    <force> 0.03930636 -0.03393635 0.00278830 </force>
  </atom>
  <atom name="O48" species="oxygen">
    <position> -20.14280677 -18.80013515 -17.70249944 </position>
    <velocity> -0.00012395 0.00026479 0.00009351 </velocity>
    <force> -0.01371370 -0.02741189 -0.00898858 </force>
  </atom>
  <atom name="O49" species="oxygen">
    <position> -39.01876685 2.28943452 -24.17094618 </position>
    <velocity> -0.00017543 0.00029185 -0.00011293 </velocity>
    <force> 0.00118381 0.00841048 0.00341623 </force>
  </atom>
  <atom name="O50" species="oxygen">
    <position> 32.37097510 16.01546964 -3.14319745 </position>
    <velocity> 0.00009554 -0.00009792 -0.00011087 </velocity>
    <force> -0.00447936 0.01586785 -0.02045003 </force>
  </atom>
  <atom name="O51" species="oxygen">
    <position> 11.41950774 4.03963238 -6.13532490 </position>
    <velocity> -0.00027745 -0.00013783 0.00003076 </velocity>
    <force> 0.03161195 0.02309991 0.01045205 </force>
  </atom>
  <atom name="O52" species="oxygen">
    <position> -2.00726609 2.73881292 18.12641735 </position>
    <velocity> 0.00009723 -0.00028508 0.00009961 </velocity>
    <force> 0.00305611 -0.00633344 -0.02044014 </force>
  </atom>
  <atom name="O53" species="oxygen">
    <position> 19.90791953 -10.34381207 -6.94163309 </position>
    <velocity> 0.00004223 0.00030052 -0.00023282 </velocity>
    <force> 0.01460175 0.02789222 -0.04332127 </force>
  </atom>
  <atom name="O54" species="oxygen">
    <position> 0.07293669 -8.55813391 12.56383693 </position>
    <velocity> -0.00023401 -0.00002456 -0.00019448 </velocity>
    <force> -0.03177198 -0.01809270 0.01545528 </force>
  </atom>
  <atom name="O55" species="oxygen">
    <position> 18.01942075 -3.35004874 -0.57174591 </position>
    <velocity> 0.00000293 -0.00010904 -0.00000677 </velocity>
    <force> -0.01131646 -0.00330073 0.01267794 </force>
  </atom>
  <atom name="O56" species="oxygen">
    <position> 23.49990051 -5.35547828 17.34451837 </position>
    <velocity> 0.00026962 -0.00031541 0.00000800 </velocity>
    <force> 0.00272965 0.00937544 0.00439193 </force>
  </atom>
  <atom name="O57" species="oxygen">
    <position> 2.67738475 32.49137080 -24.49757479 </position>
    <velocity> 0.00008795 -0.00017993 0.00007550 </velocity>
    <force> 0.01363804 0.03335798 0.00251759 </force>
  </atom>
  <atom name="O58" species="oxygen">
    <position> 5.18902487 1.41220069 -14.61484799 </position>
    <velocity> -0.00016095 0.00007984 0.00011208 </velocity>
    <force> 0.05347889 0.01260764 0.01828849 </force>
  </atom>
  <atom name="O59" species="oxygen">
    <position> -2.11586701 -15.85396428 -22.91990179 </position>
    <velocity> 0.00019782 -0.00012659 -0.00002937 </velocity>
    <force> -0.02090373 0.05310878 -0.02172608 </force>
  </atom>
  <atom name="O60" species="oxygen">
    <position> -27.36656162 -13.21227906 10.47519120 </position>
    <velocity> -0.00023023 -0.00021802 0.00005182 </velocity>
    <force> -0.02031223 0.01186683 -0.00248667 </force>
  </atom>
  <atom name="O61" species="oxygen">
    <position> -3.86617346 4.42003900 -15.45610732 </position>
    <velocity> -0.00016347 0.00014160 -0.00031048 </velocity>
    <force> 0.00002080 -0.00682990 0.01592884 </force>
  </atom>
  <atom name="O62" species="oxygen">
    <position> -6.02892743 -7.12590651 33.47308208 </position>
    <velocity> 0.00022958 -0.00012832 -0.00006150 </velocity>
    <force> -0.02870398 -0.02912893 -0.00210599 </force>
  </atom>
  <atom name="O63" species="oxygen">
    <position> -20.88273593 -8.14238763 31.67424996 </position>
    <velocity> -0.00028552 0.00003562 0.00025271 </velocity>
    <force> 0.00512686 0.01096918 0.00142042 </force>
  </atom>
  <atom name="O64" species="oxygen">
    <position> 12.28394914 6.56642081 25.70189546 </position>
    <velocity> 0.00029154 -0.00003579 0.00033402 </velocity>
    <force> -0.01013617 -0.00712484 -0.01044354 </force>
  </atom>
  <atom name="H1" species="hydrogen">
    <position> -5.91447931 7.18957751 13.81423572 </position>
    <velocity> -0.00024140 0.00072771 0.00044863 </velocity>
    <force> -0.02091733 -0.01718303 -0.01846290 </force>
  </atom>
  <atom name="H2" species="hydrogen">
    <position> -8.14493074 6.55296185 11.86788898 </position>
    <velocity> 0.00064690 -0.00073089 0.00044222 </velocity>
    <force> -0.01783385 0.01373661 0.00223905 </force>
  </atom>
  <atom name="H3" species="hydrogen">
    <position> 24.65643943 2.70115163 26.58544242 </position>
    <velocity> 0.00075463 0.00056977 -0.00079308 </velocity>
    <force> -0.00455237 0.01003012 -0.00518775 </force>
  </atom>
  <atom name="H4" species="hydrogen">
    <position> 22.03898946 1.40094598 26.47816242 </position>
    <velocity> -0.00065831 0.00014518 -0.00019044 </velocity>
    <force> 0.00101790 0.00721177 -0.01368078 </force>
  </atom>
  <atom name="H5" species="hydrogen">
    <position> -27.57462232 24.54186544 -31.89121949 </position>
    <velocity> -0.00074327 -0.00078928 0.00051190 </velocity>
    <force> -0.01091461 -0.00248083 -0.00115256 </force>
  </atom>
  <atom name="H6" species="hydrogen">
    <position> -27.79753272 23.84455906 -34.73322301 </position>
    <velocity> -0.00019825 -0.00018837 0.00062626 </velocity>
    <force> -0.01361053 -0.00413340 0.02107693 </force>
  </atom>
  <atom name="H7" species="hydrogen">
    <position> 12.64884566 -10.31410854 0.93678639 </position>
    <velocity> -0.00038598 -0.00010662 0.00136083 </velocity>
    <force> 0.00725053 0.01927419 -0.03003764 </force>
  </atom>
  <atom name="H8" species="hydrogen">
    <position> 11.72930182 -8.79258066 -1.71155072 </position>
    <velocity> 0.00015667 0.00034373 -0.00030316 </velocity>
    <force> -0.01284944 -0.00292024 0.00341007 </force>
  </atom>
  <atom name="H9" species="hydrogen">
    <position> 5.48562314 -21.02770733 -6.16489387 </position>
    <velocity> 0.00033679 -0.00034083 0.00016348 </velocity>
    <force> 0.00698271 -0.01834066 0.01021129 </force>
  </atom>
  <atom name="H10" species="hydrogen">
    <position> 6.92493700 -22.22960865 -3.78607531 </position>
    <velocity> 0.00021459 -0.00060907 0.00088114 </velocity>
    <force> -0.00721471 0.00561611 -0.01876836 </force>
  </atom>
  <atom name="H11" species="hydrogen">
    <position> 7.16520394 17.02103776 3.51240924 </position>
    <velocity> -0.00038590 0.00055522 -0.00085378 </velocity>
    <force> 0.01003194 0.00250726 0.00233534 </force>
  </atom>
  <atom name="H12" species="hydrogen">
    <position> 9.69143156 17.76257175 5.01240802 </position>
    <velocity> -0.00086278 0.00003916 0.00043855 </velocity>
    <force> -0.01226025 -0.00573205 -0.00080487 </force>
  </atom>
  <atom name="H13" species="hydrogen">
    <position> -4.26104823 -27.36835214 -18.74080232 </position>
    <velocity> 0.00082940 -0.00016694 0.00070767 </velocity>
    <force> -0.00701559 -0.01445305 0.02691569 </force>
  </atom>
  <atom name="H14" species="hydrogen">
    <position> -3.99638978 -30.10169188 -19.45111249 </position>
    <velocity> 0.00025077 0.00052655 0.00009609 </velocity>
    <force> 0.00958011 -0.02775847 -0.01655786 </force>
  </atom>
  <atom name="H15" species="hydrogen">
    <position> 1.58724758 -14.52689069 12.09015359 </position>
    <velocity> -0.00072610 -0.00034599 0.00077478 </velocity>
    <force> 0.00867407 -0.00430615 0.00949079 </force>
  </atom>
  <atom name="H16" species="hydrogen">
    <position> 4.52936081 -14.44419643 12.74825950 </position>
    <velocity> -0.00047540 0.00014468 0.00031527 </velocity>
    <force> -0.01500977 0.00115628 0.00748014 </force>
  </atom>
  <atom name="H17" species="hydrogen">
    <position> 2.42435127 5.99388691 -7.42171100 </position>
    <velocity> -0.00003012 0.00044468 0.00018965 </velocity>
    <force> -0.00417013 -0.00893109 0.00704125 </force>
  </atom>
  <atom name="H18" species="hydrogen">
    <position> 0.93414815 3.81263784 -5.74792554 </position>
    <velocity> 0.00049747 0.00225019 -0.00106027 </velocity>
    <force> -0.00199204 0.00915095 -0.01064447 </force>
  </atom>
  <atom name="H19" species="hydrogen">
    <position> -0.81117381 6.62526733 8.30614388 </position>
    <velocity> -0.00034381 0.00054706 0.00019400 </velocity>
    <force> -0.00989008 -0.01220597 0.00121841 </force>
  </atom>
  <atom name="H20" species="hydrogen">
    <position> -0.80854693 9.46485563 8.24675890 </position>
    <velocity> 0.00017840 -0.00011316 0.00008044 </velocity>
    <force> 0.01784578 -0.01910447 -0.00078207 </force>
  </atom>
  <atom name="H21" species="hydrogen">
    <position> 11.53195341 -15.14387185 10.57818920 </position>
    <velocity> -0.00004266 0.00025871 0.00002025 </velocity>
    <force> -0.00351762 -0.00137454 -0.00241012 </force>
  </atom>
  <atom name="H22" species="hydrogen">
    <position> 12.74545359 -13.12115693 12.18030671 </position>
    <velocity> -0.00024822 -0.00036266 0.00057134 </velocity>
    <force> -0.00012180 0.00812596 0.01343771 </force>
  </atom>
  <atom name="H23" species="hydrogen">
    <position> -12.41540942 -1.53426315 11.76894698 </position>
    <velocity> 0.00093394 -0.00089457 0.00072464 </velocity>
    <force> -0.00168705 0.01040126 -0.00196382 </force>
  </atom>
  <atom name="H24" species="hydrogen">
    <position> -12.37045864 -1.95264697 14.56062011 </position>
    <velocity> 0.00056756 -0.00023990 -0.00025721 </velocity>
    <force> 0.00521624 0.00375082 0.01890873 </force>
  </atom>
  <atom name="H25" species="hydrogen">
    <position> 0.50369434 -9.37585033 -21.33324048 </position>
    <velocity> 0.00028115 0.00006922 0.00024456 </velocity>
    <force> 0.00278874 -0.00103186 -0.00678061 </force>
  </atom>
  <atom name="H26" species="hydrogen">
    <position> 3.11721043 -8.31883349 -22.29283368 </position>
    <velocity> -0.00068918 0.00035330 -0.00039450 </velocity>
    <force> 0.00858621 0.00996094 -0.00308739 </force>
  </atom>
  <atom name="H27" species="hydrogen">
    <position> -7.07345500 -9.59252235 -2.48384439 </position>
    <velocity> 0.00106755 0.00041214 0.00020668 </velocity>
    <force> -0.01618234 -0.00182666 0.00156723 </force>
  </atom>
  <atom name="H28" species="hydrogen">
    <position> -4.59390205 -9.32847641 -4.20232701 </position>
    <velocity> 0.00056297 -0.00034459 0.00000272 </velocity>
    <force> -0.00156595 -0.00517661 0.00317252 </force>
  </atom>
  <atom name="H29" species="hydrogen">
    <position> 12.60523863 -13.64256452 3.62352383 </position>
    <velocity> 0.00050311 -0.00078851 -0.00073836 </velocity>
    <force> 0.00351691 -0.00396994 -0.00442546 </force>
  </atom>
  <atom name="H30" species="hydrogen">
    <position> 12.22002427 -11.49863912 5.52521789 </position>
    <velocity> 0.00129565 -0.00019353 -0.00080537 </velocity>
    <force> -0.01032072 0.00604412 0.01533719 </force>
  </atom>
  <atom name="H31" species="hydrogen">
    <position> -5.69110583 10.83471193 -7.18122204 </position>
    <velocity> -0.00002502 -0.00004988 -0.00138717 </velocity>
    <force> 0.00611084 0.00150632 0.00388268 </force>
  </atom>
  <atom name="H32" species="hydrogen">
    <position> -8.60548598 10.37355057 -7.33291893 </position>
    <velocity> -0.00069163 0.00082788 -0.00048941 </velocity>
    <force> -0.01098843 0.00265391 0.00211716 </force>
  </atom>
  <atom name="H33" species="hydrogen">
    <position> -14.98288344 -13.87983709 -28.97714675 </position>
    <velocity> -0.00096840 0.00067438 0.00050091 </velocity>
    <force> -0.00079685 0.00340059 0.01386453 </force>
  </atom>
  <atom name="H34" species="hydrogen">
    <position> -13.04375918 -15.95314012 -28.78088943 </position>
    <velocity> 0.00023155 0.00043332 -0.00093211 </velocity>
    <force> 0.00754952 -0.01323323 0.00440802 </force>
  </atom>
  <atom name="H35" species="hydrogen">
    <position> -20.43651888 -0.94737412 14.67766005 </position>
    <velocity> -0.00005201 -0.00016472 0.00025548 </velocity>
    <force> -0.00291497 -0.00598763 -0.00809948 </force>
  </atom>
  <atom name="H36" species="hydrogen">
    <position> -18.16091112 -2.61569613 14.49051169 </position>
    <velocity> -0.00030188 0.00027085 0.00024125 </velocity>
    <force> 0.02002326 -0.00196105 0.00063003 </force>
  </atom>
  <atom name="H37" species="hydrogen">
    <position> 5.62361560 -15.55377580 0.42212440 </position>
    <velocity> -0.00015482 0.00036927 0.00163267 </velocity>
    <force> 0.00730903 -0.00508983 -0.01134014 </force>
  </atom>
  <atom name="H38" species="hydrogen">
    <position> 8.15683514 -15.38385777 -1.33569517 </position>
    <velocity> -0.00021748 -0.00033537 -0.00028759 </velocity>
    <force> -0.01209044 -0.00688953 0.00902451 </force>
  </atom>
  <atom name="H39" species="hydrogen">
    <position> 5.53910294 19.57226294 -23.08897847 </position>
    <velocity> -0.00011073 -0.00010790 -0.00001688 </velocity>
    <force> -0.00390076 -0.00747011 0.00871390 </force>
  </atom>
  <atom name="H40" species="hydrogen">
    <position> 6.90249521 17.33838827 -24.47963969 </position>
    <velocity> -0.00046478 -0.00017479 0.00012970 </velocity>
    <force> 0.00880303 -0.01264502 -0.00071292 </force>
  </atom>
  <atom name="H41" species="hydrogen">
    <position> 3.78325696 1.89144155 11.41608074 </position>
    <velocity> 0.00056206 0.00015033 0.00001392 </velocity>
    <force> -0.00336960 -0.00297109 -0.00467960 </force>
  </atom>
  <atom name="H42" species="hydrogen">
    <position> 3.02745724 2.87169806 14.19563640 </position>
    <velocity> -0.00065067 -0.00033612 -0.00026732 </velocity>
    <force> -0.01263013 0.00151118 0.00035888 </force>
  </atom>
  <atom name="H43" species="hydrogen">
    <position> -8.60976592 -5.43897069 3.42761752 </position>
    <velocity> -0.00009624 -0.00077139 0.00044117 </velocity>
    <force> 0.02771599 -0.00223917 0.02535974 </force>
  </atom>
  <atom name="H44" species="hydrogen">
    <position> -9.89217553 -6.48300506 1.08576987 </position>
    <velocity> 0.00110387 0.00147249 0.00029265 </velocity>
    <force> -0.00905303 0.01474597 0.00571680 </force>
  </atom>
  <atom name="H45" species="hydrogen">
    <position> -12.85585017 -9.32093381 8.48207578 </position>
    <velocity> 0.00066013 0.00023332 -0.00026657 </velocity>
    <force> 0.00124451 -0.00593730 0.00684881 </force>
  </atom>
  <atom name="H46" species="hydrogen">
    <position> -14.71198394 -9.56918686 6.42449159 </position>
    <velocity> 0.00058156 -0.00015546 0.00032883 </velocity>
    <force> -0.00201564 -0.00375484 0.00485385 </force>
  </atom>
  <atom name="H47" species="hydrogen">
    <position> 16.74085439 -13.08513591 4.55898096 </position>
    <velocity> 0.00015134 -0.00098673 0.00050394 </velocity>
    <force> -0.00688417 0.01428501 -0.00895045 </force>
  </atom>
  <atom name="H48" species="hydrogen">
    <position> 18.61101843 -14.70723375 5.72786009 </position>
    <velocity> 0.00070902 0.00003540 -0.00062171 </velocity>
    <force> 0.01679782 -0.01946586 0.01907877 </force>
  </atom>
  <atom name="H49" species="hydrogen">
    <position> 19.91184136 12.97667107 3.17771092 </position>
    <velocity> -0.00025095 0.00074047 -0.00065020 </velocity>
    <force> 0.00385877 0.00436386 -0.00362603 </force>
  </atom>
  <atom name="H50" species="hydrogen">
    <position> 19.35184572 14.26510405 0.54421621 </position>
    <velocity> 0.00023183 -0.00023694 -0.00002681 </velocity>
    <force> 0.01312163 0.00001766 -0.00136472 </force>
  </atom>
  <atom name="H51" species="hydrogen">
    <position> 6.79320496 14.28698620 -31.55948428 </position>
    <velocity> 0.00058713 0.00061718 0.00008165 </velocity>
    <force> 0.00101530 -0.01117475 0.00259820 </force>
  </atom>
  <atom name="H52" species="hydrogen">
    <position> 4.87799561 12.86332698 -29.85992047 </position>
    <velocity> -0.00045742 0.00068346 -0.00077269 </velocity>
    <force> -0.01868374 -0.00443098 0.00215065 </force>
  </atom>
  <atom name="H53" species="hydrogen">
    <position> 14.70155048 -22.31231538 -10.23719974 </position>
    <velocity> -0.00033569 0.00000735 0.00030499 </velocity>
    <force> -0.03561404 0.01837192 0.00461053 </force>
  </atom>
  <atom name="H54" species="hydrogen">
    <position> 12.57596922 -20.67008572 -8.70368661 </position>
    <velocity> 0.00104859 -0.00015706 0.00057293 </velocity>
    <force> 0.00088304 -0.00572160 -0.00513597 </force>
  </atom>
  <atom name="H55" species="hydrogen">
    <position> 11.28120727 2.73528402 -15.92362402 </position>
    <velocity> -0.00061268 0.00097185 -0.00071021 </velocity>
    <force> -0.00158094 -0.01043691 -0.02272473 </force>
  </atom>
  <atom name="H56" species="hydrogen">
    <position> 12.02660285 3.26654270 -13.26326951 </position>
    <velocity> 0.00018617 -0.00080190 0.00002990 </velocity>
    <force> -0.01820649 0.00342474 0.01088067 </force>
  </atom>
  <atom name="H57" species="hydrogen">
    <position> -4.01757718 7.08006264 -2.12681334 </position>
    <velocity> -0.00074947 -0.00061919 -0.00076618 </velocity>
    <force> 0.01055955 0.01390615 0.01925439 </force>
  </atom>
  <atom name="H58" species="hydrogen">
    <position> -6.14041577 7.61443277 -4.45071154 </position>
    <velocity> -0.00060216 -0.00029397 -0.00054680 </velocity>
    <force> 0.02067382 0.00570228 0.00079876 </force>
  </atom>
  <atom name="H59" species="hydrogen">
    <position> -10.39944745 -1.62856982 23.49625080 </position>
    <velocity> 0.00056460 0.00032499 -0.00069126 </velocity>
    <force> 0.00574921 -0.02140948 0.01180577 </force>
  </atom>
  <atom name="H60" species="hydrogen">
    <position> -9.36563370 0.72913764 22.03064492 </position>
    <velocity> 0.00028013 0.00016054 -0.00041940 </velocity>
    <force> -0.03089564 -0.01702137 -0.00528916 </force>
  </atom>
  <atom name="H61" species="hydrogen">
    <position> 5.45340356 0.45161719 0.69284161 </position>
    <velocity> 0.00134888 0.00044889 0.00009110 </velocity>
    <force> 0.01751746 0.01912274 -0.00812260 </force>
  </atom>
  <atom name="H62" species="hydrogen">
    <position> 4.13675126 -1.16554486 2.82747420 </position>
    <velocity> -0.00039199 0.00048006 -0.00004757 </velocity>
    <force> 0.00669005 -0.00533547 -0.01992160 </force>
  </atom>
  <atom name="H63" species="hydrogen">
    <position> 23.70034463 -0.33537572 -0.29579026 </position>
    <velocity> -0.00014370 0.00043335 -0.00024334 </velocity>
    <force> -0.02311040 0.00633257 -0.03456106 </force>
  </atom>
  <atom name="H64" species="hydrogen">
    <position> 23.60518482 -2.09974407 -2.57568706 </position>
    <velocity> -0.00068294 0.00088764 -0.00034160 </velocity>
    <force> 0.01938105 -0.03434106 -0.02328700 </force>
  </atom>
  <atom name="H65" species="hydrogen">
    <position> -0.43808049 21.66057269 8.81035520 </position>
    <velocity> 0.00056833 -0.00015865 0.00012205 </velocity>
    <force> -0.00456414 -0.00563844 -0.00867162 </force>
  </atom>
  <atom name="H66" species="hydrogen">
    <position> 0.14766059 23.52020757 10.78233150 </position>
    <velocity> 0.00056671 -0.00030170 0.00018600 </velocity>
    <force> 0.05686284 0.02981098 0.05340391 </force>
  </atom>
  <atom name="H67" species="hydrogen">
    <position> -12.43619901 -1.82282651 19.30737941 </position>
    <velocity> -0.00024139 -0.00016762 0.00053166 </velocity>
    <force> 0.01589245 0.00392338 0.01907288 </force>
  </atom>
  <atom name="H68" species="hydrogen">
    <position> -14.85898522 -1.69632187 17.82118350 </position>
    <velocity> 0.00006270 0.00036873 -0.00092565 </velocity>
    <force> -0.01011042 0.00291472 -0.00827184 </force>
  </atom>
  <atom name="H69" species="hydrogen">
    <position> 4.64215792 -1.22709463 -16.23148489 </position>
    <velocity> 0.00012187 -0.00096863 0.00078395 </velocity>
    <force> -0.01899328 -0.00810928 -0.03774329 </force>
  </atom>
  <atom name="H70" species="hydrogen">
    <position> 5.29093480 -3.79927488 -17.33699994 </position>
    <velocity> 0.00040325 0.00041899 0.00041819 </velocity>
    <force> -0.00753192 0.00657832 -0.02032012 </force>
  </atom>
  <atom name="H71" species="hydrogen">
    <position> 8.00997000 8.52095054 -40.40807316 </position>
    <velocity> -0.00071974 -0.00044051 0.00029963 </velocity>
    <force> -0.00062634 -0.00950671 0.00044538 </force>
  </atom>
  <atom name="H72" species="hydrogen">
    <position> 8.52690673 5.89979913 -39.06462244 </position>
    <velocity> 0.00035104 -0.00057269 -0.00073789 </velocity>
    <force> 0.00874347 -0.00119202 0.00213483 </force>
  </atom>
  <atom name="H73" species="hydrogen">
    <position> -10.42027998 -2.64877934 7.06182524 </position>
    <velocity> -0.00069479 0.00064778 0.00056402 </velocity>
    <force> -0.00712737 0.01788311 -0.02021693 </force>
  </atom>
  <atom name="H74" species="hydrogen">
    <position> -10.90338036 -2.22055218 4.06179567 </position>
    <velocity> -0.00007384 0.00010332 -0.00036800 </velocity>
    <force> 0.00392546 0.01604048 0.03552340 </force>
  </atom>
  <atom name="H75" species="hydrogen">
    <position> 2.02015200 10.79072208 18.91998133 </position>
    <velocity> 0.00008702 0.00010501 -0.00103000 </velocity>
    <force> -0.01002943 0.00302079 0.00625984 </force>
  </atom>
  <atom name="H76" species="hydrogen">
    <position> 2.04302697 10.52191009 16.04204024 </position>
    <velocity> 0.00008751 -0.00023963 0.00123263 </velocity>
    <force> -0.00749415 0.00993676 -0.00691732 </force>
  </atom>
  <atom name="H77" species="hydrogen">
    <position> 8.46660439 10.55774201 -10.10408002 </position>
    <velocity> -0.00049730 0.00006563 0.00044831 </velocity>
    <force> -0.00014719 0.01031964 -0.00615994 </force>
  </atom>
  <atom name="H78" species="hydrogen">
    <position> 7.91526689 11.13650314 -13.06681967 </position>
    <velocity> -0.00177280 -0.00135844 0.00069172 </velocity>
    <force> 0.00609669 0.00311832 0.00877216 </force>
  </atom>
  <atom name="H79" species="hydrogen">
    <position> -17.64747609 -7.65097127 11.16177746 </position>
    <velocity> 0.00110281 0.00054296 0.00055849 </velocity>
    <force> -0.00692501 0.00102621 -0.00569926 </force>
  </atom>
  <atom name="H80" species="hydrogen">
    <position> -15.86018597 -5.72254143 12.60130187 </position>
    <velocity> -0.00122700 -0.00080725 -0.00079587 </velocity>
    <force> -0.00167729 -0.01571911 -0.00317056 </force>
  </atom>
  <atom name="H81" species="hydrogen">
    <position> 15.97310032 4.79118021 -2.71831409 </position>
    <velocity> 0.00051306 0.00028071 -0.00010256 </velocity>
    <force> -0.01538009 -0.00739509 0.00081280 </force>
  </atom>
  <atom name="H82" species="hydrogen">
    <position> 13.70247688 5.01233954 -0.81648811 </position>
    <velocity> 0.00004640 0.00122859 0.00057187 </velocity>
    <force> -0.00485886 0.00688109 0.01296001 </force>
  </atom>
  <atom name="H83" species="hydrogen">
    <position> -7.90950564 17.27031618 15.74797919 </position>
    <velocity> 0.00071705 0.00162855 0.00000365 </velocity>
    <force> 0.01040523 0.01540991 0.00083954 </force>
  </atom>
  <atom name="H84" species="hydrogen">
    <position> -10.51835845 18.20636713 16.95075603 </position>
    <velocity> -0.00002617 -0.00083689 -0.00029598 </velocity>
    <force> 0.00161204 -0.00217538 -0.00345336 </force>
  </atom>
  <atom name="H85" species="hydrogen">
    <position> -4.93911783 -3.08874449 -9.14679497 </position>
    <velocity> -0.00000197 -0.00004888 -0.00019892 </velocity>
    <force> -0.00572398 0.03409944 -0.01171941 </force>
  </atom>
  <atom name="H86" species="hydrogen">
    <position> -3.73055690 -4.76249337 -7.20095760 </position>
    <velocity> 0.00026531 0.00018921 0.00065246 </velocity>
    <force> 0.01131338 -0.00569910 0.00578601 </force>
  </atom>
  <atom name="H87" species="hydrogen">
    <position> -12.20828174 -11.40338500 17.10136200 </position>
    <velocity> 0.00067761 0.00048991 -0.00076298 </velocity>
    <force> -0.01102470 0.00193211 0.02011573 </force>
  </atom>
  <atom name="H88" species="hydrogen">
    <position> -10.33036498 -9.52678895 15.56689654 </position>
    <velocity> 0.00059398 0.00084253 -0.00024453 </velocity>
    <force> -0.02018086 -0.01506009 0.01223261 </force>
  </atom>
  <atom name="H89" species="hydrogen">
    <position> -8.59524183 25.04916846 5.30680500 </position>
    <velocity> -0.00015596 -0.00033329 -0.00023351 </velocity>
    <force> -0.00535461 -0.00724758 -0.00072515 </force>
  </atom>
  <atom name="H90" species="hydrogen">
    <position> -6.38105489 26.97664002 6.10577174 </position>
    <velocity> -0.00079081 -0.00122077 0.00090289 </velocity>
    <force> -0.01769726 -0.00738674 -0.03021821 </force>
  </atom>
  <atom name="H91" species="hydrogen">
    <position> 11.95227280 -4.94190828 -12.88706910 </position>
    <velocity> -0.00031474 0.00042153 0.00039527 </velocity>
    <force> 0.02221782 -0.00715060 -0.03699193 </force>
  </atom>
  <atom name="H92" species="hydrogen">
    <position> 14.51021273 -6.34934303 -14.04971110 </position>
    <velocity> 0.00021867 -0.00040510 -0.00032348 </velocity>
    <force> -0.02264705 0.02947128 -0.00885810 </force>
  </atom>
  <atom name="H93" species="hydrogen">
    <position> -3.95971241 -2.24398649 2.05733945 </position>
    <velocity> -0.00059532 -0.00071473 0.00000982 </velocity>
    <force> -0.00503332 0.01607141 -0.00521612 </force>
  </atom>
  <atom name="H94" species="hydrogen">
    <position> -5.30267405 -0.06246776 3.49513546 </position>
    <velocity> 0.00056853 -0.00175446 0.00001738 </velocity>
    <force> -0.03831225 0.02435307 0.00210819 </force>
  </atom>
  <atom name="H95" species="hydrogen">
    <position> -18.52597436 -18.02852721 -18.01912361 </position>
    <velocity> -0.00039723 0.00063781 0.00061088 </velocity>
    <force> 0.02494264 0.01279666 -0.00697791 </force>
  </atom>
  <atom name="H96" species="hydrogen">
    <position> -21.02543881 -17.41417341 -16.89064928 </position>
    <velocity> 0.00034857 -0.00043654 -0.00036430 </velocity>
    <force> -0.01353801 0.01254579 0.00586566 </force>
  </atom>
  <atom name="H97" species="hydrogen">
    <position> -38.78017138 4.07964056 -23.58506126 </position>
    <velocity> -0.00029660 0.00047442 -0.00021542 </velocity>
    <force> -0.01749811 -0.00168267 -0.00925535 </force>
  </atom>
  <atom name="H98" species="hydrogen">
    <position> -37.37980059 1.48879525 -23.99525624 </position>
    <velocity> 0.00018011 0.00062469 -0.00075884 </velocity>
    <force> 0.01323492 -0.01159750 0.00032674 </force>
  </atom>
  <atom name="H99" species="hydrogen">
    <position> 32.74780671 17.66742021 -4.09792450 </position>
    <velocity> 0.00006579 -0.00000632 0.00102256 </velocity>
    <force> -0.00374562 -0.01748860 0.01057506 </force>
  </atom>
  <atom name="H100" species="hydrogen">
    <position> 31.18581071 15.01837400 -4.27963380 </position>
    <velocity> 0.00047519 -0.00055181 0.00018592 </velocity>
    <force> 0.01538580 0.00292981 0.00438987 </force>
  </atom>
  <atom name="H101" species="hydrogen">
    <position> 9.85216995 3.27035576 -5.89334649 </position>
    <velocity> -0.00013421 0.00078971 -0.00073500 </velocity>
    <force> -0.05196356 -0.02516696 -0.00483201 </force>
  </atom>
  <atom name="H102" species="hydrogen">
    <position> 12.16263462 3.83269640 -4.36607173 </position>
    <velocity> 0.00119463 0.00034049 -0.00099489 </velocity>
    <force> 0.01406127 0.00834053 -0.01672457 </force>
  </atom>
  <atom name="H103" species="hydrogen">
    <position> -3.40216586 3.85417904 18.63450765 </position>
    <velocity> -0.00038775 -0.00085842 0.00027130 </velocity>
    <force> 0.00241507 0.01075347 0.00650278 </force>
  </atom>
  <atom name="H104" species="hydrogen">
    <position> -1.50883342 1.66525248 19.55701942 </position>
    <velocity> 0.00027779 0.00067500 -0.00091760 </velocity>
    <force> -0.00351727 -0.00932884 0.00779471 </force>
  </atom>
  <atom name="H105" species="hydrogen">
    <position> 21.74795593 -10.89039859 -6.92476059 </position>
    <velocity> 0.00043446 0.00068952 -0.00019504 </velocity>
    <force> -0.01119689 0.00228768 0.00358004 </force>
  </atom>
  <atom name="H106" species="hydrogen">
    <position> 19.80613193 -9.19259620 -8.53621950 </position>
    <velocity> 0.00057256 -0.00024902 0.00066310 </velocity>
    <force> 0.00756682 -0.02674758 0.03595623 </force>
  </atom>
  <atom name="H107" species="hydrogen">
    <position> 0.95541023 -8.55447412 10.97624186 </position>
    <velocity> -0.00059152 0.00069491 -0.00026271 </velocity>
    <force> 0.01348543 0.00996353 -0.01057611 </force>
  </atom>
  <atom name="H108" species="hydrogen">
    <position> 0.74652922 -7.45788280 13.84293998 </position>
    <velocity> 0.00066740 -0.00041866 -0.00011709 </velocity>
    <force> 0.00984039 0.01203236 0.00140461 </force>
  </atom>
  <atom name="H109" species="hydrogen">
    <position> 18.14027342 -5.06160555 -1.19991223 </position>
    <velocity> -0.00008846 -0.00030056 -0.00020972 </velocity>
    <force> -0.00163032 -0.01466608 -0.00517089 </force>
  </atom>
  <atom name="H110" species="hydrogen">
    <position> 19.16961258 -2.39653472 -1.58623027 </position>
    <velocity> -0.00025121 -0.00039894 -0.00017470 </velocity>
    <force> 0.01922228 0.01362339 -0.01464103 </force>
  </atom>
  <atom name="H111" species="hydrogen">
    <position> 24.00582934 -6.69532660 18.48099823 </position>
    <velocity> -0.00050496 -0.00066724 0.00052774 </velocity>
    <force> 0.00106803 -0.00590792 0.00332274 </force>
  </atom>
  <atom name="H112" species="hydrogen">
    <position> 25.02719209 -4.25424795 17.13595051 </position>
    <velocity> 0.00022658 0.00056994 0.00043846 </velocity>
    <force> -0.00503127 -0.00670507 -0.00907914 </force>
  </atom>
  <atom name="H113" species="hydrogen">
    <position> 2.29814799 34.12224248 -23.58542290 </position>
    <velocity> 0.00017258 0.00020532 -0.00009820 </velocity>
    <force> 0.01169024 -0.00537180 -0.00381538 </force>
  </atom>
  <atom name="H114" species="hydrogen">
    <position> 1.14589081 31.61645711 -24.08591172 </position>
    <velocity> 0.00013954 -0.00017231 -0.00022024 </velocity>
    <force> -0.02242907 -0.01714335 0.00301848 </force>
  </atom>
  <atom name="H115" species="hydrogen">
    <position> 6.93923370 1.88589423 -13.85235100 </position>
    <velocity> 0.00063530 -0.00018698 0.00007727 </velocity>
    <force> -0.03068804 -0.01297505 -0.02318159 </force>
  </atom>
  <atom name="H116" species="hydrogen">
    <position> 4.72527821 2.91858615 -15.74161677 </position>
    <velocity> 0.00014331 -0.00059402 0.00061150 </velocity>
    <force> -0.01069221 -0.00743351 -0.00062908 </force>
  </atom>
  <atom name="H117" species="hydrogen">
    <position> -3.35303171 -14.76763330 -21.97199395 </position>
    <velocity> 0.00053356 0.00054726 0.00092332 </velocity>
    <force> 0.01501097 -0.01233256 0.00059840 </force>
  </atom>
  <atom name="H118" species="hydrogen">
    <position> -1.95706600 -17.39117432 -22.06537274 </position>
    <velocity> -0.00052558 -0.00113224 0.00035272 </velocity>
    <force> 0.00619244 -0.04702520 0.02673159 </force>
  </atom>
  <atom name="H119" species="hydrogen">
    <position> -29.02538156 -14.00122520 10.83780723 </position>
    <velocity> 0.00050000 0.00008905 -0.00123278 </velocity>
    <force> 0.01249030 -0.01145768 -0.00035597 </force>
  </atom>
  <atom name="H120" species="hydrogen">
    <position> -28.01083459 -11.51263848 10.10641428 </position>
    <velocity> 0.00082968 0.00024335 0.00089519 </velocity>
    <force> 0.01052053 0.00647278 -0.00022143 </force>
  </atom>
  <atom name="H121" species="hydrogen">
    <position> -4.59401330 4.82690305 -13.74027336 </position>
    <velocity> -0.00069396 0.00041343 -0.00042736 </velocity>
    <force> -0.00223154 0.00488962 -0.00475019 </force>
  </atom>
  <atom name="H122" species="hydrogen">
    <position> -2.97676556 2.79958225 -15.15242131 </position>
    <velocity> -0.00029211 0.00013047 0.00009876 </velocity>
    <force> 0.00132743 0.00129956 -0.00358868 </force>
  </atom>
  <atom name="H123" species="hydrogen">
    <position> -5.15572374 -7.00605891 31.86757078 </position>
    <velocity> -0.00063952 0.00050087 0.00089072 </velocity>
    <force> 0.01077700 0.01285813 -0.01529495 </force>
  </atom>
  <atom name="H124" species="hydrogen">
    <position> -5.05290438 -6.41532092 34.79708666 </position>
    <velocity> 0.00001550 0.00089459 0.00003204 </velocity>
    <force> 0.01679690 0.01327747 0.01978898 </force>
  </atom>
  <atom name="H125" species="hydrogen">
    <position> -20.96841133 -9.19424008 30.20285393 </position>
    <velocity> 0.00017290 -0.00082368 0.00041753 </velocity>
    <force> 0.00087827 -0.02071318 -0.01468693 </force>
  </atom>
  <atom name="H126" species="hydrogen">
    <position> -20.87675474 -6.50676693 30.82998792 </position>
    <velocity> 0.00031461 0.00020682 0.00045224 </velocity>
    <force> -0.00146628 0.01083042 0.00516242 </force>
  </atom>
  <atom name="H127" species="hydrogen">
    <position> 10.47882455 6.05775179 25.15091228 </position>
    <velocity> 0.00083789 -0.00094988 -0.00050568 </velocity>
    <force> 0.03233901 0.01107748 0.02583181 </force>
  </atom>
  <atom name="H128" species="hydrogen">
    <position> 13.27521667 5.38710374 26.82880631 </position>
    <velocity> 0.00070282 -0.00041994 -0.00065710 </velocity>
    <force> -0.01721795 0.00015133 -0.01123162 </force>
  </atom>
</atomset>
<unit_cell_a_norm> 23.460000 </unit_cell_a_norm>
<unit_cell_b_norm> 23.460000 </unit_cell_b_norm>
<unit_cell_c_norm> 23.460000 </unit_cell_c_norm>
<unit_cell_alpha>  90.000 </unit_cell_alpha>
<unit_cell_beta>   90.000 </unit_cell_beta>
<unit_cell_gamma>  90.000 </unit_cell_gamma>
<unit_cell_volume> 12911.718 </unit_cell_volume>
  <timing name="iteration" min="  124.682" max="  124.688"/>
</iteration>
<timing name="         charge" min="   21.456" max="   23.505"/>
<timing name="         energy" min="   38.038" max="   38.076"/>
<timing name="    ortho_align" min="   35.394" max="   37.447"/>
<timing name="      psda_prec" min="    0.188" max="    0.213"/>
<timing name="  psda_residual" min="   12.619" max="   14.615"/>
<timing name=" psda_update_wf" min="    0.480" max="    0.535"/>
<timing name="    update_vhxc" min="   10.621" max="   10.868"/>
<timing name="      wf_update" min="   50.933" max="   52.988"/>
<timing name="           ekin" min="    0.740" max="    0.981"/>
<timing name="            exc" min="    9.591" max="    9.806"/>
<timing name="           hpsi" min="   34.960" max="   35.281"/>
<timing name="       nonlocal" min="    1.913" max="    2.033"/>
<timing name=" charge_compute" min="   19.315" max="   21.417"/>
<timing name="charge_integral" min="    0.071" max="    0.368"/>
<timing name="  charge_rowsum" min="    0.925" max="    1.240"/>
<timing name="     charge_vft" min="    0.792" max="    0.823"/>
[qbox] <cmd>save gs.xml</cmd>
 SampleWriter: write time: 10.215 s
 SampleWriter: file size: 949969533
 SampleWriter: aggregate write rate: 88.69 MB/s
[qbox]  End of command stream 
<real_time> 138.94 </real_time>
<end_time> 2016-04-24T20:31:35Z </end_time>
</fpmd:simulation>
