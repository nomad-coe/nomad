<?xml version="1.0" encoding="UTF-8"?>
<fpmd:simulation xmlns:fpmd="http://www.quantum-simulation.org/ns/fpmd/fpmd-1.0">
<uuid> abd41b30-0a5b-11e6-93de-002590a1b28a </uuid>

                   ============================
                   I qbox 1.63.2              I
                   I                          I
                   I                          I
                   I                          I
                   I                          I
                   I                          I
                   I                          I
                   I                          I
                   I                          I
                   I                          I
                   I                          I
                   I                          I
                   I http://qboxcode.org      I
                   ============================


<release> 1.63.2 presto </release>
<sysname> Linux </sysname>
<nodename> c34.local </nodename>
<start_time> 2016-04-24T20:32:32Z </start_time>
<mpi_processes count="144">
<process id="0"> c34.local </process>
<process id="1"> c34.local </process>
<process id="2"> c34.local </process>
<process id="3"> c34.local </process>
<process id="4"> c34.local </process>
<process id="5"> c34.local </process>
<process id="6"> c34.local </process>
<process id="7"> c34.local </process>
<process id="8"> c16.local </process>
<process id="9"> c16.local </process>
<process id="10"> c16.local </process>
<process id="11"> c16.local </process>
<process id="12"> c16.local </process>
<process id="13"> c16.local </process>
<process id="14"> c16.local </process>
<process id="15"> c16.local </process>
<process id="16"> c01.local </process>
<process id="17"> c01.local </process>
<process id="18"> c01.local </process>
<process id="19"> c01.local </process>
<process id="20"> c01.local </process>
<process id="21"> c01.local </process>
<process id="22"> c01.local </process>
<process id="23"> c01.local </process>
<process id="24"> c29.local </process>
<process id="25"> c29.local </process>
<process id="26"> c29.local </process>
<process id="27"> c29.local </process>
<process id="28"> c29.local </process>
<process id="29"> c29.local </process>
<process id="30"> c29.local </process>
<process id="31"> c29.local </process>
<process id="32"> c45.local </process>
<process id="33"> c45.local </process>
<process id="34"> c45.local </process>
<process id="35"> c45.local </process>
<process id="36"> c45.local </process>
<process id="37"> c45.local </process>
<process id="38"> c45.local </process>
<process id="39"> c45.local </process>
<process id="40"> c43.local </process>
<process id="41"> c43.local </process>
<process id="42"> c43.local </process>
<process id="43"> c43.local </process>
<process id="44"> c43.local </process>
<process id="45"> c43.local </process>
<process id="46"> c43.local </process>
<process id="47"> c43.local </process>
<process id="48"> c27.local </process>
<process id="49"> c27.local </process>
<process id="50"> c27.local </process>
<process id="51"> c27.local </process>
<process id="52"> c27.local </process>
<process id="53"> c27.local </process>
<process id="54"> c27.local </process>
<process id="55"> c27.local </process>
<process id="56"> c02.local </process>
<process id="57"> c02.local </process>
<process id="58"> c02.local </process>
<process id="59"> c02.local </process>
<process id="60"> c02.local </process>
<process id="61"> c02.local </process>
<process id="62"> c02.local </process>
<process id="63"> c02.local </process>
<process id="64"> c32.local </process>
<process id="65"> c32.local </process>
<process id="66"> c32.local </process>
<process id="67"> c32.local </process>
<process id="68"> c32.local </process>
<process id="69"> c32.local </process>
<process id="70"> c32.local </process>
<process id="71"> c32.local </process>
<process id="72"> c24.local </process>
<process id="73"> c24.local </process>
<process id="74"> c24.local </process>
<process id="75"> c24.local </process>
<process id="76"> c24.local </process>
<process id="77"> c24.local </process>
<process id="78"> c24.local </process>
<process id="79"> c24.local </process>
<process id="80"> c42.local </process>
<process id="81"> c42.local </process>
<process id="82"> c42.local </process>
<process id="83"> c42.local </process>
<process id="84"> c42.local </process>
<process id="85"> c42.local </process>
<process id="86"> c42.local </process>
<process id="87"> c42.local </process>
<process id="88"> c26.local </process>
<process id="89"> c26.local </process>
<process id="90"> c26.local </process>
<process id="91"> c26.local </process>
<process id="92"> c26.local </process>
<process id="93"> c26.local </process>
<process id="94"> c26.local </process>
<process id="95"> c26.local </process>
<process id="96"> c21.local </process>
<process id="97"> c21.local </process>
<process id="98"> c21.local </process>
<process id="99"> c21.local </process>
<process id="100"> c21.local </process>
<process id="101"> c21.local </process>
<process id="102"> c21.local </process>
<process id="103"> c21.local </process>
<process id="104"> c04.local </process>
<process id="105"> c04.local </process>
<process id="106"> c04.local </process>
<process id="107"> c04.local </process>
<process id="108"> c04.local </process>
<process id="109"> c04.local </process>
<process id="110"> c04.local </process>
<process id="111"> c04.local </process>
<process id="112"> c03.local </process>
<process id="113"> c03.local </process>
<process id="114"> c03.local </process>
<process id="115"> c03.local </process>
<process id="116"> c03.local </process>
<process id="117"> c03.local </process>
<process id="118"> c03.local </process>
<process id="119"> c03.local </process>
<process id="120"> c22.local </process>
<process id="121"> c22.local </process>
<process id="122"> c22.local </process>
<process id="123"> c22.local </process>
<process id="124"> c22.local </process>
<process id="125"> c22.local </process>
<process id="126"> c22.local </process>
<process id="127"> c22.local </process>
<process id="128"> c30.local </process>
<process id="129"> c30.local </process>
<process id="130"> c30.local </process>
<process id="131"> c30.local </process>
<process id="132"> c30.local </process>
<process id="133"> c30.local </process>
<process id="134"> c30.local </process>
<process id="135"> c30.local </process>
<process id="136"> c06.local </process>
<process id="137"> c06.local </process>
<process id="138"> c06.local </process>
<process id="139"> c06.local </process>
<process id="140"> c06.local </process>
<process id="141"> c06.local </process>
<process id="142"> c06.local </process>
<process id="143"> c06.local </process>
</mpi_processes>
[qbox] <cmd>set nrowmax 72</cmd>
[qbox] <cmd>load gs.xml</cmd>
 LoadCmd: loading from gs.xml
 XMLGFPreprocessor: reading from gs.xml size: 949969533
 XMLGFPreprocessor: read time: 8.682
 XMLGFPreprocessor: local read rate: 0.7246 MB/s  aggregate read rate: 104.3 MB/s
 XMLGFPreprocessor: tag fixing time: 0.01854
 XMLGFPreprocessor: segment definition time: 0.2051
 XMLGFPreprocessor: boundary adjustment time: 0.225
 XMLGFPreprocessor: transcoding time: 0.01427
 XMLGFPreprocessor: data redistribution time: 2.086
 XMLGFPreprocessor: XML compacting time: 0.1647
 XMLGFPreprocessor: total time: 11.41
 xmlcontent.size(): 334461
 Starting XML parsing

 species oxygen:
<species name="oxygen">
 <description>
 PSGen-1.6.0 pseudopotential: HSCV O xc=PBE
 Generated by PSGen-1.6.0 on 2009-02-15T02:25:11Z
 psgen arguments:
 -element O -xc PBE -smooth_v -bound l=0:rc=0.8 -bound l=1:rc=0.8
 </description>
 <symbol>O</symbol>
 <atomic_number>8</atomic_number>
 <mass>16</mass>
 <norm_conserving_pseudopotential>
 <valence_charge>6</valence_charge>
 <lmax>1</lmax>
 <llocal>1</llocal>
 <nquad>0</nquad>
 <rquad>0</rquad>
 <mesh_spacing>0.01</mesh_spacing>
 </norm_conserving_pseudopotential>
</species>
 Kleinman-Bylander potential
 rcps_ =   1.5

 species hydrogen:
<species name="hydrogen">
 <description>
 HSCV PBE Deuterium 
 PSGen-1.6.0 pseudopotential: HSCV H xc=PBE
 Generated by PSGen-1.6.0 on 2009-02-15T02:24:50Z
 psgen arguments:
 -element H -xc PBE -smooth_v -bound l=0:rc=0.5
 </description>
 <symbol>D</symbol>
 <atomic_number>1</atomic_number>
 <mass>2.014</mass>
 <norm_conserving_pseudopotential>
 <valence_charge>1</valence_charge>
 <lmax>0</lmax>
 <llocal>0</llocal>
 <nquad>0</nquad>
 <rquad>0</rquad>
 <mesh_spacing>0.01</mesh_spacing>
 </norm_conserving_pseudopotential>
</species>
 local potential
 rcps_ =   1.5
 WavefunctionHandler::startElement: wavefunction nspin=1 nel=512 nempty=0
 WavefunctionHandler::startElement: slater_determinant
 kpoint=0 0 0 weight=1 size=256
 WavefunctionHandler::endElement: slater_determinant
 XML parsing done
 SampleReader: read time: 11.71 s
[qbox] <cmd>set xc PBE</cmd>
[qbox] <cmd>set wf_dyn PSDA</cmd>
[qbox] <cmd>set ecutprec 4</cmd>
[qbox] <cmd>set atoms_dyn MD</cmd>
[qbox] <cmd>set dt 10</cmd>
[qbox] <cmd>set thermostat BDP</cmd>
[qbox] <cmd>set th_temp 400</cmd>
[qbox] <cmd>set th_time 10000</cmd>
[qbox] <cmd>run 10 5</cmd>
  EnergyFunctional: np0v,np1v,np2v: 144 144 144
  EnergyFunctional: vft->np012(): 2985984
<wavefunction ecut="42.5" nspin="1" nel="512" nempty="0">
<cell a="23.460000 0.000000 0.000000"
      b="0.000000 23.460000 0.000000"
      c="0.000000 0.000000 23.460000"/>
 reciprocal lattice vectors
 0.267825 0.000000 0.000000
 0.000000 0.267825 0.000000
 0.000000 0.000000 0.267825
<refcell a="0.000000 0.000000 0.000000"
         b="0.000000 0.000000 0.000000"
         c="0.000000 0.000000 0.000000"/>
<grid nx="70" ny="70" nz="70"/>
 kpoint: 0.000000 0.000000 0.000000 weight: 1.000000
<slater_determinant kpoint="0.000000 0.000000 0.000000" size="256">
 sdcontext: 72x2
 basis size: 85355
 c dimensions: 87840x256   (1220x128 blocks)
 <density_matrix form="diagonal" size="256">
 </density_matrix>
</slater_determinant>
</wavefunction>
<iteration count="1">
  total_electronic_charge: 512.00000000
  <ekin>       807.89218588 </ekin>
  <econf>        0.00000000 </econf>
  <eps>      -1308.33345983 </eps>
  <enl>        124.89965807 </enl>
  <ecoul>     -454.10204859 </ecoul>
  <exc>       -270.87789225 </exc>
  <esr>         92.85158837 </esr>
  <eself>      646.81841729 </eself>
  <ets>          0.00000000 </ets>
  <eexf>         0.00000000 </eexf>
  <etotal>   -1100.52155672 </etotal>
  <epv>          0.00000000 </epv>
  <eefield>      0.00000000 </eefield>
  <enthalpy> -1100.52155672 </enthalpy>
<atomset>
<unit_cell 
    a=" 23.46000000   0.00000000   0.00000000"
    b="  0.00000000  23.46000000   0.00000000"
    c="  0.00000000   0.00000000  23.46000000" />
  <atom name="O1" species="oxygen">
    <position> -6.48337908 6.01757097 12.37774040 </position>
    <velocity> -0.00018626 -0.00020031 0.00028804 </velocity>
    <force> 0.04230527 -0.00186082 0.01796086 </force>
  </atom>
  <atom name="O2" species="oxygen">
    <position> 23.13620027 2.61155301 25.49658173 </position>
    <velocity> -0.00000852 0.00006359 -0.00023066 </velocity>
    <force> 0.00297044 -0.00978401 0.01889566 </force>
  </atom>
  <atom name="O3" species="oxygen">
    <position> -28.79530384 23.73288427 -33.09468503 </position>
    <velocity> -0.00018165 0.00012688 -0.00011929 </velocity>
    <force> 0.03093720 0.00488675 -0.02167258 </force>
  </atom>
  <atom name="O4" species="oxygen">
    <position> 13.16352729 -9.21037044 -0.60382285 </position>
    <velocity> 0.00007618 -0.00022711 0.00007599 </velocity>
    <force> 0.00608149 -0.01569617 0.03031434 </force>
  </atom>
  <atom name="O5" species="oxygen">
    <position> 6.66609866 -22.47163884 -5.68002479 </position>
    <velocity> 0.00027201 -0.00000949 -0.00049678 </velocity>
    <force> -0.00322111 0.02296236 0.01745667 </force>
  </atom>
  <atom name="O6" species="oxygen">
    <position> 8.01875291 16.93359926 5.23223206 </position>
    <velocity> 0.00009179 -0.00023123 0.00036264 </velocity>
    <force> 0.00133517 0.00409385 -0.00858716 </force>
  </atom>
  <atom name="O7" species="oxygen">
    <position> -4.61485622 -29.13618554 -18.04026819 </position>
    <velocity> -0.00001565 0.00043375 -0.00028638 </velocity>
    <force> -0.00497993 0.03989147 -0.00012529 </force>
  </atom>
  <atom name="O8" species="oxygen">
    <position> 2.78492012 -14.69141749 13.53605350 </position>
    <velocity> -0.00007130 -0.00043688 0.00022492 </velocity>
    <force> 0.00968166 -0.00163967 -0.01704547 </force>
  </atom>
  <atom name="O9" species="oxygen">
    <position> 2.61394758 4.40059778 -6.43900309 </position>
    <velocity> -0.00032157 -0.00002571 -0.00039207 </velocity>
    <force> 0.01329824 0.00850532 -0.00094773 </force>
  </atom>
  <atom name="O10" species="oxygen">
    <position> 0.40775540 7.98484209 8.11656754 </position>
    <velocity> 0.00015325 0.00024751 0.00020699 </velocity>
    <force> -0.01442013 0.03333931 0.00703983 </force>
  </atom>
  <atom name="O11" species="oxygen">
    <position> 13.17840362 -14.44054701 10.99567824 </position>
    <velocity> -0.00006651 0.00010000 0.00000287 </velocity>
    <force> 0.00042492 -0.00580589 -0.01150981 </force>
  </atom>
  <atom name="O12" species="oxygen">
    <position> -13.19795332 -2.55545972 13.06971282 </position>
    <velocity> 0.00027796 -0.00012941 -0.00010469 </velocity>
    <force> -0.01776085 -0.02255012 -0.02693816 </force>
  </atom>
  <atom name="O13" species="oxygen">
    <position> 2.32510797 -9.79822461 -21.54192141 </position>
    <velocity> -0.00010638 0.00039477 0.00012161 </velocity>
    <force> -0.01118932 -0.00917834 0.00754324 </force>
  </atom>
  <atom name="O14" species="oxygen">
    <position> -5.30059909 -9.16828243 -2.45729976 </position>
    <velocity> -0.00018228 0.00002969 -0.00033938 </velocity>
    <force> 0.01361293 0.01201255 0.00661317 </force>
  </atom>
  <atom name="O15" species="oxygen">
    <position> 13.31859014 -11.98842145 4.14310527 </position>
    <velocity> -0.00049884 -0.00028788 0.00021702 </velocity>
    <force> 0.00927929 -0.01008965 -0.01905283 </force>
  </atom>
  <atom name="O16" species="oxygen">
    <position> -6.98789469 9.49975207 -7.01876185 </position>
    <velocity> -0.00006689 0.00025139 -0.00007766 </velocity>
    <force> 0.00992048 -0.01611408 -0.00033732 </force>
  </atom>
  <atom name="O17" species="oxygen">
    <position> -13.79139500 -14.61687960 -27.73505694 </position>
    <velocity> -0.00000053 0.00010530 0.00021683 </velocity>
    <force> -0.01056616 0.01031505 -0.01529449 </force>
  </atom>
  <atom name="O18" species="oxygen">
    <position> -19.92421666 -2.75646034 14.85311542 </position>
    <velocity> -0.00020692 -0.00014864 0.00011536 </velocity>
    <force> -0.01679677 0.00440912 0.00485475 </force>
  </atom>
  <atom name="O19" species="oxygen">
    <position> 7.38139414 -16.22328712 0.19736442 </position>
    <velocity> -0.00035119 -0.00035204 0.00005071 </velocity>
    <force> 0.01364636 0.00732001 -0.00273055 </force>
  </atom>
  <atom name="O20" species="oxygen">
    <position> 5.89714230 17.68761400 -22.94967014 </position>
    <velocity> 0.00008105 -0.00013530 -0.00001100 </velocity>
    <force> -0.01021097 0.01253314 0.00453496 </force>
  </atom>
  <atom name="O21" species="oxygen">
    <position> 2.46316311 1.82036862 12.74557389 </position>
    <velocity> -0.00020684 0.00029185 -0.00013774 </velocity>
    <force> -0.00091713 -0.00011931 0.01238321 </force>
  </atom>
  <atom name="O22" species="oxygen">
    <position> -9.90361701 -4.95177700 2.29604219 </position>
    <velocity> 0.00033193 0.00010942 -0.00030831 </velocity>
    <force> -0.02294082 -0.01307199 -0.03022479 </force>
  </atom>
  <atom name="O23" species="oxygen">
    <position> -13.81353707 -10.70559375 7.67834275 </position>
    <velocity> 0.00015296 0.00000252 -0.00036292 </velocity>
    <force> -0.00173571 0.01596184 -0.00894305 </force>
  </atom>
  <atom name="O24" species="oxygen">
    <position> 18.58913749 -13.36809869 4.52489240 </position>
    <velocity> 0.00035211 -0.00015072 -0.00004291 </velocity>
    <force> -0.01479890 0.00766376 -0.01356601 </force>
  </atom>
  <atom name="O25" species="oxygen">
    <position> 20.48569855 14.38870676 2.07716713 </position>
    <velocity> 0.00003420 -0.00049658 -0.00044290 </velocity>
    <force> -0.01004334 -0.00837744 0.00105704 </force>
  </atom>
  <atom name="O26" species="oxygen">
    <position> 6.68722761 13.02072680 -30.12532703 </position>
    <velocity> -0.00001791 0.00019979 0.00016304 </velocity>
    <force> 0.01293985 0.01504538 -0.00891683 </force>
  </atom>
  <atom name="O27" species="oxygen">
    <position> 12.81727313 -21.72429916 -10.28086853 </position>
    <velocity> 0.00010093 -0.00027268 0.00013013 </velocity>
    <force> 0.04729534 -0.00847667 -0.00544593 </force>
  </atom>
  <atom name="O28" species="oxygen">
    <position> 10.66103836 3.70706566 -14.52621439 </position>
    <velocity> 0.00006731 0.00033141 -0.00025626 </velocity>
    <force> 0.01406838 -0.00242690 0.01992928 </force>
  </atom>
  <atom name="O29" species="oxygen">
    <position> -4.81856258 6.48017453 -3.65040043 </position>
    <velocity> 0.00005855 -0.00005019 0.00018356 </velocity>
    <force> -0.03601696 -0.01751665 -0.02446145 </force>
  </atom>
  <atom name="O30" species="oxygen">
    <position> -10.80303056 -0.60212400 22.05932398 </position>
    <velocity> 0.00033800 0.00005618 -0.00014052 </velocity>
    <force> 0.01821376 0.03453104 -0.00729572 </force>
  </atom>
  <atom name="O31" species="oxygen">
    <position> 4.41605858 -1.01635028 0.91257900 </position>
    <velocity> 0.00018235 0.00004108 0.00025551 </velocity>
    <force> -0.02569830 -0.01886161 0.02296565 </force>
  </atom>
  <atom name="O32" species="oxygen">
    <position> 22.69748710 -0.71004283 -1.96930837 </position>
    <velocity> -0.00010054 0.00005055 0.00037268 </velocity>
    <force> 0.00512137 0.02628567 0.05544265 </force>
  </atom>
  <atom name="O33" species="oxygen">
    <position> -1.15007142 23.06255209 9.74205238 </position>
    <velocity> 0.00001609 0.00012439 0.00005821 </velocity>
    <force> -0.06012347 -0.01736230 -0.04454549 </force>
  </atom>
  <atom name="O34" species="oxygen">
    <position> -13.41851173 -2.82191889 18.12783535 </position>
    <velocity> -0.00026696 0.00004178 0.00015451 </velocity>
    <force> -0.00049709 -0.01144834 -0.00454004 </force>
  </atom>
  <atom name="O35" species="oxygen">
    <position> 4.05007591 -2.42035208 -17.77633502 </position>
    <velocity> -0.00001804 -0.00009302 0.00004897 </velocity>
    <force> 0.02674747 0.00140924 0.06225211 </force>
  </atom>
  <atom name="O36" species="oxygen">
    <position> 7.54178722 6.72558992 -40.39453176 </position>
    <velocity> -0.00035241 -0.00007099 -0.00007025 </velocity>
    <force> 0.00275044 0.02040290 -0.00707475 </force>
  </atom>
  <atom name="O37" species="oxygen">
    <position> -10.78855453 -1.22034715 5.74284370 </position>
    <velocity> -0.00027409 0.00005169 0.00001517 </velocity>
    <force> 0.00341876 -0.02718880 -0.00937197 </force>
  </atom>
  <atom name="O38" species="oxygen">
    <position> 1.47903850 11.74909104 17.40097322 </position>
    <velocity> -0.00015906 0.00013073 0.00011325 </velocity>
    <force> 0.01554516 -0.01301166 0.00349242 </force>
  </atom>
  <atom name="O39" species="oxygen">
    <position> 7.69059164 9.92671767 -11.65453590 </position>
    <velocity> 0.00017031 0.00006109 0.00006728 </velocity>
    <force> -0.00735903 -0.01362754 -0.00236965 </force>
  </atom>
  <atom name="O40" species="oxygen">
    <position> -16.38066533 -7.53270112 12.47868118 </position>
    <velocity> 0.00037297 0.00023394 0.00013230 </velocity>
    <force> 0.01211138 0.01645051 0.00988764 </force>
  </atom>
  <atom name="O41" species="oxygen">
    <position> 14.22221123 4.03353796 -2.29022304 </position>
    <velocity> -0.00015833 0.00008894 0.00014509 </velocity>
    <force> 0.03275897 0.00391967 0.00193627 </force>
  </atom>
  <atom name="O42" species="oxygen">
    <position> -9.68549415 16.85604700 16.00473905 </position>
    <velocity> -0.00014806 -0.00007353 0.00021483 </velocity>
    <force> -0.01264801 -0.01174486 -0.00094603 </force>
  </atom>
  <atom name="O43" species="oxygen">
    <position> -5.15430331 -4.69429230 -8.35319749 </position>
    <velocity> 0.00001299 0.00019975 -0.00014625 </velocity>
    <force> 0.00171697 -0.03292398 0.00685563 </force>
  </atom>
  <atom name="O44" species="oxygen">
    <position> -11.06340740 -11.35184974 15.71345993 </position>
    <velocity> -0.00017955 0.00031798 0.00033635 </velocity>
    <force> 0.02205051 0.01822790 -0.03544188 </force>
  </atom>
  <atom name="O45" species="oxygen">
    <position> -7.57465605 26.43728094 4.59889070 </position>
    <velocity> 0.00037902 -0.00028111 -0.00048220 </velocity>
    <force> 0.01836271 0.01269886 0.02874386 </force>
  </atom>
  <atom name="O46" species="oxygen">
    <position> 12.87827708 -5.28482258 -14.60822266 </position>
    <velocity> -0.00038806 -0.00010446 0.00016424 </velocity>
    <force> 0.00084807 -0.02032025 0.05071617 </force>
  </atom>
  <atom name="O47" species="oxygen">
    <position> -3.74089534 -0.89664731 3.38569457 </position>
    <velocity> 0.00036579 -0.00023889 -0.00027776 </velocity>
    <force> 0.03930636 -0.03393635 0.00278830 </force>
  </atom>
  <atom name="O48" species="oxygen">
    <position> -20.14280677 -18.80013515 -17.70249944 </position>
    <velocity> -0.00012395 0.00026479 0.00009351 </velocity>
    <force> -0.01371370 -0.02741189 -0.00898858 </force>
  </atom>
  <atom name="O49" species="oxygen">
    <position> -39.01876685 2.28943452 -24.17094618 </position>
    <velocity> -0.00017543 0.00029185 -0.00011293 </velocity>
    <force> 0.00118381 0.00841048 0.00341623 </force>
  </atom>
  <atom name="O50" species="oxygen">
    <position> 32.37097510 16.01546964 -3.14319745 </position>
    <velocity> 0.00009554 -0.00009792 -0.00011087 </velocity>
    <force> -0.00447936 0.01586785 -0.02045003 </force>
  </atom>
  <atom name="O51" species="oxygen">
    <position> 11.41950774 4.03963238 -6.13532490 </position>
    <velocity> -0.00027745 -0.00013783 0.00003076 </velocity>
    <force> 0.03161195 0.02309991 0.01045205 </force>
  </atom>
  <atom name="O52" species="oxygen">
    <position> -2.00726609 2.73881292 18.12641735 </position>
    <velocity> 0.00009723 -0.00028508 0.00009961 </velocity>
    <force> 0.00305611 -0.00633344 -0.02044014 </force>
  </atom>
  <atom name="O53" species="oxygen">
    <position> 19.90791953 -10.34381207 -6.94163309 </position>
    <velocity> 0.00004223 0.00030052 -0.00023282 </velocity>
    <force> 0.01460175 0.02789222 -0.04332127 </force>
  </atom>
  <atom name="O54" species="oxygen">
    <position> 0.07293669 -8.55813391 12.56383693 </position>
    <velocity> -0.00023401 -0.00002456 -0.00019448 </velocity>
    <force> -0.03177198 -0.01809270 0.01545528 </force>
  </atom>
  <atom name="O55" species="oxygen">
    <position> 18.01942075 -3.35004874 -0.57174591 </position>
    <velocity> 0.00000293 -0.00010904 -0.00000677 </velocity>
    <force> -0.01131646 -0.00330073 0.01267794 </force>
  </atom>
  <atom name="O56" species="oxygen">
    <position> 23.49990051 -5.35547828 17.34451837 </position>
    <velocity> 0.00026962 -0.00031541 0.00000800 </velocity>
    <force> 0.00272965 0.00937544 0.00439193 </force>
  </atom>
  <atom name="O57" species="oxygen">
    <position> 2.67738475 32.49137080 -24.49757479 </position>
    <velocity> 0.00008795 -0.00017993 0.00007550 </velocity>
    <force> 0.01363804 0.03335798 0.00251759 </force>
  </atom>
  <atom name="O58" species="oxygen">
    <position> 5.18902487 1.41220069 -14.61484799 </position>
    <velocity> -0.00016095 0.00007984 0.00011208 </velocity>
    <force> 0.05347889 0.01260764 0.01828849 </force>
  </atom>
  <atom name="O59" species="oxygen">
    <position> -2.11586701 -15.85396428 -22.91990179 </position>
    <velocity> 0.00019782 -0.00012659 -0.00002937 </velocity>
    <force> -0.02090373 0.05310878 -0.02172608 </force>
  </atom>
  <atom name="O60" species="oxygen">
    <position> -27.36656162 -13.21227906 10.47519120 </position>
    <velocity> -0.00023023 -0.00021802 0.00005182 </velocity>
    <force> -0.02031223 0.01186683 -0.00248667 </force>
  </atom>
  <atom name="O61" species="oxygen">
    <position> -3.86617346 4.42003900 -15.45610732 </position>
    <velocity> -0.00016347 0.00014160 -0.00031048 </velocity>
    <force> 0.00002080 -0.00682990 0.01592884 </force>
  </atom>
  <atom name="O62" species="oxygen">
    <position> -6.02892743 -7.12590651 33.47308208 </position>
    <velocity> 0.00022958 -0.00012832 -0.00006150 </velocity>
    <force> -0.02870398 -0.02912893 -0.00210599 </force>
  </atom>
  <atom name="O63" species="oxygen">
    <position> -20.88273593 -8.14238763 31.67424996 </position>
    <velocity> -0.00028552 0.00003562 0.00025271 </velocity>
    <force> 0.00512686 0.01096918 0.00142042 </force>
  </atom>
  <atom name="O64" species="oxygen">
    <position> 12.28394914 6.56642081 25.70189546 </position>
    <velocity> 0.00029154 -0.00003579 0.00033402 </velocity>
    <force> -0.01013617 -0.00712484 -0.01044354 </force>
  </atom>
  <atom name="H1" species="hydrogen">
    <position> -5.91447931 7.18957751 13.81423572 </position>
    <velocity> -0.00024140 0.00072771 0.00044863 </velocity>
    <force> -0.02091733 -0.01718303 -0.01846290 </force>
  </atom>
  <atom name="H2" species="hydrogen">
    <position> -8.14493074 6.55296185 11.86788898 </position>
    <velocity> 0.00064690 -0.00073089 0.00044222 </velocity>
    <force> -0.01783385 0.01373661 0.00223905 </force>
  </atom>
  <atom name="H3" species="hydrogen">
    <position> 24.65643943 2.70115163 26.58544242 </position>
    <velocity> 0.00075463 0.00056977 -0.00079308 </velocity>
    <force> -0.00455237 0.01003012 -0.00518775 </force>
  </atom>
  <atom name="H4" species="hydrogen">
    <position> 22.03898946 1.40094598 26.47816242 </position>
    <velocity> -0.00065831 0.00014518 -0.00019044 </velocity>
    <force> 0.00101790 0.00721177 -0.01368078 </force>
  </atom>
  <atom name="H5" species="hydrogen">
    <position> -27.57462232 24.54186544 -31.89121949 </position>
    <velocity> -0.00074327 -0.00078928 0.00051190 </velocity>
    <force> -0.01091461 -0.00248083 -0.00115256 </force>
  </atom>
  <atom name="H6" species="hydrogen">
    <position> -27.79753272 23.84455906 -34.73322301 </position>
    <velocity> -0.00019825 -0.00018837 0.00062626 </velocity>
    <force> -0.01361053 -0.00413340 0.02107693 </force>
  </atom>
  <atom name="H7" species="hydrogen">
    <position> 12.64884566 -10.31410854 0.93678639 </position>
    <velocity> -0.00038598 -0.00010662 0.00136083 </velocity>
    <force> 0.00725053 0.01927419 -0.03003764 </force>
  </atom>
  <atom name="H8" species="hydrogen">
    <position> 11.72930182 -8.79258066 -1.71155072 </position>
    <velocity> 0.00015667 0.00034373 -0.00030316 </velocity>
    <force> -0.01284944 -0.00292024 0.00341007 </force>
  </atom>
  <atom name="H9" species="hydrogen">
    <position> 5.48562314 -21.02770733 -6.16489387 </position>
    <velocity> 0.00033679 -0.00034083 0.00016348 </velocity>
    <force> 0.00698271 -0.01834066 0.01021129 </force>
  </atom>
  <atom name="H10" species="hydrogen">
    <position> 6.92493700 -22.22960865 -3.78607531 </position>
    <velocity> 0.00021459 -0.00060907 0.00088114 </velocity>
    <force> -0.00721471 0.00561611 -0.01876836 </force>
  </atom>
  <atom name="H11" species="hydrogen">
    <position> 7.16520394 17.02103776 3.51240924 </position>
    <velocity> -0.00038590 0.00055522 -0.00085378 </velocity>
    <force> 0.01003194 0.00250726 0.00233534 </force>
  </atom>
  <atom name="H12" species="hydrogen">
    <position> 9.69143156 17.76257175 5.01240802 </position>
    <velocity> -0.00086278 0.00003916 0.00043855 </velocity>
    <force> -0.01226025 -0.00573205 -0.00080487 </force>
  </atom>
  <atom name="H13" species="hydrogen">
    <position> -4.26104823 -27.36835214 -18.74080232 </position>
    <velocity> 0.00082940 -0.00016694 0.00070767 </velocity>
    <force> -0.00701559 -0.01445305 0.02691569 </force>
  </atom>
  <atom name="H14" species="hydrogen">
    <position> -3.99638978 -30.10169188 -19.45111249 </position>
    <velocity> 0.00025077 0.00052655 0.00009609 </velocity>
    <force> 0.00958011 -0.02775847 -0.01655786 </force>
  </atom>
  <atom name="H15" species="hydrogen">
    <position> 1.58724758 -14.52689069 12.09015359 </position>
    <velocity> -0.00072610 -0.00034599 0.00077478 </velocity>
    <force> 0.00867407 -0.00430615 0.00949079 </force>
  </atom>
  <atom name="H16" species="hydrogen">
    <position> 4.52936081 -14.44419643 12.74825950 </position>
    <velocity> -0.00047540 0.00014468 0.00031527 </velocity>
    <force> -0.01500977 0.00115628 0.00748014 </force>
  </atom>
  <atom name="H17" species="hydrogen">
    <position> 2.42435127 5.99388691 -7.42171100 </position>
    <velocity> -0.00003012 0.00044468 0.00018965 </velocity>
    <force> -0.00417013 -0.00893109 0.00704125 </force>
  </atom>
  <atom name="H18" species="hydrogen">
    <position> 0.93414815 3.81263784 -5.74792554 </position>
    <velocity> 0.00049747 0.00225019 -0.00106027 </velocity>
    <force> -0.00199204 0.00915095 -0.01064447 </force>
  </atom>
  <atom name="H19" species="hydrogen">
    <position> -0.81117381 6.62526733 8.30614388 </position>
    <velocity> -0.00034381 0.00054706 0.00019400 </velocity>
    <force> -0.00989008 -0.01220597 0.00121841 </force>
  </atom>
  <atom name="H20" species="hydrogen">
    <position> -0.80854693 9.46485563 8.24675890 </position>
    <velocity> 0.00017840 -0.00011316 0.00008044 </velocity>
    <force> 0.01784578 -0.01910447 -0.00078207 </force>
  </atom>
  <atom name="H21" species="hydrogen">
    <position> 11.53195341 -15.14387185 10.57818920 </position>
    <velocity> -0.00004266 0.00025871 0.00002025 </velocity>
    <force> -0.00351762 -0.00137454 -0.00241012 </force>
  </atom>
  <atom name="H22" species="hydrogen">
    <position> 12.74545359 -13.12115693 12.18030671 </position>
    <velocity> -0.00024822 -0.00036266 0.00057134 </velocity>
    <force> -0.00012180 0.00812596 0.01343771 </force>
  </atom>
  <atom name="H23" species="hydrogen">
    <position> -12.41540942 -1.53426315 11.76894698 </position>
    <velocity> 0.00093394 -0.00089457 0.00072464 </velocity>
    <force> -0.00168705 0.01040126 -0.00196382 </force>
  </atom>
  <atom name="H24" species="hydrogen">
    <position> -12.37045864 -1.95264697 14.56062011 </position>
    <velocity> 0.00056756 -0.00023990 -0.00025721 </velocity>
    <force> 0.00521624 0.00375082 0.01890873 </force>
  </atom>
  <atom name="H25" species="hydrogen">
    <position> 0.50369434 -9.37585033 -21.33324048 </position>
    <velocity> 0.00028115 0.00006922 0.00024456 </velocity>
    <force> 0.00278874 -0.00103186 -0.00678061 </force>
  </atom>
  <atom name="H26" species="hydrogen">
    <position> 3.11721043 -8.31883349 -22.29283368 </position>
    <velocity> -0.00068918 0.00035330 -0.00039450 </velocity>
    <force> 0.00858621 0.00996094 -0.00308739 </force>
  </atom>
  <atom name="H27" species="hydrogen">
    <position> -7.07345500 -9.59252235 -2.48384439 </position>
    <velocity> 0.00106755 0.00041214 0.00020668 </velocity>
    <force> -0.01618234 -0.00182666 0.00156723 </force>
  </atom>
  <atom name="H28" species="hydrogen">
    <position> -4.59390205 -9.32847641 -4.20232701 </position>
    <velocity> 0.00056297 -0.00034459 0.00000272 </velocity>
    <force> -0.00156595 -0.00517661 0.00317252 </force>
  </atom>
  <atom name="H29" species="hydrogen">
    <position> 12.60523863 -13.64256452 3.62352383 </position>
    <velocity> 0.00050311 -0.00078851 -0.00073836 </velocity>
    <force> 0.00351691 -0.00396994 -0.00442546 </force>
  </atom>
  <atom name="H30" species="hydrogen">
    <position> 12.22002427 -11.49863912 5.52521789 </position>
    <velocity> 0.00129565 -0.00019353 -0.00080537 </velocity>
    <force> -0.01032072 0.00604412 0.01533719 </force>
  </atom>
  <atom name="H31" species="hydrogen">
    <position> -5.69110583 10.83471193 -7.18122204 </position>
    <velocity> -0.00002502 -0.00004988 -0.00138717 </velocity>
    <force> 0.00611084 0.00150632 0.00388268 </force>
  </atom>
  <atom name="H32" species="hydrogen">
    <position> -8.60548598 10.37355057 -7.33291893 </position>
    <velocity> -0.00069163 0.00082788 -0.00048941 </velocity>
    <force> -0.01098843 0.00265391 0.00211716 </force>
  </atom>
  <atom name="H33" species="hydrogen">
    <position> -14.98288344 -13.87983709 -28.97714675 </position>
    <velocity> -0.00096840 0.00067438 0.00050091 </velocity>
    <force> -0.00079685 0.00340059 0.01386453 </force>
  </atom>
  <atom name="H34" species="hydrogen">
    <position> -13.04375918 -15.95314012 -28.78088943 </position>
    <velocity> 0.00023155 0.00043332 -0.00093211 </velocity>
    <force> 0.00754952 -0.01323323 0.00440802 </force>
  </atom>
  <atom name="H35" species="hydrogen">
    <position> -20.43651888 -0.94737412 14.67766005 </position>
    <velocity> -0.00005201 -0.00016472 0.00025548 </velocity>
    <force> -0.00291497 -0.00598763 -0.00809948 </force>
  </atom>
  <atom name="H36" species="hydrogen">
    <position> -18.16091112 -2.61569613 14.49051169 </position>
    <velocity> -0.00030188 0.00027085 0.00024125 </velocity>
    <force> 0.02002326 -0.00196105 0.00063003 </force>
  </atom>
  <atom name="H37" species="hydrogen">
    <position> 5.62361560 -15.55377580 0.42212440 </position>
    <velocity> -0.00015482 0.00036927 0.00163267 </velocity>
    <force> 0.00730903 -0.00508983 -0.01134014 </force>
  </atom>
  <atom name="H38" species="hydrogen">
    <position> 8.15683514 -15.38385777 -1.33569517 </position>
    <velocity> -0.00021748 -0.00033537 -0.00028759 </velocity>
    <force> -0.01209044 -0.00688953 0.00902451 </force>
  </atom>
  <atom name="H39" species="hydrogen">
    <position> 5.53910294 19.57226294 -23.08897847 </position>
    <velocity> -0.00011073 -0.00010790 -0.00001688 </velocity>
    <force> -0.00390076 -0.00747011 0.00871390 </force>
  </atom>
  <atom name="H40" species="hydrogen">
    <position> 6.90249521 17.33838827 -24.47963969 </position>
    <velocity> -0.00046478 -0.00017479 0.00012970 </velocity>
    <force> 0.00880303 -0.01264502 -0.00071292 </force>
  </atom>
  <atom name="H41" species="hydrogen">
    <position> 3.78325696 1.89144155 11.41608074 </position>
    <velocity> 0.00056206 0.00015033 0.00001392 </velocity>
    <force> -0.00336960 -0.00297109 -0.00467960 </force>
  </atom>
  <atom name="H42" species="hydrogen">
    <position> 3.02745724 2.87169806 14.19563640 </position>
    <velocity> -0.00065067 -0.00033612 -0.00026732 </velocity>
    <force> -0.01263013 0.00151118 0.00035888 </force>
  </atom>
  <atom name="H43" species="hydrogen">
    <position> -8.60976592 -5.43897069 3.42761752 </position>
    <velocity> -0.00009624 -0.00077139 0.00044117 </velocity>
    <force> 0.02771599 -0.00223917 0.02535974 </force>
  </atom>
  <atom name="H44" species="hydrogen">
    <position> -9.89217553 -6.48300506 1.08576987 </position>
    <velocity> 0.00110387 0.00147249 0.00029265 </velocity>
    <force> -0.00905303 0.01474597 0.00571680 </force>
  </atom>
  <atom name="H45" species="hydrogen">
    <position> -12.85585017 -9.32093381 8.48207578 </position>
    <velocity> 0.00066013 0.00023332 -0.00026657 </velocity>
    <force> 0.00124451 -0.00593730 0.00684881 </force>
  </atom>
  <atom name="H46" species="hydrogen">
    <position> -14.71198394 -9.56918686 6.42449159 </position>
    <velocity> 0.00058156 -0.00015546 0.00032883 </velocity>
    <force> -0.00201564 -0.00375484 0.00485385 </force>
  </atom>
  <atom name="H47" species="hydrogen">
    <position> 16.74085439 -13.08513591 4.55898096 </position>
    <velocity> 0.00015134 -0.00098673 0.00050394 </velocity>
    <force> -0.00688417 0.01428501 -0.00895045 </force>
  </atom>
  <atom name="H48" species="hydrogen">
    <position> 18.61101843 -14.70723375 5.72786009 </position>
    <velocity> 0.00070902 0.00003540 -0.00062171 </velocity>
    <force> 0.01679782 -0.01946586 0.01907877 </force>
  </atom>
  <atom name="H49" species="hydrogen">
    <position> 19.91184136 12.97667107 3.17771092 </position>
    <velocity> -0.00025095 0.00074047 -0.00065020 </velocity>
    <force> 0.00385877 0.00436386 -0.00362603 </force>
  </atom>
  <atom name="H50" species="hydrogen">
    <position> 19.35184572 14.26510405 0.54421621 </position>
    <velocity> 0.00023183 -0.00023694 -0.00002681 </velocity>
    <force> 0.01312163 0.00001766 -0.00136472 </force>
  </atom>
  <atom name="H51" species="hydrogen">
    <position> 6.79320496 14.28698620 -31.55948428 </position>
    <velocity> 0.00058713 0.00061718 0.00008165 </velocity>
    <force> 0.00101530 -0.01117475 0.00259820 </force>
  </atom>
  <atom name="H52" species="hydrogen">
    <position> 4.87799561 12.86332698 -29.85992047 </position>
    <velocity> -0.00045742 0.00068346 -0.00077269 </velocity>
    <force> -0.01868374 -0.00443098 0.00215065 </force>
  </atom>
  <atom name="H53" species="hydrogen">
    <position> 14.70155048 -22.31231538 -10.23719974 </position>
    <velocity> -0.00033569 0.00000735 0.00030499 </velocity>
    <force> -0.03561404 0.01837192 0.00461053 </force>
  </atom>
  <atom name="H54" species="hydrogen">
    <position> 12.57596922 -20.67008572 -8.70368661 </position>
    <velocity> 0.00104859 -0.00015706 0.00057293 </velocity>
    <force> 0.00088304 -0.00572160 -0.00513597 </force>
  </atom>
  <atom name="H55" species="hydrogen">
    <position> 11.28120727 2.73528402 -15.92362402 </position>
    <velocity> -0.00061268 0.00097185 -0.00071021 </velocity>
    <force> -0.00158094 -0.01043691 -0.02272473 </force>
  </atom>
  <atom name="H56" species="hydrogen">
    <position> 12.02660285 3.26654270 -13.26326951 </position>
    <velocity> 0.00018617 -0.00080190 0.00002990 </velocity>
    <force> -0.01820649 0.00342474 0.01088067 </force>
  </atom>
  <atom name="H57" species="hydrogen">
    <position> -4.01757718 7.08006264 -2.12681334 </position>
    <velocity> -0.00074947 -0.00061919 -0.00076618 </velocity>
    <force> 0.01055955 0.01390615 0.01925439 </force>
  </atom>
  <atom name="H58" species="hydrogen">
    <position> -6.14041577 7.61443277 -4.45071154 </position>
    <velocity> -0.00060216 -0.00029397 -0.00054680 </velocity>
    <force> 0.02067382 0.00570228 0.00079876 </force>
  </atom>
  <atom name="H59" species="hydrogen">
    <position> -10.39944745 -1.62856982 23.49625080 </position>
    <velocity> 0.00056460 0.00032499 -0.00069126 </velocity>
    <force> 0.00574921 -0.02140948 0.01180577 </force>
  </atom>
  <atom name="H60" species="hydrogen">
    <position> -9.36563370 0.72913764 22.03064492 </position>
    <velocity> 0.00028013 0.00016054 -0.00041940 </velocity>
    <force> -0.03089564 -0.01702137 -0.00528916 </force>
  </atom>
  <atom name="H61" species="hydrogen">
    <position> 5.45340356 0.45161719 0.69284161 </position>
    <velocity> 0.00134888 0.00044889 0.00009110 </velocity>
    <force> 0.01751746 0.01912274 -0.00812260 </force>
  </atom>
  <atom name="H62" species="hydrogen">
    <position> 4.13675126 -1.16554486 2.82747420 </position>
    <velocity> -0.00039199 0.00048006 -0.00004757 </velocity>
    <force> 0.00669005 -0.00533547 -0.01992160 </force>
  </atom>
  <atom name="H63" species="hydrogen">
    <position> 23.70034463 -0.33537572 -0.29579026 </position>
    <velocity> -0.00014370 0.00043335 -0.00024334 </velocity>
    <force> -0.02311040 0.00633257 -0.03456106 </force>
  </atom>
  <atom name="H64" species="hydrogen">
    <position> 23.60518482 -2.09974407 -2.57568706 </position>
    <velocity> -0.00068294 0.00088764 -0.00034160 </velocity>
    <force> 0.01938105 -0.03434106 -0.02328700 </force>
  </atom>
  <atom name="H65" species="hydrogen">
    <position> -0.43808049 21.66057269 8.81035520 </position>
    <velocity> 0.00056833 -0.00015865 0.00012205 </velocity>
    <force> -0.00456414 -0.00563844 -0.00867162 </force>
  </atom>
  <atom name="H66" species="hydrogen">
    <position> 0.14766059 23.52020757 10.78233150 </position>
    <velocity> 0.00056671 -0.00030170 0.00018600 </velocity>
    <force> 0.05686284 0.02981098 0.05340391 </force>
  </atom>
  <atom name="H67" species="hydrogen">
    <position> -12.43619901 -1.82282651 19.30737941 </position>
    <velocity> -0.00024139 -0.00016762 0.00053166 </velocity>
    <force> 0.01589245 0.00392338 0.01907288 </force>
  </atom>
  <atom name="H68" species="hydrogen">
    <position> -14.85898522 -1.69632187 17.82118350 </position>
    <velocity> 0.00006270 0.00036873 -0.00092565 </velocity>
    <force> -0.01011042 0.00291472 -0.00827184 </force>
  </atom>
  <atom name="H69" species="hydrogen">
    <position> 4.64215792 -1.22709463 -16.23148489 </position>
    <velocity> 0.00012187 -0.00096863 0.00078395 </velocity>
    <force> -0.01899328 -0.00810928 -0.03774329 </force>
  </atom>
  <atom name="H70" species="hydrogen">
    <position> 5.29093480 -3.79927488 -17.33699994 </position>
    <velocity> 0.00040325 0.00041899 0.00041819 </velocity>
    <force> -0.00753192 0.00657832 -0.02032012 </force>
  </atom>
  <atom name="H71" species="hydrogen">
    <position> 8.00997000 8.52095054 -40.40807316 </position>
    <velocity> -0.00071974 -0.00044051 0.00029963 </velocity>
    <force> -0.00062634 -0.00950671 0.00044538 </force>
  </atom>
  <atom name="H72" species="hydrogen">
    <position> 8.52690673 5.89979913 -39.06462244 </position>
    <velocity> 0.00035104 -0.00057269 -0.00073789 </velocity>
    <force> 0.00874347 -0.00119202 0.00213483 </force>
  </atom>
  <atom name="H73" species="hydrogen">
    <position> -10.42027998 -2.64877934 7.06182524 </position>
    <velocity> -0.00069479 0.00064778 0.00056402 </velocity>
    <force> -0.00712737 0.01788311 -0.02021693 </force>
  </atom>
  <atom name="H74" species="hydrogen">
    <position> -10.90338036 -2.22055218 4.06179567 </position>
    <velocity> -0.00007384 0.00010332 -0.00036800 </velocity>
    <force> 0.00392546 0.01604048 0.03552340 </force>
  </atom>
  <atom name="H75" species="hydrogen">
    <position> 2.02015200 10.79072208 18.91998133 </position>
    <velocity> 0.00008702 0.00010501 -0.00103000 </velocity>
    <force> -0.01002943 0.00302079 0.00625984 </force>
  </atom>
  <atom name="H76" species="hydrogen">
    <position> 2.04302697 10.52191009 16.04204024 </position>
    <velocity> 0.00008751 -0.00023963 0.00123263 </velocity>
    <force> -0.00749415 0.00993676 -0.00691732 </force>
  </atom>
  <atom name="H77" species="hydrogen">
    <position> 8.46660439 10.55774201 -10.10408002 </position>
    <velocity> -0.00049730 0.00006563 0.00044831 </velocity>
    <force> -0.00014719 0.01031964 -0.00615994 </force>
  </atom>
  <atom name="H78" species="hydrogen">
    <position> 7.91526689 11.13650314 -13.06681967 </position>
    <velocity> -0.00177280 -0.00135844 0.00069172 </velocity>
    <force> 0.00609669 0.00311832 0.00877216 </force>
  </atom>
  <atom name="H79" species="hydrogen">
    <position> -17.64747609 -7.65097127 11.16177746 </position>
    <velocity> 0.00110281 0.00054296 0.00055849 </velocity>
    <force> -0.00692501 0.00102621 -0.00569926 </force>
  </atom>
  <atom name="H80" species="hydrogen">
    <position> -15.86018597 -5.72254143 12.60130187 </position>
    <velocity> -0.00122700 -0.00080725 -0.00079587 </velocity>
    <force> -0.00167729 -0.01571911 -0.00317056 </force>
  </atom>
  <atom name="H81" species="hydrogen">
    <position> 15.97310032 4.79118021 -2.71831409 </position>
    <velocity> 0.00051306 0.00028071 -0.00010256 </velocity>
    <force> -0.01538009 -0.00739509 0.00081280 </force>
  </atom>
  <atom name="H82" species="hydrogen">
    <position> 13.70247688 5.01233954 -0.81648811 </position>
    <velocity> 0.00004640 0.00122859 0.00057187 </velocity>
    <force> -0.00485886 0.00688109 0.01296001 </force>
  </atom>
  <atom name="H83" species="hydrogen">
    <position> -7.90950564 17.27031618 15.74797919 </position>
    <velocity> 0.00071705 0.00162855 0.00000365 </velocity>
    <force> 0.01040523 0.01540991 0.00083954 </force>
  </atom>
  <atom name="H84" species="hydrogen">
    <position> -10.51835845 18.20636713 16.95075603 </position>
    <velocity> -0.00002617 -0.00083689 -0.00029598 </velocity>
    <force> 0.00161204 -0.00217538 -0.00345336 </force>
  </atom>
  <atom name="H85" species="hydrogen">
    <position> -4.93911783 -3.08874449 -9.14679497 </position>
    <velocity> -0.00000197 -0.00004888 -0.00019892 </velocity>
    <force> -0.00572398 0.03409944 -0.01171941 </force>
  </atom>
  <atom name="H86" species="hydrogen">
    <position> -3.73055690 -4.76249337 -7.20095760 </position>
    <velocity> 0.00026531 0.00018921 0.00065246 </velocity>
    <force> 0.01131338 -0.00569910 0.00578601 </force>
  </atom>
  <atom name="H87" species="hydrogen">
    <position> -12.20828174 -11.40338500 17.10136200 </position>
    <velocity> 0.00067761 0.00048991 -0.00076298 </velocity>
    <force> -0.01102470 0.00193211 0.02011573 </force>
  </atom>
  <atom name="H88" species="hydrogen">
    <position> -10.33036498 -9.52678895 15.56689654 </position>
    <velocity> 0.00059398 0.00084253 -0.00024453 </velocity>
    <force> -0.02018086 -0.01506009 0.01223261 </force>
  </atom>
  <atom name="H89" species="hydrogen">
    <position> -8.59524183 25.04916846 5.30680500 </position>
    <velocity> -0.00015596 -0.00033329 -0.00023351 </velocity>
    <force> -0.00535461 -0.00724758 -0.00072515 </force>
  </atom>
  <atom name="H90" species="hydrogen">
    <position> -6.38105489 26.97664002 6.10577174 </position>
    <velocity> -0.00079081 -0.00122077 0.00090289 </velocity>
    <force> -0.01769726 -0.00738674 -0.03021821 </force>
  </atom>
  <atom name="H91" species="hydrogen">
    <position> 11.95227280 -4.94190828 -12.88706910 </position>
    <velocity> -0.00031474 0.00042153 0.00039527 </velocity>
    <force> 0.02221782 -0.00715060 -0.03699193 </force>
  </atom>
  <atom name="H92" species="hydrogen">
    <position> 14.51021273 -6.34934303 -14.04971110 </position>
    <velocity> 0.00021867 -0.00040510 -0.00032348 </velocity>
    <force> -0.02264705 0.02947128 -0.00885810 </force>
  </atom>
  <atom name="H93" species="hydrogen">
    <position> -3.95971241 -2.24398649 2.05733945 </position>
    <velocity> -0.00059532 -0.00071473 0.00000982 </velocity>
    <force> -0.00503332 0.01607141 -0.00521612 </force>
  </atom>
  <atom name="H94" species="hydrogen">
    <position> -5.30267405 -0.06246776 3.49513546 </position>
    <velocity> 0.00056853 -0.00175446 0.00001738 </velocity>
    <force> -0.03831225 0.02435307 0.00210819 </force>
  </atom>
  <atom name="H95" species="hydrogen">
    <position> -18.52597436 -18.02852721 -18.01912361 </position>
    <velocity> -0.00039723 0.00063781 0.00061088 </velocity>
    <force> 0.02494264 0.01279666 -0.00697791 </force>
  </atom>
  <atom name="H96" species="hydrogen">
    <position> -21.02543881 -17.41417341 -16.89064928 </position>
    <velocity> 0.00034857 -0.00043654 -0.00036430 </velocity>
    <force> -0.01353801 0.01254579 0.00586566 </force>
  </atom>
  <atom name="H97" species="hydrogen">
    <position> -38.78017138 4.07964056 -23.58506126 </position>
    <velocity> -0.00029660 0.00047442 -0.00021542 </velocity>
    <force> -0.01749811 -0.00168267 -0.00925535 </force>
  </atom>
  <atom name="H98" species="hydrogen">
    <position> -37.37980059 1.48879525 -23.99525624 </position>
    <velocity> 0.00018011 0.00062469 -0.00075884 </velocity>
    <force> 0.01323492 -0.01159750 0.00032674 </force>
  </atom>
  <atom name="H99" species="hydrogen">
    <position> 32.74780671 17.66742021 -4.09792450 </position>
    <velocity> 0.00006579 -0.00000632 0.00102256 </velocity>
    <force> -0.00374562 -0.01748860 0.01057506 </force>
  </atom>
  <atom name="H100" species="hydrogen">
    <position> 31.18581071 15.01837400 -4.27963380 </position>
    <velocity> 0.00047519 -0.00055181 0.00018592 </velocity>
    <force> 0.01538580 0.00292981 0.00438987 </force>
  </atom>
  <atom name="H101" species="hydrogen">
    <position> 9.85216995 3.27035576 -5.89334649 </position>
    <velocity> -0.00013421 0.00078971 -0.00073500 </velocity>
    <force> -0.05196356 -0.02516696 -0.00483201 </force>
  </atom>
  <atom name="H102" species="hydrogen">
    <position> 12.16263462 3.83269640 -4.36607173 </position>
    <velocity> 0.00119463 0.00034049 -0.00099489 </velocity>
    <force> 0.01406127 0.00834053 -0.01672457 </force>
  </atom>
  <atom name="H103" species="hydrogen">
    <position> -3.40216586 3.85417904 18.63450765 </position>
    <velocity> -0.00038775 -0.00085842 0.00027130 </velocity>
    <force> 0.00241507 0.01075347 0.00650278 </force>
  </atom>
  <atom name="H104" species="hydrogen">
    <position> -1.50883342 1.66525248 19.55701942 </position>
    <velocity> 0.00027779 0.00067500 -0.00091760 </velocity>
    <force> -0.00351727 -0.00932884 0.00779471 </force>
  </atom>
  <atom name="H105" species="hydrogen">
    <position> 21.74795593 -10.89039859 -6.92476059 </position>
    <velocity> 0.00043446 0.00068952 -0.00019504 </velocity>
    <force> -0.01119689 0.00228768 0.00358004 </force>
  </atom>
  <atom name="H106" species="hydrogen">
    <position> 19.80613193 -9.19259620 -8.53621950 </position>
    <velocity> 0.00057256 -0.00024902 0.00066310 </velocity>
    <force> 0.00756682 -0.02674758 0.03595623 </force>
  </atom>
  <atom name="H107" species="hydrogen">
    <position> 0.95541023 -8.55447412 10.97624186 </position>
    <velocity> -0.00059152 0.00069491 -0.00026271 </velocity>
    <force> 0.01348543 0.00996353 -0.01057611 </force>
  </atom>
  <atom name="H108" species="hydrogen">
    <position> 0.74652922 -7.45788280 13.84293998 </position>
    <velocity> 0.00066740 -0.00041866 -0.00011709 </velocity>
    <force> 0.00984039 0.01203236 0.00140461 </force>
  </atom>
  <atom name="H109" species="hydrogen">
    <position> 18.14027342 -5.06160555 -1.19991223 </position>
    <velocity> -0.00008846 -0.00030056 -0.00020972 </velocity>
    <force> -0.00163032 -0.01466608 -0.00517089 </force>
  </atom>
  <atom name="H110" species="hydrogen">
    <position> 19.16961258 -2.39653472 -1.58623027 </position>
    <velocity> -0.00025121 -0.00039894 -0.00017470 </velocity>
    <force> 0.01922228 0.01362339 -0.01464103 </force>
  </atom>
  <atom name="H111" species="hydrogen">
    <position> 24.00582934 -6.69532660 18.48099823 </position>
    <velocity> -0.00050496 -0.00066724 0.00052774 </velocity>
    <force> 0.00106803 -0.00590792 0.00332274 </force>
  </atom>
  <atom name="H112" species="hydrogen">
    <position> 25.02719209 -4.25424795 17.13595051 </position>
    <velocity> 0.00022658 0.00056994 0.00043846 </velocity>
    <force> -0.00503127 -0.00670507 -0.00907914 </force>
  </atom>
  <atom name="H113" species="hydrogen">
    <position> 2.29814799 34.12224248 -23.58542290 </position>
    <velocity> 0.00017258 0.00020532 -0.00009820 </velocity>
    <force> 0.01169024 -0.00537180 -0.00381538 </force>
  </atom>
  <atom name="H114" species="hydrogen">
    <position> 1.14589081 31.61645711 -24.08591172 </position>
    <velocity> 0.00013954 -0.00017231 -0.00022024 </velocity>
    <force> -0.02242907 -0.01714335 0.00301848 </force>
  </atom>
  <atom name="H115" species="hydrogen">
    <position> 6.93923370 1.88589423 -13.85235100 </position>
    <velocity> 0.00063530 -0.00018698 0.00007727 </velocity>
    <force> -0.03068804 -0.01297505 -0.02318159 </force>
  </atom>
  <atom name="H116" species="hydrogen">
    <position> 4.72527821 2.91858615 -15.74161677 </position>
    <velocity> 0.00014331 -0.00059402 0.00061150 </velocity>
    <force> -0.01069221 -0.00743351 -0.00062908 </force>
  </atom>
  <atom name="H117" species="hydrogen">
    <position> -3.35303171 -14.76763330 -21.97199395 </position>
    <velocity> 0.00053356 0.00054726 0.00092332 </velocity>
    <force> 0.01501097 -0.01233256 0.00059840 </force>
  </atom>
  <atom name="H118" species="hydrogen">
    <position> -1.95706600 -17.39117432 -22.06537274 </position>
    <velocity> -0.00052558 -0.00113224 0.00035272 </velocity>
    <force> 0.00619244 -0.04702520 0.02673159 </force>
  </atom>
  <atom name="H119" species="hydrogen">
    <position> -29.02538156 -14.00122520 10.83780723 </position>
    <velocity> 0.00050000 0.00008905 -0.00123278 </velocity>
    <force> 0.01249030 -0.01145768 -0.00035597 </force>
  </atom>
  <atom name="H120" species="hydrogen">
    <position> -28.01083459 -11.51263848 10.10641428 </position>
    <velocity> 0.00082968 0.00024335 0.00089519 </velocity>
    <force> 0.01052053 0.00647278 -0.00022143 </force>
  </atom>
  <atom name="H121" species="hydrogen">
    <position> -4.59401330 4.82690305 -13.74027336 </position>
    <velocity> -0.00069396 0.00041343 -0.00042736 </velocity>
    <force> -0.00223154 0.00488962 -0.00475019 </force>
  </atom>
  <atom name="H122" species="hydrogen">
    <position> -2.97676556 2.79958225 -15.15242131 </position>
    <velocity> -0.00029211 0.00013047 0.00009876 </velocity>
    <force> 0.00132743 0.00129956 -0.00358868 </force>
  </atom>
  <atom name="H123" species="hydrogen">
    <position> -5.15572374 -7.00605891 31.86757078 </position>
    <velocity> -0.00063952 0.00050087 0.00089072 </velocity>
    <force> 0.01077700 0.01285813 -0.01529495 </force>
  </atom>
  <atom name="H124" species="hydrogen">
    <position> -5.05290438 -6.41532092 34.79708666 </position>
    <velocity> 0.00001550 0.00089459 0.00003204 </velocity>
    <force> 0.01679690 0.01327747 0.01978898 </force>
  </atom>
  <atom name="H125" species="hydrogen">
    <position> -20.96841133 -9.19424008 30.20285393 </position>
    <velocity> 0.00017290 -0.00082368 0.00041753 </velocity>
    <force> 0.00087827 -0.02071318 -0.01468693 </force>
  </atom>
  <atom name="H126" species="hydrogen">
    <position> -20.87675474 -6.50676693 30.82998792 </position>
    <velocity> 0.00031461 0.00020682 0.00045224 </velocity>
    <force> -0.00146628 0.01083042 0.00516242 </force>
  </atom>
  <atom name="H127" species="hydrogen">
    <position> 10.47882455 6.05775179 25.15091228 </position>
    <velocity> 0.00083789 -0.00094988 -0.00050568 </velocity>
    <force> 0.03233901 0.01107748 0.02583181 </force>
  </atom>
  <atom name="H128" species="hydrogen">
    <position> 13.27521667 5.38710374 26.82880631 </position>
    <velocity> 0.00070282 -0.00041994 -0.00065710 </velocity>
    <force> -0.01721795 0.00015133 -0.01123162 </force>
  </atom>
</atomset>
<unit_cell_a_norm> 23.460000 </unit_cell_a_norm>
<unit_cell_b_norm> 23.460000 </unit_cell_b_norm>
<unit_cell_c_norm> 23.460000 </unit_cell_c_norm>
<unit_cell_alpha>  90.000 </unit_cell_alpha>
<unit_cell_beta>   90.000 </unit_cell_beta>
<unit_cell_gamma>  90.000 </unit_cell_gamma>
<unit_cell_volume> 12911.718 </unit_cell_volume>
  <econst> -1100.15108916 </econst>
  <ekin_ion> 0.37046756 </ekin_ion>
  <temp_ion> 406.21590729 </temp_ion>
  total_electronic_charge: 512.00000000
  <eigenvalue_sum>  -162.40272378 </eigenvalue_sum>
  <etotal_int>   -1100.48868651 </etotal_int>
  total_electronic_charge: 512.00000000
  <eigenvalue_sum>  -162.39032613 </eigenvalue_sum>
  Anderson extrapolation: theta=1.24744043 (1.24744043)
  <etotal_int>   -1100.50715683 </etotal_int>
  total_electronic_charge: 512.00000000
  <eigenvalue_sum>  -162.36645321 </eigenvalue_sum>
  Anderson extrapolation: theta=0.06450144 (0.06450144)
  <etotal_int>   -1100.51871005 </etotal_int>
  total_electronic_charge: 512.00000000
  <eigenvalue_sum>  -162.36489248 </eigenvalue_sum>
  Anderson extrapolation: theta=1.56090805 (1.56090805)
  <etotal_int>   -1100.51928309 </etotal_int>
  total_electronic_charge: 512.00000000
  <eigenvalue_sum>  -162.36212992 </eigenvalue_sum>
  Anderson extrapolation: theta=0.15342786 (0.15342786)
  <etotal_int>   -1100.51966422 </etotal_int>
  <timing name="iteration" min="    5.087" max="    5.100"/>
</iteration>
<iteration count="2">
  total_electronic_charge: 512.00000000
  <ekin>       808.00750908 </ekin>
  <econf>        0.00000000 </econf>
  <eps>      -1308.59678764 </eps>
  <enl>        124.89407151 </enl>
  <ecoul>     -453.91984218 </ecoul>
  <exc>       -270.90464839 </exc>
  <esr>         93.00046856 </esr>
  <eself>      646.81841729 </eself>
  <ets>          0.00000000 </ets>
  <eexf>         0.00000000 </eexf>
  <etotal>   -1100.51969762 </etotal>
  <epv>          0.00000000 </epv>
  <eefield>      0.00000000 </eefield>
  <enthalpy> -1100.51969762 </enthalpy>
<atomset>
<unit_cell 
    a=" 23.46000000   0.00000000   0.00000000"
    b="  0.00000000  23.46000000   0.00000000"
    c="  0.00000000   0.00000000  23.46000000" />
  <atom name="O1" species="oxygen">
    <position> -6.48516915 6.01556468 12.38065159 </position>
    <velocity> -0.00017136 -0.00020142 0.00029531 </velocity>
    <force> 0.04557349 -0.00346033 0.02273907 </force>
  </atom>
  <atom name="O2" species="oxygen">
    <position> 23.13612016 2.61217214 25.49430752 </position>
    <velocity> -0.00000752 0.00006033 -0.00022459 </velocity>
    <force> 0.00292853 -0.00959062 0.01777811 </force>
  </atom>
  <atom name="O3" species="oxygen">
    <position> -28.79706730 23.73416145 -33.09591508 </position>
    <velocity> -0.00017180 0.00012866 -0.00012671 </velocity>
    <force> 0.02749519 0.00476123 -0.02088956 </force>
  </atom>
  <atom name="O4" species="oxygen">
    <position> 13.16429952 -9.21266845 -0.60301098 </position>
    <velocity> 0.00007822 -0.00023315 0.00008673 </velocity>
    <force> 0.00535326 -0.01822278 0.03181243 </force>
  </atom>
  <atom name="O5" species="oxygen">
    <position> 6.66881324 -22.47169437 -5.68496266 </position>
    <velocity> 0.00027180 -0.00000176 -0.00049111 </velocity>
    <force> 0.00043297 0.02212187 0.01843176 </force>
  </atom>
  <atom name="O6" species="oxygen">
    <position> 8.01967310 16.93129398 5.23584374 </position>
    <velocity> 0.00009165 -0.00023045 0.00035984 </velocity>
    <force> -0.00266485 0.00178451 -0.00978188 </force>
  </atom>
  <atom name="O7" species="oxygen">
    <position> -4.61502126 -29.13177965 -18.04313220 </position>
    <velocity> -0.00001751 0.00044812 -0.00028669 </velocity>
    <force> -0.00579690 0.04134365 -0.00006685 </force>
  </atom>
  <atom name="O8" species="oxygen">
    <position> 2.78422372 -14.69578910 13.53827348 </position>
    <velocity> -0.00006835 -0.00043847 0.00021970 </velocity>
    <force> 0.00793025 -0.00513103 -0.01464185 </force>
  </atom>
  <atom name="O9" species="oxygen">
    <position> 2.61075468 4.40035526 -6.44292541 </position>
    <velocity> -0.00031703 -0.00002234 -0.00039368 </velocity>
    <force> 0.01501551 0.01130222 -0.00617181 </force>
  </atom>
  <atom name="O10" species="oxygen">
    <position> 0.40926318 7.98737435 8.11864951 </position>
    <velocity> 0.00014865 0.00025925 0.00020985 </velocity>
    <force> -0.01327335 0.03367561 0.00841290 </force>
  </atom>
  <atom name="O11" species="oxygen">
    <position> 13.17773925 -14.43955696 10.99568721 </position>
    <velocity> -0.00006647 0.00009830 -0.00000097 </velocity>
    <force> 0.00017270 -0.00465434 -0.01088516 </force>
  </atom>
  <atom name="O12" species="oxygen">
    <position> -13.19520417 -2.55679248 13.06861974 </position>
    <velocity> 0.00027232 -0.00013772 -0.00011375 </velocity>
    <force> -0.01667706 -0.02515779 -0.02525605 </force>
  </atom>
  <atom name="O13" species="oxygen">
    <position> 2.32402499 -9.79429265 -21.54069238 </position>
    <velocity> -0.00011021 0.00039241 0.00012442 </velocity>
    <force> -0.01054769 -0.00685079 0.00811411 </force>
  </atom>
  <atom name="O14" species="oxygen">
    <position> -5.30239855 -9.16796494 -2.46068222 </position>
    <velocity> -0.00017683 0.00003420 -0.00033771 </velocity>
    <force> 0.01918739 0.01408112 0.00504046 </force>
  </atom>
  <atom name="O15" species="oxygen">
    <position> 13.31361765 -11.99131755 4.14524281 </position>
    <velocity> -0.00049586 -0.00029251 0.00020968 </velocity>
    <force> 0.01095690 -0.01523700 -0.02496792 </force>
  </atom>
  <atom name="O16" species="oxygen">
    <position> -6.98854658 9.50223834 -7.01953903 </position>
    <velocity> -0.00006414 0.00024659 -0.00007809 </velocity>
    <force> 0.00649002 -0.01328791 -0.00169807 </force>
  </atom>
  <atom name="O17" species="oxygen">
    <position> -13.79141841 -14.61580892 -27.73291486 </position>
    <velocity> -0.00000427 0.00010900 0.00021155 </velocity>
    <force> -0.01122548 0.01062286 -0.01672733 </force>
  </atom>
  <atom name="O18" species="oxygen">
    <position> -19.92631466 -2.75793918 14.85427734 </position>
    <velocity> -0.00021314 -0.00014747 0.00011727 </velocity>
    <force> -0.01826415 0.00326823 0.00562247 </force>
  </atom>
  <atom name="O19" species="oxygen">
    <position> 7.37790563 -16.22679497 0.19786684 </position>
    <velocity> -0.00034733 -0.00035022 0.00004977 </velocity>
    <force> 0.01085467 0.00532391 -0.00304353 </force>
  </atom>
  <atom name="O20" species="oxygen">
    <position> 5.89793529 17.68628249 -22.94977237 </position>
    <velocity> 0.00007751 -0.00013122 -0.00000925 </velocity>
    <force> -0.01088107 0.01199140 0.00569721 </force>
  </atom>
  <atom name="O21" species="oxygen">
    <position> 2.46109314 1.82328692 12.74421772 </position>
    <velocity> -0.00020752 0.00029228 -0.00013426 </velocity>
    <force> -0.00184151 0.00092768 0.00866826 </force>
  </atom>
  <atom name="O22" species="oxygen">
    <position> -9.90033704 -4.95070521 2.29290727 </position>
    <velocity> 0.00032525 0.00010561 -0.00031865 </velocity>
    <force> -0.01789744 -0.00975930 -0.02827613 </force>
  </atom>
  <atom name="O23" species="oxygen">
    <position> -13.81201045 -10.70554119 7.67469822 </position>
    <velocity> 0.00015311 0.00000807 -0.00036637 </velocity>
    <force> 0.00170999 0.01633837 -0.00906833 </force>
  </atom>
  <atom name="O24" species="oxygen">
    <position> 18.59263322 -13.36959275 4.52444004 </position>
    <velocity> 0.00034769 -0.00014814 -0.00004790 </velocity>
    <force> -0.01295506 0.00823432 -0.01529293 </force>
  </atom>
  <atom name="O25" species="oxygen">
    <position> 20.48602333 14.38372660 2.07273994 </position>
    <velocity> 0.00003120 -0.00050001 -0.00044364 </velocity>
    <force> -0.00766078 -0.00876127 -0.00285131 </force>
  </atom>
  <atom name="O26" species="oxygen">
    <position> 6.68707069 13.02275049 -30.12371192 </position>
    <velocity> -0.00001372 0.00020552 0.00016018 </velocity>
    <force> 0.01157210 0.01719936 -0.00866373 </force>
  </atom>
  <atom name="O27" species="oxygen">
    <position> 12.81836351 -21.72704049 -10.27957657 </position>
    <velocity> 0.00011726 -0.00027603 0.00012881 </velocity>
    <force> 0.04729526 -0.00946046 -0.00299626 </force>
  </atom>
  <atom name="O28" species="oxygen">
    <position> 10.66173558 3.71037560 -14.52874282 </position>
    <velocity> 0.00007241 0.00033129 -0.00024967 </velocity>
    <force> 0.01528238 -0.00017845 0.01995296 </force>
  </atom>
  <atom name="O29" species="oxygen">
    <position> -4.81803883 6.47964260 -3.64860677 </position>
    <velocity> 0.00004559 -0.00005656 0.00017446 </velocity>
    <force> -0.03983324 -0.01933279 -0.02961835 </force>
  </atom>
  <atom name="O30" species="oxygen">
    <position> -10.79961933 -0.60150300 22.05790627 </position>
    <velocity> 0.00034490 0.00006835 -0.00014369 </velocity>
    <force> 0.02006483 0.03605471 -0.01039682 </force>
  </atom>
  <atom name="O31" species="oxygen">
    <position> 4.41783802 -1.01597182 0.91517347 </position>
    <velocity> 0.00017441 0.00003544 0.00026365 </velocity>
    <force> -0.02159843 -0.01424034 0.02298536 </force>
  </atom>
  <atom name="O32" species="oxygen">
    <position> 22.69649048 -0.70949227 -1.96548652 </position>
    <velocity> -0.00009952 0.00006021 0.00039250 </velocity>
    <force> 0.00138733 0.02970486 0.05789966 </force>
  </atom>
  <atom name="O33" species="oxygen">
    <position> -1.15001359 23.06376622 9.74255811 </position>
    <velocity> -0.00000388 0.00011857 0.00004326 </velocity>
    <force> -0.05636783 -0.01727260 -0.04289241 </force>
  </atom>
  <atom name="O34" species="oxygen">
    <position> -13.42118218 -2.82152072 18.12937267 </position>
    <velocity> -0.00026768 0.00003803 0.00015333 </velocity>
    <force> -0.00216418 -0.01063792 -0.00323101 </force>
  </atom>
  <atom name="O35" species="oxygen">
    <position> 4.04994137 -2.42127986 -17.77573860 </position>
    <velocity> -0.00000885 -0.00009276 0.00007059 </velocity>
    <force> 0.02693785 0.00064750 0.06344458 </force>
  </atom>
  <atom name="O36" species="oxygen">
    <position> 7.53826784 6.72491500 -40.39524639 </position>
    <velocity> -0.00035225 -0.00006450 -0.00007272 </velocity>
    <force> 0.00021588 0.01782651 -0.00693464 </force>
  </atom>
  <atom name="O37" species="oxygen">
    <position> -10.79128957 -1.21987686 5.74297933 </position>
    <velocity> -0.00027356 0.00004258 0.00001186 </velocity>
    <force> 0.00123135 -0.02616963 -0.01000897 </force>
  </atom>
  <atom name="O38" species="oxygen">
    <position> 1.47747455 11.75037603 17.40211171 </position>
    <velocity> -0.00015422 0.00012687 0.00011440 </velocity>
    <force> 0.01357067 -0.01025653 0.00254053 </force>
  </atom>
  <atom name="O39" species="oxygen">
    <position> 7.69228212 9.92730521 -11.65386716 </position>
    <velocity> 0.00016796 0.00005570 0.00006752 </velocity>
    <force> -0.00732475 -0.01814341 0.00338716 </force>
  </atom>
  <atom name="O40" species="oxygen">
    <position> -16.37691487 -7.53033352 12.48002113 </position>
    <velocity> 0.00037802 0.00023936 0.00013625 </velocity>
    <force> 0.01518782 0.01376513 0.01237032 </force>
  </atom>
  <atom name="O41" species="oxygen">
    <position> 14.22068409 4.03443408 -2.28876882 </position>
    <velocity> -0.00014723 0.00009094 0.00014648 </velocity>
    <force> 0.03282830 0.00724549 0.00531619 </force>
  </atom>
  <atom name="O42" species="oxygen">
    <position> -9.68699643 16.85529156 16.00688573 </position>
    <velocity> -0.00015145 -0.00007797 0.00021450 </velocity>
    <force> -0.00625501 -0.01371430 -0.00219722 </force>
  </atom>
  <atom name="O43" species="oxygen">
    <position> -5.15417047 -4.69235124 -8.35464824 </position>
    <velocity> 0.00001397 0.00018869 -0.00014380 </velocity>
    <force> 0.00394622 -0.03265901 0.00827473 </force>
  </atom>
  <atom name="O44" species="oxygen">
    <position> -11.06516510 -11.34863869 15.71676267 </position>
    <velocity> -0.00017137 0.00032523 0.00032383 </velocity>
    <force> 0.02665887 0.02219627 -0.03945235 </force>
  </atom>
  <atom name="O45" species="oxygen">
    <position> -7.57083437 26.43449161 4.59411798 </position>
    <velocity> 0.00038592 -0.00027759 -0.00047308 </velocity>
    <force> 0.01967763 0.00942712 0.02713678 </force>
  </atom>
  <atom name="O46" species="oxygen">
    <position> 12.87439793 -5.28590202 -14.60649331 </position>
    <velocity> -0.00038855 -0.00011170 0.00018207 </velocity>
    <force> -0.00145705 -0.02125936 0.05223493 </force>
  </atom>
  <atom name="O47" species="oxygen">
    <position> -3.73717005 -0.89909439 3.38292175 </position>
    <velocity> 0.00038062 -0.00025150 -0.00027760 </velocity>
    <force> 0.04499856 -0.03820356 -0.00026587 </force>
  </atom>
  <atom name="O48" species="oxygen">
    <position> -20.14406978 -18.79753424 -17.70157975 </position>
    <velocity> -0.00012859 0.00025545 0.00009030 </velocity>
    <force> -0.01260641 -0.02850431 -0.01026702 </force>
  </atom>
  <atom name="O49" species="oxygen">
    <position> -39.02051912 2.29236744 -24.17206962 </position>
    <velocity> -0.00017529 0.00029537 -0.00011193 </velocity>
    <force> 0.00061225 0.01042800 0.00305342 </force>
  </atom>
  <atom name="O50" species="oxygen">
    <position> 32.37192282 16.01451764 -3.14434121 </position>
    <velocity> 0.00009422 -0.00009287 -0.00011786 </velocity>
    <force> -0.00377749 0.01413429 -0.01963809 </force>
  </atom>
  <atom name="O51" species="oxygen">
    <position> 11.41678743 4.03829368 -6.13499938 </position>
    <velocity> -0.00026661 -0.00012991 0.00003398 </velocity>
    <force> 0.03315610 0.02385031 0.00810989 </force>
  </atom>
  <atom name="O52" species="oxygen">
    <position> -2.00628855 2.73595126 18.12737841 </position>
    <velocity> 0.00009813 -0.00028722 0.00009209 </velocity>
    <force> 0.00164630 -0.00453000 -0.02394699 </force>
  </atom>
  <atom name="O53" species="oxygen">
    <position> 19.90836686 -10.34075905 -6.94403556 </position>
    <velocity> 0.00004762 0.00031041 -0.00024773 </velocity>
    <force> 0.01653953 0.02802105 -0.04225375 </force>
  </atom>
  <atom name="O54" species="oxygen">
    <position> 0.07054212 -8.55841053 12.56191863 </position>
    <velocity> -0.00024538 -0.00003069 -0.00018941 </velocity>
    <force> -0.03316477 -0.01748058 0.01520245 </force>
  </atom>
  <atom name="O55" species="oxygen">
    <position> 18.01943065 -3.35114480 -0.57179188 </position>
    <velocity> -0.00000100 -0.00011070 -0.00000241 </velocity>
    <force> -0.01159161 -0.00575660 0.01277445 </force>
  </atom>
  <atom name="O56" species="oxygen">
    <position> 23.50260139 -5.35861631 17.34460590 </position>
    <velocity> 0.00027132 -0.00031297 0.00000962 </velocity>
    <force> 0.00564881 0.00664116 0.00500909 </force>
  </atom>
  <atom name="O57" species="oxygen">
    <position> 2.67828763 32.48962869 -24.49681547 </position>
    <velocity> 0.00009290 -0.00016877 0.00007657 </velocity>
    <force> 0.01468118 0.03273157 0.00325632 </force>
  </atom>
  <atom name="O58" species="oxygen">
    <position> 5.18750705 1.41302070 -14.61369584 </position>
    <velocity> -0.00014259 0.00008401 0.00011900 </velocity>
    <force> 0.05445300 0.01122214 0.02139370 </force>
  </atom>
  <atom name="O59" species="oxygen">
    <position> -2.11392465 -15.85513913 -22.92023274 </position>
    <velocity> 0.00019096 -0.00010935 -0.00003612 </velocity>
    <force> -0.02021890 0.04809593 -0.01746058 </force>
  </atom>
  <atom name="O60" species="oxygen">
    <position> -27.36889874 -13.21443892 10.47570514 </position>
    <velocity> -0.00023694 -0.00021415 0.00005096 </velocity>
    <force> -0.01747777 0.01193340 -0.00284268 </force>
  </atom>
  <atom name="O61" species="oxygen">
    <position> -3.86780812 4.42144329 -15.45918481 </position>
    <velocity> -0.00016386 0.00013958 -0.00030559 </velocity>
    <force> -0.00137342 -0.00574473 0.01433819 </force>
  </atom>
  <atom name="O62" species="oxygen">
    <position> -6.02668084 -7.12723965 33.47246347 </position>
    <velocity> 0.00022001 -0.00013855 -0.00006119 </velocity>
    <force> -0.02839654 -0.02972319 0.00426122 </force>
  </atom>
  <atom name="O63" species="oxygen">
    <position> -20.88558234 -8.14201262 31.67677950 </position>
    <velocity> -0.00028445 0.00003931 0.00025354 </velocity>
    <force> 0.00274736 0.01034485 0.00194258 </force>
  </atom>
  <atom name="O64" species="oxygen">
    <position> 12.28684716 6.56605070 25.70521776 </position>
    <velocity> 0.00028867 -0.00003825 0.00033104 </velocity>
    <force> -0.00825274 -0.00702837 -0.00884783 </force>
  </atom>
  <atom name="H1" species="hydrogen">
    <position> -5.91717819 7.19662059 13.81847057 </position>
    <velocity> -0.00029940 0.00067991 0.00039679 </velocity>
    <force> -0.02145414 -0.01840308 -0.01988457 </force>
  </atom>
  <atom name="H2" species="hydrogen">
    <position> -8.13870462 6.54584003 11.87234167 </position>
    <velocity> 0.00059291 -0.00069242 0.00044684 </velocity>
    <force> -0.02223973 0.01500985 0.00083205 </force>
  </atom>
  <atom name="H3" species="hydrogen">
    <position> 24.66392373 2.70698593 26.57744097 </position>
    <velocity> 0.00074076 0.00059709 -0.00080861 </velocity>
    <force> -0.00616489 0.00959549 -0.00563526 </force>
  </atom>
  <atom name="H4" species="hydrogen">
    <position> 22.03242022 1.40249600 26.47607170 </position>
    <velocity> -0.00065441 0.00016592 -0.00022839 </velocity>
    <force> 0.00232040 0.00789817 -0.01401960 </force>
  </atom>
  <atom name="H5" species="hydrogen">
    <position> -27.58220367 24.53393885 -31.88611619 </position>
    <velocity> -0.00077234 -0.00079582 0.00051011 </velocity>
    <force> -0.00987615 -0.00174740 -0.00052882 </force>
  </atom>
  <atom name="H6" species="hydrogen">
    <position> -27.79970058 23.84261907 -34.72667336 </position>
    <velocity> -0.00023374 -0.00019930 0.00068148 </velocity>
    <force> -0.01228081 -0.00374908 0.01897553 </force>
  </atom>
  <atom name="H7" species="hydrogen">
    <position> 12.64508461 -10.31491224 0.94998560 </position>
    <velocity> -0.00036553 -0.00005188 0.00127675 </velocity>
    <force> 0.00803054 0.02095411 -0.03262059 </force>
  </atom>
  <atom name="H8" species="hydrogen">
    <position> 11.73069352 -8.78918313 -1.71453588 </position>
    <velocity> 0.00012308 0.00033542 -0.00029268 </velocity>
    <force> -0.01190611 -0.00342080 0.00449943 </force>
  </atom>
  <atom name="H9" species="hydrogen">
    <position> 5.48908614 -21.03136541 -6.16312000 </position>
    <velocity> 0.00035501 -0.00038967 0.00019077 </velocity>
    <force> 0.00614006 -0.01724012 0.00968809 </force>
  </atom>
  <atom name="H10" species="hydrogen">
    <position> 6.92698464 -22.23562286 -3.77751952 </position>
    <velocity> 0.00019452 -0.00059460 0.00082532 </velocity>
    <force> -0.00766524 0.00543743 -0.02281618 </force>
  </atom>
  <atom name="H11" species="hydrogen">
    <position> 7.16148157 17.02662411 3.50390325 </position>
    <velocity> -0.00035658 0.00056200 -0.00084303 </velocity>
    <force> 0.01175272 0.00206466 0.00616298 </force>
  </atom>
  <atom name="H12" species="hydrogen">
    <position> 9.68263679 17.76288528 5.01678256 </position>
    <velocity> -0.00089297 0.00002544 0.00043657 </velocity>
    <force> -0.00926106 -0.00435882 -0.00096693 </force>
  </atom>
  <atom name="H13" species="hydrogen">
    <position> -4.25284978 -27.37021838 -18.73335905 </position>
    <velocity> 0.00081158 -0.00020345 0.00078018 </velocity>
    <force> -0.00665324 -0.01220852 0.02575918 </force>
  </atom>
  <atom name="H14" species="hydrogen">
    <position> -3.99375161 -30.09680443 -19.45037709 </position>
    <velocity> 0.00027759 0.00045081 0.00004998 </velocity>
    <force> 0.00990936 -0.02817762 -0.01733358 </force>
  </atom>
  <atom name="H15" species="hydrogen">
    <position> 1.58010471 -14.53040924 12.09803065 </position>
    <velocity> -0.00070294 -0.00035806 0.00080110 </velocity>
    <force> 0.00883916 -0.00429677 0.00925398 </force>
  </atom>
  <atom name="H16" species="hydrogen">
    <position> 4.52440239 -14.44273388 12.75151407 </position>
    <velocity> -0.00051557 0.00014779 0.00033514 </velocity>
    <force> -0.01411112 0.00102427 0.00686983 </force>
  </atom>
  <atom name="H17" species="hydrogen">
    <position> 2.42399328 5.99821208 -7.41971860 </position>
    <velocity> -0.00004079 0.00042039 0.00020879 </velocity>
    <force> -0.00363809 -0.00920574 0.00686228 </force>
  </atom>
  <atom name="H18" species="hydrogen">
    <position> 0.93909572 3.83526437 -5.75867321 </position>
    <velocity> 0.00048632 0.00227383 -0.00108685 </velocity>
    <force> -0.00654273 0.00656813 -0.00809052 </force>
  </atom>
  <atom name="H19" species="hydrogen">
    <position> -0.81474660 6.63057170 8.30810047 </position>
    <velocity> -0.00037025 0.00051445 0.00019733 </velocity>
    <force> -0.00925972 -0.01211201 0.00108526 </force>
  </atom>
  <atom name="H20" species="hydrogen">
    <position> -0.80651989 9.46346384 8.24755265 </position>
    <velocity> 0.00022657 -0.00016368 0.00007844 </velocity>
    <force> 0.01736170 -0.01787167 -0.00074422 </force>
  </atom>
  <atom name="H21" species="hydrogen">
    <position> 11.53147890 -15.14130347 10.57835888 </position>
    <velocity> -0.00005273 0.00025496 0.00001344 </velocity>
    <force> -0.00383701 -0.00156019 -0.00260229 </force>
  </atom>
  <atom name="H22" species="hydrogen">
    <position> 12.74296973 -13.12467286 12.18620312 </position>
    <velocity> -0.00024856 -0.00034136 0.00060795 </velocity>
    <force> 0.00004885 0.00776168 0.01300507 </force>
  </atom>
  <atom name="H23" species="hydrogen">
    <position> -12.40609300 -1.54306719 11.77616663 </position>
    <velocity> 0.00093222 -0.00086440 0.00071590 </velocity>
    <force> -0.00024969 0.01237797 -0.00497341 </force>
  </atom>
  <atom name="H24" species="hydrogen">
    <position> -12.36471200 -1.95499489 14.55830553 </position>
    <velocity> 0.00058214 -0.00023026 -0.00020551 </velocity>
    <force> 0.00506940 0.00349155 0.01919942 </force>
  </atom>
  <atom name="H25" species="hydrogen">
    <position> 0.50654382 -9.37517218 -21.33088723 </position>
    <velocity> 0.00028678 0.00006685 0.00022658 </velocity>
    <force> 0.00114128 -0.00075818 -0.00658227 </force>
  </atom>
  <atom name="H26" species="hydrogen">
    <position> 3.11043557 -8.31516483 -22.29682073 </position>
    <velocity> -0.00066627 0.00038084 -0.00040327 </velocity>
    <force> 0.00872017 0.00998916 -0.00306245 </force>
  </atom>
  <atom name="H27" species="hydrogen">
    <position> -7.06299989 -9.58842583 -2.48175625 </position>
    <velocity> 0.00101554 0.00040525 0.00021058 </velocity>
    <force> -0.02273627 -0.00352158 0.00114696 </force>
  </atom>
  <atom name="H28" species="hydrogen">
    <position> -4.58829368 -9.33199281 -4.20225660 </position>
    <velocity> 0.00055852 -0.00035907 0.00001143 </velocity>
    <force> -0.00210210 -0.00519299 0.00321231 </force>
  </atom>
  <atom name="H29" species="hydrogen">
    <position> 12.61031763 -13.65050369 3.61607996 </position>
    <velocity> 0.00051318 -0.00079796 -0.00074969 </velocity>
    <force> 0.00350758 -0.00239105 -0.00335409 </force>
  </atom>
  <atom name="H30" species="hydrogen">
    <position> 12.23284021 -11.50049210 5.51737307 </position>
    <velocity> 0.00126125 -0.00017482 -0.00075561 </velocity>
    <force> -0.01584514 0.00781926 0.02174693 </force>
  </atom>
  <atom name="H31" species="hydrogen">
    <position> -5.69127281 10.83423364 -7.19504086 </position>
    <velocity> -0.00000824 -0.00004569 -0.00137763 </velocity>
    <force> 0.00621501 0.00160117 0.00411909 </force>
  </atom>
  <atom name="H32" species="hydrogen">
    <position> -8.61255193 10.38186551 -7.33778420 </position>
    <velocity> -0.00071844 0.00083387 -0.00048318 </velocity>
    <force> -0.00817756 0.00113914 0.00280466 </force>
  </atom>
  <atom name="H33" species="hydrogen">
    <position> -14.99257829 -13.87304698 -28.97194883 </position>
    <velocity> -0.00096885 0.00068280 0.00054147 </velocity>
    <force> 0.00116889 0.00229213 0.01552441 </force>
  </atom>
  <atom name="H34" species="hydrogen">
    <position> -13.04134086 -15.94898715 -28.79015050 </position>
    <velocity> 0.00025087 0.00040003 -0.00091926 </velocity>
    <force> 0.00645215 -0.01149826 0.00568717 </force>
  </atom>
  <atom name="H35" species="hydrogen">
    <position> -20.43707868 -0.94910287 14.68010454 </position>
    <velocity> -0.00006052 -0.00018077 0.00023371 </velocity>
    <force> -0.00328819 -0.00567029 -0.00805174 </force>
  </atom>
  <atom name="H36" species="hydrogen">
    <position> -18.16365722 -2.61301434 14.49293277 </position>
    <velocity> -0.00024675 0.00026558 0.00024321 </velocity>
    <force> 0.02063313 -0.00210037 0.00063388 </force>
  </atom>
  <atom name="H37" species="hydrogen">
    <position> 5.62216694 -15.55015242 0.43829666 </position>
    <velocity> -0.00013354 0.00035520 0.00160251 </velocity>
    <force> 0.00841116 -0.00550081 -0.01195933 </force>
  </atom>
  <atom name="H38" species="hydrogen">
    <position> 8.15449568 -15.38730530 -1.33844816 </position>
    <velocity> -0.00025155 -0.00035479 -0.00026212 </velocity>
    <force> -0.01274707 -0.00711096 0.00986503 </force>
  </atom>
  <atom name="H39" species="hydrogen">
    <position> 5.53794251 19.57108220 -23.08902859 </position>
    <velocity> -0.00012146 -0.00012832 0.00000697 </velocity>
    <force> -0.00388971 -0.00742897 0.00879152 </force>
  </atom>
  <atom name="H40" species="hydrogen">
    <position> 6.89796730 17.33646816 -24.47835240 </position>
    <velocity> -0.00043995 -0.00020991 0.00012609 </velocity>
    <force> 0.00974588 -0.01299223 -0.00202931 </force>
  </atom>
  <atom name="H41" species="hydrogen">
    <position> 3.78883167 1.89290439 11.41615621 </position>
    <velocity> 0.00055157 0.00014238 0.00000273 </velocity>
    <force> -0.00473235 -0.00296868 -0.00353713 </force>
  </atom>
  <atom name="H42" species="hydrogen">
    <position> 3.02077853 2.86835744 14.19296809 </position>
    <velocity> -0.00068471 -0.00033041 -0.00026428 </velocity>
    <force> -0.01186934 0.00291947 0.00206637 </force>
  </atom>
  <atom name="H43" species="hydrogen">
    <position> -8.61035085 -5.44671509 3.43237460 </position>
    <velocity> -0.00002363 -0.00077699 0.00050874 </velocity>
    <force> 0.02561412 -0.00131173 0.02388934 </force>
  </atom>
  <atom name="H44" species="hydrogen">
    <position> -9.88126012 -6.46807933 1.08877423 </position>
    <velocity> 0.00107970 0.00150954 0.00030455 </velocity>
    <force> -0.00947467 0.01137181 0.00280251 </force>
  </atom>
  <atom name="H45" species="hydrogen">
    <position> -12.84923192 -9.31868147 8.47950336 </position>
    <velocity> 0.00066264 0.00021507 -0.00024939 </velocity>
    <force> 0.00012270 -0.00761712 0.00594627 </force>
  </atom>
  <atom name="H46" species="hydrogen">
    <position> -14.70619579 -9.57079260 6.42784600 </position>
    <velocity> 0.00057498 -0.00016423 0.00033991 </velocity>
    <force> -0.00323029 -0.00256874 0.00303983 </force>
  </atom>
  <atom name="H47" species="hydrogen">
    <position> 16.74227403 -13.09480866 4.56389846 </position>
    <velocity> 0.00013327 -0.00094848 0.00047968 </velocity>
    <force> -0.00647820 0.01448287 -0.00920778 </force>
  </atom>
  <atom name="H48" species="hydrogen">
    <position> 18.61833740 -14.70714486 5.72190283 </position>
    <velocity> 0.00075620 -0.00002070 -0.00056789 </velocity>
    <force> 0.01729941 -0.02171339 0.02084570 </force>
  </atom>
  <atom name="H49" species="hydrogen">
    <position> 19.90938441 12.98413520 3.17115954 </position>
    <velocity> -0.00024209 0.00074902 -0.00065758 </velocity>
    <force> 0.00282102 0.00137599 -0.00132169 </force>
  </atom>
  <atom name="H50" species="hydrogen">
    <position> 19.35434273 14.26273489 0.54392952 </position>
    <velocity> 0.00026657 -0.00023719 -0.00003238 </velocity>
    <force> 0.01219667 -0.00003319 -0.00270284 </force>
  </atom>
  <atom name="H51" species="hydrogen">
    <position> 6.79909009 14.29300581 -31.55863239 </position>
    <velocity> 0.00059046 0.00058619 0.00009011 </velocity>
    <force> 0.00100356 -0.01200372 0.00355178 </force>
  </atom>
  <atom name="H52" species="hydrogen">
    <position> 4.87316695 12.87010123 -29.86761808 </position>
    <velocity> -0.00050682 0.00067226 -0.00076770 </velocity>
    <force> -0.01722293 -0.00428123 0.00206649 </force>
  </atom>
  <atom name="H53" species="hydrogen">
    <position> 14.69770855 -22.31199167 -10.23408705 </position>
    <velocity> -0.00043091 0.00005643 0.00031731 </velocity>
    <force> -0.03399232 0.01762844 0.00420862 </force>
  </atom>
  <atom name="H54" species="hydrogen">
    <position> 12.58646715 -20.67173424 -8.69802726 </position>
    <velocity> 0.00105114 -0.00017330 0.00055827 </velocity>
    <force> 0.00023349 -0.00608075 -0.00602764 </force>
  </atom>
  <atom name="H55" species="hydrogen">
    <position> 11.27505894 2.74486038 -15.93103561 </position>
    <velocity> -0.00061691 0.00094372 -0.00077378 </velocity>
    <force> -0.00108328 -0.01089848 -0.02339645 </force>
  </atom>
  <atom name="H56" species="hydrogen">
    <position> 12.02821659 3.25857034 -13.26282232 </position>
    <velocity> 0.00013511 -0.00079269 0.00005778 </velocity>
    <force> -0.01938546 0.00390840 0.00954900 </force>
  </atom>
  <atom name="H57" species="hydrogen">
    <position> -4.02492807 7.07406013 -2.13421291 </position>
    <velocity> -0.00071773 -0.00057851 -0.00070678 </velocity>
    <force> 0.01326440 0.01638332 0.02486988 </force>
  </atom>
  <atom name="H58" species="hydrogen">
    <position> -6.14615581 7.61157073 -4.45616866 </position>
    <velocity> -0.00054429 -0.00027976 -0.00054387 </velocity>
    <force> 0.02220803 0.00493242 0.00174653 </force>
  </atom>
  <atom name="H59" species="hydrogen">
    <position> -10.39372315 -1.62561150 23.48949898 </position>
    <velocity> 0.00058172 0.00026483 -0.00065678 </velocity>
    <force> 0.00640357 -0.02295154 0.01398871 </force>
  </atom>
  <atom name="H60" species="hydrogen">
    <position> -9.36325317 0.73051122 22.02637889 </position>
    <velocity> 0.00019617 0.00011449 -0.00043413 </velocity>
    <force> -0.03089097 -0.01687463 -0.00521595 </force>
  </atom>
  <atom name="H61" species="hydrogen">
    <position> 5.46713093 0.45636653 0.69364199 </position>
    <velocity> 0.00139378 0.00049546 0.00007011 </velocity>
    <force> 0.01444368 0.01471585 -0.00733986 </force>
  </atom>
  <atom name="H62" species="hydrogen">
    <position> 4.13292247 -1.16081692 2.82672718 </position>
    <velocity> -0.00037400 0.00046599 -0.00010108 </velocity>
    <force> 0.00679266 -0.00533303 -0.01929209 </force>
  </atom>
  <atom name="H63" species="hydrogen">
    <position> 23.69859289 -0.33095598 -0.29869435 </position>
    <velocity> -0.00020603 0.00045091 -0.00033630 </velocity>
    <force> -0.02250451 0.00623825 -0.03345611 </force>
  </atom>
  <atom name="H64" species="hydrogen">
    <position> 23.59861937 -2.09133537 -2.57942021 </position>
    <velocity> -0.00062780 0.00079064 -0.00040716 </velocity>
    <force> 0.02155705 -0.03745156 -0.02455620 </force>
  </atom>
  <atom name="H65" species="hydrogen">
    <position> -0.43245935 21.65890940 8.81145760 </position>
    <velocity> 0.00055520 -0.00017222 0.00009962 </velocity>
    <force> -0.00547691 -0.00420426 -0.00786713 </force>
  </atom>
  <atom name="H66" species="hydrogen">
    <position> 0.15410211 23.51759657 10.78491882 </position>
    <velocity> 0.00071858 -0.00022180 0.00032907 </velocity>
    <force> 0.05413215 0.02901771 0.05140930 </force>
  </atom>
  <atom name="H67" species="hydrogen">
    <position> -12.43839647 -1.82444928 19.31295577 </position>
    <velocity> -0.00019922 -0.00015749 0.00058321 </velocity>
    <force> 0.01521752 0.00362504 0.01835609 </force>
  </atom>
  <atom name="H68" species="hydrogen">
    <position> -14.85849592 -1.69259487 17.81181434 </position>
    <velocity> 0.00003625 0.00037657 -0.00094866 </velocity>
    <force> -0.00933610 0.00256918 -0.00793557 </force>
  </atom>
  <atom name="H69" species="hydrogen">
    <position> 4.64311795 -1.23689137 -16.22415942 </position>
    <velocity> 0.00006953 -0.00099081 0.00068111 </velocity>
    <force> -0.01948780 -0.00745944 -0.03825674 </force>
  </atom>
  <atom name="H70" species="hydrogen">
    <position> 5.29486472 -3.79499539 -17.33309478 </position>
    <velocity> 0.00038316 0.00043638 0.00036260 </velocity>
    <force> -0.00749549 0.00587904 -0.02075659 </force>
  </atom>
  <atom name="H71" species="hydrogen">
    <position> 8.00276407 8.51641597 -40.40507079 </position>
    <velocity> -0.00072123 -0.00046374 0.00030103 </velocity>
    <force> 0.00004944 -0.00721736 0.00036677 </force>
  </atom>
  <atom name="H72" species="hydrogen">
    <position> 8.53053621 5.89405600 -39.07197227 </position>
    <velocity> 0.00037479 -0.00057607 -0.00073320 </velocity>
    <force> 0.00842811 -0.00087360 0.00183859 </force>
  </atom>
  <atom name="H73" species="hydrogen">
    <position> -10.42732495 -2.64205799 7.06719010 </position>
    <velocity> -0.00071465 0.00069623 0.00050919 </velocity>
    <force> -0.00694124 0.01718709 -0.02040716 </force>
  </atom>
  <atom name="H74" species="hydrogen">
    <position> -10.90406530 -2.21930052 4.05859947 </position>
    <velocity> -0.00006312 0.00014731 -0.00027025 </velocity>
    <force> 0.00399458 0.01615539 0.03644311 </force>
  </atom>
  <atom name="H75" species="hydrogen">
    <position> 2.02088561 10.79181332 18.90976658 </position>
    <velocity> 0.00006083 0.00011156 -0.00100873 </velocity>
    <force> -0.00924488 0.00171002 0.01008726 </force>
  </atom>
  <atom name="H76" species="hydrogen">
    <position> 2.04380001 10.51964912 16.05427233 </position>
    <velocity> 0.00006733 -0.00021363 0.00121221 </velocity>
    <force> -0.00737245 0.00930889 -0.00894867 </force>
  </atom>
  <atom name="H77" species="hydrogen">
    <position> 8.46162939 10.55853885 -10.09968081 </position>
    <velocity> -0.00049835 0.00009411 0.00043101 </velocity>
    <force> -0.00026380 0.01052743 -0.00685270 </force>
  </atom>
  <atom name="H78" species="hydrogen">
    <position> 7.89762192 11.12296121 -13.05978300 </position>
    <velocity> -0.00175633 -0.00134476 0.00070992 </velocity>
    <force> 0.00726159 0.00789943 0.00407594 </force>
  </atom>
  <atom name="H79" species="hydrogen">
    <position> -17.63654230 -7.64552769 11.16728474 </position>
    <velocity> 0.00108075 0.00054469 0.00053922 </velocity>
    <force> -0.01005495 -0.00014754 -0.00884161 </force>
  </atom>
  <atom name="H80" species="hydrogen">
    <position> -15.87247881 -5.73082801 12.59329999 </position>
    <velocity> -0.00122957 -0.00084284 -0.00080374 </velocity>
    <force> 0.00067566 -0.00980507 -0.00202778 </force>
  </atom>
  <atom name="H81" species="hydrogen">
    <position> 15.97802146 4.79388660 -2.71932862 </position>
    <velocity> 0.00046945 0.00025980 -0.00009967 </velocity>
    <force> -0.01697782 -0.00814486 0.00138465 </force>
  </atom>
  <atom name="H82" species="hydrogen">
    <position> 13.70287471 5.02471915 -0.81059291 </position>
    <velocity> 0.00003473 0.00124545 0.00060309 </velocity>
    <force> -0.00373395 0.00459896 0.00952641 </force>
  </atom>
  <atom name="H83" species="hydrogen">
    <position> -7.90219343 17.28681155 15.74802712 </position>
    <velocity> 0.00073915 0.00166999 0.00000665 </velocity>
    <force> 0.00529186 0.01381564 0.00135526 </force>
  </atom>
  <atom name="H84" species="hydrogen">
    <position> -10.51859820 18.19796860 16.94774920 </position>
    <velocity> -0.00002506 -0.00083950 -0.00030253 </velocity>
    <force> -0.00077838 0.00086739 -0.00113619 </force>
  </atom>
  <atom name="H85" species="hydrogen">
    <position> -4.93921549 -3.08876888 -9.14894378 </position>
    <velocity> -0.00001737 0.00004506 -0.00023138 </velocity>
    <force> -0.00557010 0.03484244 -0.01195119 </force>
  </atom>
  <atom name="H86" species="hydrogen">
    <position> -3.72774972 -4.76067889 -7.19435420 </position>
    <velocity> 0.00029287 0.00017418 0.00066580 </velocity>
    <force> 0.00871438 -0.00546282 0.00352986 </force>
  </atom>
  <atom name="H87" species="hydrogen">
    <position> -12.20165579 -11.39845959 17.09400616 </position>
    <velocity> 0.00064160 0.00049560 -0.00070060 </velocity>
    <force> -0.01588142 0.00188880 0.02619176 </force>
  </atom>
  <atom name="H88" species="hydrogen">
    <position> -10.32470003 -9.51856876 15.56461784 </position>
    <velocity> 0.00053824 0.00080023 -0.00021071 </velocity>
    <force> -0.02113827 -0.01657858 0.01275050 </force>
  </atom>
  <atom name="H89" species="hydrogen">
    <position> -8.59687436 25.04573685 5.30446002 </position>
    <velocity> -0.00016977 -0.00035174 -0.00023734 </velocity>
    <force> -0.00466466 -0.00604731 -0.00191694 </force>
  </atom>
  <atom name="H90" species="hydrogen">
    <position> -6.38920401 26.96433172 6.11438909 </position>
    <velocity> -0.00083904 -0.00124104 0.00082022 </velocity>
    <force> -0.01711275 -0.00660375 -0.03107739 </force>
  </atom>
  <atom name="H91" species="hydrogen">
    <position> 11.94942799 -4.93779037 -12.88362020 </position>
    <velocity> -0.00025398 0.00040171 0.00029431 </velocity>
    <force> 0.02258271 -0.00769557 -0.03734951 </force>
  </atom>
  <atom name="H92" species="hydrogen">
    <position> 14.51209100 -6.35299266 -14.05306654 </position>
    <velocity> 0.00015564 -0.00032431 -0.00034760 </velocity>
    <force> -0.02374709 0.03008689 -0.00860257 </force>
  </atom>
  <atom name="H93" species="hydrogen">
    <position> -3.96573416 -2.25091491 2.05736661 </position>
    <velocity> -0.00060871 -0.00067115 -0.00000380 </velocity>
    <force> -0.00435664 0.01641462 -0.00478476 </force>
  </atom>
  <atom name="H94" species="hydrogen">
    <position> -5.29751053 -0.07968069 3.49533797 </position>
    <velocity> 0.00045847 -0.00168650 0.00002412 </velocity>
    <force> -0.04283422 0.02676651 0.00282512 </force>
  </atom>
  <atom name="H95" species="hydrogen">
    <position> -18.52960696 -18.02197483 -18.01310984 </position>
    <velocity> -0.00032847 0.00067327 0.00059223 </velocity>
    <force> 0.02577927 0.01275394 -0.00714128 </force>
  </atom>
  <atom name="H96" species="hydrogen">
    <position> -21.02213749 -17.41836795 -16.89421239 </position>
    <velocity> 0.00030856 -0.00039860 -0.00034595 </velocity>
    <force> -0.01605907 0.01559659 0.00786031 </force>
  </atom>
  <atom name="H97" species="hydrogen">
    <position> -38.78337569 4.08436184 -23.58734151 </position>
    <velocity> -0.00034499 0.00047021 -0.00024095 </velocity>
    <force> -0.01778357 -0.00174782 -0.00931382 </force>
  </atom>
  <atom name="H98" species="hydrogen">
    <position> -37.37781924 1.49488420 -24.00284019 </position>
    <velocity> 0.00021579 0.00059404 -0.00075876 </velocity>
    <force> 0.01280456 -0.01133650 0.00028295 </force>
  </atom>
  <atom name="H99" species="hydrogen">
    <position> 32.74841360 17.66711883 -4.08755488 </position>
    <velocity> 0.00005563 -0.00005260 0.00105058 </velocity>
    <force> -0.00375362 -0.01645186 0.00923915 </force>
  </atom>
  <atom name="H100" species="hydrogen">
    <position> 31.19077215 15.01289580 -4.27771481 </position>
    <velocity> 0.00051704 -0.00054415 0.00019730 </velocity>
    <force> 0.01496832 0.00309064 0.00382170 </force>
  </atom>
  <atom name="H101" species="hydrogen">
    <position> 9.85012015 3.27791011 -5.90076230 </position>
    <velocity> -0.00027956 0.00071998 -0.00074748 </velocity>
    <force> -0.05455631 -0.02654962 -0.00378965 </force>
  </atom>
  <atom name="H102" species="hydrogen">
    <position> 12.17477242 3.83621489 -4.37624840 </position>
    <velocity> 0.00123322 0.00036288 -0.00103909 </velocity>
    <force> 0.01338302 0.00783822 -0.01498311 </force>
  </atom>
  <atom name="H103" species="hydrogen">
    <position> -3.40601047 3.84574129 18.63730921 </position>
    <velocity> -0.00038097 -0.00083044 0.00028902 </velocity>
    <force> 0.00284085 0.01039161 0.00629977 </force>
  </atom>
  <atom name="H104" species="hydrogen">
    <position> -1.50610342 1.67187543 19.54794958 </position>
    <velocity> 0.00027056 0.00064607 -0.00089144 </velocity>
    <force> -0.00199003 -0.01238012 0.01205407 </force>
  </atom>
  <atom name="H105" species="hydrogen">
    <position> 21.75214804 -10.88347223 -6.92666223 </position>
    <velocity> 0.00040295 0.00069639 -0.00018521 </velocity>
    <force> -0.01223110 0.00225278 0.00377126 </force>
  </atom>
  <atom name="H106" species="hydrogen">
    <position> 19.81196058 -9.19545068 -8.52909881 </position>
    <velocity> 0.00059296 -0.00031919 0.00075792 </velocity>
    <force> 0.00698354 -0.02454714 0.03311654 </force>
  </atom>
  <atom name="H107" species="hydrogen">
    <position> 0.94967869 -8.54738933 10.97347072 </position>
    <velocity> -0.00055509 0.00072250 -0.00029264 </velocity>
    <force> 0.01366562 0.00977630 -0.01118570 </force>
  </atom>
  <atom name="H108" species="hydrogen">
    <position> 0.75333724 -7.46190553 13.84178821 </position>
    <velocity> 0.00069425 -0.00038699 -0.00011399 </velocity>
    <force> 0.00937500 0.01149978 0.00095751 </force>
  </atom>
  <atom name="H109" species="hydrogen">
    <position> 18.13936662 -5.06481089 -1.20207985 </position>
    <velocity> -0.00009320 -0.00033916 -0.00022321 </velocity>
    <force> -0.00177984 -0.01342922 -0.00457666 </force>
  </atom>
  <atom name="H110" species="hydrogen">
    <position> 19.16736227 -2.40033858 -1.58817667 </position>
    <velocity> -0.00019811 -0.00036124 -0.00021544 </velocity>
    <force> 0.01991024 0.01431649 -0.01511695 </force>
  </atom>
  <atom name="H111" species="hydrogen">
    <position> 24.00079429 -6.70207946 18.48632088 </position>
    <velocity> -0.00050282 -0.00068142 0.00053554 </velocity>
    <force> 0.00086768 -0.00401174 0.00201510 </force>
  </atom>
  <atom name="H112" species="hydrogen">
    <position> 25.02938937 -4.24863987 17.14021146 </position>
    <velocity> 0.00021158 0.00055023 0.00041471 </velocity>
    <force> -0.00613659 -0.00816601 -0.00866111 </force>
  </atom>
  <atom name="H113" species="hydrogen">
    <position> 2.30003300 34.12422252 -23.58645686 </position>
    <velocity> 0.00020449 0.00018961 -0.00010918 </velocity>
    <force> 0.01158968 -0.00629666 -0.00417156 </force>
  </atom>
  <atom name="H114" species="hydrogen">
    <position> 1.14698075 31.61450053 -24.08807301 </position>
    <velocity> 0.00007789 -0.00021936 -0.00021184 </velocity>
    <force> -0.02289493 -0.01724508 0.00330075 </force>
  </atom>
  <atom name="H115" species="hydrogen">
    <position> 6.94516875 1.88384772 -13.85189401 </position>
    <velocity> 0.00055007 -0.00022273 0.00001327 </velocity>
    <force> -0.03228796 -0.01311072 -0.02382012 </force>
  </atom>
  <atom name="H116" species="hydrogen">
    <position> 4.72656569 2.91254471 -15.73551034 </position>
    <velocity> 0.00011375 -0.00061205 0.00060834 </velocity>
    <force> -0.01109569 -0.00536070 -0.00213311 </force>
  </atom>
  <atom name="H117" species="hydrogen">
    <position> -3.34749167 -14.76232866 -21.96275260 </position>
    <velocity> 0.00057677 0.00051229 0.00092409 </velocity>
    <force> 0.01629703 -0.01371532 -0.00070027 </force>
  </atom>
  <atom name="H118" species="hydrogen">
    <position> -1.96223746 -17.40313716 -22.06148148 </position>
    <velocity> -0.00050994 -0.00125372 0.00042144 </velocity>
    <force> 0.00565683 -0.04126739 0.02342331 </force>
  </atom>
  <atom name="H119" species="hydrogen">
    <position> -29.02021145 -14.00049074 10.82547458 </position>
    <velocity> 0.00052910 0.00005568 -0.00123383 </velocity>
    <force> 0.00849759 -0.01308591 0.00047774 </force>
  </atom>
  <atom name="H120" species="hydrogen">
    <position> -28.00239451 -11.51011683 10.11536316 </position>
    <velocity> 0.00085879 0.00026157 0.00089545 </velocity>
    <force> 0.01023564 0.00671412 -0.00023601 </force>
  </atom>
  <atom name="H121" species="hydrogen">
    <position> -4.60098329 4.83110394 -13.74461165 </position>
    <velocity> -0.00070017 0.00042688 -0.00044118 </velocity>
    <force> -0.00182032 0.00467975 -0.00508030 </force>
  </atom>
  <atom name="H122" species="hydrogen">
    <position> -2.97966858 2.80090465 -15.15148258 </position>
    <velocity> -0.00028864 0.00013420 0.00008911 </velocity>
    <force> 0.00143182 0.00134246 -0.00356021 </force>
  </atom>
  <atom name="H123" species="hydrogen">
    <position> -5.16197217 -7.00087509 31.87626968 </position>
    <velocity> -0.00060691 0.00053678 0.00084302 </velocity>
    <force> 0.01360605 0.01311818 -0.02033535 </force>
  </atom>
  <atom name="H124" species="hydrogen">
    <position> -5.05252062 -6.40619419 34.79767657 </position>
    <velocity> 0.00005942 0.00093050 0.00008375 </velocity>
    <force> 0.01540772 0.01242171 0.01811907 </force>
  </atom>
  <atom name="H125" species="hydrogen">
    <position> -20.96667037 -9.20275898 30.20682921 </position>
    <velocity> 0.00017562 -0.00087860 0.00038002 </velocity>
    <force> 0.00099121 -0.01897934 -0.01312611 </force>
  </atom>
  <atom name="H126" species="hydrogen">
    <position> -20.87362861 -6.50455123 30.83458063 </position>
    <velocity> 0.00031092 0.00023562 0.00046631 </velocity>
    <force> -0.00146994 0.01014363 0.00483278 </force>
  </atom>
  <atom name="H127" species="hydrogen">
    <position> 10.48764388 6.04840386 25.14620729 </position>
    <velocity> 0.00092642 -0.00092035 -0.00043567 </velocity>
    <force> 0.03199747 0.01126897 0.02588541 </force>
  </atom>
  <atom name="H128" species="hydrogen">
    <position> 13.28201038 5.38290640 26.82208234 </position>
    <velocity> 0.00065724 -0.00042040 -0.00068769 </velocity>
    <force> -0.01672550 -0.00018888 -0.01073396 </force>
  </atom>
</atomset>
<unit_cell_a_norm> 23.460000 </unit_cell_a_norm>
<unit_cell_b_norm> 23.460000 </unit_cell_b_norm>
<unit_cell_c_norm> 23.460000 </unit_cell_c_norm>
<unit_cell_alpha>  90.000 </unit_cell_alpha>
<unit_cell_beta>   90.000 </unit_cell_beta>
<unit_cell_gamma>  90.000 </unit_cell_gamma>
<unit_cell_volume> 12911.718 </unit_cell_volume>
  <econst> -1100.15070508 </econst>
  <ekin_ion> 0.36971894 </ekin_ion>
  <temp_ion> 405.39504435 </temp_ion>
  total_electronic_charge: 512.00000000
  <eigenvalue_sum>  -162.38025163 </eigenvalue_sum>
  <etotal_int>   -1100.51729687 </etotal_int>
  total_electronic_charge: 512.00000000
  <eigenvalue_sum>  -162.38384331 </eigenvalue_sum>
  Anderson extrapolation: theta=1.81414312 (1.81414312)
  <etotal_int>   -1100.51741888 </etotal_int>
  total_electronic_charge: 512.00000000
  <eigenvalue_sum>  -162.38907704 </eigenvalue_sum>
  Anderson extrapolation: theta=0.22025960 (0.22025960)
  <etotal_int>   -1100.51755004 </etotal_int>
  total_electronic_charge: 512.00000000
  <eigenvalue_sum>  -162.38910380 </eigenvalue_sum>
  Anderson extrapolation: theta=2.32881892 (2.00000000)
  <etotal_int>   -1100.51757512 </etotal_int>
  total_electronic_charge: 512.00000000
  <eigenvalue_sum>  -162.38856610 </eigenvalue_sum>
  Anderson extrapolation: theta=0.42580758 (0.42580758)
  <etotal_int>   -1100.51760895 </etotal_int>
  <timing name="iteration" min="    5.806" max="    5.815"/>
</iteration>
<iteration count="3">
  total_electronic_charge: 512.00000000
  <ekin>       808.12400973 </ekin>
  <econf>        0.00000000 </econf>
  <eps>      -1308.85125024 </eps>
  <enl>        124.88348719 </enl>
  <ecoul>     -453.74256570 </ecoul>
  <exc>       -270.93129869 </exc>
  <esr>         93.14327692 </esr>
  <eself>      646.81841729 </eself>
  <ets>          0.00000000 </ets>
  <eexf>         0.00000000 </eexf>
  <etotal>   -1100.51761772 </etotal>
  <epv>          0.00000000 </epv>
  <eefield>      0.00000000 </eefield>
  <enthalpy> -1100.51761772 </enthalpy>
<atomset>
<unit_cell 
    a=" 23.46000000   0.00000000   0.00000000"
    b="  0.00000000  23.46000000   0.00000000"
    c="  0.00000000   0.00000000  23.46000000" />
  <atom name="O1" species="oxygen">
    <position> -6.48680465 6.01354455 12.38364365 </position>
    <velocity> -0.00015443 -0.00020223 0.00030303 </velocity>
    <force> 0.05287055 -0.00173410 0.02299332 </force>
  </atom>
  <atom name="O2" species="oxygen">
    <position> 23.13605002 2.61275897 25.49209207 </position>
    <velocity> -0.00000643 0.00005689 -0.00021784 </velocity>
    <force> 0.00339636 -0.01034156 0.02114377 </force>
  </atom>
  <atom name="O3" species="oxygen">
    <position> -28.79873818 23.73545622 -33.09721801 </position>
    <velocity> -0.00016233 0.00012985 -0.00013343 </velocity>
    <force> 0.02735286 0.00244670 -0.01859561 </force>
  </atom>
  <atom name="O4" species="oxygen">
    <position> 13.16509087 -9.21503123 -0.60208918 </position>
    <velocity> 0.00007964 -0.00023923 0.00009784 </velocity>
    <force> 0.00312592 -0.01777790 0.03322194 </force>
  </atom>
  <atom name="O5" species="oxygen">
    <position> 6.67153197 -22.47167407 -5.68984216 </position>
    <velocity> 0.00027158 0.00000577 -0.00048304 </velocity>
    <force> -0.00110580 0.02184317 0.02753775 </force>
  </atom>
  <atom name="O6" species="oxygen">
    <position> 8.02058505 16.92899255 5.23942541 </position>
    <velocity> 0.00008966 -0.00022948 0.00035509 </velocity>
    <force> -0.00876355 0.00332583 -0.01711129 </force>
  </atom>
  <atom name="O7" species="oxygen">
    <position> -4.61520634 -29.12722760 -18.04599927 </position>
    <velocity> -0.00001958 0.00046109 -0.00028592 </velocity>
    <force> -0.00628827 0.03535575 0.00392951 </force>
  </atom>
  <atom name="O8" species="oxygen">
    <position> 2.78355384 -14.70018261 13.54044541 </position>
    <velocity> -0.00006563 -0.00043932 0.00021438 </velocity>
    <force> 0.00780203 -0.00080863 -0.01592300 </force>
  </atom>
  <atom name="O9" species="oxygen">
    <position> 2.60761014 4.40015128 -6.44687277 </position>
    <velocity> -0.00031039 -0.00001793 -0.00039531 </velocity>
    <force> 0.02296345 0.01434199 -0.00426530 </force>
  </atom>
  <atom name="O10" species="oxygen">
    <position> 0.41072691 7.99002462 8.12076239 </position>
    <velocity> 0.00014369 0.00027017 0.00021238 </velocity>
    <force> -0.01532687 0.03060186 0.00685581 </force>
  </atom>
  <atom name="O11" species="oxygen">
    <position> 13.17707482 -14.43858191 10.99565884 </position>
    <velocity> -0.00006626 0.00009663 -0.00000462 </velocity>
    <force> 0.00089952 -0.00487607 -0.01042841 </force>
  </atom>
  <atom name="O12" species="oxygen">
    <position> -13.19250952 -2.55821285 13.06743894 </position>
    <velocity> 0.00026577 -0.00014640 -0.00012172 </velocity>
    <force> -0.02096102 -0.02576580 -0.02153669 </force>
  </atom>
  <atom name="O13" species="oxygen">
    <position> 2.32290476 -9.79038031 -21.53943430 </position>
    <velocity> -0.00011333 0.00038921 0.00012693 </velocity>
    <force> -0.00785970 -0.01091733 0.00684021 </force>
  </atom>
  <atom name="O14" species="oxygen">
    <position> -5.30413396 -9.16759883 -2.46405072 </position>
    <velocity> -0.00016860 0.00003930 -0.00033531 </velocity>
    <force> 0.02844224 0.01576264 0.00819776 </force>
  </atom>
  <atom name="O15" species="oxygen">
    <position> 13.30867785 -11.99426876 4.14729679 </position>
    <velocity> -0.00049002 -0.00029786 0.00019921 </velocity>
    <force> 0.02199302 -0.01665100 -0.03563893 </force>
  </atom>
  <atom name="O16" species="oxygen">
    <position> -6.98917685 9.50468148 -7.02032280 </position>
    <velocity> -0.00006228 0.00024174 -0.00007863 </velocity>
    <force> 0.00422581 -0.01445447 -0.00163218 </force>
  </atom>
  <atom name="O17" species="oxygen">
    <position> -13.79148036 -14.61470074 -27.73082806 </position>
    <velocity> -0.00000830 0.00011232 0.00020487 </velocity>
    <force> -0.01228569 0.00903881 -0.02175744 </force>
  </atom>
  <atom name="O18" species="oxygen">
    <position> -19.92847737 -2.75940827 14.85545970 </position>
    <velocity> -0.00021905 -0.00014603 0.00011897 </velocity>
    <force> -0.01673056 0.00477091 0.00455268 </force>
  </atom>
  <atom name="O19" species="oxygen">
    <position> 7.37445093 -16.23028801 0.19835931 </position>
    <velocity> -0.00034286 -0.00034756 0.00004861 </velocity>
    <force> 0.01443113 0.00939250 -0.00359663 </force>
  </atom>
  <atom name="O20" species="oxygen">
    <position> 5.89869174 17.68499080 -22.94985515 </position>
    <velocity> 0.00007346 -0.00012673 -0.00000699 </velocity>
    <force> -0.01256901 0.01395846 0.00752562 </force>
  </atom>
  <atom name="O21" species="oxygen">
    <position> 2.45901481 1.82621126 12.74288995 </position>
    <velocity> -0.00020763 0.00029168 -0.00013154 </velocity>
    <force> 0.00070983 -0.00372796 0.00690208 </force>
  </atom>
  <atom name="O22" species="oxygen">
    <position> -9.89711524 -4.94966584 2.28967227 </position>
    <velocity> 0.00031882 0.00010248 -0.00032691 </velocity>
    <force> -0.01884858 -0.00828917 -0.02062769 </force>
  </atom>
  <atom name="O23" species="oxygen">
    <position> -13.81047645 -10.70543252 7.67101899 </position>
    <velocity> 0.00015375 0.00001371 -0.00036824 </velocity>
    <force> 0.00238244 0.01660930 -0.00271077 </force>
  </atom>
  <atom name="O24" species="oxygen">
    <position> 18.59608795 -13.37106004 4.52393478 </position>
    <velocity> 0.00034234 -0.00014466 -0.00005333 </velocity>
    <force> -0.01751484 0.01172370 -0.01645193 </force>
  </atom>
  <atom name="O25" species="oxygen">
    <position> 20.48632215 14.37871148 2.06829862 </position>
    <velocity> 0.00002876 -0.00050145 -0.00044391 </velocity>
    <force> -0.00648520 -0.00078865 0.00028088 </force>
  </atom>
  <atom name="O26" species="oxygen">
    <position> 6.68695332 13.02483518 -30.12212493 </position>
    <velocity> -0.00000999 0.00021114 0.00015671 </velocity>
    <force> 0.01015167 0.01606701 -0.01121287 </force>
  </atom>
  <atom name="O27" species="oxygen">
    <position> 12.81961721 -21.72981697 -10.27829361 </position>
    <velocity> 0.00013312 -0.00027847 0.00012766 </velocity>
    <force> 0.04553823 -0.00545211 -0.00340325 </force>
  </atom>
  <atom name="O28" species="oxygen">
    <position> 10.66248591 3.71368818 -14.53120530 </position>
    <velocity> 0.00007768 0.00033051 -0.00024190 </velocity>
    <force> 0.01561121 -0.00361009 0.02479224 </force>
  </atom>
  <atom name="O29" species="oxygen">
    <position> -4.81765120 6.47904383 -3.64691294 </position>
    <velocity> 0.00003092 -0.00006341 0.00016265 </velocity>
    <force> -0.04567817 -0.02077413 -0.03890100 </force>
  </atom>
  <atom name="O30" species="oxygen">
    <position> -10.79613592 -0.60075771 22.05645150 </position>
    <velocity> 0.00035099 0.00008097 -0.00014735 </velocity>
    <force> 0.01623098 0.03776067 -0.01124601 </force>
  </atom>
  <atom name="O31" species="oxygen">
    <position> 4.41954513 -1.01564183 0.91784935 </position>
    <velocity> 0.00016718 0.00003120 0.00027081 </velocity>
    <force> -0.02021250 -0.01044298 0.01939955 </force>
  </atom>
  <atom name="O32" species="oxygen">
    <position> 22.69549764 -0.70883926 -1.96146229 </position>
    <velocity> -0.00009925 0.00007079 0.00041176 </velocity>
    <force> -0.00000877 0.03218135 0.05537679 </force>
  </atom>
  <atom name="O33" species="oxygen">
    <position> -1.15014908 23.06492230 9.74291720 </position>
    <velocity> -0.00002265 0.00011229 0.00002863 </velocity>
    <force> -0.05315035 -0.01909813 -0.04237958 </force>
  </atom>
  <atom name="O34" species="oxygen">
    <position> -13.42386269 -2.82115864 18.13090041 </position>
    <velocity> -0.00026788 0.00003443 0.00015200 </velocity>
    <force> 0.00036582 -0.01029938 -0.00415951 </force>
  </atom>
  <atom name="O35" species="oxygen">
    <position> 4.04989910 -2.42220634 -17.77492394 </position>
    <velocity> 0.00000056 -0.00009236 0.00009261 </velocity>
    <force> 0.02790704 0.00146791 0.06520798 </force>
  </atom>
  <atom name="O36" species="oxygen">
    <position> 7.53474573 6.72430057 -40.39598551 </position>
    <velocity> -0.00035149 -0.00005866 -0.00007492 </velocity>
    <force> 0.00341851 0.01612423 -0.00603305 </force>
  </atom>
  <atom name="O37" species="oxygen">
    <position> -10.79402307 -1.21949588 5.74308076 </position>
    <velocity> -0.00027260 0.00003351 0.00000821 </velocity>
    <force> 0.00374096 -0.02669373 -0.01123325 </force>
  </atom>
  <atom name="O38" species="oxygen">
    <position> 1.47595562 11.75162711 17.40326003 </position>
    <velocity> -0.00014938 0.00012343 0.00011473 </velocity>
    <force> 0.01431410 -0.00950660 -0.00031874 </force>
  </atom>
  <atom name="O39" species="oxygen">
    <position> 7.69394914 9.92783108 -11.65318615 </position>
    <velocity> 0.00016489 0.00004840 0.00006958 </velocity>
    <force> -0.01020252 -0.02430491 0.00881168 </force>
  </atom>
  <atom name="O40" species="oxygen">
    <position> -16.37310861 -7.52791637 12.48140484 </position>
    <velocity> 0.00038261 0.00024271 0.00014062 </velocity>
    <force> 0.01243939 0.00633720 0.01344721 </force>
  </atom>
  <atom name="O41" species="oxygen">
    <position> 14.21926807 4.03535594 -2.28729493 </position>
    <velocity> -0.00013550 0.00009383 0.00014850 </velocity>
    <force> 0.03531278 0.00980466 0.00683894 </force>
  </atom>
  <atom name="O42" species="oxygen">
    <position> -9.68852165 16.85448834 16.00902698 </position>
    <velocity> -0.00015192 -0.00008280 0.00021277 </velocity>
    <force> 0.00315724 -0.01465909 -0.00741878 </force>
  </atom>
  <atom name="O43" species="oxygen">
    <position> -5.15402395 -4.69052031 -8.35607203 </position>
    <velocity> 0.00001573 0.00017688 -0.00014023 </velocity>
    <force> 0.00630215 -0.03584954 0.01220413 </force>
  </atom>
  <atom name="O44" species="oxygen">
    <position> -11.06683307 -11.34534834 15.71993332 </position>
    <velocity> -0.00016078 0.00033251 0.00030839 </velocity>
    <force> 0.03473738 0.02100378 -0.04990460 </force>
  </atom>
  <atom name="O45" species="oxygen">
    <position> -7.56694143 26.43173188 4.58943365 </position>
    <velocity> 0.00039167 -0.00027416 -0.00046242 </velocity>
    <force> 0.01472331 0.00994709 0.03399761 </force>
  </atom>
  <atom name="O46" species="oxygen">
    <position> 12.87050997 -5.28705544 -14.60458308 </position>
    <velocity> -0.00038809 -0.00011883 0.00019980 </velocity>
    <force> 0.00321328 -0.02062569 0.05165821 </force>
  </atom>
  <atom name="O47" species="oxygen">
    <position> -3.73328674 -0.90167493 3.38014529 </position>
    <velocity> 0.00039606 -0.00026462 -0.00027735 </velocity>
    <force> 0.04596987 -0.03892784 0.00111237 </force>
  </atom>
  <atom name="O48" species="oxygen">
    <position> -20.14537728 -18.79502856 -17.70069438 </position>
    <velocity> -0.00013250 0.00024448 0.00008622 </velocity>
    <force> -0.01050950 -0.03492951 -0.01332722 </force>
  </atom>
  <atom name="O49" species="oxygen">
    <position> -39.02227101 2.29533902 -24.17318370 </position>
    <velocity> -0.00017460 0.00029822 -0.00011069 </velocity>
    <force> 0.00304518 0.00689902 0.00395329 </force>
  </atom>
  <atom name="O50" species="oxygen">
    <position> 32.37285852 16.01361320 -3.14555346 </position>
    <velocity> 0.00009282 -0.00008799 -0.00012406 </velocity>
    <force> -0.00416749 0.01410890 -0.01679753 </force>
  </atom>
  <atom name="O51" species="oxygen">
    <position> 11.41417819 4.03703548 -6.13464572 </position>
    <velocity> -0.00025411 -0.00012108 0.00003625 </velocity>
    <force> 0.03916892 0.02735873 0.00521897 </force>
  </atom>
  <atom name="O52" species="oxygen">
    <position> -2.00530440 2.73307125 18.12825826 </position>
    <velocity> 0.00009804 -0.00028758 0.00008288 </velocity>
    <force> -0.00198570 0.00180106 -0.02960209 </force>
  </atom>
  <atom name="O53" species="oxygen">
    <position> 19.90887137 -10.33760691 -6.94658534 </position>
    <velocity> 0.00005356 0.00031905 -0.00026142 </velocity>
    <force> 0.01824403 0.02307613 -0.03816375 </force>
  </atom>
  <atom name="O54" species="oxygen">
    <position> 0.06803143 -8.55874738 12.56005059 </position>
    <velocity> -0.00025629 -0.00003656 -0.00018356 </velocity>
    <force> -0.03105174 -0.01687537 0.01851323 </force>
  </atom>
  <atom name="O55" species="oxygen">
    <position> 18.01940079 -3.35226168 -0.57179406 </position>
    <velocity> -0.00000511 -0.00011281 0.00000195 </velocity>
    <force> -0.01241751 -0.00679215 0.01262806 </force>
  </atom>
  <atom name="O56" species="oxygen">
    <position> 23.50532430 -5.36173464 17.34471070 </position>
    <velocity> 0.00027292 -0.00031011 0.00001153 </velocity>
    <force> 0.00427455 0.00936776 0.00616604 </force>
  </atom>
  <atom name="O57" species="oxygen">
    <position> 2.67924176 32.48799715 -24.49604424 </position>
    <velocity> 0.00009783 -0.00015689 0.00007756 </velocity>
    <force> 0.01432850 0.03619446 0.00272742 </force>
  </atom>
  <atom name="O58" species="oxygen">
    <position> 5.18617454 1.41388002 -14.61246916 </position>
    <velocity> -0.00012303 0.00008739 0.00012654 </velocity>
    <force> 0.05936588 0.00870972 0.02286216 </force>
  </atom>
  <atom name="O59" species="oxygen">
    <position> -2.11204973 -15.85615015 -22.92062391 </position>
    <velocity> 0.00018350 -0.00009336 -0.00004131 </velocity>
    <force> -0.02285647 0.04496776 -0.01291172 </force>
  </atom>
  <atom name="O60" species="oxygen">
    <position> -27.37129812 -13.21655996 10.47620983 </position>
    <velocity> -0.00024180 -0.00020937 0.00004974 </velocity>
    <force> -0.01144094 0.01549078 -0.00414267 </force>
  </atom>
  <atom name="O61" species="oxygen">
    <position> -3.86944911 4.42282926 -15.46221615 </position>
    <velocity> -0.00016409 0.00013736 -0.00029991 </velocity>
    <force> -0.00032869 -0.00690563 0.01812247 </force>
  </atom>
  <atom name="O62" species="oxygen">
    <position> -6.02452945 -7.12867606 33.47185887 </position>
    <velocity> 0.00020950 -0.00014844 -0.00005843 </velocity>
    <force> -0.03241590 -0.02833392 0.01171643 </force>
  </atom>
  <atom name="O63" species="oxygen">
    <position> -20.88842213 -8.14160176 31.67931818 </position>
    <velocity> -0.00028287 0.00004262 0.00025343 </velocity>
    <force> 0.00581148 0.00905426 -0.00200204 </force>
  </atom>
  <atom name="O64" species="oxygen">
    <position> 12.28971973 6.56565611 25.70851297 </position>
    <velocity> 0.00028526 -0.00004061 0.00032727 </velocity>
    <force> -0.01097052 -0.00682680 -0.01238916 </force>
  </atom>
  <atom name="H1" species="hydrogen">
    <position> -5.92046438 7.20316909 13.82216770 </position>
    <velocity> -0.00035814 0.00062809 0.00034094 </velocity>
    <force> -0.02178160 -0.01947027 -0.02102579 </force>
  </atom>
  <atom name="H2" species="hydrogen">
    <position> -8.13307845 6.53912025 11.87682142 </position>
    <velocity> 0.00052645 -0.00064957 0.00044696 </velocity>
    <force> -0.02640339 0.01627016 -0.00061494 </force>
  </atom>
  <atom name="H3" species="hydrogen">
    <position> 24.67124739 2.71308747 26.56927807 </position>
    <velocity> 0.00072142 0.00062222 -0.00082383 </velocity>
    <force> -0.00782709 0.00903659 -0.00577664 </force>
  </atom>
  <atom name="H4" species="hydrogen">
    <position> 22.02590776 1.40426278 26.47359686 </position>
    <velocity> -0.00064592 0.00018818 -0.00026663 </velocity>
    <force> 0.00372768 0.00849790 -0.01413593 </force>
  </atom>
  <atom name="H5" species="hydrogen">
    <position> -27.59006162 24.52595685 -31.88102227 </position>
    <velocity> -0.00079742 -0.00079922 0.00050916 </velocity>
    <force> -0.00876888 -0.00097647 -0.00002011 </force>
  </atom>
  <atom name="H6" species="hydrogen">
    <position> -27.80220525 23.84057500 -34.71960015 </position>
    <velocity> -0.00026498 -0.00020880 0.00072974 </velocity>
    <force> -0.01073438 -0.00328740 0.01667248 </force>
  </atom>
  <atom name="H7" species="hydrogen">
    <position> 12.64153870 -10.31514570 0.96230883 </position>
    <velocity> -0.00034283 0.00000698 0.00118442 </velocity>
    <force> 0.00853685 0.02227247 -0.03483101 </force>
  </atom>
  <atom name="H8" species="hydrogen">
    <position> 11.73176213 -8.78587548 -1.71740136 </position>
    <velocity> 0.00009197 0.00032519 -0.00027853 </velocity>
    <force> -0.01090926 -0.00399742 0.00580995 </force>
  </atom>
  <atom name="H9" species="hydrogen">
    <position> 5.49271987 -21.03549692 -6.16108037 </position>
    <velocity> 0.00037032 -0.00043490 0.00021656 </velocity>
    <force> 0.00520968 -0.01609288 0.00931045 </force>
  </atom>
  <atom name="H10" species="hydrogen">
    <position> 6.92882541 -22.24149481 -3.76957709 </position>
    <velocity> 0.00017299 -0.00057964 0.00075779 </velocity>
    <force> -0.00809250 0.00538004 -0.02654913 </force>
  </atom>
  <atom name="H11" species="hydrogen">
    <position> 7.15807581 17.03227222 3.49555683 </position>
    <velocity> -0.00032226 0.00056675 -0.00082113 </velocity>
    <force> 0.01335287 0.00158502 0.00968795 </force>
  </atom>
  <atom name="H12" species="hydrogen">
    <position> 9.67358098 17.76308034 5.02113505 </position>
    <velocity> -0.00091367 0.00001545 0.00043342 </velocity>
    <force> -0.00619918 -0.00297164 -0.00121689 </force>
  </atom>
  <atom name="H13" species="hydrogen">
    <position> -4.24482457 -27.37241916 -18.72520648 </position>
    <velocity> 0.00079364 -0.00023324 0.00084821 </velocity>
    <force> -0.00629564 -0.00973488 0.02444257 </force>
  </atom>
  <atom name="H14" species="hydrogen">
    <position> -3.99084079 -30.09268005 -19.45011334 </position>
    <velocity> 0.00030458 0.00037352 0.00000221 </velocity>
    <force> 0.00999795 -0.02846758 -0.01774124 </force>
  </atom>
  <atom name="H15" species="hydrogen">
    <position> 1.57319570 -14.53404834 12.10616764 </position>
    <velocity> -0.00067813 -0.00036949 0.00082553 </velocity>
    <force> 0.00918031 -0.00420543 0.00892348 </force>
  </atom>
  <atom name="H16" species="hydrogen">
    <position> 4.51905454 -14.44124198 12.75495906 </position>
    <velocity> -0.00055257 0.00015042 0.00035271 </velocity>
    <force> -0.01321463 0.00094376 0.00613307 </force>
  </atom>
  <atom name="H17" species="hydrogen">
    <position> 2.42353579 6.00229063 -7.41753724 </position>
    <velocity> -0.00004958 0.00039513 0.00022688 </velocity>
    <force> -0.00282360 -0.00923162 0.00648588 </force>
  </atom>
  <atom name="H18" species="hydrogen">
    <position> 0.94386986 3.85809215 -5.76965193 </position>
    <velocity> 0.00046195 0.00228695 -0.00110464 </velocity>
    <force> -0.01121981 0.00372302 -0.00529047 </force>
  </atom>
  <atom name="H19" species="hydrogen">
    <position> -0.81857526 6.63555121 8.31008857 </position>
    <velocity> -0.00039407 0.00048158 0.00019994 </velocity>
    <force> -0.00833853 -0.01188272 0.00088866 </force>
  </atom>
  <atom name="H20" species="hydrogen">
    <position> -0.80401771 9.46158365 8.24832690 </position>
    <velocity> 0.00027278 -0.00021017 0.00007650 </velocity>
    <force> 0.01664481 -0.01632776 -0.00065905 </force>
  </atom>
  <atom name="H21" species="hydrogen">
    <position> 11.53089936 -15.13877508 10.57845780 </position>
    <velocity> -0.00006349 0.00025033 0.00000605 </velocity>
    <force> -0.00408136 -0.00177120 -0.00281731 </force>
  </atom>
  <atom name="H22" species="hydrogen">
    <position> 12.74048476 -13.12798073 12.19245974 </position>
    <velocity> -0.00024800 -0.00032059 0.00064236 </velocity>
    <force> 0.00029070 0.00739688 0.01244511 </force>
  </atom>
  <atom name="H23" species="hydrogen">
    <position> -12.39677421 -1.55154258 11.78325786 </position>
    <velocity> 0.00093288 -0.00082747 0.00069795 </velocity>
    <force> 0.00100632 0.01450097 -0.00800519 </force>
  </atom>
  <atom name="H24" species="hydrogen">
    <position> -12.35882156 -1.95724996 14.55651189 </position>
    <velocity> 0.00059509 -0.00022109 -0.00015290 </velocity>
    <force> 0.00460859 0.00317809 0.01938477 </force>
  </atom>
  <atom name="H25" species="hydrogen">
    <position> 0.50942721 -9.37451403 -21.32871104 </position>
    <velocity> 0.00028734 0.00006502 0.00020891 </velocity>
    <force> -0.00065139 -0.00056380 -0.00633589 </force>
  </atom>
  <atom name="H26" species="hydrogen">
    <position> 3.10389168 -8.31122034 -22.30089515 </position>
    <velocity> -0.00064185 0.00040788 -0.00041135 </velocity>
    <force> 0.00902229 0.00997690 -0.00298868 </force>
  </atom>
  <atom name="H27" species="hydrogen">
    <position> -7.05315410 -9.58442124 -2.47963479 </position>
    <velocity> 0.00094435 0.00039319 0.00021303 </velocity>
    <force> -0.02926704 -0.00522517 0.00070960 </force>
  </atom>
  <atom name="H28" species="hydrogen">
    <position> -4.58273707 -9.33565419 -4.20209859 </position>
    <velocity> 0.00055168 -0.00037307 0.00002002 </velocity>
    <force> -0.00276556 -0.00519715 0.00310165 </force>
  </atom>
  <atom name="H29" species="hydrogen">
    <position> 12.61549721 -13.65851583 3.60853736 </position>
    <velocity> 0.00052220 -0.00080220 -0.00075699 </velocity>
    <force> 0.00326711 -0.00095320 -0.00222114 </force>
  </atom>
  <atom name="H30" species="hydrogen">
    <position> 12.24523695 -11.50213382 5.51011317 </position>
    <velocity> 0.00120994 -0.00015108 -0.00068718 </velocity>
    <force> -0.02148643 0.00957108 0.02829577 </force>
  </atom>
  <atom name="H31" species="hydrogen">
    <position> -5.69127058 10.83379852 -7.20876103 </position>
    <velocity> 0.00000881 -0.00004131 -0.00136526 </velocity>
    <force> 0.00631131 0.00160175 0.00456581 </force>
  </atom>
  <atom name="H32" species="hydrogen">
    <position> -8.61984769 10.39021968 -7.34257782 </position>
    <velocity> -0.00073677 0.00083448 -0.00047429 </velocity>
    <force> -0.00549656 -0.00044659 0.00358458 </force>
  </atom>
  <atom name="H33" species="hydrogen">
    <position> -15.00225083 -13.86618772 -28.96632272 </position>
    <velocity> -0.00096266 0.00068717 0.00058552 </velocity>
    <force> 0.00309710 0.00110870 0.01698645 </force>
  </atom>
  <atom name="H34" species="hydrogen">
    <position> -13.03874433 -15.94514343 -28.79926569 </position>
    <velocity> 0.00026665 0.00037093 -0.00090149 </velocity>
    <force> 0.00521245 -0.00976282 0.00710558 </force>
  </atom>
  <atom name="H35" species="hydrogen">
    <position> -20.43772864 -0.95098784 14.68233202 </position>
    <velocity> -0.00006993 -0.00019568 0.00021167 </velocity>
    <force> -0.00364601 -0.00533096 -0.00806915 </force>
  </atom>
  <atom name="H36" species="hydrogen">
    <position> -18.16584373 -2.61038715 14.49537351 </position>
    <velocity> -0.00019044 0.00025949 0.00024500 </velocity>
    <force> 0.02065764 -0.00229978 0.00074802 </force>
  </atom>
  <atom name="H37" species="hydrogen">
    <position> 5.62094608 -15.54667538 0.45415891 </position>
    <velocity> -0.00010935 0.00033967 0.00156825 </velocity>
    <force> 0.00931842 -0.00580301 -0.01274881 </force>
  </atom>
  <atom name="H38" species="hydrogen">
    <position> 8.15180654 -15.39095001 -1.34093503 </position>
    <velocity> -0.00028705 -0.00037425 -0.00023401 </velocity>
    <force> -0.01339566 -0.00728482 0.01070977 </force>
  </atom>
  <atom name="H39" species="hydrogen">
    <position> 5.53667495 19.56969785 -23.08883918 </position>
    <velocity> -0.00013193 -0.00014836 0.00003104 </velocity>
    <force> -0.00383804 -0.00732925 0.00889417 </force>
  </atom>
  <atom name="H40" species="hydrogen">
    <position> 6.89370053 17.33419209 -24.47711914 </position>
    <velocity> -0.00041192 -0.00024556 0.00011893 </velocity>
    <force> 0.01072015 -0.01325457 -0.00319658 </force>
  </atom>
  <atom name="H41" species="hydrogen">
    <position> 3.79428290 1.89428776 11.41613536 </position>
    <velocity> 0.00053673 0.00013420 -0.00000549 </velocity>
    <force> -0.00600693 -0.00299628 -0.00249806 </force>
  </atom>
  <atom name="H42" species="hydrogen">
    <position> 3.01376979 2.86509310 14.19035346 </position>
    <velocity> -0.00071575 -0.00032053 -0.00025614 </velocity>
    <force> -0.01112515 0.00424103 0.00383108 </force>
  </atom>
  <atom name="H43" species="hydrogen">
    <position> -8.61023833 -5.45450285 3.43778738 </position>
    <velocity> 0.00004296 -0.00077870 0.00057140 </velocity>
    <force> 0.02329080 -0.00016891 0.02227924 </force>
  </atom>
  <atom name="H44" species="hydrogen">
    <position> -9.87059218 -6.45282902 1.09185791 </position>
    <velocity> 0.00105276 0.00153510 0.00030794 </velocity>
    <force> -0.01000381 0.00783820 -0.00022637 </force>
  </atom>
  <atom name="H45" species="hydrogen">
    <position> -12.84260382 -9.31663450 8.47709045 </position>
    <velocity> 0.00066123 0.00019206 -0.00023405 </velocity>
    <force> -0.00097339 -0.00922602 0.00524984 </force>
  </atom>
  <atom name="H46" species="hydrogen">
    <position> -14.70048998 -9.57246992 6.43128654 </position>
    <velocity> 0.00056416 -0.00016946 0.00034553 </velocity>
    <force> -0.00455008 -0.00131981 0.00118255 </force>
  </atom>
  <atom name="H47" species="hydrogen">
    <position> 16.74351853 -13.10409624 4.56856988 </position>
    <velocity> 0.00011638 -0.00090824 0.00045401 </velocity>
    <force> -0.00589499 0.01480814 -0.00951210 </force>
  </atom>
  <atom name="H48" species="hydrogen">
    <position> 18.62613501 -14.70764761 5.71650778 </position>
    <velocity> 0.00080345 -0.00008231 -0.00050882 </velocity>
    <force> 0.01762573 -0.02354741 0.02238133 </force>
  </atom>
  <atom name="H49" species="hydrogen">
    <position> 19.90700193 12.99164418 3.16456569 </position>
    <velocity> -0.00023583 0.00074824 -0.00065751 </velocity>
    <force> 0.00170537 -0.00173601 0.00118580 </force>
  </atom>
  <atom name="H50" species="hydrogen">
    <position> 19.35717457 14.26036250 0.54356890 </position>
    <velocity> 0.00029820 -0.00023718 -0.00004166 </velocity>
    <force> 0.01111144 -0.00002446 -0.00412463 </force>
  </atom>
  <atom name="H51" species="hydrogen">
    <position> 6.80500835 14.29870422 -31.55768288 </position>
    <velocity> 0.00059293 0.00055215 0.00010084 </velocity>
    <force> 0.00098090 -0.01282765 0.00435327 </force>
  </atom>
  <atom name="H52" species="hydrogen">
    <position> 4.86786419 12.87676548 -29.87526695 </position>
    <velocity> -0.00055132 0.00066037 -0.00076181 </velocity>
    <force> -0.01561214 -0.00425439 0.00203951 </force>
  </atom>
  <atom name="H53" species="hydrogen">
    <position> 14.69293649 -22.31118724 -10.23085660 </position>
    <velocity> -0.00052072 0.00010322 0.00032780 </velocity>
    <force> -0.03209807 0.01675645 0.00358937 </force>
  </atom>
  <atom name="H54" species="hydrogen">
    <position> 12.59698176 -20.67355010 -8.69252660 </position>
    <velocity> 0.00105010 -0.00019005 0.00054037 </velocity>
    <force> -0.00069820 -0.00626730 -0.00696653 </force>
  </atom>
  <atom name="H55" species="hydrogen">
    <position> 11.26887504 2.75414916 -15.93909209 </position>
    <velocity> -0.00061893 0.00091311 -0.00083744 </velocity>
    <force> -0.00057756 -0.01131724 -0.02358128 </force>
  </atom>
  <atom name="H56" species="hydrogen">
    <position> 12.02930364 3.25069665 -13.26211447 </position>
    <velocity> 0.00008073 -0.00078106 0.00008200 </velocity>
    <force> -0.02051458 0.00440520 0.00825605 </force>
  </atom>
  <atom name="H57" species="hydrogen">
    <position> -4.03192471 7.06849819 -2.14094202 </position>
    <velocity> -0.00067778 -0.00053025 -0.00063141 </velocity>
    <force> 0.01587569 0.01890044 0.03029160 </force>
  </atom>
  <atom name="H58" species="hydrogen">
    <position> -6.15129629 7.60884029 -4.46158356 </position>
    <velocity> -0.00048155 -0.00026702 -0.00053759 </velocity>
    <force> 0.02372574 0.00434534 0.00270903 </force>
  </atom>
  <atom name="H59" species="hydrogen">
    <position> -10.38781871 -1.62327574 23.48312174 </position>
    <velocity> 0.00059950 0.00020050 -0.00061591 </velocity>
    <force> 0.00681856 -0.02423160 0.01583957 </force>
  </atom>
  <atom name="H60" species="hydrogen">
    <position> -9.36171213 0.73142630 22.02196651 </position>
    <velocity> 0.00011228 0.00006900 -0.00044803 </velocity>
    <force> -0.03067505 -0.01650514 -0.00511720 </force>
  </atom>
  <atom name="H61" species="hydrogen">
    <position> 5.48126543 0.46152157 0.69424313 </position>
    <velocity> 0.00142829 0.00052943 0.00005112 </velocity>
    <force> 0.01130935 0.01037404 -0.00658747 </force>
  </atom>
  <atom name="H62" species="hydrogen">
    <position> 4.12927503 -1.15622967 2.82545369 </position>
    <velocity> -0.00035521 0.00045127 -0.00015260 </velocity>
    <force> 0.00689794 -0.00534317 -0.01858623 </force>
  </atom>
  <atom name="H63" species="hydrogen">
    <position> 23.69622613 -0.32636188 -0.30251304 </position>
    <velocity> -0.00026595 0.00046744 -0.00042531 </velocity>
    <force> -0.02156819 0.00603326 -0.03202076 </force>
  </atom>
  <atom name="H64" species="hydrogen">
    <position> 23.59263493 -2.08393901 -2.58382623 </position>
    <velocity> -0.00056647 0.00068512 -0.00047499 </velocity>
    <force> 0.02331634 -0.03982986 -0.02538523 </force>
  </atom>
  <atom name="H65" species="hydrogen">
    <position> -0.42698193 21.65712990 8.81234669 </position>
    <velocity> 0.00053858 -0.00018156 0.00007918 </velocity>
    <force> -0.00657119 -0.00270066 -0.00712303 </force>
  </atom>
  <atom name="H66" species="hydrogen">
    <position> 0.16202517 23.51577378 10.78890967 </position>
    <velocity> 0.00086052 -0.00014407 0.00046516 </velocity>
    <force> 0.05033803 0.02801050 0.04864843 </force>
  </atom>
  <atom name="H67" species="hydrogen">
    <position> -12.44018139 -1.82597485 19.31903784 </position>
    <velocity> -0.00015883 -0.00014807 0.00063172 </velocity>
    <force> 0.01439054 0.00325290 0.01744396 </force>
  </atom>
  <atom name="H68" species="hydrogen">
    <position> -14.85826055 -1.68879420 17.80221971 </position>
    <velocity> 0.00001187 0.00038293 -0.00096921 </velocity>
    <force> -0.00856259 0.00221038 -0.00743316 </force>
  </atom>
  <atom name="H69" species="hydrogen">
    <position> 4.64354784 -1.24690103 -16.21786931 </position>
    <velocity> 0.00001574 -0.00100962 0.00057610 </velocity>
    <force> -0.02000527 -0.00664330 -0.03868620 </force>
  </atom>
  <atom name="H70" species="hydrogen">
    <position> 5.29859424 -3.79055147 -17.32975144 </position>
    <velocity> 0.00036280 0.00045095 0.00030521 </velocity>
    <force> -0.00734768 0.00494801 -0.02129442 </force>
  </atom>
  <atom name="H71" species="hydrogen">
    <position> 7.99555240 8.51168025 -40.40205548 </position>
    <velocity> -0.00071978 -0.00048023 0.00030185 </velocity>
    <force> 0.00080944 -0.00502488 0.00031961 </force>
  </atom>
  <atom name="H72" species="hydrogen">
    <position> 8.53439894 5.88828340 -39.07927922 </position>
    <velocity> 0.00039703 -0.00057758 -0.00072830 </velocity>
    <force> 0.00801190 -0.00039962 0.00154564 </force>
  </atom>
  <atom name="H73" species="hydrogen">
    <position> -10.43456601 -2.63486164 7.07200411 </position>
    <velocity> -0.00073290 0.00074160 0.00045308 </velocity>
    <force> -0.00666664 0.01634493 -0.02066722 </force>
  </atom>
  <atom name="H74" species="hydrogen">
    <position> -10.90464205 -2.21760737 4.05639326 </position>
    <velocity> -0.00005211 0.00019113 -0.00016984 </velocity>
    <force> 0.00407102 0.01607329 0.03723526 </force>
  </atom>
  <atom name="H75" species="hydrogen">
    <position> 2.02136800 10.79295224 18.89981668 </position>
    <velocity> 0.00003664 0.00011454 -0.00097554 </velocity>
    <force> -0.00850891 0.00050878 0.01400001 </force>
  </atom>
  <atom name="H76" species="hydrogen">
    <position> 2.04437289 10.51763961 16.06627259 </position>
    <velocity> 0.00004736 -0.00018892 0.00118434 </velocity>
    <force> -0.00727494 0.00877917 -0.01117760 </force>
  </atom>
  <atom name="H77" species="hydrogen">
    <position> 8.45664230 10.55962337 -10.09546403 </position>
    <velocity> -0.00049880 0.00012328 0.00041123 </velocity>
    <force> -0.00020694 0.01092036 -0.00755475 </force>
  </atom>
  <atom name="H78" species="hydrogen">
    <position> 7.88015748 11.10962123 -13.05262833 </position>
    <velocity> -0.00173414 -0.00131601 0.00071423 </velocity>
    <force> 0.00853655 0.01283168 -0.00070428 </force>
  </atom>
  <atom name="H79" species="hydrogen">
    <position> -17.62587177 -7.64008278 11.17255649 </position>
    <velocity> 0.00104889 0.00054201 0.00051108 </velocity>
    <force> -0.01303450 -0.00166350 -0.01167030 </force>
  </atom>
  <atom name="H80" species="hydrogen">
    <position> -15.88476534 -5.73938995 12.58523498 </position>
    <velocity> -0.00122367 -0.00086042 -0.00080715 </velocity>
    <force> 0.00330771 -0.00335312 -0.00071103 </force>
  </atom>
  <atom name="H81" species="hydrogen">
    <position> 15.98248476 4.79637368 -2.72030641 </position>
    <velocity> 0.00042104 0.00023656 -0.00009516 </velocity>
    <force> -0.01845183 -0.00884944 0.00189410 </force>
  </atom>
  <atom name="H82" species="hydrogen">
    <position> 13.70317117 5.03723628 -0.80443229 </position>
    <velocity> 0.00002585 0.00125443 0.00062437 </velocity>
    <force> -0.00277629 0.00235652 0.00628242 </force>
  </atom>
  <atom name="H83" species="hydrogen">
    <position> -7.89472981 17.30369965 15.74811204 </position>
    <velocity> 0.00074654 0.00170450 0.00001101 </velocity>
    <force> 0.00034545 0.01200947 0.00185555 </force>
  </atom>
  <atom name="H84" species="hydrogen">
    <position> -10.51885939 18.18958545 16.94470845 </position>
    <velocity> -0.00003059 -0.00083261 -0.00030231 </velocity>
    <force> -0.00329433 0.00395119 0.00120676 </force>
  </atom>
  <atom name="H85" species="hydrogen">
    <position> -4.93946503 -3.08784379 -9.15142039 </position>
    <velocity> -0.00003236 0.00014050 -0.00026382 </velocity>
    <force> -0.00544946 0.03527417 -0.01193892 </force>
  </atom>
  <atom name="H86" species="hydrogen">
    <position> -3.72470230 -4.75901149 -7.18764811 </position>
    <velocity> 0.00031297 0.00015952 0.00067199 </velocity>
    <force> 0.00612856 -0.00525700 0.00120498 </force>
  </atom>
  <atom name="H87" species="hydrogen">
    <position> -12.19545611 -11.39347785 17.08735685 </position>
    <velocity> 0.00059152 0.00050035 -0.00062078 </velocity>
    <force> -0.02071538 0.00174128 0.03223673 </force>
  </atom>
  <atom name="H88" species="hydrogen">
    <position> -10.31960555 -9.51079227 15.56268437 </position>
    <velocity> 0.00047937 0.00075300 -0.00017533 </velocity>
    <force> -0.02194609 -0.01788396 0.01317935 </force>
  </atom>
  <atom name="H89" species="hydrogen">
    <position> -8.59863561 25.04213707 5.30206050 </position>
    <velocity> -0.00018150 -0.00036641 -0.00024418 </velocity>
    <force> -0.00399584 -0.00482776 -0.00317809 </force>
  </atom>
  <atom name="H90" species="hydrogen">
    <position> -6.39782750 26.95183135 6.12216801 </position>
    <velocity> -0.00088427 -0.00125736 0.00073424 </velocity>
    <force> -0.01634945 -0.00574007 -0.03184204 </force>
  </atom>
  <atom name="H91" species="hydrogen">
    <position> 11.94719579 -4.93387812 -12.88118574 </position>
    <velocity> -0.00019197 0.00037986 0.00019244 </velocity>
    <force> 0.02288690 -0.00823399 -0.03739532 </force>
  </atom>
  <atom name="H92" species="hydrogen">
    <position> 14.51332396 -6.35582595 -14.05665972 </position>
    <velocity> 0.00008960 -0.00024147 -0.00037051 </velocity>
    <force> -0.02471640 0.03066415 -0.00832178 </force>
  </atom>
  <atom name="H93" species="hydrogen">
    <position> -3.97188056 -2.25740282 2.05726341 </position>
    <velocity> -0.00061916 -0.00062587 -0.00001651 </velocity>
    <force> -0.00349991 0.01665081 -0.00455198 </force>
  </atom>
  <atom name="H94" species="hydrogen">
    <position> -5.29350924 -0.09618113 3.49561767 </position>
    <velocity> 0.00033718 -0.00161004 0.00003287 </velocity>
    <force> -0.04612505 0.02890858 0.00360928 </force>
  </atom>
  <atom name="H95" species="hydrogen">
    <position> -18.53254061 -18.01506844 -18.00728477 </position>
    <velocity> -0.00025732 0.00070724 0.00057234 </velocity>
    <force> 0.02639173 0.01239486 -0.00730106 </force>
  </atom>
  <atom name="H96" species="hydrogen">
    <position> -21.01927055 -17.42214158 -16.89756481 </position>
    <velocity> 0.00026114 -0.00035198 -0.00032168 </velocity>
    <force> -0.01868449 0.01853954 0.00986664 </force>
  </atom>
  <atom name="H97" species="hydrogen">
    <position> -38.78706778 4.08904014 -23.58987782 </position>
    <velocity> -0.00039354 0.00046542 -0.00026618 </velocity>
    <force> -0.01797523 -0.00163569 -0.00929369 </force>
  </atom>
  <atom name="H98" species="hydrogen">
    <position> -37.37548700 1.50067021 -24.01042389 </position>
    <velocity> 0.00024942 0.00056335 -0.00075768 </velocity>
    <force> 0.01196375 -0.01103874 0.00029082 </force>
  </atom>
  <atom name="H99" species="hydrogen">
    <position> 32.74891879 17.66636881 -4.07692327 </position>
    <velocity> 0.00004535 -0.00009585 0.00107333 </velocity>
    <force> -0.00377931 -0.01533534 0.00777393 </force>
  </atom>
  <atom name="H100" species="hydrogen">
    <position> 31.19614639 15.00749644 -4.27568979 </position>
    <velocity> 0.00055693 -0.00053525 0.00020669 </velocity>
    <force> 0.01448269 0.00329048 0.00313226 </force>
  </atom>
  <atom name="H101" species="hydrogen">
    <position> 9.84658158 3.28474836 -5.90828868 </position>
    <velocity> -0.00043037 0.00064586 -0.00075582 </velocity>
    <force> -0.05630505 -0.02768778 -0.00255729 </force>
  </atom>
  <atom name="H102" species="hydrogen">
    <position> 12.18728688 3.83995045 -4.38684341 </position>
    <velocity> 0.00126797 0.00038331 -0.00107697 </velocity>
    <force> 0.01249503 0.00727430 -0.01314037 </force>
  </atom>
  <atom name="H103" species="hydrogen">
    <position> -3.40978144 3.83757843 18.64028521 </position>
    <velocity> -0.00037236 -0.00080233 0.00030573 </velocity>
    <force> 0.00336807 0.01001898 0.00605749 </force>
  </atom>
  <atom name="H104" species="hydrogen">
    <position> -1.50342497 1.67816751 19.53919931 </position>
    <velocity> 0.00026717 0.00060785 -0.00085234 </velocity>
    <force> -0.00042110 -0.01551052 0.01641616 </force>
  </atom>
  <atom name="H105" species="hydrogen">
    <position> 21.75601095 -10.87647767 -6.92846297 </position>
    <velocity> 0.00036818 0.00070189 -0.00017451 </velocity>
    <force> -0.01318919 0.00199131 0.00403608 </force>
  </atom>
  <atom name="H106" species="hydrogen">
    <position> 19.81798529 -9.19897692 -8.52106863 </position>
    <velocity> 0.00061073 -0.00038245 0.00084323 </velocity>
    <force> 0.00624158 -0.02201124 0.02976923 </force>
  </atom>
  <atom name="H107" species="hydrogen">
    <position> 0.94431392 -8.54003114 10.97039203 </position>
    <velocity> -0.00051742 0.00074843 -0.00032357 </velocity>
    <force> 0.01384484 0.00947305 -0.01162022 </force>
  </atom>
  <atom name="H108" species="hydrogen">
    <position> 0.76040744 -7.46561883 13.84066140 </position>
    <velocity> 0.00071854 -0.00035643 -0.00011218 </velocity>
    <force> 0.00866444 0.01083812 0.00033405 </force>
  </atom>
  <atom name="H109" species="hydrogen">
    <position> 18.13841042 -5.06838535 -1.20437433 </position>
    <velocity> -0.00009825 -0.00037403 -0.00023482 </velocity>
    <force> -0.00195594 -0.01228368 -0.00400981 </force>
  </atom>
  <atom name="H110" species="hydrogen">
    <position> 19.16565234 -2.40375604 -1.59053694 </position>
    <velocity> -0.00014327 -0.00032147 -0.00025675 </velocity>
    <force> 0.02031530 0.01479180 -0.01529088 </force>
  </atom>
  <atom name="H111" species="hydrogen">
    <position> 23.99577792 -6.70894829 18.49170369 </position>
    <velocity> -0.00050026 -0.00068967 0.00053927 </velocity>
    <force> 0.00086554 -0.00224699 0.00088212 </force>
  </atom>
  <atom name="H112" species="hydrogen">
    <position> 25.03142158 -4.24324880 17.14424057 </position>
    <velocity> 0.00019353 0.00052587 0.00039148 </velocity>
    <force> -0.00706102 -0.00956874 -0.00827917 </force>
  </atom>
  <atom name="H113" species="hydrogen">
    <position> 2.30223571 34.12603291 -23.58760552 </position>
    <velocity> 0.00023572 0.00017118 -0.00012095 </velocity>
    <force> 0.01141449 -0.00719252 -0.00449835 </force>
  </atom>
  <atom name="H114" species="hydrogen">
    <position> 1.14744783 31.61207207 -24.09014648 </position>
    <velocity> 0.00001530 -0.00026587 -0.00020241 </velocity>
    <force> -0.02305783 -0.01698381 0.00356440 </force>
  </atom>
  <atom name="H115" species="hydrogen">
    <position> 6.95022975 1.88144191 -13.85208572 </position>
    <velocity> 0.00046021 -0.00025834 -0.00005230 </velocity>
    <force> -0.03355898 -0.01311169 -0.02434277 </force>
  </atom>
  <atom name="H116" species="hydrogen">
    <position> 4.72755206 2.90635124 -15.72945603 </position>
    <velocity> 0.00008295 -0.00062359 0.00060019 </velocity>
    <force> -0.01149487 -0.00329709 -0.00367844 </force>
  </atom>
  <atom name="H117" species="hydrogen">
    <position> -3.34150206 -14.75739257 -21.95352124 </position>
    <velocity> 0.00062238 0.00047299 0.00091995 </velocity>
    <force> 0.01737735 -0.01500456 -0.00207093 </force>
  </atom>
  <atom name="H118" species="hydrogen">
    <position> -1.96725986 -17.41623638 -22.05694806 </position>
    <velocity> -0.00049490 -0.00135734 0.00048039 </velocity>
    <force> 0.00524380 -0.03521068 0.01999980 </force>
  </atom>
  <atom name="H119" species="hydrogen">
    <position> -29.01480469 -14.00011218 10.81314282 </position>
    <velocity> 0.00054617 0.00001782 -0.00123082 </velocity>
    <force> 0.00418785 -0.01470649 0.00137848 </force>
  </atom>
  <atom name="H120" species="hydrogen">
    <position> -27.99366719 -11.50740972 10.12431442 </position>
    <velocity> 0.00088578 0.00027979 0.00089438 </velocity>
    <force> 0.00983196 0.00674757 -0.00028775 </force>
  </atom>
  <atom name="H121" species="hydrogen">
    <position> -4.60800975 4.83543650 -13.74909266 </position>
    <velocity> -0.00070413 0.00043905 -0.00045530 </velocity>
    <force> -0.00129056 0.00437746 -0.00541382 </force>
  </atom>
  <atom name="H122" species="hydrogen">
    <position> -2.98253544 2.80226493 -15.15063996 </position>
    <velocity> -0.00028460 0.00013808 0.00007949 </velocity>
    <force> 0.00144889 0.00154786 -0.00348221 </force>
  </atom>
  <atom name="H123" species="hydrogen">
    <position> -5.16785595 -6.99532868 31.88442296 </position>
    <velocity> -0.00056589 0.00057258 0.00078048 </velocity>
    <force> 0.01635186 0.01333850 -0.02536053 </force>
  </atom>
  <atom name="H124" species="hydrogen">
    <position> -5.05171660 -6.39671997 34.79876083 </position>
    <velocity> 0.00009916 0.00096244 0.00013045 </velocity>
    <force> 0.01379898 0.01130393 0.01620523 </force>
  </atom>
  <atom name="H125" species="hydrogen">
    <position> -20.96490068 -9.21180347 30.21045068 </position>
    <velocity> 0.00017843 -0.00092693 0.00034651 </velocity>
    <force> 0.00112505 -0.01677194 -0.01138592 </force>
  </atom>
  <atom name="H126" species="hydrogen">
    <position> -20.87053946 -6.50205692 30.83930956 </position>
    <velocity> 0.00030677 0.00026182 0.00047867 </velocity>
    <force> -0.00148353 0.00917241 0.00438238 </force>
  </atom>
  <atom name="H127" species="hydrogen">
    <position> 10.49734387 6.03935382 25.14220309 </position>
    <velocity> 0.00101249 -0.00088890 -0.00036497 </velocity>
    <force> 0.03149259 0.01156662 0.02592502 </force>
  </atom>
  <atom name="H128" species="hydrogen">
    <position> 13.28835497 5.37869979 26.81505925 </position>
    <velocity> 0.00061214 -0.00042134 -0.00071570 </velocity>
    <force> -0.01621563 -0.00062147 -0.01003734 </force>
  </atom>
</atomset>
<unit_cell_a_norm> 23.460000 </unit_cell_a_norm>
<unit_cell_b_norm> 23.460000 </unit_cell_b_norm>
<unit_cell_c_norm> 23.460000 </unit_cell_c_norm>
<unit_cell_alpha>  90.000 </unit_cell_alpha>
<unit_cell_beta>   90.000 </unit_cell_beta>
<unit_cell_gamma>  90.000 </unit_cell_gamma>
<unit_cell_volume> 12911.718 </unit_cell_volume>
  <econst> -1100.15056337 </econst>
  <ekin_ion> 0.36749276 </ekin_ion>
  <temp_ion> 402.95404577 </temp_ion>
  total_electronic_charge: 512.00000000
  <eigenvalue_sum>  -162.40221032 </eigenvalue_sum>
  <etotal_int>   -1100.51512754 </etotal_int>
  total_electronic_charge: 512.00000000
  <eigenvalue_sum>  -162.40560563 </eigenvalue_sum>
  Anderson extrapolation: theta=1.44297568 (1.44297568)
  <etotal_int>   -1100.51518670 </etotal_int>
  total_electronic_charge: 512.00000000
  <eigenvalue_sum>  -162.41026739 </eigenvalue_sum>
  Anderson extrapolation: theta=0.16118580 (0.16118580)
  <etotal_int>   -1100.51523271 </etotal_int>
  total_electronic_charge: 512.00000000
  <eigenvalue_sum>  -162.41082899 </eigenvalue_sum>
  Anderson extrapolation: theta=2.05740919 (2.00000000)
  <etotal_int>   -1100.51523845 </etotal_int>
  total_electronic_charge: 512.00000000
  <eigenvalue_sum>  -162.41187698 </eigenvalue_sum>
  Anderson extrapolation: theta=0.24649384 (0.24649384)
  <etotal_int>   -1100.51524489 </etotal_int>
  <timing name="iteration" min="    5.574" max="    5.584"/>
</iteration>
<iteration count="4">
  total_electronic_charge: 512.00000000
  <ekin>       808.24196435 </ekin>
  <econf>        0.00000000 </econf>
  <eps>      -1309.09779448 </eps>
  <enl>        124.87276651 </enl>
  <ecoul>     -453.57540289 </ecoul>
  <exc>       -270.95677957 </exc>
  <esr>         93.27727039 </esr>
  <eself>      646.81841729 </eself>
  <ets>          0.00000000 </ets>
  <eexf>         0.00000000 </eexf>
  <etotal>   -1100.51524608 </etotal>
  <epv>          0.00000000 </epv>
  <eefield>      0.00000000 </eefield>
  <enthalpy> -1100.51524608 </enthalpy>
<atomset>
<unit_cell 
    a=" 23.46000000   0.00000000   0.00000000"
    b="  0.00000000  23.46000000   0.00000000"
    c="  0.00000000   0.00000000  23.46000000" />
  <atom name="O1" species="oxygen">
    <position> -6.48825826 6.01151926 12.38671336 </position>
    <velocity> -0.00013583 -0.00020294 0.00031130 </velocity>
    <force> 0.05535903 -0.00273653 0.02575573 </force>
  </atom>
  <atom name="O2" species="oxygen">
    <position> 23.13599155 2.61331013 25.48994996 </position>
    <velocity> -0.00000524 0.00005341 -0.00021065 </velocity>
    <force> 0.00355085 -0.00986926 0.02043355 </force>
  </atom>
  <atom name="O3" species="oxygen">
    <position> -28.80031463 23.73675886 -33.09858417 </position>
    <velocity> -0.00015354 0.00013053 -0.00013946 </velocity>
    <force> 0.02371559 0.00172556 -0.01679299 </force>
  </atom>
  <atom name="O4" species="oxygen">
    <position> 13.16589262 -9.21745403 -0.60105385 </position>
    <velocity> 0.00008048 -0.00024549 0.00010926 </velocity>
    <force> 0.00190147 -0.01911191 0.03358452 </force>
  </atom>
  <atom name="O5" species="oxygen">
    <position> 6.67424585 -22.47157890 -5.69462535 </position>
    <velocity> 0.00027152 0.00001302 -0.00047320 </velocity>
    <force> 0.00122622 0.02044172 0.02911020 </force>
  </atom>
  <atom name="O6" species="oxygen">
    <position> 8.02146661 16.92670342 5.24294703 </position>
    <velocity> 0.00008588 -0.00022854 0.00034884 </velocity>
    <force> -0.01316005 0.00183807 -0.01881654 </force>
  </atom>
  <atom name="O7" species="oxygen">
    <position> -4.61541291 -29.12255613 -18.04885173 </position>
    <velocity> -0.00002180 0.00047273 -0.00028448 </velocity>
    <force> -0.00667979 0.03332009 0.00400316 </force>
  </atom>
  <atom name="O8" species="oxygen">
    <position> 2.78291096 -14.70457718 13.54256191 </position>
    <velocity> -0.00006320 -0.00043975 0.00020925 </velocity>
    <force> 0.00627007 -0.00241126 -0.01368722 </force>
  </atom>
  <atom name="O9" species="oxygen">
    <position> 2.60454556 4.39999654 -6.45083320 </position>
    <velocity> -0.00030194 -0.00001263 -0.00039723 </velocity>
    <force> 0.02590333 0.01655822 -0.00752467 </force>
  </atom>
  <atom name="O10" species="oxygen">
    <position> 0.41213752 7.99277875 8.12289794 </position>
    <velocity> 0.00013848 0.00028032 0.00021482 </velocity>
    <force> -0.01484511 0.02904953 0.00772091 </force>
  </atom>
  <atom name="O11" species="oxygen">
    <position> 13.17641373 -14.43762395 10.99559474 </position>
    <velocity> -0.00006598 0.00009516 -0.00000802 </velocity>
    <force> 0.00064061 -0.00356516 -0.00942222 </force>
  </atom>
  <atom name="O12" species="oxygen">
    <position> -13.18988779 -2.55972100 13.06618478 </position>
    <velocity> 0.00025861 -0.00015543 -0.00012856 </velocity>
    <force> -0.02036985 -0.02715713 -0.01854726 </force>
  </atom>
  <atom name="O13" species="oxygen">
    <position> 2.32175802 -9.78650694 -21.53815327 </position>
    <velocity> -0.00011571 0.00038561 0.00012923 </velocity>
    <force> -0.00624302 -0.00947131 0.00679940 </force>
  </atom>
  <atom name="O14" species="oxygen">
    <position> -5.30577119 -9.16717882 -2.46738980 </position>
    <velocity> -0.00015782 0.00004497 -0.00033258 </velocity>
    <force> 0.03417836 0.01737557 0.00722603 </force>
  </atom>
  <atom name="O15" species="oxygen">
    <position> 13.30381538 -11.99727591 4.14922781 </position>
    <velocity> -0.00048170 -0.00030419 0.00018580 </velocity>
    <force> 0.02578094 -0.02075590 -0.04226542 </force>
  </atom>
  <atom name="O16" species="oxygen">
    <position> -6.98979239 9.50707411 -7.02111185 </position>
    <velocity> -0.00006132 0.00023712 -0.00007936 </velocity>
    <force> 0.00124656 -0.01210794 -0.00275309 </force>
  </atom>
  <atom name="O17" species="oxygen">
    <position> -13.79158440 -14.61356201 -27.72881665 </position>
    <velocity> -0.00001260 0.00011530 0.00019709 </velocity>
    <force> -0.01280937 0.00848677 -0.02330077 </force>
  </atom>
  <atom name="O18" species="oxygen">
    <position> -19.93069659 -2.76086042 14.85665719 </position>
    <velocity> -0.00022471 -0.00014446 0.00012053 </velocity>
    <force> -0.01661066 0.00417110 0.00473744 </force>
  </atom>
  <atom name="O19" species="oxygen">
    <position> 7.37104706 -16.23374748 0.19883926 </position>
    <velocity> -0.00033807 -0.00034442 0.00004738 </velocity>
    <force> 0.01297128 0.00834441 -0.00350884 </force>
  </atom>
  <atom name="O20" species="oxygen">
    <position> 5.89940481 17.68374747 -22.94991210 </position>
    <velocity> 0.00006908 -0.00012197 -0.00000419 </velocity>
    <force> -0.01285737 0.01356751 0.00878584 </force>
  </atom>
  <atom name="O21" species="oxygen">
    <position> 2.45693973 1.82912169 12.74158636 </position>
    <velocity> -0.00020737 0.00029024 -0.00012975 </velocity>
    <force> 0.00048867 -0.00420589 0.00332100 </force>
  </atom>
  <atom name="O22" species="oxygen">
    <position> -9.89395931 -4.94865530 2.28636783 </position>
    <velocity> 0.00031305 0.00010014 -0.00033309 </velocity>
    <force> -0.01431305 -0.00515185 -0.01597660 </force>
  </atom>
  <atom name="O23" species="oxygen">
    <position> -13.80893489 -10.70526696 7.66733192 </position>
    <velocity> 0.00015500 0.00001936 -0.00036881 </velocity>
    <force> 0.00514957 0.01637240 -0.00119275 </force>
  </atom>
  <atom name="O24" species="oxygen">
    <position> 18.59948128 -13.37248656 4.52337331 </position>
    <velocity> 0.00033631 -0.00014052 -0.00005909 </velocity>
    <force> -0.01708766 0.01220807 -0.01726484 </force>
  </atom>
  <atom name="O25" species="oxygen">
    <position> 20.48659863 14.37369563 2.06385999 </position>
    <velocity> 0.00002694 -0.00050130 -0.00044412 </velocity>
    <force> -0.00410086 0.00084242 -0.00221728 </force>
  </atom>
  <atom name="O26" species="oxygen">
    <position> 6.68687079 13.02697413 -30.12057701 </position>
    <velocity> -0.00000687 0.00021675 0.00015284 </velocity>
    <force> 0.00805908 0.01699465 -0.01111640 </force>
  </atom>
  <atom name="O27" species="oxygen">
    <position> 12.82102653 -21.73261106 -10.27702282 </position>
    <velocity> 0.00014835 -0.00028018 0.00012674 </velocity>
    <force> 0.04348973 -0.00493351 -0.00179325 </force>
  </atom>
  <atom name="O28" species="oxygen">
    <position> 10.66328946 3.71698709 -14.53358182 </position>
    <velocity> 0.00008313 0.00032932 -0.00023334 </velocity>
    <force> 0.01632662 -0.00281483 0.02477095 </force>
  </atom>
  <atom name="O29" species="oxygen">
    <position> -4.81742032 6.47837407 -3.64535314 </position>
    <velocity> 0.00001471 -0.00007076 0.00014843 </velocity>
    <force> -0.04887620 -0.02218010 -0.04380223 </force>
  </atom>
  <atom name="O30" species="oxygen">
    <position> -10.79259823 -0.59988326 22.05495875 </position>
    <velocity> 0.00035644 0.00009393 -0.00015147 </velocity>
    <force> 0.01615781 0.03796414 -0.01307105 </force>
  </atom>
  <atom name="O31" species="oxygen">
    <position> 4.42118227 -1.01534777 0.92059068 </position>
    <velocity> 0.00016095 0.00002840 0.00027716 </velocity>
    <force> -0.01587346 -0.00582403 0.01809118 </force>
  </atom>
  <atom name="O32" species="oxygen">
    <position> 22.69450516 -0.70807619 -1.95724980 </position>
    <velocity> -0.00009965 0.00008196 0.00043052 </velocity>
    <force> -0.00251437 0.03312517 0.05476424 </force>
  </atom>
  <atom name="O33" species="oxygen">
    <position> -1.15046671 23.06601245 9.74313087 </position>
    <velocity> -0.00003973 0.00010582 0.00001473 </velocity>
    <force> -0.04650374 -0.01846260 -0.03867009 </force>
  </atom>
  <atom name="O34" species="oxygen">
    <position> -13.42654089 -2.82083202 18.13241330 </position>
    <velocity> -0.00026782 0.00003112 0.00015075 </velocity>
    <force> -0.00039869 -0.00896264 -0.00288447 </force>
  </atom>
  <atom name="O35" species="oxygen">
    <position> 4.04995251 -2.42312742 -17.77388607 </position>
    <velocity> 0.00001005 -0.00009191 0.00011494 </velocity>
    <force> 0.02749641 0.00098228 0.06521032 </force>
  </atom>
  <atom name="O36" species="oxygen">
    <position> 7.53123672 6.72374165 -40.39674502 </position>
    <velocity> -0.00035045 -0.00005364 -0.00007689 </velocity>
    <force> 0.00209497 0.01305531 -0.00560074 </force>
  </atom>
  <atom name="O37" species="oxygen">
    <position> -10.79674269 -1.21920656 5.74314365 </position>
    <velocity> -0.00027146 0.00002461 0.00000431 </velocity>
    <force> 0.00249360 -0.02516133 -0.01153779 </force>
  </atom>
  <atom name="O38" species="oxygen">
    <position> 1.47448634 11.75284510 17.40440681 </position>
    <velocity> -0.00014472 0.00012057 0.00011435 </velocity>
    <force> 0.01262609 -0.00695122 -0.00170835 </force>
  </atom>
  <atom name="O39" species="oxygen">
    <position> 7.69558054 9.92827343 -11.65247519 </position>
    <velocity> 0.00016129 0.00003926 0.00007359 </velocity>
    <force> -0.01052664 -0.02895488 0.01465519 </force>
  </atom>
  <atom name="O40" species="oxygen">
    <position> -16.36926121 -7.52547844 12.48283410 </position>
    <velocity> 0.00038697 0.00024397 0.00014551 </velocity>
    <force> 0.01361132 0.00139894 0.01530845 </force>
  </atom>
  <atom name="O41" species="oxygen">
    <position> 14.21797365 4.03631104 -2.28579818 </position>
    <velocity> -0.00012346 0.00009770 0.00015130 </velocity>
    <force> 0.03469173 0.01290352 0.00970507 </force>
  </atom>
  <atom name="O42" species="oxygen">
    <position> -9.69003545 16.85363518 16.01114196 </position>
    <velocity> -0.00014959 -0.00008806 0.00020980 </velocity>
    <force> 0.01018170 -0.01612029 -0.00959205 </force>
  </atom>
  <atom name="O43" species="oxygen">
    <position> -5.15385590 -4.68881299 -8.35745342 </position>
    <velocity> 0.00001827 0.00016472 -0.00013577 </velocity>
    <force> 0.00857664 -0.03479546 0.01358100 </force>
  </atom>
  <atom name="O44" species="oxygen">
    <position> -11.06838131 -11.34198727 15.72293165 </position>
    <velocity> -0.00014809 0.00033993 0.00029048 </velocity>
    <force> 0.03902935 0.02282792 -0.05408834 </force>
  </atom>
  <atom name="O45" species="oxygen">
    <position> -7.56299953 26.42900732 4.58486771 </position>
    <velocity> 0.00039648 -0.00027123 -0.00045073 </velocity>
    <force> 0.01398007 0.00671527 0.03351875 </force>
  </atom>
  <atom name="O46" species="oxygen">
    <position> 12.86663455 -5.28827913 -14.60249650 </position>
    <velocity> -0.00038698 -0.00012588 0.00021734 </velocity>
    <force> 0.00264702 -0.02070439 0.05096899 </force>
  </atom>
  <atom name="O47" species="oxygen">
    <position> -3.72924736 -0.90438791 3.37737373 </position>
    <velocity> 0.00041214 -0.00027819 -0.00027721 </velocity>
    <force> 0.04850383 -0.04063038 -0.00075778 </force>
  </atom>
  <atom name="O48" species="oxygen">
    <position> -20.14672029 -18.79264360 -17.69985503 </position>
    <velocity> -0.00013578 0.00023224 0.00008137 </velocity>
    <force> -0.00885572 -0.03609700 -0.01480344 </force>
  </atom>
  <atom name="O49" species="oxygen">
    <position> -39.02401178 2.29833308 -24.17428378 </position>
    <velocity> -0.00017345 0.00030049 -0.00010941 </velocity>
    <force> 0.00340266 0.00678018 0.00334096 </force>
  </atom>
  <atom name="O50" species="oxygen">
    <position> 32.37377956 16.01275747 -3.14682282 </position>
    <velocity> 0.00009151 -0.00008345 -0.00012944 </velocity>
    <force> -0.00330385 0.01223138 -0.01478334 </force>
  </atom>
  <atom name="O51" species="oxygen">
    <position> 11.41170425 4.03587157 -6.13427431 </position>
    <velocity> -0.00024060 -0.00011163 0.00003758 </velocity>
    <force> 0.03927974 0.02758542 0.00263503 </force>
  </atom>
  <atom name="O52" species="oxygen">
    <position> -2.00432745 2.73019854 18.12903629 </position>
    <velocity> 0.00009690 -0.00028642 0.00007213 </velocity>
    <force> -0.00447243 0.00451100 -0.03299488 </force>
  </atom>
  <atom name="O53" species="oxygen">
    <position> 19.90943823 -10.33437689 -6.94926495 </position>
    <velocity> 0.00006006 0.00032651 -0.00027389 </velocity>
    <force> 0.01978993 0.02098797 -0.03501820 </force>
  </atom>
  <atom name="O54" species="oxygen">
    <position> 0.06541527 -8.55914196 12.55824674 </position>
    <velocity> -0.00026680 -0.00004215 -0.00017716 </velocity>
    <force> -0.03063303 -0.01574797 0.01854536 </force>
  </atom>
  <atom name="O55" species="oxygen">
    <position> 18.01932838 -3.35340141 -0.57175296 </position>
    <velocity> -0.00000934 -0.00011543 0.00000613 </velocity>
    <force> -0.01223315 -0.00867555 0.01176373 </force>
  </atom>
  <atom name="O56" species="oxygen">
    <position> 23.50806081 -5.36481964 17.34483659 </position>
    <velocity> 0.00027458 -0.00030711 0.00001377 </velocity>
    <force> 0.00588704 0.00761404 0.00691569 </force>
  </atom>
  <atom name="O57" species="oxygen">
    <position> 2.68024464 32.48649032 -24.49526396 </position>
    <velocity> 0.00010270 -0.00014455 0.00007856 </velocity>
    <force> 0.01425095 0.03552899 0.00325095 </force>
  </atom>
  <atom name="O58" species="oxygen">
    <position> 5.18504606 1.41476886 -14.61116459 </position>
    <velocity> -0.00010258 0.00009002 0.00013471 </velocity>
    <force> 0.05974389 0.00679221 0.02502142 </force>
  </atom>
  <atom name="O59" species="oxygen">
    <position> -2.11025391 -15.85700662 -22.92105919 </position>
    <velocity> 0.00017574 -0.00007904 -0.00004489 </velocity>
    <force> -0.02211143 0.03840773 -0.00802598 </force>
  </atom>
  <atom name="O60" species="oxygen">
    <position> -27.37373578 -13.21862707 10.47670012 </position>
    <velocity> -0.00024499 -0.00020387 0.00004822 </velocity>
    <force> -0.00752527 0.01624502 -0.00462738 </force>
  </atom>
  <atom name="O61" species="oxygen">
    <position> -3.87109058 4.42419101 -15.46518417 </position>
    <velocity> -0.00016434 0.00013508 -0.00029374 </velocity>
    <force> -0.00136218 -0.00617882 0.01740961 </force>
  </atom>
  <atom name="O62" species="oxygen">
    <position> -6.02249003 -7.13020904 33.47129467 </position>
    <velocity> 0.00019841 -0.00015797 -0.00005328 </velocity>
    <force> -0.03192878 -0.02752611 0.01822077 </force>
  </atom>
  <atom name="O63" species="oxygen">
    <position> -20.89124088 -8.14116002 31.68184901 </position>
    <velocity> -0.00028100 0.00004550 0.00025252 </velocity>
    <force> 0.00466204 0.00779539 -0.00290306 </force>
  </atom>
  <atom name="O64" species="oxygen">
    <position> 12.29255356 6.56523827 25.71176442 </position>
    <velocity> 0.00028168 -0.00004289 0.00032307 </velocity>
    <force> -0.00948139 -0.00651214 -0.01158172 </force>
  </atom>
  <atom name="H1" species="hydrogen">
    <position> -5.92434246 7.20918479 13.82529079 </position>
    <velocity> -0.00041759 0.00057388 0.00028256 </velocity>
    <force> -0.02194809 -0.02021589 -0.02178901 </force>
  </atom>
  <atom name="H2" species="hydrogen">
    <position> -8.12817352 6.53284618 11.88128267 </position>
    <velocity> 0.00044944 -0.00060377 0.00044346 </velocity>
    <force> -0.03005277 0.01723596 -0.00186794 </force>
  </atom>
  <atom name="H3" species="hydrogen">
    <position> 24.67835503 2.71943271 26.56096106 </position>
    <velocity> 0.00069801 0.00064598 -0.00083961 </velocity>
    <force> -0.00922749 0.00854391 -0.00597508 </force>
  </atom>
  <atom name="H4" species="hydrogen">
    <position> 22.01949936 1.40626029 26.47073803 </position>
    <velocity> -0.00063406 0.00021184 -0.00030512 </velocity>
    <force> 0.00485008 0.00891911 -0.01418615 </force>
  </atom>
  <atom name="H5" species="hydrogen">
    <position> -27.59815529 24.51795138 -31.87593090 </position>
    <velocity> -0.00081961 -0.00080069 0.00050988 </velocity>
    <force> -0.00768187 -0.00026520 0.00064773 </force>
  </atom>
  <atom name="H6" species="hydrogen">
    <position> -27.80500127 23.83844220 -34.71207567 </position>
    <velocity> -0.00029184 -0.00021710 0.00077141 </velocity>
    <force> -0.00904258 -0.00285041 0.01407447 </force>
  </atom>
  <atom name="H7" species="hydrogen">
    <position> 12.63822666 -10.31477252 0.97367869 </position>
    <velocity> -0.00031896 0.00006904 0.00108695 </velocity>
    <force> 0.00892493 0.02330643 -0.03652266 </force>
  </atom>
  <atom name="H8" species="hydrogen">
    <position> 11.73253323 -8.78267799 -1.72010749 </position>
    <velocity> 0.00006371 0.00031353 -0.00026102 </velocity>
    <force> -0.00982542 -0.00450587 0.00699047 </force>
  </atom>
  <atom name="H9" species="hydrogen">
    <position> 5.49649406 -21.04006507 -6.15878799 </position>
    <velocity> 0.00038298 -0.00047674 0.00024104 </velocity>
    <force> 0.00415641 -0.01472643 0.00871455 </force>
  </atom>
  <atom name="H10" species="hydrogen">
    <position> 6.93044507 -22.24721795 -3.76236078 </position>
    <velocity> 0.00015054 -0.00056495 0.00068117 </velocity>
    <force> -0.00835712 0.00529057 -0.02957026 </force>
  </atom>
  <atom name="H11" species="hydrogen">
    <position> 7.15503503 17.03796128 3.48747752 </position>
    <velocity> -0.00028405 0.00057030 -0.00079038 </velocity>
    <force> 0.01465181 0.00113705 0.01273080 </force>
  </atom>
  <atom name="H12" species="hydrogen">
    <position> 9.66435990 17.76319440 5.02545270 </position>
    <velocity> -0.00092600 0.00000941 0.00042979 </velocity>
    <force> -0.00303935 -0.00146534 -0.00136083 </force>
  </atom>
  <atom name="H13" species="hydrogen">
    <position> -4.23697395 -27.37488418 -18.71639145 </position>
    <velocity> 0.00077707 -0.00025607 0.00091263 </velocity>
    <force> -0.00571533 -0.00707789 0.02304097 </force>
  </atom>
  <atom name="H14" species="hydrogen">
    <position> -3.98765884 -30.08933255 -19.45033284 </position>
    <velocity> 0.00033166 0.00029622 -0.00004610 </velocity>
    <force> 0.00995271 -0.02823010 -0.01774299 </force>
  </atom>
  <atom name="H15" species="hydrogen">
    <position> 1.56653940 -14.53780054 12.11454446 </position>
    <velocity> -0.00065292 -0.00038081 0.00084906 </velocity>
    <force> 0.00920419 -0.00418036 0.00852061 </force>
  </atom>
  <atom name="H16" species="hydrogen">
    <position> 4.51334891 -14.43972497 12.75856972 </position>
    <velocity> -0.00058689 0.00015284 0.00036831 </velocity>
    <force> -0.01210633 0.00086545 0.00539507 </force>
  </atom>
  <atom name="H17" species="hydrogen">
    <position> 2.42300158 6.00611617 -7.41518010 </position>
    <velocity> -0.00005631 0.00037000 0.00024392 </velocity>
    <force> -0.00212944 -0.00914373 0.00607648 </force>
  </atom>
  <atom name="H18" species="hydrogen">
    <position> 0.94833658 3.88101238 -5.78077043 </position>
    <velocity> 0.00042457 0.00229294 -0.00111501 </velocity>
    <force> -0.01614664 0.00112783 -0.00254314 </force>
  </atom>
  <atom name="H19" species="hydrogen">
    <position> -0.82262949 6.64020516 8.31210008 </position>
    <velocity> -0.00041536 0.00044966 0.00020209 </velocity>
    <force> -0.00738114 -0.01146136 0.00072601 </force>
  </atom>
  <atom name="H20" species="hydrogen">
    <position> -0.80106323 9.45925955 8.24908289 </position>
    <velocity> 0.00031681 -0.00025216 0.00007483 </velocity>
    <force> 0.01575011 -0.01455395 -0.00054710 </force>
  </atom>
  <atom name="H21" species="hydrogen">
    <position> 11.53020890 -15.13629592 10.57847997 </position>
    <velocity> -0.00007487 0.00024526 -0.00000185 </velocity>
    <force> -0.00428887 -0.00189791 -0.00298354 </force>
  </atom>
  <atom name="H22" species="hydrogen">
    <position> 12.73800868 -13.13108587 12.19905283 </position>
    <velocity> -0.00024678 -0.00030126 0.00067511 </velocity>
    <force> 0.00055593 0.00673643 0.01173461 </force>
  </atom>
  <atom name="H23" species="hydrogen">
    <position> -12.38743167 -1.55961974 11.79012830 </position>
    <velocity> 0.00093724 -0.00078537 0.00067226 </velocity>
    <force> 0.00238196 0.01625085 -0.01071992 </force>
  </atom>
  <atom name="H24" species="hydrogen">
    <position> -12.35280791 -1.95941761 14.55524686 </position>
    <velocity> 0.00060681 -0.00021304 -0.00010047 </velocity>
    <force> 0.00412232 0.00269014 0.01909348 </force>
  </atom>
  <atom name="H25" species="hydrogen">
    <position> 0.51229172 -9.37387149 -21.32670824 </position>
    <velocity> 0.00028312 0.00006383 0.00019197 </velocity>
    <force> -0.00239279 -0.00030159 -0.00605935 </force>
  </atom>
  <atom name="H26" species="hydrogen">
    <position> 3.09759606 -8.30700569 -22.30504938 </position>
    <velocity> -0.00061712 0.00043460 -0.00041914 </velocity>
    <force> 0.00901622 0.00972984 -0.00281576 </force>
  </atom>
  <atom name="H27" species="hydrogen">
    <position> -7.04410919 -9.58056053 -2.47749484 </position>
    <velocity> 0.00085615 0.00037674 0.00021442 </velocity>
    <force> -0.03532359 -0.00677868 0.00035159 </force>
  </atom>
  <atom name="H28" species="hydrogen">
    <position> -4.57725796 -9.33945567 -4.20185616 </position>
    <velocity> 0.00054318 -0.00038713 0.00002841 </velocity>
    <force> -0.00336818 -0.00520224 0.00306296 </force>
  </atom>
  <atom name="H29" species="hydrogen">
    <position> 12.62076374 -13.66655078 3.60093723 </position>
    <velocity> 0.00053077 -0.00080250 -0.00076129 </velocity>
    <force> 0.00313196 0.00057330 -0.00108736 </force>
  </atom>
  <atom name="H30" species="hydrogen">
    <position> 12.25704370 -11.50351425 5.50362670 </position>
    <velocity> 0.00114391 -0.00012264 -0.00060139 </velocity>
    <force> -0.02676306 0.01128826 0.03458088 </force>
  </atom>
  <atom name="H31" species="hydrogen">
    <position> -5.69109647 10.83340719 -7.22235148 </position>
    <velocity> 0.00002589 -0.00003707 -0.00135218 </velocity>
    <force> 0.00622805 0.00150694 0.00477295 </force>
  </atom>
  <atom name="H32" species="hydrogen">
    <position> -8.62729028 10.39855842 -7.34727194 </position>
    <velocity> -0.00074791 0.00083108 -0.00046346 </velocity>
    <force> -0.00283384 -0.00188266 0.00428087 </force>
  </atom>
  <atom name="H33" species="hydrogen">
    <position> -15.01183523 -13.85930095 -28.96023623 </position>
    <velocity> -0.00095168 0.00068857 0.00063333 </velocity>
    <force> 0.00477184 0.00006085 0.01824829 </force>
  </atom>
  <atom name="H34" species="hydrogen">
    <position> -13.03600687 -15.94156709 -28.80818381 </position>
    <velocity> 0.00027916 0.00034668 -0.00088015 </velocity>
    <force> 0.00402859 -0.00797346 0.00838817 </force>
  </atom>
  <atom name="H35" species="hydrogen">
    <position> -20.43847763 -0.95301725 14.68433887 </position>
    <velocity> -0.00008033 -0.00020963 0.00018972 </velocity>
    <force> -0.00400394 -0.00495031 -0.00801694 </force>
  </atom>
  <atom name="H36" species="hydrogen">
    <position> -18.16746682 -2.60782361 14.49783366 </position>
    <velocity> -0.00013450 0.00025290 0.00024722 </velocity>
    <force> 0.02039103 -0.00248408 0.00093489 </force>
  </atom>
  <atom name="H37" species="hydrogen">
    <position> 5.61997946 -15.54335774 0.46966777 </position>
    <velocity> -0.00008276 0.00032335 0.00153238 </velocity>
    <force> 0.01019395 -0.00611306 -0.01328015 </force>
  </atom>
  <atom name="H38" species="hydrogen">
    <position> 8.14875364 -15.39479167 -1.34312926 </position>
    <velocity> -0.00032410 -0.00039411 -0.00020408 </velocity>
    <force> -0.01387662 -0.00738075 0.01122605 </force>
  </atom>
  <atom name="H39" species="hydrogen">
    <position> 5.53530335 19.56811445 -23.08840763 </position>
    <velocity> -0.00014230 -0.00016798 0.00005529 </velocity>
    <force> -0.00380580 -0.00710987 0.00891789 </force>
  </atom>
  <atom name="H40" species="hydrogen">
    <position> 6.88972737 17.33155596 -24.47597342 </position>
    <velocity> -0.00038156 -0.00028188 0.00010877 </velocity>
    <force> 0.01149122 -0.01346866 -0.00424205 </force>
  </atom>
  <atom name="H41" species="hydrogen">
    <position> 3.79956841 1.89558899 11.41604648 </position>
    <velocity> 0.00051861 0.00012607 -0.00001090 </velocity>
    <force> -0.00719694 -0.00295411 -0.00147887 </force>
  </atom>
  <atom name="H42" species="hydrogen">
    <position> 3.00646082 2.86194552 14.18784419 </position>
    <velocity> -0.00074487 -0.00030703 -0.00024323 </velocity>
    <force> -0.01040836 0.00561347 0.00560508 </force>
  </atom>
  <atom name="H43" species="hydrogen">
    <position> -8.60949158 -5.46229216 3.44380478 </position>
    <velocity> 0.00010262 -0.00077735 0.00062905 </velocity>
    <force> 0.02053979 0.00100529 0.02017699 </force>
  </atom>
  <atom name="H44" species="hydrogen">
    <position> -9.86020085 -6.43737122 1.09493423 </position>
    <velocity> 0.00102494 0.00155103 0.00030281 </velocity>
    <force> -0.01021559 0.00416537 -0.00347895 </force>
  </atom>
  <atom name="H45" species="hydrogen">
    <position> -12.83600482 -9.31483957 8.47482145 </position>
    <velocity> 0.00065712 0.00016495 -0.00022074 </velocity>
    <force> -0.00190865 -0.01064186 0.00448129 </force>
  </atom>
  <atom name="H46" species="hydrogen">
    <position> -14.69491031 -9.57418252 6.43475794 </position>
    <velocity> 0.00054992 -0.00017123 0.00034608 </velocity>
    <force> -0.00580005 -0.00001126 -0.00070707 </force>
  </atom>
  <atom name="H47" species="hydrogen">
    <position> 16.74460200 -13.11297692 4.57298042 </position>
    <velocity> 0.00010111 -0.00086756 0.00042775 </velocity>
    <force> -0.00529096 0.01488726 -0.00968364 </force>
  </atom>
  <atom name="H48" species="hydrogen">
    <position> 18.63440957 -14.70879142 5.71172436 </position>
    <velocity> 0.00085168 -0.00014819 -0.00044644 </velocity>
    <force> 0.01795814 -0.02485636 0.02333337 </force>
  </atom>
  <atom name="H49" species="hydrogen">
    <position> 19.90466682 12.99910293 3.15800672 </position>
    <velocity> -0.00023274 0.00073903 -0.00065072 </velocity>
    <force> 0.00051672 -0.00487922 0.00366862 </force>
  </atom>
  <atom name="H50" species="hydrogen">
    <position> 19.36030790 14.25799036 0.54309609 </position>
    <velocity> 0.00032694 -0.00023727 -0.00005481 </velocity>
    <force> 0.01005279 -0.00008873 -0.00553599 </force>
  </atom>
  <atom name="H51" species="hydrogen">
    <position> 6.81095102 14.30405106 -31.55661518 </position>
    <velocity> 0.00059545 0.00051626 0.00011367 </velocity>
    <force> 0.00098568 -0.01342531 0.00509032 </force>
  </atom>
  <atom name="H52" species="hydrogen">
    <position> 4.86213834 12.88331126 -29.88285728 </position>
    <velocity> -0.00059112 0.00064884 -0.00075623 </velocity>
    <force> -0.01372601 -0.00408647 0.00190512 </force>
  </atom>
  <atom name="H53" species="hydrogen">
    <position> 14.68729217 -22.30992679 -10.22752967 </position>
    <velocity> -0.00060480 0.00014739 0.00033679 </velocity>
    <force> -0.02976056 0.01570175 0.00307207 </force>
  </atom>
  <atom name="H54" species="hydrogen">
    <position> 12.60747325 -20.67553592 -8.68721782 </position>
    <velocity> 0.00104687 -0.00020733 0.00052022 </velocity>
    <force> -0.00146344 -0.00646485 -0.00772222 </force>
  </atom>
  <atom name="H55" species="hydrogen">
    <position> 11.26267783 2.76312609 -15.94778760 </position>
    <velocity> -0.00061994 0.00088207 -0.00090122 </velocity>
    <force> -0.00028713 -0.01129594 -0.02342975 </force>
  </atom>
  <atom name="H56" species="hydrogen">
    <position> 12.02983158 3.24294601 -13.26118206 </position>
    <velocity> 0.00002365 -0.00076835 0.00010278 </velocity>
    <force> -0.02139130 0.00477530 0.00702410 </force>
  </atom>
  <atom name="H57" species="hydrogen">
    <position> -4.03848627 7.06345314 -2.14684356 </position>
    <velocity> -0.00063121 -0.00047570 -0.00054207 </velocity>
    <force> 0.01818980 0.02105755 0.03519614 </force>
  </atom>
  <atom name="H58" species="hydrogen">
    <position> -6.15578864 7.60622926 -4.46692256 </position>
    <velocity> -0.00041518 -0.00025586 -0.00052896 </velocity>
    <force> 0.02491991 0.00379901 0.00352196 </force>
  </atom>
  <atom name="H59" species="hydrogen">
    <position> -10.38173089 -1.62160079 23.47717836 </position>
    <velocity> 0.00061853 0.00013312 -0.00057073 </velocity>
    <force> 0.00728113 -0.02521206 0.01722425 </force>
  </atom>
  <atom name="H60" species="hydrogen">
    <position> -9.36100707 0.73189153 22.01741651 </position>
    <velocity> 0.00002951 0.00002479 -0.00046174 </velocity>
    <force> -0.03009615 -0.01595563 -0.00503799 </force>
  </atom>
  <atom name="H61" species="hydrogen">
    <position> 5.49570237 0.46695710 0.69466464 </position>
    <velocity> 0.00145449 0.00055156 0.00003431 </velocity>
    <force> 0.00821691 0.00598687 -0.00574802 </force>
  </atom>
  <atom name="H62" species="hydrogen">
    <position> 4.12581687 -1.15178973 2.82367454 </position>
    <velocity> -0.00033635 0.00043672 -0.00020190 </velocity>
    <force> 0.00688152 -0.00525255 -0.01764789 </force>
  </atom>
  <atom name="H63" species="hydrogen">
    <position> 23.69327294 -0.32160528 -0.30720225 </position>
    <velocity> -0.00032314 0.00048365 -0.00050998 </velocity>
    <force> -0.02049311 0.00596424 -0.03025321 </force>
  </atom>
  <atom name="H64" species="hydrogen">
    <position> 23.58728781 -2.07763023 -2.58892184 </position>
    <velocity> -0.00050137 0.00057466 -0.00054462 </velocity>
    <force> 0.02437843 -0.04116569 -0.02585418 </force>
  </atom>
  <atom name="H65" species="hydrogen">
    <position> -0.42168562 21.65527755 8.81304145 </position>
    <velocity> 0.00051936 -0.00018689 0.00006087 </velocity>
    <force> -0.00744150 -0.00125281 -0.00630857 </force>
  </atom>
  <atom name="H66" species="hydrogen">
    <position> 0.17131597 23.51471452 10.79422380 </position>
    <velocity> 0.00099052 -0.00006989 0.00059228 </velocity>
    <force> 0.04531103 0.02644719 0.04480942 </force>
  </atom>
  <atom name="H67" species="hydrogen">
    <position> -12.44157371 -1.82741124 19.32559259 </position>
    <velocity> -0.00012105 -0.00013992 0.00067757 </velocity>
    <force> 0.01332498 0.00270128 0.01635811 </force>
  </atom>
  <atom name="H68" species="hydrogen">
    <position> -14.85825847 -1.68493481 17.79242641 </position>
    <velocity> -0.00001002 0.00038818 -0.00098854 </velocity>
    <force> -0.00751250 0.00172388 -0.00695804 </force>
  </atom>
  <atom name="H69" species="hydrogen">
    <position> 4.64343277 -1.25708769 -16.21263520 </position>
    <velocity> -0.00003922 -0.00102636 0.00047063 </velocity>
    <force> -0.02035503 -0.00585478 -0.03866451 </force>
  </atom>
  <atom name="H70" species="hydrogen">
    <position> 5.30212221 -3.78597455 -17.32698931 </position>
    <velocity> 0.00034313 0.00046301 0.00024673 </velocity>
    <force> -0.00702811 0.00399447 -0.02159547 </force>
  </atom>
  <atom name="H71" species="hydrogen">
    <position> 7.98836559 8.50680954 -40.39903264 </position>
    <velocity> -0.00071650 -0.00049051 0.00030260 </velocity>
    <force> 0.00145828 -0.00262591 0.00029169 </force>
  </atom>
  <atom name="H72" species="hydrogen">
    <position> 8.53847834 5.88250219 -39.08654121 </position>
    <velocity> 0.00041812 -0.00057796 -0.00072452 </velocity>
    <force> 0.00755553 -0.00000015 0.00108978 </force>
  </atom>
  <atom name="H73" species="hydrogen">
    <position> -10.44198579 -2.62722300 7.07625341 </position>
    <velocity> -0.00075056 0.00078464 0.00039680 </velocity>
    <force> -0.00644839 0.01541145 -0.02057455 </force>
  </atom>
  <atom name="H74" species="hydrogen">
    <position> -10.90510771 -2.21547716 4.05520194 </position>
    <velocity> -0.00004101 0.00023453 -0.00006806 </velocity>
    <force> 0.00406860 0.01584186 0.03748305 </force>
  </atom>
  <atom name="H75" species="hydrogen">
    <position> 2.02161848 10.79410456 18.89025194 </position>
    <velocity> 0.00001457 0.00011416 -0.00093208 </velocity>
    <force> -0.00768745 -0.00076477 0.01772599 </force>
  </atom>
  <atom name="H76" species="hydrogen">
    <position> 2.04474743 10.51586997 16.07796375 </position>
    <velocity> 0.00002776 -0.00016592 0.00115080 </velocity>
    <force> -0.00711406 0.00807287 -0.01321657 </force>
  </atom>
  <atom name="H77" species="hydrogen">
    <position> 8.45165153 10.56100486 -10.09145463 </position>
    <velocity> -0.00049934 0.00015334 0.00038970 </velocity>
    <force> -0.00029480 0.01118338 -0.00817734 </force>
  </atom>
  <atom name="H78" species="hydrogen">
    <position> 7.86293236 11.09663592 -13.04549565 </position>
    <velocity> -0.00170922 -0.00127411 0.00070537 </velocity>
    <force> 0.00942193 0.01767856 -0.00566007 </force>
  </atom>
  <atom name="H79" species="hydrogen">
    <position> -17.61556039 -7.63468531 11.17750836 </position>
    <velocity> 0.00100935 0.00053554 0.00047541 </velocity>
    <force> -0.01580034 -0.00298059 -0.01442686 </force>
  </atom>
  <atom name="H80" species="hydrogen">
    <position> -15.89695697 -5.74803985 12.57715376 </position>
    <velocity> -0.00121092 -0.00086021 -0.00080725 </velocity>
    <force> 0.00580780 0.00333439 0.00048127 </force>
  </atom>
  <atom name="H81" species="hydrogen">
    <position> 15.98644382 4.79861880 -2.72123224 </position>
    <velocity> 0.00036916 0.00021170 -0.00008936 </velocity>
    <force> -0.01956564 -0.00936448 0.00235155 </force>
  </atom>
  <atom name="H82" species="hydrogen">
    <position> 13.70339191 5.04981267 -0.79810300 </position>
    <velocity> 0.00001968 0.00125755 0.00063684 </velocity>
    <force> -0.00175305 0.00018874 0.00299968 </force>
  </atom>
  <atom name="H83" species="hydrogen">
    <position> -7.88725971 17.32090819 15.74824745 </position>
    <velocity> 0.00074098 0.00173446 0.00001669 </velocity>
    <force> -0.00428280 0.01034027 0.00231491 </force>
  </atom>
  <atom name="H84" species="hydrogen">
    <position> -10.51921019 18.18131319 16.94170175 </position>
    <velocity> -0.00004293 -0.00081756 -0.00029580 </velocity>
    <force> -0.00577246 0.00693322 0.00351721 </force>
  </atom>
  <atom name="H85" species="hydrogen">
    <position> -4.93986289 -3.08595843 -9.15422117 </position>
    <velocity> -0.00004712 0.00023608 -0.00029578 </velocity>
    <force> -0.00539837 0.03496075 -0.01158752 </force>
  </atom>
  <atom name="H86" species="hydrogen">
    <position> -3.72148917 -4.75748791 -7.18091183 </position>
    <velocity> 0.00032614 0.00014554 0.00067205 </velocity>
    <force> 0.00361008 -0.00497424 -0.00102504 </force>
  </atom>
  <atom name="H87" species="hydrogen">
    <position> -12.18982300 -11.38845065 17.08158805 </position>
    <velocity> 0.00052906 0.00050486 -0.00052547 </velocity>
    <force> -0.02504427 0.00167474 0.03764068 </force>
  </atom>
  <atom name="H88" species="hydrogen">
    <position> -10.31511073 -9.50350586 15.56111057 </position>
    <velocity> 0.00041864 0.00070282 -0.00013888 </velocity>
    <force> -0.02256096 -0.01882035 0.01355382 </force>
  </atom>
  <atom name="H89" species="hydrogen">
    <position> -8.60050499 25.03840723 5.29957537 </position>
    <velocity> -0.00019133 -0.00037783 -0.00025444 </velocity>
    <force> -0.00326273 -0.00363098 -0.00439904 </force>
  </atom>
  <atom name="H90" species="hydrogen">
    <position> -6.40689286 26.93917955 6.12907673 </position>
    <velocity> -0.00092732 -0.00127151 0.00064684 </velocity>
    <force> -0.01544306 -0.00490074 -0.03219972 </force>
  </atom>
  <atom name="H91" species="hydrogen">
    <position> 11.94558775 -4.93019164 -12.87977062 </position>
    <velocity> -0.00012964 0.00035683 0.00009110 </velocity>
    <force> 0.02285898 -0.00860629 -0.03699644 </force>
  </atom>
  <atom name="H92" species="hydrogen">
    <position> 14.51388334 -6.35782307 -14.06047811 </position>
    <velocity> 0.00002135 -0.00015758 -0.00039255 </velocity>
    <force> -0.02539448 0.03090584 -0.00794056 </force>
  </atom>
  <atom name="H93" species="hydrogen">
    <position> -3.97811986 -2.26343474 2.05703628 </position>
    <velocity> -0.00062749 -0.00058024 -0.00002852 </velocity>
    <force> -0.00274191 0.01673756 -0.00426955 </force>
  </atom>
  <atom name="H94" species="hydrogen">
    <position> -5.29076563 -0.11188783 3.49599555 </position>
    <velocity> 0.00020819 -0.00152901 0.00004364 </velocity>
    <force> -0.04854488 0.03028612 0.00430202 </force>
  </atom>
  <atom name="H95" species="hydrogen">
    <position> -18.53475438 -18.00782720 -18.00166081 </position>
    <velocity> -0.00018533 0.00074020 0.00055239 </velocity>
    <force> 0.02643114 0.01195004 -0.00723742 </force>
  </atom>
  <atom name="H96" species="hydrogen">
    <position> -21.01691357 -17.42540884 -16.90064721 </position>
    <velocity> 0.00020714 -0.00029784 -0.00029235 </velocity>
    <force> -0.02092847 0.02115056 0.01161081 </force>
  </atom>
  <atom name="H97" species="hydrogen">
    <position> -38.79124795 4.09367206 -23.59266623 </position>
    <velocity> -0.00044259 0.00046110 -0.00029137 </velocity>
    <force> -0.01812926 -0.00144076 -0.00925418 </force>
  </atom>
  <atom name="H98" species="hydrogen">
    <position> -37.37282986 1.50615333 -24.01799670 </position>
    <velocity> 0.00028067 0.00053386 -0.00075682 </velocity>
    <force> 0.01103507 -0.01050846 0.00018988 </force>
  </atom>
  <atom name="H99" species="hydrogen">
    <position> 32.74932086 17.66520146 -4.06608412 </position>
    <velocity> 0.00003513 -0.00013570 0.00109219 </velocity>
    <force> -0.00372151 -0.01395294 0.00629288 </force>
  </atom>
  <atom name="H100" species="hydrogen">
    <position> 31.20191292 15.00218880 -4.27358026 </position>
    <velocity> 0.00059544 -0.00052611 0.00021415 </velocity>
    <force> 0.01391630 0.00331403 0.00238950 </force>
  </atom>
  <atom name="H101" species="hydrogen">
    <position> 9.84151104 3.29082992 -5.91588175 </position>
    <velocity> -0.00058405 0.00056985 -0.00076136 </velocity>
    <force> -0.05664876 -0.02801327 -0.00166129 </force>
  </atom>
  <atom name="H102" species="hydrogen">
    <position> 12.20013671 3.84388264 -4.39779211 </position>
    <velocity> 0.00130062 0.00040224 -0.00110992 </velocity>
    <force> 0.01174213 0.00670003 -0.01127503 </force>
  </atom>
  <atom name="H103" species="hydrogen">
    <position> -3.41345922 3.82969162 18.64342501 </position>
    <velocity> -0.00036245 -0.00077551 0.00032180 </velocity>
    <force> 0.00384205 0.00951587 0.00580445 </force>
  </atom>
  <atom name="H104" species="hydrogen">
    <position> -1.50075904 1.68403474 19.53089952 </position>
    <velocity> 0.00026811 0.00056147 -0.00080179 </velocity>
    <force> 0.00116625 -0.01843203 0.02053616 </force>
  </atom>
  <atom name="H105" species="hydrogen">
    <position> 21.75951317 -10.86943162 -6.93015309 </position>
    <velocity> 0.00033119 0.00070690 -0.00016320 </velocity>
    <force> -0.01390875 0.00182619 0.00423705 </force>
  </atom>
  <atom name="H106" species="hydrogen">
    <position> 19.82417760 -9.20310121 -8.51223088 </position>
    <velocity> 0.00062662 -0.00043834 0.00091891 </velocity>
    <force> 0.00554688 -0.01911331 0.02598072 </force>
  </atom>
  <atom name="H107" species="hydrogen">
    <position> 0.93932829 -8.53241786 10.96699809 </position>
    <velocity> -0.00047981 0.00077372 -0.00035530 </velocity>
    <force> 0.01367409 0.00925136 -0.01174689 </force>
  </atom>
  <atom name="H108" species="hydrogen">
    <position> 0.76771083 -7.46903552 13.83954413 </position>
    <velocity> 0.00074100 -0.00032791 -0.00011218 </velocity>
    <force> 0.00797839 0.01004089 -0.00035143 </force>
  </atom>
  <atom name="H109" species="hydrogen">
    <position> 18.13740133 -5.07229294 -1.20677711 </position>
    <velocity> -0.00010376 -0.00040544 -0.00024482 </velocity>
    <force> -0.00211728 -0.01086234 -0.00338116 </force>
  </atom>
  <atom name="H110" species="hydrogen">
    <position> 19.16449632 -2.40676933 -1.59331271 </position>
    <velocity> -0.00008787 -0.00028094 -0.00029818 </velocity>
    <force> 0.02034685 0.01491556 -0.01518432 </force>
  </atom>
  <atom name="H111" species="hydrogen">
    <position> 23.99078710 -6.71587563 18.49710841 </position>
    <velocity> -0.00049793 -0.00069314 0.00053985 </velocity>
    <force> 0.00074746 -0.00043578 -0.00035130 </force>
  </atom>
  <atom name="H112" species="hydrogen">
    <position> 25.03326070 -4.23812044 17.14804264 </position>
    <velocity> 0.00017320 0.00049798 0.00036940 </velocity>
    <force> -0.00783291 -0.01080843 -0.00786117 </force>
  </atom>
  <atom name="H113" species="hydrogen">
    <position> 2.30474840 34.12764673 -23.58887624 </position>
    <velocity> 0.00026642 0.00015054 -0.00013347 </velocity>
    <force> 0.01117537 -0.00792750 -0.00472528 </force>
  </atom>
  <atom name="H114" species="hydrogen">
    <position> 1.14728679 31.60918204 -24.09212206 </position>
    <velocity> -0.00004701 -0.00031138 -0.00019249 </velocity>
    <force> -0.02270621 -0.01649040 0.00368403 </force>
  </atom>
  <atom name="H115" species="hydrogen">
    <position> 6.95437485 1.87867997 -13.85294027 </position>
    <velocity> 0.00036769 -0.00029381 -0.00011890 </velocity>
    <force> -0.03430295 -0.01299142 -0.02458169 </force>
  </atom>
  <atom name="H116" species="hydrogen">
    <position> 4.72822501 2.90007041 -15.72350426 </position>
    <velocity> 0.00005109 -0.00062950 0.00058794 </velocity>
    <force> -0.01188732 -0.00116672 -0.00519280 </force>
  </atom>
  <atom name="H117" species="hydrogen">
    <position> -3.33504156 -14.75286702 -21.94434990 </position>
    <velocity> 0.00067071 0.00043070 0.00091267 </velocity>
    <force> 0.01823860 -0.01596397 -0.00309237 </force>
  </atom>
  <atom name="H118" species="hydrogen">
    <position> -1.97213748 -17.43028936 -22.05187177 </position>
    <velocity> -0.00048113 -0.00144401 0.00052965 </velocity>
    <force> 0.00477366 -0.02870988 0.01627343 </force>
  </atom>
  <atom name="H119" species="hydrogen">
    <position> -29.00928599 -14.00013426 10.80085343 </position>
    <velocity> 0.00055166 -0.00002434 -0.00122579 </velocity>
    <force> -0.00004086 -0.01625712 0.00206580 </force>
  </atom>
  <atom name="H120" species="hydrogen">
    <position> -27.98467553 -11.50451992 10.13325434 </position>
    <velocity> 0.00091184 0.00029813 0.00089349 </velocity>
    <force> 0.00948734 0.00677827 -0.00018822 </force>
  </atom>
  <atom name="H121" species="hydrogen">
    <position> -4.61506860 4.83988657 -13.75371935 </position>
    <velocity> -0.00070690 0.00045049 -0.00047032 </velocity>
    <force> -0.00088290 0.00411487 -0.00571440 </force>
  </atom>
  <atom name="H122" species="hydrogen">
    <position> -2.98536172 2.80366684 -15.14989249 </position>
    <velocity> -0.00028052 0.00014235 0.00007008 </velocity>
    <force> 0.00149390 0.00161647 -0.00340950 </force>
  </atom>
  <atom name="H123" species="hydrogen">
    <position> -5.17329212 -6.98942120 31.89188240 </position>
    <velocity> -0.00051784 0.00060915 0.00070503 </velocity>
    <force> 0.01882060 0.01363392 -0.02989967 </force>
  </atom>
  <atom name="H124" species="hydrogen">
    <position> -5.05053710 -6.38694162 34.80028599 </position>
    <velocity> 0.00013423 0.00099128 0.00017147 </velocity>
    <force> 0.01198174 0.01006887 0.01394902 </force>
  </atom>
  <atom name="H125" species="hydrogen">
    <position> -20.96310105 -9.22130118 30.21376067 </position>
    <velocity> 0.00018159 -0.00096928 0.00031812 </velocity>
    <force> 0.00123345 -0.01451949 -0.00939190 </force>
  </atom>
  <atom name="H126" species="hydrogen">
    <position> -20.86749192 -6.49931379 30.84415598 </position>
    <velocity> 0.00030264 0.00028541 0.00049003 </velocity>
    <force> -0.00148842 0.00820855 0.00405548 </force>
  </atom>
  <atom name="H127" species="hydrogen">
    <position> 10.50789770 6.03062233 25.13890647 </position>
    <velocity> 0.00109670 -0.00085720 -0.00029465 </velocity>
    <force> 0.03055952 0.01154180 0.02565048 </force>
  </atom>
  <atom name="H128" species="hydrogen">
    <position> 13.29425547 5.37447789 26.80776555 </position>
    <velocity> 0.00056870 -0.00042348 -0.00074203 </velocity>
    <force> -0.01556416 -0.00103145 -0.00944242 </force>
  </atom>
</atomset>
<unit_cell_a_norm> 23.460000 </unit_cell_a_norm>
<unit_cell_b_norm> 23.460000 </unit_cell_b_norm>
<unit_cell_c_norm> 23.460000 </unit_cell_c_norm>
<unit_cell_alpha>  90.000 </unit_cell_alpha>
<unit_cell_beta>   90.000 </unit_cell_beta>
<unit_cell_gamma>  90.000 </unit_cell_gamma>
<unit_cell_volume> 12911.718 </unit_cell_volume>
  <econst> -1100.15061769 </econst>
  <ekin_ion> 0.36486831 </ekin_ion>
  <temp_ion> 400.07635412 </temp_ion>
  total_electronic_charge: 512.00000000
  <eigenvalue_sum>  -162.42194692 </eigenvalue_sum>
  <etotal_int>   -1100.51262074 </etotal_int>
  total_electronic_charge: 512.00000000
  <eigenvalue_sum>  -162.42658610 </eigenvalue_sum>
  Anderson extrapolation: theta=1.30471823 (1.30471823)
  <etotal_int>   -1100.51267987 </etotal_int>
  total_electronic_charge: 512.00000000
  <eigenvalue_sum>  -162.43266437 </eigenvalue_sum>
  Anderson extrapolation: theta=0.08971052 (0.08971052)
  <etotal_int>   -1100.51271815 </etotal_int>
  total_electronic_charge: 512.00000000
  <eigenvalue_sum>  -162.43325811 </eigenvalue_sum>
  Anderson extrapolation: theta=2.18302377 (2.00000000)
  <etotal_int>   -1100.51272108 </etotal_int>
  total_electronic_charge: 512.00000000
  <eigenvalue_sum>  -162.43446375 </eigenvalue_sum>
  Anderson extrapolation: theta=0.40302823 (0.40302823)
  <etotal_int>   -1100.51272488 </etotal_int>
  <timing name="iteration" min="    6.613" max="    6.622"/>
</iteration>
<iteration count="5">
  total_electronic_charge: 512.00000000
  <ekin>       808.34384283 </ekin>
  <econf>        0.00000000 </econf>
  <eps>      -1309.31833266 </eps>
  <enl>        124.86421636 </enl>
  <ecoul>     -453.42308456 </ecoul>
  <exc>       -270.97936800 </exc>
  <esr>         93.40016113 </esr>
  <eself>      646.81841729 </eself>
  <ets>          0.00000000 </ets>
  <eexf>         0.00000000 </eexf>
  <etotal>   -1100.51272603 </etotal>
  <epv>          0.00000000 </epv>
  <eefield>      0.00000000 </eefield>
  <enthalpy> -1100.51272603 </enthalpy>
<atomset>
<unit_cell 
    a=" 23.46000000   0.00000000   0.00000000"
    b="  0.00000000  23.46000000   0.00000000"
    c="  0.00000000   0.00000000  23.46000000" />
  <atom name="O1" species="oxygen">
    <position> -6.48952169 6.00948514 12.38987054 </position>
    <velocity> -0.00011641 -0.00020417 0.00032080 </velocity>
    <force> 0.05889777 -0.00273054 0.02699584 </force>
  </atom>
  <atom name="O2" species="oxygen">
    <position> 23.13594527 2.61382730 25.48787849 </position>
    <velocity> -0.00000400 0.00005012 -0.00020384 </velocity>
    <force> 0.00371901 -0.00971882 0.02098227 </force>
  </atom>
  <atom name="O3" species="oxygen">
    <position> -28.80180935 23.73806707 -33.10000753 </position>
    <velocity> -0.00014606 0.00013106 -0.00014501 </velocity>
    <force> 0.02108391 0.00033412 -0.01440545 </force>
  </atom>
  <atom name="O4" species="oxygen">
    <position> 13.16670068 -9.21994170 -0.59990367 </position>
    <velocity> 0.00008098 -0.00025242 0.00012097 </velocity>
    <force> 0.00034108 -0.01924331 0.03369911 </force>
  </atom>
  <atom name="O5" species="oxygen">
    <position> 6.67696319 -22.47141368 -5.69930744 </position>
    <velocity> 0.00027252 0.00001983 -0.00046317 </velocity>
    <force> 0.00233691 0.01911500 0.03319315 </force>
  </atom>
  <atom name="O6" species="oxygen">
    <position> 8.02230280 16.92442122 5.24640318 </position>
    <velocity> 0.00008063 -0.00022831 0.00034228 </velocity>
    <force> -0.01812249 0.00137868 -0.02228359 </force>
  </atom>
  <atom name="O7" species="oxygen">
    <position> -4.61564233 -29.11777170 -18.05168970 </position>
    <velocity> -0.00002419 0.00048409 -0.00028327 </velocity>
    <force> -0.00708612 0.02897016 0.00541235 </force>
  </atom>
  <atom name="O8" species="oxygen">
    <position> 2.78228976 -14.70897882 13.54463091 </position>
    <velocity> -0.00006133 -0.00044110 0.00020503 </velocity>
    <force> 0.00510856 -0.00180359 -0.01260200 </force>
  </atom>
  <atom name="O9" species="oxygen">
    <position> 2.60157062 4.39989860 -6.45481835 </position>
    <velocity> -0.00029258 -0.00000656 -0.00040061 </velocity>
    <force> 0.03109543 0.01892593 -0.00893921 </force>
  </atom>
  <atom name="O10" species="oxygen">
    <position> 0.41349686 7.99563173 8.12505938 </position>
    <velocity> 0.00013353 0.00029020 0.00021775 </velocity>
    <force> -0.01509312 0.02618594 0.00755233 </force>
  </atom>
  <atom name="O11" species="oxygen">
    <position> 13.17575501 -14.43667848 10.99549835 </position>
    <velocity> -0.00006585 0.00009421 -0.00001110 </velocity>
    <force> 0.00067006 -0.00277246 -0.00844697 </force>
  </atom>
  <atom name="O12" species="oxygen">
    <position> -13.18733660 -2.56132183 13.06486737 </position>
    <velocity> 0.00025182 -0.00016511 -0.00013453 </velocity>
    <force> -0.02130707 -0.02793493 -0.01518553 </force>
  </atom>
  <atom name="O13" species="oxygen">
    <position> 2.32059019 -9.78266709 -21.53684928 </position>
    <velocity> -0.00011765 0.00038282 0.00013164 </velocity>
    <force> -0.00406764 -0.00994224 0.00613197 </force>
  </atom>
  <atom name="O14" species="oxygen">
    <position> -5.30729081 -9.16669937 -2.47070320 </position>
    <velocity> -0.00014518 0.00005126 -0.00033043 </velocity>
    <force> 0.04075829 0.01892029 0.00805159 </force>
  </atom>
  <atom name="O15" species="oxygen">
    <position> 13.29904262 -12.00035339 4.15101339 </position>
    <velocity> -0.00047246 -0.00031226 0.00017020 </velocity>
    <force> 0.03197039 -0.02372015 -0.05016352 </force>
  </atom>
  <atom name="O16" species="oxygen">
    <position> -6.99040349 9.50942458 -7.02191013 </position>
    <velocity> -0.00006142 0.00023348 -0.00008053 </velocity>
    <force> -0.00127568 -0.01107498 -0.00343199 </force>
  </atom>
  <atom name="O17" species="oxygen">
    <position> -13.79173232 -14.61239449 -27.72688568 </position>
    <velocity> -0.00001709 0.00011820 0.00018890 </velocity>
    <force> -0.01326623 0.00748177 -0.02602524 </force>
  </atom>
  <atom name="O18" species="oxygen">
    <position> -19.93297215 -2.76229788 14.85787061 </position>
    <velocity> -0.00023052 -0.00014321 0.00012226 </velocity>
    <force> -0.01538541 0.00429613 0.00433364 </force>
  </atom>
  <atom name="O19" species="oxygen">
    <position> 7.36768857 -16.23717741 0.19930705 </position>
    <velocity> -0.00033403 -0.00034190 0.00004623 </velocity>
    <force> 0.01334399 0.00918650 -0.00356251 </force>
  </atom>
  <atom name="O20" species="oxygen">
    <position> 5.90007360 17.68255099 -22.94993891 </position>
    <velocity> 0.00006463 -0.00011743 -0.00000096 </velocity>
    <force> -0.01365089 0.01389320 0.01005988 </force>
  </atom>
  <atom name="O21" species="oxygen">
    <position> 2.45486689 1.83201690 12.74029451 </position>
    <velocity> -0.00020736 0.00028886 -0.00012928 </velocity>
    <force> 0.00127732 -0.00624535 0.00048810 </force>
  </atom>
  <atom name="O22" species="oxygen">
    <position> -9.89085331 -4.94766270 2.28300951 </position>
    <velocity> 0.00030906 0.00009900 -0.00033792 </velocity>
    <force> -0.01154243 -0.00235863 -0.00939599 </force>
  </atom>
  <atom name="O23" species="oxygen">
    <position> -13.80737610 -10.70504532 7.66364175 </position>
    <velocity> 0.00015733 0.00002496 -0.00036917 </velocity>
    <force> 0.00715048 0.01608906 0.00214596 </force>
  </atom>
  <atom name="O24" species="oxygen">
    <position> 18.60281511 -13.37387083 4.52275281 </position>
    <velocity> 0.00033067 -0.00013635 -0.00006517 </velocity>
    <force> -0.01852864 0.01325630 -0.01766919 </force>
  </atom>
  <atom name="O25" species="oxygen">
    <position> 20.48686097 14.36868402 2.05941498 </position>
    <velocity> 0.00002594 -0.00050100 -0.00044555 </velocity>
    <force> -0.00190033 0.00507226 -0.00245648 </force>
  </atom>
  <atom name="O26" species="oxygen">
    <position> 6.68681592 13.02917076 -30.11906762 </position>
    <velocity> -0.00000447 0.00022290 0.00014912 </velocity>
    <force> 0.00596850 0.01703984 -0.01185762 </force>
  </atom>
  <atom name="O27" species="oxygen">
    <position> 12.82258455 -21.73542130 -10.27575853 </position>
    <velocity> 0.00016307 -0.00028194 0.00012645 </velocity>
    <force> 0.04106740 -0.00299899 -0.00092605 </force>
  </atom>
  <atom name="O28" species="oxygen">
    <position> 10.66414877 3.72027546 -14.53587277 </position>
    <velocity> 0.00008896 0.00032863 -0.00022496 </velocity>
    <force> 0.01693322 -0.00391941 0.02595874 </force>
  </atom>
  <atom name="O29" species="oxygen">
    <position> -4.81735706 6.47762846 -3.64394392 </position>
    <velocity> -0.00000265 -0.00007869 0.00013262 </velocity>
    <force> -0.05236200 -0.02344161 -0.04952812 </force>
  </atom>
  <atom name="O30" species="oxygen">
    <position> -10.78900611 -0.59887890 22.05342160 </position>
    <velocity> 0.00036220 0.00010709 -0.00015633 </velocity>
    <force> 0.01442828 0.03792915 -0.01394226 </force>
  </atom>
  <atom name="O31" species="oxygen">
    <position> 4.42276455 -1.01507376 0.92339328 </position>
    <velocity> 0.00015628 0.00002718 0.00028332 </velocity>
    <force> -0.01265919 -0.00153693 0.01551049 </force>
  </atom>
  <atom name="O32" species="oxygen">
    <position> 22.69350432 -0.70719977 -1.95285071 </position>
    <velocity> -0.00010095 0.00009350 0.00044950 </velocity>
    <force> -0.00422391 0.03339815 0.05221423 </force>
  </atom>
  <atom name="O33" species="oxygen">
    <position> -1.15094369 23.06703902 9.74321191 </position>
    <velocity> -0.00005461 0.00009966 0.00000210 </velocity>
    <force> -0.03985708 -0.01829794 -0.03506161 </force>
  </atom>
  <atom name="O34" species="oxygen">
    <position> -13.42921972 -2.82053621 18.13391589 </position>
    <velocity> -0.00026823 0.00002829 0.00015007 </velocity>
    <force> 0.00020001 -0.00775919 -0.00233610 </force>
  </atom>
  <atom name="O35" species="oxygen">
    <position> 4.05010018 -2.42404488 -17.77262492 </position>
    <velocity> 0.00001947 -0.00009171 0.00013751 </velocity>
    <force> 0.02728840 0.00098493 0.06532684 </force>
  </atom>
  <atom name="O36" species="oxygen">
    <position> 7.52773585 6.72322764 -40.39752353 </position>
    <velocity> -0.00035013 -0.00004969 -0.00007879 </velocity>
    <force> 0.00264782 0.01036076 -0.00483017 </force>
  </atom>
  <atom name="O37" species="oxygen">
    <position> -10.79945301 -1.21900358 5.74316696 </position>
    <velocity> -0.00027096 0.00001622 0.00000028 </velocity>
    <force> 0.00266957 -0.02391288 -0.01195550 </force>
  </atom>
  <atom name="O38" species="oxygen">
    <position> 1.47306076 11.75403893 17.40554742 </position>
    <velocity> -0.00014073 0.00011870 0.00011360 </velocity>
    <force> 0.01183547 -0.00498508 -0.00360405 </force>
  </atom>
  <atom name="O39" species="oxygen">
    <position> 7.69717540 9.92861640 -11.65171419 </position>
    <velocity> 0.00015772 0.00002847 0.00007972 </velocity>
    <force> -0.01159121 -0.03423297 0.02047521 </force>
  </atom>
  <atom name="O40" species="oxygen">
    <position> -16.36536818 -7.52303637 12.48431545 </position>
    <velocity> 0.00039208 0.00024370 0.00015119 </velocity>
    <force> 0.01299066 -0.00498078 0.01658301 </force>
  </atom>
  <atom name="O41" species="oxygen">
    <position> 14.21679852 4.03731013 -2.28426856 </position>
    <velocity> -0.00011165 0.00010272 0.00015524 </velocity>
    <force> 0.03513223 0.01556992 0.01198341 </force>
  </atom>
  <atom name="O42" species="oxygen">
    <position> -9.69151393 16.85272698 16.01322349 </position>
    <velocity> -0.00014502 -0.00009392 0.00020625 </velocity>
    <force> 0.01768878 -0.01730819 -0.01282003 </force>
  </atom>
  <atom name="O43" species="oxygen">
    <position> -5.15365848 -4.68722543 -8.35878788 </position>
    <velocity> 0.00002163 0.00015303 -0.00013097 </velocity>
    <force> 0.01086295 -0.03464114 0.01551824 </force>
  </atom>
  <atom name="O44" species="oxygen">
    <position> -11.06979533 -11.33854886 15.72574374 </position>
    <velocity> -0.00013404 0.00034831 0.00027132 </velocity>
    <force> 0.04405977 0.02318582 -0.05993533 </force>
  </atom>
  <atom name="O45" species="oxygen">
    <position> -7.55901079 26.42630653 4.58041791 </position>
    <velocity> 0.00040140 -0.00026960 -0.00043951 </velocity>
    <force> 0.01142379 0.00501185 0.03552697 </force>
  </atom>
  <atom name="O46" species="oxygen">
    <position> 12.86276926 -5.28957346 -14.60023575 </position>
    <velocity> -0.00038639 -0.00013312 0.00023494 </velocity>
    <force> 0.00397354 -0.02042771 0.04976763 </force>
  </atom>
  <atom name="O47" species="oxygen">
    <position> -3.72504279 -0.90723944 3.37460033 </position>
    <velocity> 0.00042943 -0.00029260 -0.00027793 </velocity>
    <force> 0.04880904 -0.04103770 -0.00113201 </force>
  </atom>
  <atom name="O48" species="oxygen">
    <position> -20.14809330 -18.79038304 -17.69906667 </position>
    <velocity> -0.00013860 0.00021975 0.00007607 </velocity>
    <force> -0.00644739 -0.03861591 -0.01677854 </force>
  </atom>
  <atom name="O49" species="oxygen">
    <position> -39.02574041 2.30134957 -24.17537212 </position>
    <velocity> -0.00017229 0.00030298 -0.00010839 </velocity>
    <force> 0.00478328 0.00525833 0.00345296 </force>
  </atom>
  <atom name="O50" species="oxygen">
    <position> 32.37468902 16.01194391 -3.14814252 </position>
    <velocity> 0.00009056 -0.00007960 -0.00013426 </velocity>
    <force> -0.00301848 0.01089412 -0.01224588 </force>
  </atom>
  <atom name="O51" species="oxygen">
    <position> 11.40936564 4.03480254 -6.13389397 </position>
    <velocity> -0.00022733 -0.00010220 0.00003810 </velocity>
    <force> 0.03997151 0.02826708 0.00005558 </force>
  </atom>
  <atom name="O52" species="oxygen">
    <position> -2.00336609 2.72734207 18.12970100 </position>
    <velocity> 0.00009503 -0.00028457 0.00006019 </velocity>
    <force> -0.00724963 0.00862952 -0.03711820 </force>
  </atom>
  <atom name="O53" species="oxygen">
    <position> 19.91007278 -10.33107580 -6.95206389 </position>
    <velocity> 0.00006718 0.00033355 -0.00028554 </velocity>
    <force> 0.02116815 0.01731540 -0.03060986 </force>
  </atom>
  <atom name="O54" species="oxygen">
    <position> 0.06269480 -8.55959041 12.55650697 </position>
    <velocity> -0.00027744 -0.00004742 -0.00017086 </velocity>
    <force> -0.02918932 -0.01464698 0.01957892 </force>
  </atom>
  <atom name="O55" species="oxygen">
    <position> 18.01921405 -3.35457058 -0.57167154 </position>
    <velocity> -0.00001349 -0.00011879 0.00001000 </velocity>
    <force> -0.01190953 -0.00996913 0.01077370 </force>
  </atom>
  <atom name="O56" species="oxygen">
    <position> 23.51081675 -5.36787769 17.34498616 </position>
    <velocity> 0.00027705 -0.00030496 0.00001632 </velocity>
    <force> 0.00621152 0.00742961 0.00784267 </force>
  </atom>
  <atom name="O57" species="oxygen">
    <position> 2.68129610 32.48510571 -24.49447274 </position>
    <velocity> 0.00010762 -0.00013252 0.00007982 </velocity>
    <force> 0.01352215 0.03575805 0.00339757 </force>
  </atom>
  <atom name="O58" species="oxygen">
    <position> 5.18412271 1.41568074 -14.60977460 </position>
    <velocity> -0.00008195 0.00009207 0.00014379 </velocity>
    <force> 0.06126803 0.00439204 0.02673610 </force>
  </atom>
  <atom name="O59" species="oxygen">
    <position> -2.10853437 -15.85773118 -22.92152186 </position>
    <velocity> 0.00016833 -0.00006697 -0.00004689 </velocity>
    <force> -0.02254874 0.03258083 -0.00326900 </force>
  </atom>
  <atom name="O60" species="oxygen">
    <position> -27.37619858 -13.22063792 10.47717441 </position>
    <velocity> -0.00024706 -0.00019824 0.00004657 </velocity>
    <force> -0.00253384 0.01825133 -0.00539817 </force>
  </atom>
  <atom name="O61" species="oxygen">
    <position> -3.87273627 4.42553120 -15.46809170 </position>
    <velocity> -0.00016506 0.00013315 -0.00028802 </velocity>
    <force> -0.00149001 -0.00614561 0.01831585 </force>
  </atom>
  <atom name="O62" species="oxygen">
    <position> -6.02056062 -7.13183597 33.47079309 </position>
    <velocity> 0.00018761 -0.00016744 -0.00004592 </velocity>
    <force> -0.03261530 -0.02632451 0.02507732 </force>
  </atom>
  <atom name="O63" species="oxygen">
    <position> -20.89404288 -8.14069168 31.68436920 </position>
    <velocity> -0.00027972 0.00004800 0.00025147 </velocity>
    <force> 0.00509148 0.00641805 -0.00525333 </force>
  </atom>
  <atom name="O64" species="oxygen">
    <position> 12.29535411 6.56479822 25.71497528 </position>
    <velocity> 0.00027885 -0.00004509 0.00031941 </velocity>
    <force> -0.00931152 -0.00598634 -0.01241949 </force>
  </atom>
  <atom name="H1" species="hydrogen">
    <position> -5.92881724 7.21464828 13.82781961 </position>
    <velocity> -0.00047808 0.00051867 0.00022274 </velocity>
    <force> -0.02197636 -0.02085858 -0.02236635 </force>
  </atom>
  <atom name="H2" species="hydrogen">
    <position> -8.12408840 6.52704324 11.88569184 </position>
    <velocity> 0.00036360 -0.00055639 0.00043738 </velocity>
    <force> -0.03335354 0.01812885 -0.00305317 </force>
  </atom>
  <atom name="H3" species="hydrogen">
    <position> 24.68520943 2.72600891 26.55248358 </position>
    <velocity> 0.00067195 0.00066949 -0.00085719 </velocity>
    <force> -0.01060391 0.00802098 -0.00603950 </force>
  </atom>
  <atom name="H4" species="hydrogen">
    <position> 22.01322479 1.40850017 26.46749363 </position>
    <velocity> -0.00062023 0.00023691 -0.00034419 </velocity>
    <force> 0.00595354 0.00924359 -0.01414268 </force>
  </atom>
  <atom name="H5" species="hydrogen">
    <position> -27.60645598 24.50994086 -31.87082328 </position>
    <velocity> -0.00084013 -0.00080149 0.00051329 </velocity>
    <force> -0.00651312 0.00050838 0.00132061 </force>
  </atom>
  <atom name="H6" species="hydrogen">
    <position> -27.80804280 23.83623235 -34.70416992 </position>
    <velocity> -0.00031431 -0.00022455 0.00080691 </velocity>
    <force> -0.00713353 -0.00238384 0.01115733 </force>
  </atom>
  <atom name="H7" species="hydrogen">
    <position> 12.63515859 -10.31376470 0.98405077 </position>
    <velocity> -0.00029456 0.00013386 0.00098678 </velocity>
    <force> 0.00929900 0.02414554 -0.03805282 </force>
  </atom>
  <atom name="H8" species="hydrogen">
    <position> 11.73303653 -8.77960408 -1.72262250 </position>
    <velocity> 0.00003856 0.00030094 -0.00024063 </velocity>
    <force> -0.00867917 -0.00505059 0.00823427 </force>
  </atom>
  <atom name="H9" species="hydrogen">
    <position> 5.50038041 -21.04503304 -6.15625889 </position>
    <velocity> 0.00039314 -0.00051545 0.00026425 </velocity>
    <force> 0.00289992 -0.01316279 0.00805211 </force>
  </atom>
  <atom name="H10" species="hydrogen">
    <position> 6.93183669 -22.25279545 -3.75595177 </position>
    <velocity> 0.00012763 -0.00055137 0.00059762 </velocity>
    <force> -0.00859647 0.00525973 -0.03239946 </force>
  </atom>
  <atom name="H11" species="hydrogen">
    <position> 7.15239411 17.04367976 3.47974713 </position>
    <velocity> -0.00024283 0.00057351 -0.00075280 </velocity>
    <force> 0.01586050 0.00062738 0.01563964 </force>
  </atom>
  <atom name="H12" species="hydrogen">
    <position> 9.65505855 17.76326851 5.02973211 </position>
    <velocity> -0.00093101 0.00000760 0.00042640 </velocity>
    <force> 0.00032035 0.00013369 -0.00157376 </force>
  </atom>
  <atom name="H13" species="hydrogen">
    <position> -4.22928113 -27.37754130 -18.70695131 </position>
    <velocity> 0.00076344 -0.00027169 0.00097463 </velocity>
    <force> -0.00508404 -0.00410885 0.02146565 </force>
  </atom>
  <atom name="H14" species="hydrogen">
    <position> -3.98420670 -30.08675480 -19.45103551 </position>
    <velocity> 0.00035900 0.00022022 -0.00009411 </velocity>
    <force> 0.00974910 -0.02780241 -0.01741300 </force>
  </atom>
  <atom name="H15" species="hydrogen">
    <position> 1.56013559 -14.54166558 12.12315106 </position>
    <velocity> -0.00062873 -0.00039264 0.00087276 </velocity>
    <force> 0.00920727 -0.00409504 0.00798022 </force>
  </atom>
  <atom name="H16" species="hydrogen">
    <position> 4.50731512 -14.43818479 12.76232634 </position>
    <velocity> -0.00061902 0.00015536 0.00038244 </velocity>
    <force> -0.01083985 0.00082118 0.00457995 </force>
  </atom>
  <atom name="H17" species="hydrogen">
    <position> 2.42240953 6.00969165 -7.41265811 </position>
    <velocity> -0.00006117 0.00034581 0.00026017 </velocity>
    <force> -0.00137820 -0.00897447 0.00558324 </force>
  </atom>
  <atom name="H18" species="hydrogen">
    <position> 0.95236233 3.90395710 -5.79195517 </position>
    <velocity> 0.00037401 0.00229556 -0.00111956 </velocity>
    <force> -0.02136529 -0.00158068 0.00036229 </force>
  </atom>
  <atom name="H19" species="hydrogen">
    <position> -0.82688365 6.64454571 8.31413083 </position>
    <velocity> -0.00043457 0.00041976 0.00020408 </velocity>
    <force> -0.00626962 -0.01093058 0.00052802 </force>
  </atom>
  <atom name="H20" species="hydrogen">
    <position> -0.79768060 9.45653970 8.24982379 </position>
    <velocity> 0.00035871 -0.00028946 0.00007361 </velocity>
    <force> 0.01464202 -0.01253356 -0.00043168 </force>
  </atom>
  <atom name="H21" species="hydrogen">
    <position> 11.52940183 -15.13386912 10.57842087 </position>
    <velocity> -0.00008689 0.00024028 -0.00001018 </velocity>
    <force> -0.00445208 -0.00201359 -0.00312700 </force>
  </atom>
  <atom name="H22" species="hydrogen">
    <position> 12.73554841 -13.13400670 12.20596371 </position>
    <velocity> -0.00024518 -0.00028433 0.00070690 </velocity>
    <force> 0.00087753 0.00598614 0.01087829 </force>
  </atom>
  <atom name="H23" species="hydrogen">
    <position> -12.37802680 -1.56725212 11.79670492 </position>
    <velocity> 0.00094678 -0.00073980 0.00064040 </velocity>
    <force> 0.00363564 0.01797815 -0.01334148 </force>
  </atom>
  <atom name="H24" species="hydrogen">
    <position> -12.34668363 -1.96151140 14.55450218 </position>
    <velocity> 0.00061797 -0.00020678 -0.00004923 </velocity>
    <force> 0.00342739 0.00212005 0.01858029 </force>
  </atom>
  <atom name="H25" species="hydrogen">
    <position> 0.51509029 -9.37323734 -21.32487102 </position>
    <velocity> 0.00027451 0.00006345 0.00017608 </velocity>
    <force> -0.00421155 -0.00003935 -0.00579509 </force>
  </atom>
  <atom name="H26" species="hydrogen">
    <position> 3.09154770 -8.30252720 -22.30927916 </position>
    <velocity> -0.00059342 0.00046119 -0.00042704 </velocity>
    <force> 0.00899938 0.00932073 -0.00253832 </force>
  </atom>
  <atom name="H27" species="hydrogen">
    <position> -7.03602876 -9.57688547 -2.47534590 </position>
    <velocity> 0.00075306 0.00035671 0.00021523 </velocity>
    <force> -0.04115028 -0.00829487 0.00002577 </force>
  </atom>
  <atom name="H28" species="hydrogen">
    <position> -4.57187206 -9.34339779 -4.20153039 </position>
    <velocity> 0.00053393 -0.00040186 0.00003668 </velocity>
    <force> -0.00397346 -0.00519466 0.00297208 </force>
  </atom>
  <atom name="H29" species="hydrogen">
    <position> 12.62611413 -13.67456795 3.59330955 </position>
    <velocity> 0.00053982 -0.00079994 -0.00076371 </velocity>
    <force> 0.00294713 0.00213066 0.00009791 </force>
  </atom>
  <atom name="H30" species="hydrogen">
    <position> 12.26811836 -11.50458687 5.49808378 </position>
    <velocity> 0.00106548 -0.00008970 -0.00049944 </velocity>
    <force> -0.03193431 0.01299106 0.04079445 </force>
  </atom>
  <atom name="H31" species="hydrogen">
    <position> -5.69075280 10.83305701 -7.23580824 </position>
    <velocity> 0.00004272 -0.00003321 -0.00134064 </velocity>
    <force> 0.00608517 0.00136122 0.00509098 </force>
  </atom>
  <atom name="H32" species="hydrogen">
    <position> -8.63480802 10.40684361 -7.35184820 </position>
    <velocity> -0.00075314 0.00082516 -0.00045145 </velocity>
    <force> -0.00021922 -0.00332068 0.00500197 </force>
  </atom>
  <atom name="H33" species="hydrogen">
    <position> -15.02128707 -13.85241440 -28.95365441 </position>
    <velocity> -0.00093775 0.00068829 0.00068546 </velocity>
    <force> 0.00643044 -0.00098234 0.01932126 </force>
  </atom>
  <atom name="H34" species="hydrogen">
    <position> -13.03316043 -15.93820888 -28.81687105 </position>
    <velocity> 0.00028885 0.00032784 -0.00085665 </velocity>
    <force> 0.00278980 -0.00619863 0.00975839 </force>
  </atom>
  <atom name="H35" species="hydrogen">
    <position> -20.43933547 -0.95518093 14.68612684 </position>
    <velocity> -0.00009184 -0.00022283 0.00016814 </velocity>
    <force> -0.00435019 -0.00451349 -0.00799627 </force>
  </atom>
  <atom name="H36" species="hydrogen">
    <position> -18.16853413 -2.60532843 14.50031860 </position>
    <velocity> -0.00007983 0.00024619 0.00025042 </velocity>
    <force> 0.01983606 -0.00269708 0.00115149 </force>
  </atom>
  <atom name="H37" species="hydrogen">
    <position> 5.61929073 -15.54020748 0.48481073 </position>
    <velocity> -0.00005395 0.00030671 0.00149745 </velocity>
    <force> 0.01101039 -0.00642766 -0.01392115 </force>
  </atom>
  <atom name="H38" species="hydrogen">
    <position> 8.14532366 -15.39883331 -1.34501716 </position>
    <velocity> -0.00036294 -0.00041481 -0.00017310 </velocity>
    <force> -0.01426603 -0.00738836 0.01169682 </force>
  </atom>
  <atom name="H39" species="hydrogen">
    <position> 5.53382848 19.56633784 -23.08773332 </position>
    <velocity> -0.00015283 -0.00018724 0.00007968 </velocity>
    <force> -0.00376465 -0.00684067 0.00890809 </force>
  </atom>
  <atom name="H40" species="hydrogen">
    <position> 6.88606824 17.32855373 -24.47494355 </position>
    <velocity> -0.00034976 -0.00031923 0.00009603 </velocity>
    <force> 0.01221983 -0.01362429 -0.00520551 </force>
  </atom>
  <atom name="H41" species="hydrogen">
    <position> 3.80465647 1.89680942 11.41591736 </position>
    <velocity> 0.00049809 0.00011823 -0.00001360 </velocity>
    <force> -0.00838697 -0.00292461 -0.00049162 </force>
  </atom>
  <atom name="H42" species="hydrogen">
    <position> 2.99887037 2.85895169 14.18548826 </position>
    <velocity> -0.00077325 -0.00029024 -0.00022578 </velocity>
    <force> -0.00962744 0.00701231 0.00743784 </force>
  </atom>
  <atom name="H43" species="hydrogen">
    <position> -8.60818563 -5.47005197 3.45037005 </position>
    <velocity> 0.00015472 -0.00077386 0.00068167 </velocity>
    <force> 0.01755407 0.00235803 0.01775150 </force>
  </atom>
  <atom name="H44" species="hydrogen">
    <position> -9.85009056 -6.42180418 1.09791496 </position>
    <velocity> 0.00099822 0.00155899 0.00028896 </velocity>
    <force> -0.01043905 0.00005730 -0.00699409 </force>
  </atom>
  <atom name="H45" species="hydrogen">
    <position> -12.82945959 -9.31333497 8.47267512 </position>
    <velocity> 0.00065152 0.00013426 -0.00020979 </velocity>
    <force> -0.00288011 -0.01203298 0.00377154 </force>
  </atom>
  <atom name="H46" species="hydrogen">
    <position> -14.68949013 -9.57589497 6.43820915 </position>
    <velocity> 0.00053304 -0.00016959 0.00034198 </velocity>
    <force> -0.00714669 0.00139038 -0.00266163 </force>
  </atom>
  <atom name="H47" species="hydrogen">
    <position> 16.74554109 -13.12144974 4.57712603 </position>
    <velocity> 0.00008778 -0.00082805 0.00040172 </velocity>
    <force> -0.00459169 0.01498328 -0.00984395 </force>
  </atom>
  <atom name="H48" species="hydrogen">
    <position> 18.64317096 -14.71061188 5.70757772 </position>
    <velocity> 0.00090217 -0.00021743 -0.00038253 </velocity>
    <force> 0.01817398 -0.02575318 0.02399440 </force>
  </atom>
  <atom name="H49" species="hydrogen">
    <position> 19.90234641 13.00642678 3.15154944 </position>
    <velocity> -0.00023337 0.00072232 -0.00063805 </velocity>
    <force> -0.00073193 -0.00813893 0.00629808 </force>
  </atom>
  <atom name="H50" species="hydrogen">
    <position> 19.36371416 14.25561646 0.54247264 </position>
    <velocity> 0.00035324 -0.00023790 -0.00007205 </velocity>
    <force> 0.00889539 -0.00012528 -0.00704817 </force>
  </atom>
  <atom name="H51" species="hydrogen">
    <position> 6.81691891 14.30903082 -31.55540914 </position>
    <velocity> 0.00059892 0.00047959 0.00012859 </velocity>
    <force> 0.00094595 -0.01399936 0.00573248 </force>
  </atom>
  <atom name="H52" species="hydrogen">
    <position> 4.85604023 12.88974396 -29.89039366 </position>
    <velocity> -0.00062654 0.00063877 -0.00075223 </velocity>
    <force> -0.01163094 -0.00396506 0.00181527 </force>
  </atom>
  <atom name="H53" species="hydrogen">
    <position> 14.68083887 -22.30823906 -10.22411998 </position>
    <velocity> -0.00068309 0.00018884 0.00034490 </velocity>
    <force> -0.02701913 0.01453446 0.00252628 </force>
  </atom>
  <atom name="H54" species="hydrogen">
    <position> 12.61792203 -20.67769727 -8.68212079 </position>
    <velocity> 0.00104316 -0.00022546 0.00049885 </velocity>
    <force> -0.00234673 -0.00661133 -0.00848548 </force>
  </atom>
  <atom name="H55" species="hydrogen">
    <position> 11.25647449 2.77179295 -15.95711884 </position>
    <velocity> -0.00062128 0.00085266 -0.00096568 </velocity>
    <force> -0.00005123 -0.01117995 -0.02290188 </force>
  </atom>
  <atom name="H56" species="hydrogen">
    <position> 12.02977680 3.23532753 -13.26005860 </position>
    <velocity> -0.00003577 -0.00075586 0.00012043 </velocity>
    <force> -0.02220420 0.00517904 0.00581071 </force>
  </atom>
  <atom name="H57" species="hydrogen">
    <position> -4.04455066 7.05898296 -2.15178494 </position>
    <velocity> -0.00057956 -0.00041617 -0.00044064 </velocity>
    <force> 0.02034047 0.02308262 0.03974005 </force>
  </atom>
  <atom name="H58" species="hydrogen">
    <position> -6.15960108 7.60372240 -4.47216418 </position>
    <velocity> -0.00034629 -0.00024646 -0.00051907 </velocity>
    <force> 0.02602285 0.00335541 0.00427582 </force>
  </atom>
  <atom name="H59" species="hydrogen">
    <position> -10.37544643 -1.62061293 23.47170568 </position>
    <velocity> 0.00063971 0.00006351 -0.00052307 </velocity>
    <force> 0.00760533 -0.02596578 0.01830829 </force>
  </atom>
  <atom name="H60" species="hydrogen">
    <position> -9.36112186 0.73192208 22.01273054 </position>
    <velocity> -0.00005147 -0.00001768 -0.00047599 </velocity>
    <force> -0.02930966 -0.01520586 -0.00493116 </force>
  </atom>
  <atom name="H61" species="hydrogen">
    <position> 5.51035918 0.47255421 0.69492949 </position>
    <velocity> 0.00147463 0.00056278 0.00001978 </velocity>
    <force> 0.00504284 0.00166770 -0.00494637 </force>
  </atom>
  <atom name="H62" species="hydrogen">
    <position> 4.12254706 -1.14749404 2.82141524 </position>
    <velocity> -0.00031810 0.00042309 -0.00024874 </velocity>
    <force> 0.00685252 -0.00519924 -0.01648709 </force>
  </atom>
  <atom name="H63" species="hydrogen">
    <position> 23.68976243 -0.31668754 -0.31271412 </position>
    <velocity> -0.00037768 0.00050055 -0.00059036 </velocity>
    <force> -0.01916222 0.00592221 -0.02814847 </force>
  </atom>
  <atom name="H64" species="hydrogen">
    <position> 23.58260608 -2.07244430 -2.59472019 </position>
    <velocity> -0.00043479 0.00046242 -0.00061604 </velocity>
    <force> 0.02496076 -0.04172875 -0.02594326 </force>
  </atom>
  <atom name="H65" species="hydrogen">
    <position> -0.41659341 21.65339158 8.81356422 </position>
    <velocity> 0.00049858 -0.00018856 0.00004488 </velocity>
    <force> -0.00833335 0.00021951 -0.00547660 </force>
  </atom>
  <atom name="H66" species="hydrogen">
    <position> 0.18183828 23.51437582 10.80075685 </position>
    <velocity> 0.00110756 -0.00000028 0.00070924 </velocity>
    <force> 0.03947295 0.02466031 0.04033413 </force>
  </atom>
  <atom name="H67" species="hydrogen">
    <position> -12.44260275 -1.82877368 19.33259106 </position>
    <velocity> -0.00008647 -0.00013362 0.00072139 </velocity>
    <force> 0.01215310 0.00206229 0.01506804 </force>
  </atom>
  <atom name="H68" species="hydrogen">
    <position> -14.85846099 -1.68102953 17.78244628 </position>
    <velocity> -0.00002900 0.00039266 -0.00100811 </velocity>
    <force> -0.00639068 0.00115571 -0.00636422 </force>
  </atom>
  <atom name="H69" species="hydrogen">
    <position> 4.64276336 -1.26743104 -16.20845552 </position>
    <velocity> -0.00009518 -0.00104250 0.00036601 </velocity>
    <force> -0.02063744 -0.00491588 -0.03852887 </force>
  </atom>
  <atom name="H70" species="hydrogen">
    <position> 5.30545781 -3.78129008 -17.32481608 </position>
    <velocity> 0.00032497 0.00047309 0.00018780 </velocity>
    <force> -0.00664184 0.00292180 -0.02187459 </force>
  </atom>
  <atom name="H71" species="hydrogen">
    <position> 7.98122046 8.50186864 -40.39600268 </position>
    <velocity> -0.00071253 -0.00049491 0.00030377 </velocity>
    <force> 0.00219773 -0.00008909 0.00025320 </force>
  </atom>
  <atom name="H72" species="hydrogen">
    <position> 8.54276241 5.87672254 -39.09377156 </position>
    <velocity> 0.00043857 -0.00057811 -0.00072319 </velocity>
    <force> 0.00700519 0.00049415 0.00063407 </force>
  </atom>
  <atom name="H73" species="hydrogen">
    <position> -10.44957917 -2.61916670 7.07994121 </position>
    <velocity> -0.00076878 0.00082630 0.00034151 </velocity>
    <force> -0.00613303 0.01432278 -0.02037434 </force>
  </atom>
  <atom name="H74" species="hydrogen">
    <position> -10.90546244 -2.21291608 4.05503178 </position>
    <velocity> -0.00003000 0.00027755 0.00003408 </velocity>
    <force> 0.00404802 0.01545404 0.03747922 </force>
  </atom>
  <atom name="H75" species="hydrogen">
    <position> 2.02165952 10.79523574 18.88117256 </position>
    <velocity> -0.00000523 0.00011044 -0.00087990 </velocity>
    <force> -0.00684666 -0.00208037 0.02150285 </force>
  </atom>
  <atom name="H76" species="hydrogen">
    <position> 2.04492813 10.51432067 16.08929179 </position>
    <velocity> 0.00000863 -0.00014511 0.00111352 </velocity>
    <force> -0.00693707 0.00735996 -0.01531475 </force>
  </atom>
  <atom name="H77" species="hydrogen">
    <position> 8.44665408 10.56269055 -10.08766903 </position>
    <velocity> -0.00050093 0.00018440 0.00036711 </velocity>
    <force> -0.00035083 0.01143082 -0.00878618 </force>
  </atom>
  <atom name="H78" species="hydrogen">
    <position> 7.84596853 11.08413560 -13.03851905 </position>
    <velocity> -0.00168475 -0.00122087 0.00068388 </velocity>
    <force> 0.01028865 0.02267595 -0.01083070 </force>
  </atom>
  <atom name="H79" species="hydrogen">
    <position> -17.60568213 -7.62937047 11.18206597 </position>
    <velocity> 0.00096401 0.00052630 0.00043314 </velocity>
    <force> -0.01848516 -0.00435252 -0.01705947 </force>
  </atom>
  <atom name="H80" species="hydrogen">
    <position> -15.90898712 -5.75659659 12.56908784 </position>
    <velocity> -0.00119324 -0.00084253 -0.00080543 </velocity>
    <force> 0.00841208 0.01052470 0.00168878 </force>
  </atom>
  <atom name="H81" species="hydrogen">
    <position> 15.98986893 4.80060827 -2.72209378 </position>
    <velocity> 0.00031493 0.00018581 -0.00008248 </velocity>
    <force> -0.02057984 -0.00983538 0.00278181 </force>
  </atom>
  <atom name="H82" species="hydrogen">
    <position> 13.70356484 5.06239079 -0.79169373 </position>
    <velocity> 0.00001627 0.00125680 0.00064149 </velocity>
    <force> -0.00076710 -0.00204581 -0.00024916 </force>
  </atom>
  <atom name="H83" species="hydrogen">
    <position> -7.87990828 17.33839366 15.74844587 </position>
    <velocity> 0.00072432 0.00176267 0.00002360 </velocity>
    <force> -0.00869631 0.00853975 0.00273586 </force>
  </atom>
  <atom name="H84" species="hydrogen">
    <position> -10.51971812 18.17323199 16.93879165 </position>
    <velocity> -0.00006213 -0.00079562 -0.00028344 </velocity>
    <force> -0.00826062 0.01000108 0.00585190 </force>
  </atom>
  <atom name="H85" species="hydrogen">
    <position> -4.94040765 -3.08312145 -9.15733676 </position>
    <velocity> -0.00006192 0.00033079 -0.00032697 </velocity>
    <force> -0.00539893 0.03423071 -0.01097875 </force>
  </atom>
  <atom name="H86" species="hydrogen">
    <position> -3.71817860 -4.75610021 -7.17420529 </position>
    <velocity> 0.00033307 0.00013255 0.00066712 </velocity>
    <force> 0.00113320 -0.00470360 -0.00328728 </force>
  </atom>
  <atom name="H87" species="hydrogen">
    <position> -12.18487350 -11.38337921 17.07684595 </position>
    <velocity> 0.00045598 0.00050998 -0.00041665 </velocity>
    <force> -0.02909014 0.00155116 0.04269467 </force>
  </atom>
  <atom name="H88" species="hydrogen">
    <position> -10.31123157 -9.49673400 15.55990632 </position>
    <velocity> 0.00035698 0.00065139 -0.00010167 </velocity>
    <force> -0.02308724 -0.01961848 0.01387762 </force>
  </atom>
  <atom name="H89" species="hydrogen">
    <position> -8.60246272 25.03457951 5.29697111 </position>
    <velocity> -0.00019947 -0.00038656 -0.00026844 </velocity>
    <force> -0.00250427 -0.00238363 -0.00560330 </force>
  </atom>
  <atom name="H90" species="hydrogen">
    <position> -6.41637634 26.92639772 6.13510663 </position>
    <velocity> -0.00096938 -0.00128540 0.00055955 </velocity>
    <force> -0.01443634 -0.00396182 -0.03247975 </force>
  </atom>
  <atom name="H91" species="hydrogen">
    <position> 11.94460270 -4.92674055 -12.87936347 </position>
    <velocity> -0.00006768 0.00033338 -0.00000881 </velocity>
    <force> 0.02270725 -0.00895529 -0.03635404 </force>
  </atom>
  <atom name="H92" species="hydrogen">
    <position> 14.51375096 -6.35897793 -14.06451173 </position>
    <velocity> -0.00004862 -0.00007326 -0.00041419 </velocity>
    <force> -0.02593219 0.03107762 -0.00751927 </force>
  </atom>
  <atom name="H93" species="hydrogen">
    <position> -3.98443215 -2.26900918 2.05669293 </position>
    <velocity> -0.00063479 -0.00053533 -0.00003993 </velocity>
    <force> -0.00195695 0.01679027 -0.00406605 </force>
  </atom>
  <atom name="H94" species="hydrogen">
    <position> -5.28934487 -0.12676543 3.49649050 </position>
    <velocity> 0.00007409 -0.00144723 0.00005628 </velocity>
    <force> -0.04999903 0.03126013 0.00492431 </force>
  </atom>
  <atom name="H95" species="hydrogen">
    <position> -18.53624771 -18.00026248 -17.99623549 </position>
    <velocity> -0.00011395 0.00077293 0.00053357 </velocity>
    <force> 0.02609563 0.01128421 -0.00713100 </force>
  </atom>
  <atom name="H96" species="hydrogen">
    <position> -21.01512722 -17.42809919 -16.90341256 </position>
    <velocity> 0.00014746 -0.00023726 -0.00025887 </velocity>
    <force> -0.02304631 0.02357542 0.01324240 </force>
  </atom>
  <atom name="H97" species="hydrogen">
    <position> -38.79592073 4.09826348 -23.59570592 </position>
    <velocity> -0.00049277 0.00045812 -0.00031689 </velocity>
    <force> -0.01820407 -0.00122423 -0.00915581 </force>
  </atom>
  <atom name="H98" species="hydrogen">
    <position> -37.36987291 1.51134876 -24.02556228 </position>
    <velocity> 0.00030963 0.00050675 -0.00075743 </velocity>
    <force> 0.00991055 -0.00992268 0.00014599 </force>
  </atom>
  <atom name="H99" species="hydrogen">
    <position> 32.74962147 17.66365443 -4.05507653 </position>
    <velocity> 0.00002517 -0.00017182 0.00110868 </velocity>
    <force> -0.00361517 -0.01238756 0.00466396 </force>
  </atom>
  <atom name="H100" species="hydrogen">
    <position> 31.20805690 14.99697286 -4.27140623 </position>
    <velocity> 0.00063331 -0.00051781 0.00021986 </velocity>
    <force> 0.01322682 0.00331292 0.00157199 </force>
  </atom>
  <atom name="H101" species="hydrogen">
    <position> 9.83489908 3.29614690 -5.92351800 </position>
    <velocity> -0.00073846 0.00049434 -0.00076583 </velocity>
    <force> -0.05596177 -0.02794332 -0.00082055 </force>
  </atom>
  <atom name="H102" species="hydrogen">
    <position> 12.21330284 3.84799624 -4.40904491 </position>
    <velocity> 0.00133334 0.00042026 -0.00113953 </velocity>
    <force> 0.01089980 0.00609970 -0.00928234 </force>
  </atom>
  <atom name="H103" species="hydrogen">
    <position> -3.41703135 3.82206611 18.64672203 </position>
    <velocity> -0.00035169 -0.00075126 0.00033768 </velocity>
    <force> 0.00442402 0.00907206 0.00550419 </force>
  </atom>
  <atom name="H104" species="hydrogen">
    <position> -1.49806206 1.68939838 19.52316129 </position>
    <velocity> 0.00027383 0.00050800 -0.00074130 </velocity>
    <force> 0.00274900 -0.02135192 0.02465070 </force>
  </atom>
  <atom name="H105" species="hydrogen">
    <position> 21.76263564 -10.86233775 -6.93172736 </position>
    <velocity> 0.00029281 0.00071252 -0.00015156 </velocity>
    <force> -0.01457275 0.00156053 0.00446771 </force>
  </atom>
  <atom name="H106" species="hydrogen">
    <position> 19.83051931 -9.20774492 -8.50268797 </position>
    <velocity> 0.00064159 -0.00048657 0.00098511 </velocity>
    <force> 0.00477994 -0.01579578 0.02160443 </force>
  </atom>
  <atom name="H107" species="hydrogen">
    <position> 0.93471643 -8.52455468 10.96328515 </position>
    <velocity> -0.00044354 0.00079965 -0.00038764 </velocity>
    <force> 0.01341603 0.00896057 -0.01160315 </force>
  </atom>
  <atom name="H108" species="hydrogen">
    <position> 0.77522952 -7.47217782 13.83841759 </position>
    <velocity> 0.00076270 -0.00030216 -0.00011438 </velocity>
    <force> 0.00716116 0.00917613 -0.00115033 </force>
  </atom>
  <atom name="H109" species="hydrogen">
    <position> 18.13633485 -5.07649529 -1.20927132 </position>
    <velocity> -0.00010989 -0.00043353 -0.00025347 </velocity>
    <force> -0.00226664 -0.00931404 -0.00270649 </force>
  </atom>
  <atom name="H110" species="hydrogen">
    <position> 19.16389475 -2.40937558 -1.59650126 </position>
    <velocity> -0.00003280 -0.00024079 -0.00033952 </velocity>
    <force> 0.02011730 0.01481439 -0.01481746 </force>
  </atom>
  <atom name="H111" species="hydrogen">
    <position> 23.98581798 -6.72281294 18.50250209 </position>
    <velocity> -0.00049669 -0.00069279 0.00053794 </velocity>
    <force> 0.00067807 0.00140863 -0.00160730 </force>
  </atom>
  <atom name="H112" species="hydrogen">
    <position> 25.03488599 -4.23328783 17.15162958 </position>
    <velocity> 0.00015111 0.00046755 0.00034898 </velocity>
    <force> -0.00854418 -0.01202206 -0.00749710 </force>
  </atom>
  <atom name="H113" species="hydrogen">
    <position> 2.30756476 34.12904420 -23.59027530 </position>
    <velocity> 0.00029689 0.00012825 -0.00014676 </velocity>
    <force> 0.01089274 -0.00857344 -0.00487967 </force>
  </atom>
  <atom name="H114" species="hydrogen">
    <position> 1.14650741 31.60584369 -24.09399678 </position>
    <velocity> -0.00010808 -0.00035578 -0.00018264 </velocity>
    <force> -0.02201789 -0.01574448 0.00373371 </force>
  </atom>
  <atom name="H115" species="hydrogen">
    <position> 6.95758459 1.87556496 -13.85446406 </position>
    <velocity> 0.00027392 -0.00032939 -0.00018630 </velocity>
    <force> -0.03483308 -0.01279600 -0.02471028 </force>
  </atom>
  <atom name="H116" species="hydrogen">
    <position> 4.72857402 2.89375951 -15.71769554 </position>
    <velocity> 0.00001816 -0.00063051 0.00057241 </velocity>
    <force> -0.01231372 0.00108026 -0.00681078 </force>
  </atom>
  <atom name="H117" species="hydrogen">
    <position> -3.32808610 -14.74877748 -21.93526526 </position>
    <velocity> 0.00072232 0.00038656 0.00090417 </velocity>
    <force> 0.01891047 -0.01684321 -0.00408963 </force>
  </atom>
  <atom name="H118" species="hydrogen">
    <position> -1.97688377 -17.44512043 -22.04635366 </position>
    <velocity> -0.00046928 -0.00151518 0.00056955 </velocity>
    <force> 0.00441396 -0.02197989 0.01243669 </force>
  </atom>
  <atom name="H119" species="hydrogen">
    <position> -29.00376990 -14.00059910 10.78862364 </position>
    <velocity> 0.00054634 -0.00007088 -0.00122087 </velocity>
    <force> -0.00443761 -0.01784229 0.00281592 </force>
  </atom>
  <atom name="H120" species="hydrogen">
    <position> -27.97542793 -11.50144630 10.14218669 </position>
    <velocity> 0.00093845 0.00031693 0.00089430 </velocity>
    <force> 0.00907963 0.00669626 -0.00014864 </force>
  </atom>
  <atom name="H121" species="hydrogen">
    <position> -4.62214957 4.84444750 -13.75850041 </position>
    <velocity> -0.00070968 0.00046195 -0.00048689 </velocity>
    <force> -0.00042514 0.00382054 -0.00594620 </force>
  </atom>
  <atom name="H122" species="hydrogen">
    <position> -2.98814654 2.80511238 -15.14923809 </position>
    <velocity> -0.00027675 0.00014705 0.00006101 </velocity>
    <force> 0.00156207 0.00167924 -0.00331658 </force>
  </atom>
  <atom name="H123" species="hydrogen">
    <position> -5.17821425 -6.98314401 31.89852551 </position>
    <velocity> -0.00046406 0.00064762 0.00061856 </velocity>
    <force> 0.02115186 0.01393707 -0.03423157 </force>
  </atom>
  <atom name="H124" species="hydrogen">
    <position> -5.04903161 -6.37689171 34.80219063 </position>
    <velocity> 0.00016443 0.00101816 0.00020642 </velocity>
    <force> 0.01002074 0.00861289 0.01149990 </force>
  </atom>
  <atom name="H125" species="hydrogen">
    <position> -20.96126832 -9.23119173 30.21681398 </position>
    <velocity> 0.00018536 -0.00100689 0.00029583 </velocity>
    <force> 0.00134034 -0.01204726 -0.00728237 </force>
  </atom>
  <atom name="H126" species="hydrogen">
    <position> -20.86448575 -6.49634785 30.84911153 </position>
    <velocity> 0.00029898 0.00030678 0.00050130 </velocity>
    <force> -0.00151075 0.00716430 0.00369761 </force>
  </atom>
  <atom name="H127" species="hydrogen">
    <position> 10.51928094 6.02220754 25.13630933 </position>
    <velocity> 0.00117995 -0.00082697 -0.00022554 </velocity>
    <force> 0.02933950 0.01151129 0.02532302 </force>
  </atom>
  <atom name="H128" species="hydrogen">
    <position> 13.29973049 5.37022906 26.80021668 </position>
    <velocity> 0.00052799 -0.00042750 -0.00076784 </velocity>
    <force> -0.01487581 -0.00147934 -0.00871328 </force>
  </atom>
</atomset>
<unit_cell_a_norm> 23.460000 </unit_cell_a_norm>
<unit_cell_b_norm> 23.460000 </unit_cell_b_norm>
<unit_cell_c_norm> 23.460000 </unit_cell_c_norm>
<unit_cell_alpha>  90.000 </unit_cell_alpha>
<unit_cell_beta>   90.000 </unit_cell_beta>
<unit_cell_gamma>  90.000 </unit_cell_gamma>
<unit_cell_volume> 12911.718 </unit_cell_volume>
  <econst> -1100.15054092 </econst>
  <ekin_ion> 0.36345175 </ekin_ion>
  <temp_ion> 398.52310058 </temp_ion>
  total_electronic_charge: 512.00000000
  <eigenvalue_sum>  -162.44234512 </eigenvalue_sum>
  <etotal_int>   -1100.51010427 </etotal_int>
  total_electronic_charge: 512.00000000
  <eigenvalue_sum>  -162.44707556 </eigenvalue_sum>
  Anderson extrapolation: theta=1.22086969 (1.22086969)
  <etotal_int>   -1100.51015606 </etotal_int>
  total_electronic_charge: 512.00000000
  <eigenvalue_sum>  -162.45290483 </eigenvalue_sum>
  Anderson extrapolation: theta=0.07285844 (0.07285844)
  <etotal_int>   -1100.51018652 </etotal_int>
  total_electronic_charge: 512.00000000
  <eigenvalue_sum>  -162.45341902 </eigenvalue_sum>
  Anderson extrapolation: theta=2.04938259 (2.00000000)
  <etotal_int>   -1100.51018846 </etotal_int>
  total_electronic_charge: 512.00000000
  <eigenvalue_sum>  -162.45451310 </eigenvalue_sum>
  Anderson extrapolation: theta=0.32844651 (0.32844651)
  <etotal_int>   -1100.51019085 </etotal_int>
  <timing name="iteration" min="    5.899" max="    5.914"/>
</iteration>
<iteration count="6">
  total_electronic_charge: 512.00000000
  <ekin>       808.43654964 </ekin>
  <econf>        0.00000000 </econf>
  <eps>      -1309.51626152 </eps>
  <enl>        124.85593134 </enl>
  <ecoul>     -453.28695318 </ecoul>
  <exc>       -270.99945779 </exc>
  <esr>         93.50980045 </esr>
  <eself>      646.81841729 </eself>
  <ets>          0.00000000 </ets>
  <eexf>         0.00000000 </eexf>
  <etotal>   -1100.51019152 </etotal>
  <epv>          0.00000000 </epv>
  <eefield>      0.00000000 </eefield>
  <enthalpy> -1100.51019152 </enthalpy>
<atomset>
<unit_cell 
    a=" 23.46000000   0.00000000   0.00000000"
    b="  0.00000000  23.46000000   0.00000000"
    c="  0.00000000   0.00000000  23.46000000" />
  <atom name="O1" species="oxygen">
    <position> -6.49058482 6.00743877 12.39312481 </position>
    <velocity> -0.00009580 -0.00020512 0.00033022 </velocity>
    <force> 0.06121624 -0.00310578 0.02837626 </force>
  </atom>
  <atom name="O2" species="oxygen">
    <position> 23.13591169 2.61431185 25.48587608 </position>
    <velocity> -0.00000270 0.00004685 -0.00019663 </velocity>
    <force> 0.00382004 -0.00928438 0.02080136 </force>
  </atom>
  <atom name="O3" species="oxygen">
    <position> -28.80323385 23.73937828 -33.10148234 </position>
    <velocity> -0.00013936 0.00013095 -0.00014950 </velocity>
    <force> 0.01784658 -0.00081795 -0.01196871 </force>
  </atom>
  <atom name="O4" species="oxygen">
    <position> 13.16751105 -9.22249891 -0.59863624 </position>
    <velocity> 0.00008085 -0.00025901 0.00013247 </velocity>
    <force> -0.00100979 -0.01952055 0.03354746 </force>
  </atom>
  <atom name="O5" species="oxygen">
    <position> 6.67969240 -22.47118263 -5.70388227 </position>
    <velocity> 0.00027356 0.00002610 -0.00045122 </velocity>
    <force> 0.00409884 0.01751198 0.03592399 </force>
  </atom>
  <atom name="O6" species="oxygen">
    <position> 8.02307800 16.92214052 5.24978776 </position>
    <velocity> 0.00007360 -0.00022795 0.00033415 </velocity>
    <force> -0.02276324 0.00038667 -0.02470723 </force>
  </atom>
  <atom name="O7" species="oxygen">
    <position> -4.61589638 -29.11288110 -18.05451312 </position>
    <velocity> -0.00002668 0.00049322 -0.00028124 </velocity>
    <force> -0.00745894 0.02488307 0.00603165 </force>
  </atom>
  <atom name="O8" species="oxygen">
    <position> 2.78168520 -14.71339287 13.54665960 </position>
    <velocity> -0.00005981 -0.00044166 0.00020095 </velocity>
    <force> 0.00371140 -0.00206329 -0.01091216 </force>
  </atom>
  <atom name="O9" species="oxygen">
    <position> 2.59869816 4.39986547 -6.45883982 </position>
    <velocity> -0.00028108 0.00000029 -0.00040396 </velocity>
    <force> 0.03558552 0.02100628 -0.01111294 </force>
  </atom>
  <atom name="O10" species="oxygen">
    <position> 0.41480633 7.99857860 8.12724979 </position>
    <velocity> 0.00012837 0.00029863 0.00022032 </velocity>
    <force> -0.01489263 0.02337542 0.00773253 </force>
  </atom>
  <atom name="O11" species="oxygen">
    <position> 13.17509767 -14.43574118 10.99537285 </position>
    <velocity> -0.00006564 0.00009341 -0.00001381 </velocity>
    <force> 0.00047250 -0.00172091 -0.00734329 </force>
  </atom>
  <atom name="O12" species="oxygen">
    <position> -13.18485491 -2.56302078 13.06349599 </position>
    <velocity> 0.00024444 -0.00017477 -0.00013916 </velocity>
    <force> -0.02141017 -0.02863811 -0.01196068 </force>
  </atom>
  <atom name="O13" species="oxygen">
    <position> 2.31940675 -9.77885591 -21.53552240 </position>
    <velocity> -0.00011867 0.00037941 0.00013362 </velocity>
    <force> -0.00203033 -0.00947089 0.00559990 </force>
  </atom>
  <atom name="O14" species="oxygen">
    <position> -5.30867272 -9.16615431 -2.47399366 </position>
    <velocity> -0.00013022 0.00005798 -0.00032756 </velocity>
    <force> 0.04630842 0.02034482 0.00822050 </force>
  </atom>
  <atom name="O15" species="oxygen">
    <position> 13.29437280 -12.00351661 4.15262939 </position>
    <velocity> -0.00046059 -0.00032088 0.00015178 </velocity>
    <force> 0.03670352 -0.02698550 -0.05707080 </force>
  </atom>
  <atom name="O16" species="oxygen">
    <position> -6.99101982 9.51174038 -7.02272132 </position>
    <velocity> -0.00006226 0.00022990 -0.00008183 </velocity>
    <force> -0.00374361 -0.00949557 -0.00424834 </force>
  </atom>
  <atom name="O17" species="oxygen">
    <position> -13.79192597 -14.61119965 -27.72504127 </position>
    <velocity> -0.00002168 0.00012060 0.00017959 </velocity>
    <force> -0.01354599 0.00666025 -0.02806303 </force>
  </atom>
  <atom name="O18" species="oxygen">
    <position> -19.93530373 -2.76372263 14.85910061 </position>
    <velocity> -0.00023554 -0.00014174 0.00012367 </velocity>
    <force> -0.01422665 0.00408594 0.00409346 </force>
  </atom>
  <atom name="O19" species="oxygen">
    <position> 7.36437112 -16.24058067 0.19976328 </position>
    <velocity> -0.00032946 -0.00033867 0.00004503 </velocity>
    <force> 0.01291235 0.00922207 -0.00340009 </force>
  </atom>
  <atom name="O20" species="oxygen">
    <position> 5.90069650 17.68140048 -22.94993125 </position>
    <velocity> 0.00005985 -0.00011266 0.00000268 </velocity>
    <force> -0.01416335 0.01376816 0.01114707 </force>
  </atom>
  <atom name="O21" species="oxygen">
    <position> 2.45279550 1.83489478 12.73900251 </position>
    <velocity> -0.00020682 0.00028641 -0.00012961 </velocity>
    <force> 0.00158102 -0.00766928 -0.00256775 </force>
  </atom>
  <atom name="O22" species="oxygen">
    <position> -9.88778252 -4.94667678 2.27961419 </position>
    <velocity> 0.00030564 0.00009871 -0.00033996 </velocity>
    <force> -0.00799949 0.00083814 -0.00295733 </force>
  </atom>
  <atom name="O23" species="oxygen">
    <position> -13.80579057 -10.70476816 7.65995373 </position>
    <velocity> 0.00016013 0.00003039 -0.00036791 </velocity>
    <force> 0.00941295 0.01563227 0.00471679 </force>
  </atom>
  <atom name="O24" species="oxygen">
    <position> 18.60609008 -13.37521159 4.52207081 </position>
    <velocity> 0.00032414 -0.00013173 -0.00007122 </velocity>
    <force> -0.01918794 0.01353656 -0.01771581 </force>
  </atom>
  <atom name="O25" species="oxygen">
    <position> 20.48711715 14.36368273 2.05495524 </position>
    <velocity> 0.00002569 -0.00049859 -0.00044648 </velocity>
    <force> 0.00046501 0.00832503 -0.00352435 </force>
  </atom>
  <atom name="O26" species="oxygen">
    <position> 6.68678144 13.03142896 -30.11759678 </position>
    <velocity> -0.00000281 0.00022875 0.00014497 </velocity>
    <force> 0.00369039 0.01737293 -0.01211843 </force>
  </atom>
  <atom name="O27" species="oxygen">
    <position> 12.82428570 -21.73824581 -10.27449562 </position>
    <velocity> 0.00017666 -0.00028265 0.00012629 </velocity>
    <force> 0.03839825 -0.00153667 0.00016909 </force>
  </atom>
  <atom name="O28" species="oxygen">
    <position> 10.66506739 3.72355503 -14.53807789 </position>
    <velocity> 0.00009486 0.00032711 -0.00021599 </velocity>
    <force> 0.01760969 -0.00450068 0.02611386 </force>
  </atom>
  <atom name="O29" species="oxygen">
    <position> -4.81747338 6.47680136 -3.64270265 </position>
    <velocity> -0.00002107 -0.00008690 0.00011484 </velocity>
    <force> -0.05505367 -0.02458215 -0.05403244 </force>
  </atom>
  <atom name="O30" species="oxygen">
    <position> -10.78535940 -0.59774297 22.05183443 </position>
    <velocity> 0.00036685 0.00011997 -0.00016119 </velocity>
    <force> 0.01319116 0.03736425 -0.01465194 </force>
  </atom>
  <atom name="O31" species="oxygen">
    <position> 4.42430563 -1.01480464 0.92625307 </position>
    <velocity> 0.00015252 0.00002737 0.00028818 </velocity>
    <force> -0.00909392 0.00268897 0.01320698 </force>
  </atom>
  <atom name="O32" species="oxygen">
    <position> 22.69248758 -0.70620750 -1.94826623 </position>
    <velocity> -0.00010265 0.00010481 0.00046682 </velocity>
    <force> -0.00582867 0.03273389 0.04945153 </force>
  </atom>
  <atom name="O33" species="oxygen">
    <position> -1.15155810 23.06800425 9.74317276 </position>
    <velocity> -0.00006699 0.00009348 -0.00000918 </velocity>
    <force> -0.03248219 -0.01760683 -0.03071718 </force>
  </atom>
  <atom name="O34" species="oxygen">
    <position> -13.43190167 -2.82026661 18.13541259 </position>
    <velocity> -0.00026808 0.00002587 0.00014940 </velocity>
    <force> 0.00032388 -0.00630837 -0.00139159 </force>
  </atom>
  <atom name="O35" species="oxygen">
    <position> 4.05034169 -2.42496026 -17.77113784 </position>
    <velocity> 0.00002874 -0.00009138 0.00015982 </velocity>
    <force> 0.02679743 0.00077753 0.06504437 </force>
  </atom>
  <atom name="O36" species="oxygen">
    <position> 7.52423911 6.72274845 -40.39831971 </position>
    <velocity> -0.00034916 -0.00004664 -0.00008031 </velocity>
    <force> 0.00253653 0.00740136 -0.00414452 </force>
  </atom>
  <atom name="O37" species="oxygen">
    <position> -10.80215801 -1.21888236 5.74314928 </position>
    <velocity> -0.00027005 0.00000832 -0.00000385 </velocity>
    <force> 0.00228874 -0.02217706 -0.01214672 </force>
  </atom>
  <atom name="O38" species="oxygen">
    <position> 1.47167377 11.75521735 17.40667728 </position>
    <velocity> -0.00013684 0.00011735 0.00011207 </velocity>
    <force> 0.01068490 -0.00274325 -0.00518059 </force>
  </atom>
  <atom name="O39" species="oxygen">
    <position> 7.69873274 9.92884239 -11.65088185 </position>
    <velocity> 0.00015362 0.00001587 0.00008773 </velocity>
    <force> -0.01211775 -0.03920547 0.02631413 </force>
  </atom>
  <atom name="O40" species="oxygen">
    <position> -16.36142507 -7.52060794 12.48585580 </position>
    <velocity> 0.00039643 0.00024089 0.00015706 </velocity>
    <force> 0.01287235 -0.01110279 0.01784716 </force>
  </atom>
  <atom name="O41" species="oxygen">
    <position> 14.21574227 4.03836405 -2.28269566 </position>
    <velocity> -0.00009959 0.00010849 0.00015973 </velocity>
    <force> 0.03504445 0.01822140 0.01442352 </force>
  </atom>
  <atom name="O42" species="oxygen">
    <position> -9.69293381 16.85175811 16.01526397 </position>
    <velocity> -0.00013776 -0.00010004 0.00020135 </velocity>
    <force> 0.02446477 -0.01849722 -0.01545625 </force>
  </atom>
  <atom name="O43" species="oxygen">
    <position> -5.15342351 -4.68575448 -8.36007098 </position>
    <velocity> 0.00002573 0.00014132 -0.00012540 </velocity>
    <force> 0.01305252 -0.03352903 0.01680303 </force>
  </atom>
  <atom name="O44" species="oxygen">
    <position> -11.07106016 -11.33502603 15.72835415 </position>
    <velocity> -0.00011823 0.00035630 0.00024997 </velocity>
    <force> 0.04796697 0.02387457 -0.06426072 </force>
  </atom>
  <atom name="O45" species="oxygen">
    <position> -7.55497720 26.42361911 4.57608372 </position>
    <velocity> 0.00040489 -0.00026821 -0.00042711 </velocity>
    <force> 0.00944240 0.00273163 0.03626448 </force>
  </atom>
  <atom name="O46" species="oxygen">
    <position> 12.85891212 -5.29093971 -14.59780105 </position>
    <velocity> -0.00038486 -0.00014006 0.00025171 </velocity>
    <force> 0.00447328 -0.02024217 0.04839729 </force>
  </atom>
  <atom name="O47" species="oxygen">
    <position> -3.72066479 -0.91023582 3.37181911 </position>
    <velocity> 0.00044603 -0.00030663 -0.00027839 </velocity>
    <force> 0.04857940 -0.04118446 -0.00190223 </force>
  </atom>
  <atom name="O48" species="oxygen">
    <position> -20.14949038 -18.78825178 -17.69833476 </position>
    <velocity> -0.00014038 0.00020623 0.00007002 </velocity>
    <force> -0.00409765 -0.03997134 -0.01837837 </force>
  </atom>
  <atom name="O49" species="oxygen">
    <position> -39.02745508 2.30438838 -24.17645014 </position>
    <velocity> -0.00017042 0.00030453 -0.00010720 </velocity>
    <force> 0.00589753 0.00419339 0.00334898 </force>
  </atom>
  <atom name="O50" species="oxygen">
    <position> 32.37558942 16.01116658 -3.14950610 </position>
    <velocity> 0.00008959 -0.00007614 -0.00013800 </velocity>
    <force> -0.00251083 0.00921603 -0.00975621 </force>
  </atom>
  <atom name="O51" species="oxygen">
    <position> 11.40716086 4.03382898 -6.13351289 </position>
    <velocity> -0.00021376 -0.00009252 0.00003769 </velocity>
    <force> 0.03891485 0.02809066 -0.00241270 </force>
  </atom>
  <atom name="O52" species="oxygen">
    <position> -2.00242824 2.72451117 18.13023929 </position>
    <velocity> 0.00009210 -0.00028097 0.00004684 </velocity>
    <force> -0.00972757 0.01200350 -0.04068581 </force>
  </atom>
  <atom name="O53" species="oxygen">
    <position> 19.91078085 -10.32771062 -6.95497181 </position>
    <velocity> 0.00007464 0.00033882 -0.00029519 </velocity>
    <force> 0.02247287 0.01387579 -0.02604760 </force>
  </atom>
  <atom name="O54" species="oxygen">
    <position> 0.05987033 -8.56008976 12.55483191 </position>
    <velocity> -0.00028716 -0.00005223 -0.00016404 </velocity>
    <force> -0.02788451 -0.01345011 0.01998512 </force>
  </atom>
  <atom name="O55" species="oxygen">
    <position> 18.01905870 -3.35577560 -0.57155304 </position>
    <velocity> -0.00001746 -0.00012241 0.00001347 </velocity>
    <force> -0.01125471 -0.01129165 0.00944790 </force>
  </atom>
  <atom name="O56" species="oxygen">
    <position> 23.51359790 -5.37091458 17.34516286 </position>
    <velocity> 0.00027924 -0.00030250 0.00001916 </velocity>
    <force> 0.00689489 0.00653154 0.00874871 </force>
  </atom>
  <atom name="O57" species="oxygen">
    <position> 2.68239545 32.48384183 -24.49366875 </position>
    <velocity> 0.00011207 -0.00012033 0.00008101 </velocity>
    <force> 0.01261362 0.03515926 0.00366381 </force>
  </atom>
  <atom name="O58" species="oxygen">
    <position> 5.18340827 1.41660899 -14.60829090 </position>
    <velocity> -0.00006081 0.00009315 0.00015322 </velocity>
    <force> 0.06194736 0.00203500 0.02847774 </force>
  </atom>
  <atom name="O59" species="oxygen">
    <position> -2.10688977 -15.85834498 -22.92199641 </position>
    <velocity> 0.00016058 -0.00005687 -0.00004722 </velocity>
    <force> -0.02243970 0.02623858 0.00132910 </force>
  </atom>
  <atom name="O60" species="oxygen">
    <position> -27.37867355 -13.22258900 10.47763086 </position>
    <velocity> -0.00024708 -0.00019167 0.00004460 </velocity>
    <force> 0.00208721 0.01983300 -0.00600997 </force>
  </atom>
  <atom name="O61" species="oxygen">
    <position> -3.87438940 4.42685221 -15.47094050 </position>
    <velocity> -0.00016560 0.00013108 -0.00028165 </velocity>
    <force> -0.00190100 -0.00577450 0.01848232 </force>
  </atom>
  <atom name="O62" species="oxygen">
    <position> -6.01874039 -7.13355553 33.47037684 </position>
    <velocity> 0.00017644 -0.00017623 -0.00003623 </velocity>
    <force> -0.03234770 -0.02517128 0.03142263 </force>
  </atom>
  <atom name="O63" species="oxygen">
    <position> -20.89683138 -8.14020065 31.68687493 </position>
    <velocity> -0.00027794 0.00004995 0.00024929 </velocity>
    <force> 0.00492706 0.00503376 -0.00716886 </force>
  </atom>
  <atom name="O64" species="oxygen">
    <position> 12.29812668 6.56433701 25.71814807 </position>
    <velocity> 0.00027577 -0.00004703 0.00031506 </velocity>
    <force> -0.00832227 -0.00537974 -0.01250834 </force>
  </atom>
  <atom name="H1" species="hydrogen">
    <position> -5.93389738 7.21955095 13.82974236 </position>
    <velocity> -0.00053767 0.00046115 0.00016134 </velocity>
    <force> -0.02186448 -0.02130729 -0.02268799 </force>
  </atom>
  <atom name="H2" species="hydrogen">
    <position> -8.12090664 6.52172623 11.89002402 </position>
    <velocity> 0.00026897 -0.00050595 0.00042758 </velocity>
    <force> -0.03608735 0.01882445 -0.00407367 </force>
  </atom>
  <atom name="H3" species="hydrogen">
    <position> 24.69178449 2.73281305 26.54382947 </position>
    <velocity> 0.00064123 0.00069050 -0.00087343 </velocity>
    <force> -0.01184831 0.00751524 -0.00602878 </force>
  </atom>
  <atom name="H4" species="hydrogen">
    <position> 22.00710362 1.41099518 26.46385913 </position>
    <velocity> -0.00060253 0.00026230 -0.00038244 </velocity>
    <force> 0.00693872 0.00944370 -0.01400391 </force>
  </atom>
  <atom name="H5" species="hydrogen">
    <position> -27.61494594 24.50193286 -31.86567242 </position>
    <velocity> -0.00085607 -0.00079889 0.00051774 </velocity>
    <force> -0.00533156 0.00127322 0.00203298 </force>
  </atom>
  <atom name="H6" species="hydrogen">
    <position> -27.81128308 23.83395440 -34.69594886 </position>
    <velocity> -0.00033083 -0.00023034 0.00083281 </velocity>
    <force> -0.00504843 -0.00190879 0.00799770 </force>
  </atom>
  <atom name="H7" species="hydrogen">
    <position> 12.63233965 -10.31209731 0.99340031 </position>
    <velocity> -0.00026876 0.00020041 0.00088127 </velocity>
    <force> 0.00960157 0.02475564 -0.03927312 </force>
  </atom>
  <atom name="H8" species="hydrogen">
    <position> 11.73330396 -8.77666349 -1.72491663 </position>
    <velocity> 0.00001653 0.00028639 -0.00021647 </velocity>
    <force> -0.00749802 -0.00558728 0.00946797 </force>
  </atom>
  <atom name="H9" species="hydrogen">
    <position> 5.50435132 -21.05036683 -6.15350673 </position>
    <velocity> 0.00039905 -0.00054885 0.00028512 </velocity>
    <force> 0.00150165 -0.01144933 0.00731817 </force>
  </atom>
  <atom name="H10" species="hydrogen">
    <position> 6.93299596 -22.25823747 -3.75041682 </position>
    <velocity> 0.00010397 -0.00053695 0.00050594 </velocity>
    <force> -0.00876104 0.00523858 -0.03483277 </force>
  </atom>
  <atom name="H11" species="hydrogen">
    <position> 7.15018177 17.04942344 3.47243209 </position>
    <velocity> -0.00019818 0.00057439 -0.00070650 </velocity>
    <force> 0.01689286 0.00010829 0.01824730 </force>
  </atom>
  <atom name="H12" species="hydrogen">
    <position> 9.64575276 17.76334638 5.03397468 </position>
    <velocity> -0.00092528 0.00001022 0.00042174 </velocity>
    <force> 0.00373915 0.00178539 -0.00178093 </force>
  </atom>
  <atom name="H13" species="hydrogen">
    <position> -4.22171599 -27.38031418 -18.69691271 </position>
    <velocity> 0.00075044 -0.00027848 0.00103059 </velocity>
    <force> -0.00433689 -0.00092020 0.01979611 </force>
  </atom>
  <atom name="H14" species="hydrogen">
    <position> -3.98048393 -30.08493122 -19.45221380 </position>
    <velocity> 0.00038499 0.00014546 -0.00014060 </velocity>
    <force> 0.00940024 -0.02706888 -0.01674262 </force>
  </atom>
  <atom name="H15" species="hydrogen">
    <position> 1.55397367 -14.54564770 12.13198736 </position>
    <velocity> -0.00060368 -0.00040356 0.00089345 </velocity>
    <force> 0.00908948 -0.00399324 0.00735550 </force>
  </atom>
  <atom name="H16" species="hydrogen">
    <position> 4.50097732 -14.43662005 12.76621311 </position>
    <velocity> -0.00064648 0.00015755 0.00039365 </velocity>
    <force> -0.00943409 0.00081242 0.00371380 </force>
  </atom>
  <atom name="H17" species="hydrogen">
    <position> 2.42177907 6.01302758 -7.40998036 </position>
    <velocity> -0.00006386 0.00032169 0.00027455 </velocity>
    <force> -0.00060735 -0.00868578 0.00501880 </force>
  </atom>
  <atom name="H18" species="hydrogen">
    <position> 0.95581142 3.92689120 -5.80314586 </position>
    <velocity> 0.00030853 0.00228724 -0.00111440 </velocity>
    <force> -0.02665998 -0.00415702 0.00324879 </force>
  </atom>
  <atom name="H19" species="hydrogen">
    <position> -0.83131472 6.64859446 8.31617883 </position>
    <velocity> -0.00044992 0.00039079 0.00020519 </velocity>
    <force> -0.00507406 -0.01027687 0.00032216 </force>
  </atom>
  <atom name="H20" species="hydrogen">
    <position> -0.79389408 9.45347437 8.25055396 </position>
    <velocity> 0.00039674 -0.00032047 0.00007259 </velocity>
    <force> 0.01334724 -0.01028565 -0.00030103 </force>
  </atom>
  <atom name="H21" species="hydrogen">
    <position> 11.52847225 -15.13149377 10.57827645 </position>
    <velocity> -0.00009915 0.00023464 -0.00001885 </velocity>
    <force> -0.00456330 -0.00208630 -0.00324065 </force>
  </atom>
  <atom name="H22" species="hydrogen">
    <position> 12.73310858 -13.13676849 12.21318090 </position>
    <velocity> -0.00024226 -0.00026915 0.00073506 </velocity>
    <force> 0.00122867 0.00511461 0.00991887 </force>
  </atom>
  <atom name="H23" species="hydrogen">
    <position> -12.36850951 -1.57440526 11.80292719 </position>
    <velocity> 0.00095806 -0.00068859 0.00060070 </velocity>
    <force> 0.00480437 0.01950881 -0.01570610 </force>
  </atom>
  <atom name="H24" species="hydrogen">
    <position> -12.34045727 -1.96355036 14.55426289 </position>
    <velocity> 0.00062604 -0.00020187 0.00000033 </velocity>
    <force> 0.00260082 0.00145333 0.01780989 </force>
  </atom>
  <atom name="H25" species="hydrogen">
    <position> 0.51777803 -9.37260336 -21.32318915 </position>
    <velocity> 0.00026053 0.00006369 0.00016062 </velocity>
    <force> -0.00600936 0.00022357 -0.00552974 </force>
  </atom>
  <atom name="H26" species="hydrogen">
    <position> 3.08573608 -8.29778832 -22.31358411 </position>
    <velocity> -0.00056894 0.00048571 -0.00043337 </velocity>
    <force> 0.00888211 0.00876011 -0.00217775 </force>
  </atom>
  <atom name="H27" species="hydrogen">
    <position> -7.02905855 -9.57343131 -2.47319321 </position>
    <velocity> 0.00063372 0.00033218 0.00021487 </velocity>
    <force> -0.04637274 -0.00966293 -0.00025815 </force>
  </atom>
  <atom name="H28" species="hydrogen">
    <position> -4.56658685 -9.34748709 -4.20112314 </position>
    <velocity> 0.00052220 -0.00041590 0.00004460 </velocity>
    <force> -0.00455623 -0.00518869 0.00285330 </force>
  </atom>
  <atom name="H29" species="hydrogen">
    <position> 12.63155243 -13.68253838 3.58567374 </position>
    <velocity> 0.00054744 -0.00079188 -0.00076166 </velocity>
    <force> 0.00273929 0.00366228 0.00128616 </force>
  </atom>
  <atom name="H30" species="hydrogen">
    <position> 12.27833824 -11.50530691 5.49364498 </position>
    <velocity> 0.00097186 -0.00005219 -0.00038042 </velocity>
    <force> -0.03664940 0.01453622 0.04653087 </force>
  </atom>
  <atom name="H31" species="hydrogen">
    <position> -5.69024277 10.83274344 -7.24914529 </position>
    <velocity> 0.00005895 -0.00002980 -0.00132608 </velocity>
    <force> 0.00584569 0.00113540 0.00538463 </force>
  </atom>
  <atom name="H32" species="hydrogen">
    <position> -8.64234238 10.41505002 -7.35629460 </position>
    <velocity> -0.00075016 0.00081409 -0.00043678 </velocity>
    <force> 0.00228597 -0.00467565 0.00569709 </force>
  </atom>
  <atom name="H33" species="hydrogen">
    <position> -15.03057701 -13.84554488 -28.94653662 </position>
    <velocity> -0.00091796 0.00068415 0.00073915 </velocity>
    <force> 0.00794848 -0.00194493 0.02022016 </force>
  </atom>
  <atom name="H34" species="hydrogen">
    <position> -13.03023393 -15.93501488 -28.82530460 </position>
    <velocity> 0.00029471 0.00031327 -0.00082807 </velocity>
    <force> 0.00155672 -0.00445285 0.01108662 </force>
  </atom>
  <atom name="H35" species="hydrogen">
    <position> -20.44031310 -0.95747070 14.68769938 </position>
    <velocity> -0.00010413 -0.00023443 0.00014636 </velocity>
    <force> -0.00469370 -0.00404112 -0.00797306 </force>
  </atom>
  <atom name="H36" species="hydrogen">
    <position> -18.16906226 -2.60290323 14.50283845 </position>
    <velocity> -0.00002695 0.00023849 0.00025386 </velocity>
    <force> 0.01898587 -0.00292287 0.00141840 </force>
  </atom>
  <atom name="H37" species="hydrogen">
    <position> 5.61890115 -15.53722797 0.49959567 </position>
    <velocity> -0.00002296 0.00028873 0.00145840 </velocity>
    <force> 0.01173984 -0.00672479 -0.01451680 </force>
  </atom>
  <atom name="H38" species="hydrogen">
    <position> 8.14149996 -15.40308205 -1.34658890 </position>
    <velocity> -0.00040211 -0.00043474 -0.00014077 </velocity>
    <force> -0.01455708 -0.00731460 0.01202492 </force>
  </atom>
  <atom name="H39" species="hydrogen">
    <position> 5.53224891 19.56437225 -23.08681525 </position>
    <velocity> -0.00016300 -0.00020538 0.00010385 </velocity>
    <force> -0.00372787 -0.00650990 0.00885763 </force>
  </atom>
  <atom name="H40" species="hydrogen">
    <position> 6.88273703 17.32517588 -24.47405410 </position>
    <velocity> -0.00031558 -0.00035640 0.00008072 </velocity>
    <force> 0.01282737 -0.01372734 -0.00602719 </force>
  </atom>
  <atom name="H41" species="hydrogen">
    <position> 3.80952313 1.89795186 11.41577465 </position>
    <velocity> 0.00047364 0.00011030 -0.00001368 </velocity>
    <force> -0.00949015 -0.00287414 0.00043143 </force>
  </atom>
  <atom name="H42" species="hydrogen">
    <position> 2.99100676 2.85614476 14.18333172 </position>
    <velocity> -0.00079827 -0.00026921 -0.00020300 </velocity>
    <force> -0.00887313 0.00838973 0.00925798 </force>
  </atom>
  <atom name="H43" species="hydrogen">
    <position> -8.60639936 -5.47775850 3.45742847 </position>
    <velocity> 0.00019821 -0.00076534 0.00072623 </velocity>
    <force> 0.01441275 0.00377218 0.01508694 </force>
  </atom>
  <atom name="H44" species="hydrogen">
    <position> -9.84025050 -6.40621355 1.10070927 </position>
    <velocity> 0.00096941 0.00155292 0.00026483 </velocity>
    <force> -0.01056160 -0.00425862 -0.01067722 </force>
  </atom>
  <atom name="H45" species="hydrogen">
    <position> -12.82298361 -9.31215622 8.47062855 </position>
    <velocity> 0.00064230 0.00009974 -0.00020038 </velocity>
    <force> -0.00378513 -0.01330218 0.00310698 </force>
  </atom>
  <atom name="H46" species="hydrogen">
    <position> -14.68425707 -9.57757194 6.44159268 </position>
    <velocity> 0.00051163 -0.00016380 0.00033199 </velocity>
    <force> -0.00848881 0.00283528 -0.00461860 </force>
  </atom>
  <atom name="H47" species="hydrogen">
    <position> 16.74635634 -13.12952613 4.58100918 </position>
    <velocity> 0.00007627 -0.00078703 0.00037468 </velocity>
    <force> -0.00384566 0.01500229 -0.00995146 </force>
  </atom>
  <atom name="H48" species="hydrogen">
    <position> 18.65244013 -14.71313689 5.70407923 </position>
    <velocity> 0.00095167 -0.00028807 -0.00031678 </velocity>
    <force> 0.01833143 -0.02616135 0.02422977 </force>
  </atom>
  <atom name="H49" species="hydrogen">
    <position> 19.90000277 13.01353914 3.14525470 </position>
    <velocity> -0.00023706 0.00069558 -0.00061719 </velocity>
    <force> -0.00202054 -0.01137934 0.00892175 </force>
  </atom>
  <atom name="H50" species="hydrogen">
    <position> 19.36736771 14.25323578 0.54165619 </position>
    <velocity> 0.00037578 -0.00023825 -0.00009332 </velocity>
    <force> 0.00771552 -0.00017206 -0.00858628 </force>
  </atom>
  <atom name="H51" species="hydrogen">
    <position> 6.82292103 14.31363604 -31.55404514 </position>
    <velocity> 0.00060132 0.00044072 0.00014492 </velocity>
    <force> 0.00091497 -0.01446735 0.00628323 </force>
  </atom>
  <atom name="H52" species="hydrogen">
    <position> 4.84961645 12.89607770 -29.89789123 </position>
    <velocity> -0.00065503 0.00062802 -0.00074726 </velocity>
    <force> -0.00939414 -0.00382666 0.00171371 </force>
  </atom>
  <atom name="H53" species="hydrogen">
    <position> 14.67363995 -22.30615276 -10.22063660 </position>
    <velocity> -0.00075226 0.00022661 0.00035096 </velocity>
    <force> -0.02389342 0.01324232 0.00198319 </force>
  </atom>
  <atom name="H54" species="hydrogen">
    <position> 12.62832163 -20.68004189 -8.67724784 </position>
    <velocity> 0.00103533 -0.00024355 0.00047471 </velocity>
    <force> -0.00323392 -0.00670953 -0.00916238 </force>
  </atom>
  <atom name="H55" species="hydrogen">
    <position> 11.25026097 2.78016734 -15.96708755 </position>
    <velocity> -0.00062113 0.00082249 -0.00102664 </velocity>
    <force> 0.00006222 -0.01084381 -0.02202362 </force>
  </atom>
  <atom name="H56" species="hydrogen">
    <position> 12.02911671 3.22783944 -13.25877517 </position>
    <velocity> -0.00009715 -0.00074111 0.00013464 </velocity>
    <force> -0.02287967 0.00553577 0.00464862 </force>
  </atom>
  <atom name="H57" species="hydrogen">
    <position> -4.05006919 7.05513562 -2.15565010 </position>
    <velocity> -0.00052157 -0.00035086 -0.00032703 </velocity>
    <force> 0.02214930 0.02481436 0.04362506 </force>
  </atom>
  <atom name="H58" species="hydrogen">
    <position> -6.16270959 7.60130345 -4.47729668 </position>
    <velocity> -0.00027410 -0.00023775 -0.00050643 </velocity>
    <force> 0.02694171 0.00300405 0.00492850 </force>
  </atom>
  <atom name="H59" species="hydrogen">
    <position> -10.36894578 -1.62033144 23.46672430 </position>
    <velocity> 0.00066061 -0.00000783 -0.00047220 </velocity>
    <force> 0.00784828 -0.02641667 0.01896936 </force>
  </atom>
  <atom name="H60" species="hydrogen">
    <position> -9.36203572 0.73153821 22.00790352 </position>
    <velocity> -0.00012986 -0.00005780 -0.00048917 </velocity>
    <force> -0.02827200 -0.01426088 -0.00482913 </force>
  </atom>
  <atom name="H61" species="hydrogen">
    <position> 5.52517418 0.47820470 0.69505988 </position>
    <velocity> 0.00148383 0.00056156 0.00000737 </velocity>
    <force> 0.00195444 -0.00247240 -0.00415979 </force>
  </atom>
  <atom name="H62" species="hydrogen">
    <position> 4.11945941 -1.14333399 2.81870334 </position>
    <velocity> -0.00029948 0.00040893 -0.00029176 </velocity>
    <force> 0.00676924 -0.00512983 -0.01515186 </force>
  </atom>
  <atom name="H63" species="hydrogen">
    <position> 23.68572463 -0.31160141 -0.31900105 </position>
    <velocity> -0.00042765 0.00051660 -0.00066355 </velocity>
    <force> -0.01759747 0.00594798 -0.02570419 </force>
  </atom>
  <atom name="H64" species="hydrogen">
    <position> 23.57859809 -2.06838846 -2.60123390 </position>
    <velocity> -0.00036671 0.00034914 -0.00068610 </velocity>
    <force> 0.02496816 -0.04138695 -0.02561320 </force>
  </atom>
  <atom name="H65" species="hydrogen">
    <position> -0.41172113 21.65150893 8.81393844 </position>
    <velocity> 0.00047463 -0.00018597 0.00003109 </velocity>
    <force> -0.00916950 0.00165740 -0.00464365 </force>
  </atom>
  <atom name="H66" species="hydrogen">
    <position> 0.19345142 23.51470883 10.80839856 </position>
    <velocity> 0.00120605 0.00006417 0.00081217 </velocity>
    <force> 0.03304562 0.02267969 0.03537554 </force>
  </atom>
  <atom name="H67" species="hydrogen">
    <position> -12.44330198 -1.83008182 19.34001016 </position>
    <velocity> -0.00005513 -0.00012897 0.00076031 </velocity>
    <force> 0.01085687 0.00133660 0.01363454 </force>
  </atom>
  <atom name="H68" species="hydrogen">
    <position> -14.85883798 -1.67708721 17.77227854 </position>
    <velocity> -0.00004473 0.00039485 -0.00102435 </velocity>
    <force> -0.00516740 0.00052172 -0.00573255 </force>
  </atom>
  <atom name="H69" species="hydrogen">
    <position> 4.64153049 -1.27792301 -16.20532014 </position>
    <velocity> -0.00015161 -0.00105428 0.00026151 </velocity>
    <force> -0.02082135 -0.00390711 -0.03816064 </force>
  </atom>
  <atom name="H70" species="hydrogen">
    <position> 5.30861708 -3.77651934 -17.32323602 </position>
    <velocity> 0.00030748 0.00047939 0.00012792 </velocity>
    <force> -0.00615538 0.00177818 -0.02207299 </force>
  </atom>
  <atom name="H71" species="hydrogen">
    <position> 7.97412511 8.49691832 -40.39296153 </position>
    <velocity> -0.00070538 -0.00049151 0.00030435 </velocity>
    <force> 0.00293347 0.00250675 0.00022029 </force>
  </atom>
  <atom name="H72" species="hydrogen">
    <position> 8.54724349 5.87094819 -39.10099485 </position>
    <velocity> 0.00045673 -0.00057595 -0.00072198 </velocity>
    <force> 0.00640881 0.00099980 0.00014034 </force>
  </atom>
  <atom name="H73" species="hydrogen">
    <position> -10.45735046 -2.61070860 7.08307887 </position>
    <velocity> -0.00078483 0.00086350 0.00028647 </velocity>
    <force> -0.00578479 0.01312934 -0.01999493 </force>
  </atom>
  <atom name="H74" species="hydrogen">
    <position> -10.90570733 -2.20993014 4.05588298 </position>
    <velocity> -0.00001904 0.00031883 0.00013568 </velocity>
    <force> 0.00399555 0.01491321 0.03714725 </force>
  </atom>
  <atom name="H75" species="hydrogen">
    <position> 2.02151400 10.79631182 18.87266644 </position>
    <velocity> -0.00002273 0.00010298 -0.00081619 </velocity>
    <force> -0.00600570 -0.00337870 0.02514019 </force>
  </atom>
  <atom name="H76" species="hydrogen">
    <position> 2.04491998 10.51296979 16.10021841 </position>
    <velocity> -0.00000998 -0.00012607 0.00106879 </velocity>
    <force> -0.00673512 0.00660270 -0.01735352 </force>
  </atom>
  <atom name="H77" species="hydrogen">
    <position> 8.44164000 10.56469020 -10.08411756 </position>
    <velocity> -0.00050186 0.00021581 0.00034236 </velocity>
    <force> -0.00041102 0.01166788 -0.00933077 </force>
  </atom>
  <atom name="H78" species="hydrogen">
    <position> 7.82926112 11.07223569 -13.03182779 </position>
    <velocity> -0.00165544 -0.00115222 0.00064723 </velocity>
    <force> 0.01096292 0.02754719 -0.01597119 </force>
  </atom>
  <atom name="H79" species="hydrogen">
    <position> -17.59629374 -7.62416675 11.18616504 </position>
    <velocity> 0.00091013 0.00051251 0.00038331 </velocity>
    <force> -0.02093082 -0.00568873 -0.01946432 </force>
  </atom>
  <atom name="H80" species="hydrogen">
    <position> -15.92080500 -5.76487856 12.56105654 </position>
    <velocity> -0.00116659 -0.00080360 -0.00079910 </velocity>
    <force> 0.01096540 0.01793051 0.00283062 </force>
  </atom>
  <atom name="H81" species="hydrogen">
    <position> 15.99273794 4.80233246 -2.72288071 </position>
    <velocity> 0.00025769 0.00015847 -0.00007436 </velocity>
    <force> -0.02140399 -0.01021697 0.00317083 </force>
  </atom>
  <atom name="H82" species="hydrogen">
    <position> 13.70371711 5.07493095 -0.78528219 </position>
    <velocity> 0.00001547 0.00124801 0.00063641 </velocity>
    <force> 0.00017757 -0.00420884 -0.00337820 </force>
  </atom>
  <atom name="H83" species="hydrogen">
    <position> -7.87278349 17.35613665 15.74871915 </position>
    <velocity> 0.00069496 0.00178312 0.00003156 </velocity>
    <force> -0.01275333 0.00676707 0.00311080 </force>
  </atom>
  <atom name="H84" species="hydrogen">
    <position> -10.52045192 18.16541197 16.93603695 </position>
    <velocity> -0.00008792 -0.00076420 -0.00026438 </velocity>
    <force> -0.01069247 0.01294409 0.00809699 </force>
  </atom>
  <atom name="H85" species="hydrogen">
    <position> -4.94110035 -3.07934740 -9.16075602 </position>
    <velocity> -0.00007669 0.00042227 -0.00035562 </velocity>
    <force> -0.00545904 0.03301424 -0.01011108 </force>
  </atom>
  <atom name="H86" species="hydrogen">
    <position> -3.71483245 -4.75483876 -7.16757887 </position>
    <velocity> 0.00033285 0.00012009 0.00065503 </velocity>
    <force> -0.00123795 -0.00442871 -0.00547897 </force>
  </atom>
  <atom name="H87" species="hydrogen">
    <position> -12.18070992 -11.37825830 17.07326088 </position>
    <velocity> 0.00037195 0.00051393 -0.00029439 </velocity>
    <force> -0.03254893 0.00143629 0.04703228 </force>
  </atom>
  <atom name="H88" species="hydrogen">
    <position> -10.30797622 -9.49048730 15.55907865 </position>
    <velocity> 0.00029350 0.00059703 -0.00006350 </velocity>
    <force> -0.02347605 -0.02019622 0.01413684 </force>
  </atom>
  <atom name="H89" species="hydrogen">
    <position> -8.60449148 25.03068140 5.29421043 </position>
    <velocity> -0.00020521 -0.00039130 -0.00028525 </velocity>
    <force> -0.00174555 -0.00115500 -0.00678733 </force>
  </atom>
  <atom name="H90" species="hydrogen">
    <position> -6.42626674 26.91348981 6.14025974 </position>
    <velocity> -0.00100698 -0.00129459 0.00047088 </velocity>
    <force> -0.01333600 -0.00299818 -0.03254493 </force>
  </atom>
  <atom name="H91" species="hydrogen">
    <position> 11.94423521 -4.92352867 -12.87994667 </position>
    <velocity> -0.00000628 0.00030854 -0.00010652 </velocity>
    <force> 0.02237351 -0.00923526 -0.03540793 </force>
  </atom>
  <atom name="H92" species="hydrogen">
    <position> 14.51291155 -6.35928732 -14.06875601 </position>
    <velocity> -0.00011971 0.00001141 -0.00043393 </velocity>
    <force> -0.02628140 0.03109586 -0.00704883 </force>
  </atom>
  <atom name="H93" species="hydrogen">
    <position> -3.99080671 -2.27413385 2.05623827 </position>
    <velocity> -0.00063893 -0.00048955 -0.00005078 </velocity>
    <force> -0.00118324 0.01674578 -0.00391098 </force>
  </atom>
  <atom name="H94" species="hydrogen">
    <position> -5.28928496 -0.14081202 3.49712037 </position>
    <velocity> -0.00006259 -0.00136125 0.00007040 </velocity>
    <force> -0.05036552 0.03165342 0.00545574 </force>
  </atom>
  <atom name="H95" species="hydrogen">
    <position> -18.53703185 -17.99237947 -17.99099686 </position>
    <velocity> -0.00004386 0.00080239 0.00051432 </velocity>
    <force> 0.02536759 0.01047530 -0.00692271 </force>
  </atom>
  <atom name="H96" species="hydrogen">
    <position> -21.01396651 -17.43015074 -16.90582087 </position>
    <velocity> 0.00008215 -0.00017020 -0.00022085 </velocity>
    <force> -0.02489330 0.02563918 0.01463620 </force>
  </atom>
  <atom name="H97" species="hydrogen">
    <position> -38.80109631 4.10282804 -23.59899948 </position>
    <velocity> -0.00054227 0.00045506 -0.00034157 </velocity>
    <force> -0.01823519 -0.00095079 -0.00902396 </force>
  </atom>
  <atom name="H98" species="hydrogen">
    <position> -37.36664163 1.51628108 -24.03313459 </position>
    <velocity> 0.00033483 0.00048055 -0.00075694 </velocity>
    <force> 0.00864850 -0.00923106 0.00009200 </force>
  </atom>
  <atom name="H99" species="hydrogen">
    <position> 32.74982397 17.66176754 -4.04392623 </position>
    <velocity> 0.00001554 -0.00020315 0.00111883 </velocity>
    <force> -0.00345786 -0.01065109 0.00297472 </force>
  </atom>
  <atom name="H100" species="hydrogen">
    <position> 31.21457010 14.99183984 -4.26918627 </position>
    <velocity> 0.00066814 -0.00050878 0.00022289 </velocity>
    <force> 0.01246079 0.00323532 0.00069149 </force>
  </atom>
  <atom name="H101" species="hydrogen">
    <position> 9.82675237 3.30070973 -5.93118743 </position>
    <velocity> -0.00088821 0.00041892 -0.00076692 </velocity>
    <force> -0.05414470 -0.02736513 -0.00010485 </force>
  </atom>
  <atom name="H102" species="hydrogen">
    <position> 12.22678470 3.85228193 -4.42056665 </position>
    <velocity> 0.00136159 0.00043595 -0.00116181 </velocity>
    <force> 0.01006377 0.00549222 -0.00726612 </force>
  </atom>
  <atom name="H103" species="hydrogen">
    <position> -3.42048796 3.81467709 18.65017375 </position>
    <velocity> -0.00033875 -0.00072700 0.00035218 </velocity>
    <force> 0.00501786 0.00862069 0.00520028 </force>
  </atom>
  <atom name="H104" species="hydrogen">
    <position> -1.49528634 1.69418761 19.51608402 </position>
    <velocity> 0.00028335 0.00044603 -0.00066876 </velocity>
    <force> 0.00428506 -0.02407935 0.02850044 </force>
  </atom>
  <atom name="H105" species="hydrogen">
    <position> 21.76536531 -10.85519130 -6.93318208 </position>
    <velocity> 0.00025235 0.00071621 -0.00013906 </velocity>
    <force> -0.01509487 0.00126807 0.00468738 </force>
  </atom>
  <atom name="H106" species="hydrogen">
    <position> 19.83700027 -9.21282576 -8.49254267 </position>
    <velocity> 0.00065340 -0.00052445 0.00103709 </velocity>
    <force> 0.00400203 -0.01210543 0.01673043 </force>
  </atom>
  <atom name="H107" species="hydrogen">
    <position> 0.93046372 -8.51643614 10.95925068 </position>
    <velocity> -0.00040749 0.00082346 -0.00041862 </velocity>
    <force> 0.01298977 0.00865822 -0.01121006 </force>
  </atom>
  <atom name="H108" species="hydrogen">
    <position> 0.78295405 -7.47507445 13.83725810 </position>
    <velocity> 0.00078084 -0.00027838 -0.00011868 </velocity>
    <force> 0.00628538 0.00823723 -0.00202381 </force>
  </atom>
  <atom name="H109" species="hydrogen">
    <position> 18.13520507 -5.08095747 -1.21184283 </position>
    <velocity> -0.00011623 -0.00045657 -0.00025983 </velocity>
    <force> -0.00240763 -0.00767326 -0.00200878 </force>
  </atom>
  <atom name="H110" species="hydrogen">
    <position> 19.16384068 -2.41158172 -1.60009822 </position>
    <velocity> 0.00002127 -0.00020090 -0.00037893 </velocity>
    <force> 0.01959139 0.01444334 -0.01418542 </force>
  </atom>
  <atom name="H111" species="hydrogen">
    <position> 23.98086032 -6.72972169 18.50785959 </position>
    <velocity> -0.00049483 -0.00068634 0.00053175 </velocity>
    <force> 0.00060842 0.00322010 -0.00285002 </force>
  </atom>
  <atom name="H112" species="hydrogen">
    <position> 25.03628069 -4.22877607 17.15501724 </position>
    <velocity> 0.00012699 0.00043318 0.00032895 </velocity>
    <force> -0.00913918 -0.01314170 -0.00715289 </force>
  </atom>
  <atom name="H113" species="hydrogen">
    <position> 2.31068202 34.13020995 -23.59180935 </position>
    <velocity> 0.00032605 0.00010417 -0.00016012 </velocity>
    <force> 0.01056840 -0.00909267 -0.00495966 </force>
  </atom>
  <atom name="H114" species="hydrogen">
    <position> 1.14512676 31.60207145 -24.09577237 </position>
    <velocity> -0.00016658 -0.00039725 -0.00017249 </velocity>
    <force> -0.02096845 -0.01476927 0.00369623 </force>
  </atom>
  <atom name="H115" species="hydrogen">
    <position> 6.95984941 1.87209676 -13.85666356 </position>
    <velocity> 0.00017872 -0.00036379 -0.00025351 </velocity>
    <force> -0.03503861 -0.01251686 -0.02468322 </force>
  </atom>
  <atom name="H116" species="hydrogen">
    <position> 4.72858789 2.88746912 -15.71206424 </position>
    <velocity> -0.00001597 -0.00062435 0.00055153 </velocity>
    <force> -0.01274989 0.00334193 -0.00842971 </force>
  </atom>
  <atom name="H117" species="hydrogen">
    <position> -3.32060534 -14.74514126 -21.92627925 </position>
    <velocity> 0.00077433 0.00033965 0.00089166 </velocity>
    <force> 0.01940370 -0.01754395 -0.00495038 </force>
  </atom>
  <atom name="H118" species="hydrogen">
    <position> -1.98151646 -17.46057160 -22.04048874 </position>
    <velocity> -0.00045754 -0.00156558 0.00059808 </velocity>
    <force> 0.00412906 -0.01527930 0.00860921 </force>
  </atom>
  <atom name="H119" species="hydrogen">
    <position> -28.99836697 -14.00155093 10.77645329 </position>
    <velocity> 0.00052820 -0.00012154 -0.00121201 </velocity>
    <force> -0.00879611 -0.01937592 0.00349169 </force>
  </atom>
  <atom name="H120" species="hydrogen">
    <position> -27.96591975 -11.49818580 10.15112764 </position>
    <velocity> 0.00096240 0.00033487 0.00089378 </velocity>
    <force> 0.00866076 0.00653260 -0.00008203 </force>
  </atom>
  <atom name="H121" species="hydrogen">
    <position> -4.62925216 4.84911902 -13.76345032 </position>
    <velocity> -0.00071009 0.00047186 -0.00050323 </velocity>
    <force> 0.00001053 0.00353347 -0.00613305 </force>
  </atom>
  <atom name="H122" species="hydrogen">
    <position> -2.99089273 2.80660575 -15.14867315 </position>
    <velocity> -0.00027233 0.00015163 0.00005212 </velocity>
    <force> 0.00163802 0.00170809 -0.00320411 </force>
  </atom>
  <atom name="H123" species="hydrogen">
    <position> -5.18256679 -6.97647804 31.90424496 </position>
    <velocity> -0.00040360 0.00068586 0.00052002 </velocity>
    <force> 0.02317406 0.01425912 -0.03803810 </force>
  </atom>
  <atom name="H124" species="hydrogen">
    <position> -5.04725084 -6.36659281 34.80441142 </position>
    <velocity> 0.00018888 0.00103925 0.00023417 </velocity>
    <force> 0.00796653 0.00703960 0.00891616 </force>
  </atom>
  <atom name="H125" species="hydrogen">
    <position> -20.95939645 -9.24142466 30.21967310 </position>
    <velocity> 0.00018910 -0.00103598 0.00027893 </velocity>
    <force> 0.00143883 -0.00948586 -0.00508241 </force>
  </atom>
  <atom name="H126" species="hydrogen">
    <position> -20.86151650 -6.49318243 30.85417489 </position>
    <velocity> 0.00029477 0.00032475 0.00051080 </velocity>
    <force> -0.00153301 0.00608187 0.00336116 </force>
  </atom>
  <atom name="H127" species="hydrogen">
    <position> 10.53148001 6.01409462 25.13439876 </position>
    <velocity> 0.00125754 -0.00079565 -0.00015716 </velocity>
    <force> 0.02783382 0.01135756 0.02486054 </force>
  </atom>
  <atom name="H128" species="hydrogen">
    <position> 13.30480778 5.36593388 26.79241962 </position>
    <velocity> 0.00048840 -0.00043208 -0.00079035 </velocity>
    <force> -0.01411152 -0.00194965 -0.00794728 </force>
  </atom>
</atomset>
<unit_cell_a_norm> 23.460000 </unit_cell_a_norm>
<unit_cell_b_norm> 23.460000 </unit_cell_b_norm>
<unit_cell_c_norm> 23.460000 </unit_cell_c_norm>
<unit_cell_alpha>  90.000 </unit_cell_alpha>
<unit_cell_beta>   90.000 </unit_cell_beta>
<unit_cell_gamma>  90.000 </unit_cell_gamma>
<unit_cell_volume> 12911.718 </unit_cell_volume>
  <econst> -1100.15052246 </econst>
  <ekin_ion> 0.36077529 </ekin_ion>
  <temp_ion> 395.58837423 </temp_ion>
  total_electronic_charge: 512.00000000
  <eigenvalue_sum>  -162.45801669 </eigenvalue_sum>
  <etotal_int>   -1100.50770100 </etotal_int>
  total_electronic_charge: 512.00000000
  <eigenvalue_sum>  -162.46326029 </eigenvalue_sum>
  Anderson extrapolation: theta=1.23317758 (1.23317758)
  <etotal_int>   -1100.50775626 </etotal_int>
  total_electronic_charge: 512.00000000
  <eigenvalue_sum>  -162.46977664 </eigenvalue_sum>
  Anderson extrapolation: theta=0.06974075 (0.06974075)
  <etotal_int>   -1100.50778870 </etotal_int>
  total_electronic_charge: 512.00000000
  <eigenvalue_sum>  -162.47032524 </eigenvalue_sum>
  Anderson extrapolation: theta=1.84917231 (1.84917231)
  <etotal_int>   -1100.50779046 </etotal_int>
  total_electronic_charge: 512.00000000
  <eigenvalue_sum>  -162.47141916 </eigenvalue_sum>
  Anderson extrapolation: theta=0.26172179 (0.26172179)
  <etotal_int>   -1100.50779228 </etotal_int>
  <timing name="iteration" min="    5.665" max="    5.675"/>
</iteration>
<iteration count="7">
  total_electronic_charge: 512.00000000
  <ekin>       808.51592968 </ekin>
  <econf>        0.00000000 </econf>
  <eps>      -1309.68533064 </eps>
  <enl>        124.84834711 </enl>
  <ecoul>     -453.17021222 </ecoul>
  <exc>       -271.01652663 </exc>
  <esr>         93.60381429 </esr>
  <eself>      646.81841729 </eself>
  <ets>          0.00000000 </ets>
  <eexf>         0.00000000 </eexf>
  <etotal>   -1100.50779271 </etotal>
  <epv>          0.00000000 </epv>
  <eefield>      0.00000000 </eefield>
  <enthalpy> -1100.50779271 </enthalpy>
<atomset>
<unit_cell 
    a=" 23.46000000   0.00000000   0.00000000"
    b="  0.00000000  23.46000000   0.00000000"
    c="  0.00000000   0.00000000  23.46000000" />
  <atom name="O1" species="oxygen">
    <position> -6.49143784 6.00538221 12.39647564 </position>
    <velocity> -0.00007450 -0.00020616 0.00033998 </velocity>
    <force> 0.06290940 -0.00330342 0.02914665 </force>
  </atom>
  <atom name="O2" species="oxygen">
    <position> 23.13589120 2.61476447 25.48394543 </position>
    <velocity> -0.00000138 0.00004375 -0.00018948 </velocity>
    <force> 0.00389402 -0.00876753 0.02061511 </force>
  </atom>
  <atom name="O3" species="oxygen">
    <position> -28.80459684 23.74068639 -33.10299785 </position>
    <velocity> -0.00013376 0.00013042 -0.00015310 </velocity>
    <force> 0.01461901 -0.00205284 -0.00926874 </force>
  </atom>
  <atom name="O4" species="oxygen">
    <position> 13.16831778 -9.22512247 -0.59725407 </position>
    <velocity> 0.00008025 -0.00026561 0.00014385 </velocity>
    <force> -0.00234751 -0.01943165 0.03307914 </force>
  </atom>
  <atom name="O5" species="oxygen">
    <position> 6.68243506 -22.47089160 -5.70833292 </position>
    <velocity> 0.00027517 0.00003180 -0.00043831 </velocity>
    <force> 0.00572185 0.01580557 0.03870816 </force>
  </atom>
  <atom name="O6" species="oxygen">
    <position> 8.02377499 16.91986165 5.25308688 </position>
    <velocity> 0.00006500 -0.00022790 0.00032517 </velocity>
    <force> -0.02729380 -0.00047585 -0.02711121 </force>
  </atom>
  <atom name="O7" species="oxygen">
    <position> -4.61617595 -29.10790627 -18.05731523 </position>
    <velocity> -0.00002928 0.00050078 -0.00027900 </velocity>
    <force> -0.00777567 0.02006516 0.00658324 </force>
  </atom>
  <atom name="O8" species="oxygen">
    <position> 2.78109350 -14.71781302 13.54865042 </position>
    <velocity> -0.00005875 -0.00044224 0.00019744 </velocity>
    <force> 0.00234389 -0.00202389 -0.00928515 </force>
  </atom>
  <atom name="O9" species="oxygen">
    <position> 2.59594834 4.39990436 -6.46289849 </position>
    <velocity> -0.00026802 0.00000780 -0.00040796 </velocity>
    <force> 0.04019091 0.02282640 -0.01289498 </force>
  </atom>
  <atom name="O10" species="oxygen">
    <position> 0.41606446 8.00160495 8.12946623 </position>
    <velocity> 0.00012326 0.00030600 0.00022291 </velocity>
    <force> -0.01471481 0.02010831 0.00774992 </force>
  </atom>
  <atom name="O11" species="oxygen">
    <position> 13.17444209 -14.43480999 10.99522219 </position>
    <velocity> -0.00006550 0.00009297 -0.00001612 </velocity>
    <force> 0.00023331 -0.00070084 -0.00618655 </force>
  </atom>
  <atom name="O12" species="oxygen">
    <position> -13.18244717 -2.56481754 13.06208391 </position>
    <velocity> 0.00023702 -0.00018459 -0.00014267 </velocity>
    <force> -0.02149609 -0.02896823 -0.00874895 </force>
  </atom>
  <atom name="O13" species="oxygen">
    <position> 2.31821662 -9.77507806 -21.53417661 </position>
    <velocity> -0.00011896 0.00037611 0.00013538 </velocity>
    <force> 0.00010328 -0.00913630 0.00491934 </force>
  </atom>
  <atom name="O14" species="oxygen">
    <position> -5.30989556 -9.16553963 -2.47725520 </position>
    <velocity> -0.00011348 0.00006515 -0.00032458 </velocity>
    <force> 0.05119743 0.02157300 0.00863031 </force>
  </atom>
  <atom name="O15" species="oxygen">
    <position> 13.28982985 -12.00677165 4.15404937 </position>
    <velocity> -0.00044711 -0.00033051 0.00013109 </velocity>
    <force> 0.04119945 -0.02975332 -0.06340957 </force>
  </atom>
  <atom name="O16" species="oxygen">
    <position> -6.99164886 9.51402310 -7.02354689 </position>
    <velocity> -0.00006390 0.00022682 -0.00008339 </velocity>
    <force> -0.00594447 -0.00810223 -0.00498577 </force>
  </atom>
  <atom name="O17" species="oxygen">
    <position> -13.79216602 -14.60998225 -27.72329348 </position>
    <velocity> -0.00002635 0.00012270 0.00016958 </velocity>
    <force> -0.01370680 0.00576819 -0.03003626 </force>
  </atom>
  <atom name="O18" species="oxygen">
    <position> -19.93768356 -2.76513306 14.86034437 </position>
    <velocity> -0.00024009 -0.00014032 0.00012498 </velocity>
    <force> -0.01266161 0.00396907 0.00373103 </force>
  </atom>
  <atom name="O19" species="oxygen">
    <position> 7.36109868 -16.24395155 0.20020775 </position>
    <velocity> -0.00032497 -0.00033538 0.00004389 </velocity>
    <force> 0.01271295 0.00942604 -0.00315349 </force>
  </atom>
  <atom name="O20" species="oxygen">
    <position> 5.90127070 17.68029744 -22.94988537 </position>
    <velocity> 0.00005490 -0.00010794 0.00000666 </velocity>
    <force> -0.01462184 0.01362438 0.01209245 </force>
  </atom>
  <atom name="O21" species="oxygen">
    <position> 2.45072999 1.83774573 12.73770199 </position>
    <velocity> -0.00020616 0.00028342 -0.00013094 </velocity>
    <force> 0.00196808 -0.00928403 -0.00541164 </force>
  </atom>
  <atom name="O22" species="oxygen">
    <position> -9.88473984 -4.94568821 2.27620949 </position>
    <velocity> 0.00030337 0.00009953 -0.00033969 </velocity>
    <force> -0.00475963 0.00405820 0.00396534 </force>
  </atom>
  <atom name="O23" species="oxygen">
    <position> -13.80417311 -10.70443746 7.65628269 </position>
    <velocity> 0.00016367 0.00003564 -0.00036572 </velocity>
    <force> 0.01147206 0.01505306 0.00745936 </force>
  </atom>
  <atom name="O24" species="oxygen">
    <position> 18.60929854 -13.37650564 4.52132822 </position>
    <velocity> 0.00031732 -0.00012706 -0.00007721 </velocity>
    <force> -0.02006957 0.01348470 -0.01735097 </force>
  </atom>
  <atom name="O25" species="oxygen">
    <position> 20.48737488 14.35871108 2.05048441 </position>
    <velocity> 0.00002625 -0.00049500 -0.00044768 </velocity>
    <force> 0.00280425 0.01183446 -0.00422170 </force>
  </atom>
  <atom name="O26" species="oxygen">
    <position> 6.68675963 13.03374623 -30.11616781 </position>
    <velocity> -0.00000195 0.00023466 0.00014073 </velocity>
    <force> 0.00134342 0.01749187 -0.01238185 </force>
  </atom>
  <atom name="O27" species="oxygen">
    <position> 12.82611810 -21.74107496 -10.27323242 </position>
    <velocity> 0.00018925 -0.00028280 0.00012647 </velocity>
    <force> 0.03533411 0.00019269 0.00108398 </force>
  </atom>
  <atom name="O28" species="oxygen">
    <position> 10.66604618 3.72681844 -14.54019300 </position>
    <velocity> 0.00010097 0.00032531 -0.00020699 </velocity>
    <force> 0.01822220 -0.00546431 0.02603469 </force>
  </atom>
  <atom name="O29" species="oxygen">
    <position> -4.81777841 6.47589017 -3.64164690 </position>
    <velocity> -0.00004030 -0.00009546 0.00009565 </velocity>
    <force> -0.05719970 -0.02549073 -0.05775691 </force>
  </atom>
  <atom name="O30" species="oxygen">
    <position> -10.78166828 -0.59647920 22.05019738 </position>
    <velocity> 0.00037100 0.00013256 -0.00016620 </velocity>
    <force> 0.01160208 0.03626290 -0.01481738 </force>
  </atom>
  <atom name="O31" species="oxygen">
    <position> 4.42581520 -1.01452635 0.92915751 </position>
    <velocity> 0.00014992 0.00002896 0.00029218 </velocity>
    <force> -0.00578145 0.00663810 0.01060161 </force>
  </atom>
  <atom name="O32" species="oxygen">
    <position> 22.69145108 -0.70510324 -1.94351324 </position>
    <velocity> -0.00010483 0.00011572 0.00048300 </velocity>
    <force> -0.00704710 0.03109288 0.04568751 </force>
  </atom>
  <atom name="O33" species="oxygen">
    <position> -1.15228373 23.06890890 9.74302831 </position>
    <velocity> -0.00007681 0.00008755 -0.00001892 </velocity>
    <force> -0.02489726 -0.01684636 -0.02614261 </force>
  </atom>
  <atom name="O34" species="oxygen">
    <position> -13.43458191 -2.82001869 18.13690418 </position>
    <velocity> -0.00026783 0.00002397 0.00014903 </velocity>
    <force> 0.00066741 -0.00477274 -0.00048789 </force>
  </atom>
  <atom name="O35" species="oxygen">
    <position> 4.05067501 -2.42587278 -17.76942809 </position>
    <velocity> 0.00003781 -0.00009112 0.00018198 </velocity>
    <force> 0.02616588 0.00060790 0.06447563 </force>
  </atom>
  <atom name="O36" species="oxygen">
    <position> 7.52075184 6.72229475 -40.39912993 </position>
    <velocity> -0.00034816 -0.00004459 -0.00008158 </velocity>
    <force> 0.00272320 0.00447346 -0.00341050 </force>
  </atom>
  <atom name="O37" species="oxygen">
    <position> -10.80485456 -1.21883720 5.74308996 </position>
    <velocity> -0.00026922 0.00000105 -0.00000802 </velocity>
    <force> 0.00212131 -0.02022353 -0.01220712 </force>
  </atom>
  <atom name="O38" species="oxygen">
    <position> 1.47032371 11.75638610 17.40778913 </position>
    <velocity> -0.00013331 0.00011673 0.00011001 </velocity>
    <force> 0.00969399 -0.00065435 -0.00669521 </force>
  </atom>
  <atom name="O39" species="oxygen">
    <position> 7.70024820 9.92893392 -11.64995949 </position>
    <velocity> 0.00014935 0.00000161 0.00009767 </velocity>
    <force> -0.01258284 -0.04399234 0.03183620 </force>
  </atom>
  <atom name="O40" species="oxygen">
    <position> -16.35743871 -7.51821812 12.48745700 </position>
    <velocity> 0.00040063 0.00023592 0.00016329 </velocity>
    <force> 0.01230388 -0.01745374 0.01878604 </force>
  </atom>
  <atom name="O41" species="oxygen">
    <position> 14.21480640 4.03948021 -2.28107366 </position>
    <velocity> -0.00008757 0.00011512 0.00016501 </velocity>
    <force> 0.03496235 0.02063220 0.01665746 </force>
  </atom>
  <atom name="O42" species="oxygen">
    <position> -9.69426950 16.85072605 16.01725100 </position>
    <velocity> -0.00012825 -0.00010651 0.00019556 </velocity>
    <force> 0.03083323 -0.01946255 -0.01804232 </force>
  </atom>
  <atom name="O43" species="oxygen">
    <position> -5.15314385 -4.68439880 -8.36129619 </position>
    <velocity> 0.00003055 0.00013002 -0.00011943 </velocity>
    <force> 0.01512879 -0.03213751 0.01785219 </force>
  </atom>
  <atom name="O44" species="oxygen">
    <position> -11.07216027 -11.33142213 15.73074368 </position>
    <velocity> -0.00010121 0.00036442 0.00022724 </velocity>
    <force> 0.05116698 0.02412658 -0.06792197 </force>
  </atom>
  <atom name="O45" species="oxygen">
    <position> -7.55091213 26.42094166 4.57187482 </position>
    <velocity> 0.00040761 -0.00026756 -0.00041441 </velocity>
    <force> 0.00709597 0.00066256 0.03711826 </force>
  </atom>
  <atom name="O46" species="oxygen">
    <position> 12.85507119 -5.29237506 -14.59520096 </position>
    <velocity> -0.00038309 -0.00014691 0.00026792 </velocity>
    <force> 0.00522514 -0.01993678 0.04660656 </force>
  </atom>
  <atom name="O47" species="oxygen">
    <position> -3.71612122 -0.91337273 3.36903200 </position>
    <velocity> 0.00046229 -0.00032056 -0.00027903 </velocity>
    <force> 0.04701733 -0.04056662 -0.00230549 </force>
  </atom>
  <atom name="O48" species="oxygen">
    <position> -20.15090119 -18.78625803 -17.69766603 </position>
    <velocity> -0.00014132 0.00019230 0.00006345 </velocity>
    <force> -0.00162572 -0.04096877 -0.01984448 </force>
  </atom>
  <atom name="O49" species="oxygen">
    <position> -39.02914914 2.30744089 -24.17751645 </position>
    <velocity> -0.00016812 0.00030565 -0.00010603 </velocity>
    <force> 0.00720815 0.00280716 0.00331448 </force>
  </atom>
  <atom name="O50" species="oxygen">
    <position> 32.37648100 16.01042101 -3.15090283 </position>
    <velocity> 0.00008878 -0.00007325 -0.00014085 </velocity>
    <force> -0.00204377 0.00752844 -0.00709387 </force>
  </atom>
  <atom name="O51" species="oxygen">
    <position> 11.40509000 4.03295195 -6.13314017 </position>
    <velocity> -0.00020069 -0.00008295 0.00003644 </velocity>
    <force> 0.03698942 0.02756299 -0.00479583 </force>
  </atom>
  <atom name="O52" species="oxygen">
    <position> -2.00152396 2.72172206 18.13063797 </position>
    <velocity> 0.00008832 -0.00027621 0.00003232 </velocity>
    <force> -0.01213136 0.01528536 -0.04395788 </force>
  </atom>
  <atom name="O53" species="oxygen">
    <position> 19.91156582 -10.32429862 -6.95796839 </position>
    <velocity> 0.00008252 0.00034281 -0.00030315 </velocity>
    <force> 0.02363278 0.00993298 -0.02087989 </force>
  </atom>
  <atom name="O54" species="oxygen">
    <position> 0.05695089 -8.56063511 12.55322574 </position>
    <velocity> -0.00029636 -0.00005661 -0.00015709 </velocity>
    <force> -0.02623529 -0.01218655 0.02034297 </force>
  </atom>
  <atom name="O55" species="oxygen">
    <position> 18.01886479 -3.35701907 -0.57140217 </position>
    <velocity> -0.00002116 -0.00012643 0.00001643 </velocity>
    <force> -0.01035990 -0.01235636 0.00786604 </force>
  </atom>
  <atom name="O56" species="oxygen">
    <position> 23.51640207 -5.37392841 17.34536950 </position>
    <velocity> 0.00028158 -0.00030030 0.00002231 </velocity>
    <force> 0.00724416 0.00583008 0.00965296 </force>
  </atom>
  <atom name="O57" species="oxygen">
    <position> 2.68353779 32.48269877 -24.49285238 </position>
    <velocity> 0.00011615 -0.00010838 0.00008228 </velocity>
    <force> 0.01135815 0.03438100 0.00385429 </force>
  </atom>
  <atom name="O58" species="oxygen">
    <position> 5.18290636 1.41754400 -14.60670989 </position>
    <velocity> -0.00003948 0.00009341 0.00016319 </velocity>
    <force> 0.06242637 -0.00040209 0.02996988 </force>
  </atom>
  <atom name="O59" species="oxygen">
    <position> -2.10532247 -15.85886868 -22.92246629 </position>
    <velocity> 0.00015285 -0.00004892 -0.00004600 </velocity>
    <force> -0.02239656 0.02002574 0.00567916 </force>
  </atom>
  <atom name="O60" species="oxygen">
    <position> -27.38114082 -13.22447165 10.47806660 </position>
    <velocity> -0.00024550 -0.00018452 0.00004243 </velocity>
    <force> 0.00675846 0.02156874 -0.00660227 </force>
  </atom>
  <atom name="O61" species="oxygen">
    <position> -3.87604869 4.42815313 -15.47372530 </position>
    <velocity> -0.00016625 0.00012912 -0.00027518 </velocity>
    <force> -0.00216786 -0.00547507 0.01880519 </force>
  </atom>
  <atom name="O62" species="oxygen">
    <position> -6.01703147 -7.13536101 33.47006842 </position>
    <velocity> 0.00016539 -0.00018458 -0.00002445 </velocity>
    <force> -0.03184471 -0.02384834 0.03722681 </force>
  </atom>
  <atom name="O63" species="oxygen">
    <position> -20.89960237 -8.13969247 31.68935553 </position>
    <velocity> -0.00027616 0.00005142 0.00024640 </velocity>
    <force> 0.00499603 0.00361071 -0.00930073 </force>
  </atom>
  <atom name="O64" species="oxygen">
    <position> 12.30087010 6.56385745 25.72127728 </position>
    <velocity> 0.00027301 -0.00004874 0.00031065 </velocity>
    <force> -0.00731168 -0.00464756 -0.01274018 </force>
  </atom>
  <atom name="H1" species="hydrogen">
    <position> -5.93957187 7.22387222 13.83104677 </position>
    <velocity> -0.00059671 0.00040264 0.00009941 </velocity>
    <force> -0.02160469 -0.02156639 -0.02276270 </force>
  </atom>
  <atom name="H2" species="hydrogen">
    <position> -8.11870843 6.51692309 11.89424429 </position>
    <velocity> 0.00016778 -0.00045389 0.00041522 </velocity>
    <force> -0.03817613 0.01930962 -0.00491565 </force>
  </atom>
  <atom name="H3" species="hydrogen">
    <position> 24.69803540 2.73982037 26.53501310 </position>
    <velocity> 0.00060726 0.00071008 -0.00088945 </velocity>
    <force> -0.01296829 0.00701168 -0.00591812 </force>
  </atom>
  <atom name="H4" species="hydrogen">
    <position> 22.00117279 1.41374683 26.45984405 </position>
    <velocity> -0.00058227 0.00028805 -0.00042013 </velocity>
    <force> 0.00782049 0.00952199 -0.01376096 </force>
  </atom>
  <atom name="H5" species="hydrogen">
    <position> -27.62357923 24.49396132 -31.86046735 </position>
    <velocity> -0.00086873 -0.00079417 0.00052411 </velocity>
    <force> -0.00414242 0.00203094 0.00275483 </force>
  </atom>
  <atom name="H6" species="hydrogen">
    <position> -27.81466013 23.83162497 -34.68751181 </position>
    <velocity> -0.00034142 -0.00023482 0.00084975 </velocity>
    <force> -0.00279757 -0.00142533 0.00461456 </force>
  </atom>
  <atom name="H7" species="hydrogen">
    <position> 12.62978284 -10.30975605 1.00167815 </position>
    <velocity> -0.00024224 0.00026829 0.00077282 </velocity>
    <force> 0.00982303 0.02514033 -0.04019809 </force>
  </atom>
  <atom name="H8" species="hydrogen">
    <position> 11.73336713 -8.77387573 -1.72695239 </position>
    <velocity> -0.00000226 0.00027037 -0.00018897 </velocity>
    <force> -0.00630063 -0.00611481 0.01068550 </force>
  </atom>
  <atom name="H9" species="hydrogen">
    <position> 5.50836223 -21.05601126 -6.15055587 </position>
    <velocity> 0.00040094 -0.00057735 0.00030389 </velocity>
    <force> -0.00003048 -0.00959648 0.00652673 </force>
  </atom>
  <atom name="H10" species="hydrogen">
    <position> 6.93391636 -22.26353561 -3.74583178 </position>
    <velocity> 0.00007995 -0.00052254 0.00040814 </velocity>
    <force> -0.00886274 0.00523482 -0.03689955 </force>
  </atom>
  <atom name="H11" species="hydrogen">
    <position> 7.14843001 17.05516878 3.46561564 </position>
    <velocity> -0.00015094 0.00057380 -0.00065345 </velocity>
    <force> 0.01776158 -0.00042509 0.02056973 </force>
  </atom>
  <atom name="H12" species="hydrogen">
    <position> 9.63655088 17.76347285 5.03816781 </position>
    <velocity> -0.00091018 0.00001735 0.00041649 </velocity>
    <force> 0.00716415 0.00345518 -0.00198706 </force>
  </atom>
  <atom name="H13" species="hydrogen">
    <position> -4.21427065 -27.38311150 -18.68633718 </position>
    <velocity> 0.00073957 -0.00027631 0.00108182 </velocity>
    <force> -0.00349177 0.00245944 0.01803908 </force>
  </atom>
  <atom name="H14" species="hydrogen">
    <position> -3.97650598 -30.08384527 -19.45384782 </position>
    <velocity> 0.00040980 0.00007308 -0.00018480 </velocity>
    <force> 0.00890216 -0.02605967 -0.01575242 </force>
  </atom>
  <atom name="H15" species="hydrogen">
    <position> 1.54806068 -14.54973770 12.14102202 </position>
    <velocity> -0.00057904 -0.00041415 0.00091226 </velocity>
    <force> 0.00888221 -0.00386858 0.00664246 </force>
  </atom>
  <atom name="H16" species="hydrogen">
    <position> 4.49438399 -14.43503354 12.77020016 </position>
    <velocity> -0.00066991 0.00015975 0.00040240 </velocity>
    <force> -0.00790304 0.00083782 0.00279806 </force>
  </atom>
  <atom name="H17" species="hydrogen">
    <position> 2.42113221 6.01612619 -7.40716652 </position>
    <velocity> -0.00006441 0.00029852 0.00028726 </velocity>
    <force> 0.00019295 -0.00826976 0.00437526 </force>
  </atom>
  <atom name="H18" species="hydrogen">
    <position> 0.95853365 3.94970699 -5.81424559 </position>
    <velocity> 0.00022872 0.00227194 -0.00110138 </velocity>
    <force> -0.03189492 -0.00660698 0.00608227 </force>
  </atom>
  <atom name="H19" species="hydrogen">
    <position> -0.83588300 6.65236242 8.31823516 </position>
    <velocity> -0.00046187 0.00036372 0.00020572 </velocity>
    <force> -0.00379700 -0.00952905 0.00010639 </force>
  </atom>
  <atom name="H20" species="hydrogen">
    <position> -0.78974489 9.45012959 8.25127577 </position>
    <velocity> 0.00043096 -0.00034503 0.00007195 </velocity>
    <force> 0.01186403 -0.00782080 -0.00015781 </force>
  </atom>
  <atom name="H21" species="hydrogen">
    <position> 11.52741861 -15.12917577 10.57804381 </position>
    <velocity> -0.00011162 0.00022884 -0.00002779 </velocity>
    <force> -0.00461884 -0.00212384 -0.00332610 </force>
  </atom>
  <atom name="H22" species="hydrogen">
    <position> 12.73070275 -13.13939038 12.22066662 </position>
    <velocity> -0.00023832 -0.00025646 0.00076043 </velocity>
    <force> 0.00160882 0.00415124 0.00886217 </force>
  </atom>
  <atom name="H23" species="hydrogen">
    <position> -12.35886350 -1.58102549 11.80872032 </position>
    <velocity> 0.00097227 -0.00063348 0.00055495 </velocity>
    <force> 0.00582715 0.02082851 -0.01777284 </force>
  </atom>
  <atom name="H24" species="hydrogen">
    <position> -12.33416145 -1.96554930 14.55450872 </position>
    <velocity> 0.00063164 -0.00019887 0.00004747 </velocity>
    <force> 0.00164350 0.00071171 0.01681352 </force>
  </atom>
  <atom name="H25" species="hydrogen">
    <position> 0.52030150 -9.37196343 -21.32165826 </position>
    <velocity> 0.00024169 0.00006463 0.00014587 </velocity>
    <force> -0.00777587 0.00047880 -0.00526765 </force>
  </atom>
  <atom name="H26" species="hydrogen">
    <position> 3.08016766 -8.29281190 -22.31794742 </position>
    <velocity> -0.00054485 0.00050848 -0.00043858 </velocity>
    <force> 0.00869595 0.00806234 -0.00173824 </force>
  </atom>
  <atom name="H27" species="hydrogen">
    <position> -7.02335287 -9.57024110 -2.47104803 </position>
    <velocity> 0.00050119 0.00030416 0.00021377 </velocity>
    <force> -0.05083837 -0.01084866 -0.00050439 </force>
  </atom>
  <atom name="H28" species="hydrogen">
    <position> -4.56142691 -9.35171680 -4.20063827 </position>
    <velocity> 0.00050887 -0.00042991 0.00005214 </velocity>
    <force> -0.00512441 -0.00518155 0.00269122 </force>
  </atom>
  <atom name="H29" species="hydrogen">
    <position> 12.63706412 -13.69040730 3.57807465 </position>
    <velocity> 0.00055440 -0.00077967 -0.00075633 </velocity>
    <force> 0.00248807 0.00514265 0.00247467 </force>
  </atom>
  <atom name="H30" species="hydrogen">
    <position> 12.28755769 -11.50563088 5.49047444 </position>
    <velocity> 0.00086618 -0.00001082 -0.00024674 </velocity>
    <force> -0.04076789 0.01584033 0.05157770 </force>
  </atom>
  <atom name="H31" species="hydrogen">
    <position> -5.68957364 10.83246085 -7.26233272 </position>
    <velocity> 0.00007441 -0.00002711 -0.00131063 </velocity>
    <force> 0.00552298 0.00084014 0.00568451 </force>
  </atom>
  <atom name="H32" species="hydrogen">
    <position> -8.64981281 10.42312726 -7.36058485 </position>
    <velocity> -0.00074048 0.00079939 -0.00042023 </velocity>
    <force> 0.00466556 -0.00595159 0.00637150 </force>
  </atom>
  <atom name="H33" species="hydrogen">
    <position> -15.03964841 -13.83872986 -28.93886971 </position>
    <velocity> -0.00089418 0.00067744 0.00079496 </velocity>
    <force> 0.00933356 -0.00284022 0.02092394 </force>
  </atom>
  <atom name="H34" species="hydrogen">
    <position> -13.02726567 -15.93194286 -28.83343433 </position>
    <velocity> 0.00029720 0.00030335 -0.00079590 </velocity>
    <force> 0.00033801 -0.00276671 0.01237328 </force>
  </atom>
  <atom name="H35" species="hydrogen">
    <position> -20.44141835 -0.95987002 14.68905443 </position>
    <velocity> -0.00011733 -0.00024468 0.00012464 </velocity>
    <force> -0.00502465 -0.00353842 -0.00795484 </force>
  </atom>
  <atom name="H36" species="hydrogen">
    <position> -18.16907319 -2.60055818 14.50539637 </position>
    <velocity> 0.00002320 0.00023013 0.00025808 </velocity>
    <force> 0.01784280 -0.00316516 0.00173154 </force>
  </atom>
  <atom name="H37" species="hydrogen">
    <position> 5.61883139 -15.53443227 0.51398195 </position>
    <velocity> 0.00000987 0.00026997 0.00141768 </velocity>
    <force> 0.01236951 -0.00699618 -0.01509026 </force>
  </atom>
  <atom name="H38" species="hydrogen">
    <position> 8.13728064 -15.40752907 -1.34783279 </position>
    <velocity> -0.00044190 -0.00045433 -0.00010771 </velocity>
    <force> -0.01475009 -0.00716133 0.01222224 </force>
  </atom>
  <atom name="H39" species="hydrogen">
    <position> 5.53056816 19.56222981 -23.08565614 </position>
    <velocity> -0.00017305 -0.00022252 0.00012782 </velocity>
    <force> -0.00368986 -0.00612222 0.00876731 </force>
  </atom>
  <atom name="H40" species="hydrogen">
    <position> 6.87975591 17.32142492 -24.47332901 </position>
    <velocity> -0.00027990 -0.00039373 0.00006338 </velocity>
    <force> 0.01331464 -0.01376519 -0.00668949 </force>
  </atom>
  <atom name="H41" species="hydrogen">
    <position> 3.81413024 1.89901576 11.41564373 </position>
    <velocity> 0.00044628 0.00010254 -0.00001134 </velocity>
    <force> -0.01050486 -0.00280867 0.00128221 </force>
  </atom>
  <atom name="H42" species="hydrogen">
    <position> 2.98290323 2.85356694 14.18142781 </position>
    <velocity> -0.00082122 -0.00024447 -0.00017531 </velocity>
    <force> -0.00814675 0.00972027 0.01103769 </force>
  </atom>
  <atom name="H43" species="hydrogen">
    <position> -8.60422094 -5.48536057 3.46489623 </position>
    <velocity> 0.00023303 -0.00075287 0.00076326 </velocity>
    <force> 0.01119680 0.00523140 0.01225779 </force>
  </atom>
  <atom name="H44" species="hydrogen">
    <position> -9.83070028 -6.39074236 1.10321216 </position>
    <velocity> 0.00094032 0.00153478 0.00023050 </velocity>
    <force> -0.01060053 -0.00874292 -0.01448544 </force>
  </atom>
  <atom name="H45" species="hydrogen">
    <position> -12.81661215 -9.31134002 8.46866705 </position>
    <velocity> 0.00063067 0.00006194 -0.00019267 </velocity>
    <force> -0.00462373 -0.01443560 0.00251393 </force>
  </atom>
  <atom name="H46" species="hydrogen">
    <position> -14.67925637 -9.57917132 6.44484968 </position>
    <velocity> 0.00048656 -0.00015403 0.00031668 </velocity>
    <force> -0.00982311 0.00430546 -0.00655715 </force>
  </atom>
  <atom name="H47" species="hydrogen">
    <position> 16.74706667 -13.13719215 4.58462045 </position>
    <velocity> 0.00006685 -0.00074601 0.00034739 </velocity>
    <force> -0.00305620 0.01496931 -0.01001710 </force>
  </atom>
  <atom name="H48" species="hydrogen">
    <position> 18.66220651 -14.71637384 5.70124143 </position>
    <velocity> 0.00100141 -0.00035908 -0.00025097 </velocity>
    <force> 0.01839898 -0.02605652 0.02403970 </force>
  </atom>
  <atom name="H49" species="hydrogen">
    <position> 19.89760463 13.02034000 3.13920434 </position>
    <velocity> -0.00024427 0.00066008 -0.00058919 </velocity>
    <force> -0.00332020 -0.01455315 0.01151524 </force>
  </atom>
  <atom name="H50" species="hydrogen">
    <position> 19.37123058 14.25085095 0.54060607 </position>
    <velocity> 0.00039504 -0.00023872 -0.00011879 </velocity>
    <force> 0.00650973 -0.00021976 -0.01013891 </force>
  </atom>
  <atom name="H51" species="hydrogen">
    <position> 6.82894674 14.31784621 -31.55251032 </position>
    <velocity> 0.00060360 0.00040070 0.00016260 </velocity>
    <force> 0.00088105 -0.01483660 0.00673052 </force>
  </atom>
  <atom name="H52" species="hydrogen">
    <position> 4.84293824 12.90230580 -29.90534046 </position>
    <velocity> -0.00067724 0.00061761 -0.00074250 </velocity>
    <force> -0.00705585 -0.00369358 0.00162333 </force>
  </atom>
  <atom name="H53" species="hydrogen">
    <position> 14.66579190 -22.30370627 -10.21709998 </position>
    <velocity> -0.00081232 0.00026068 0.00035552 </velocity>
    <force> -0.02036938 0.01182362 0.00143435 </force>
  </atom>
  <atom name="H54" species="hydrogen">
    <position> 12.63863084 -20.68256872 -8.67262551 </position>
    <velocity> 0.00102498 -0.00026180 0.00044881 </velocity>
    <force> -0.00415030 -0.00674752 -0.00976072 </force>
  </atom>
  <atom name="H55" species="hydrogen">
    <position> 11.24405052 2.78824453 -15.97765385 </position>
    <velocity> -0.00062076 0.00079344 -0.00108463 </velocity>
    <force> 0.00007910 -0.01032243 -0.02078259 </force>
  </atom>
  <atom name="H56" species="hydrogen">
    <position> 12.02783363 3.22050377 -13.25736542 </position>
    <velocity> -0.00016016 -0.00072539 0.00014576 </velocity>
    <force> -0.02341847 0.00585559 0.00354670 </force>
  </atom>
  <atom name="H57" species="hydrogen">
    <position> -4.05498326 7.05196497 -2.15832626 </position>
    <velocity> -0.00045919 -0.00028129 -0.00020394 </velocity>
    <force> 0.02356144 0.02621046 0.04671521 </force>
  </atom>
  <atom name="H58" species="hydrogen">
    <position> -6.16508365 7.59896686 -4.48229381 </position>
    <velocity> -0.00019964 -0.00022984 -0.00049210 </velocity>
    <force> 0.02768561 0.00275470 0.00549078 </force>
  </atom>
  <atom name="H59" species="hydrogen">
    <position> -10.36223281 -1.62076948 23.46226066 </position>
    <velocity> 0.00068197 -0.00007994 -0.00042010 </velocity>
    <force> 0.00797742 -0.02655040 0.01919584 </force>
  </atom>
  <atom name="H60" species="hydrogen">
    <position> -9.36371937 0.73076602 22.00294605 </position>
    <velocity> -0.00020506 -0.00009506 -0.00050204 </velocity>
    <force> -0.02698475 -0.01311746 -0.00472262 </force>
  </atom>
  <atom name="H61" species="hydrogen">
    <position> 5.54003913 0.48378660 0.69507696 </position>
    <velocity> 0.00148469 0.00054934 -0.00000292 </velocity>
    <force> -0.00102270 -0.00638185 -0.00340110 </force>
  </atom>
  <atom name="H62" species="hydrogen">
    <position> 4.11655681 -1.13931458 2.81557938 </position>
    <velocity> -0.00028114 0.00039495 -0.00033088 </velocity>
    <force> 0.00663570 -0.00505408 -0.01363934 </force>
  </atom>
  <atom name="H63" species="hydrogen">
    <position> 23.68120846 -0.30635442 -0.32598664 </position>
    <velocity> -0.00047297 0.00053277 -0.00072955 </velocity>
    <force> -0.01577879 0.00603932 -0.02290680 </force>
  </atom>
  <atom name="H64" species="hydrogen">
    <position> 23.57527101 -2.06546070 -2.60844375 </position>
    <velocity> -0.00029938 0.00023803 -0.00075459 </velocity>
    <force> 0.02441262 -0.04015216 -0.02483112 </force>
  </atom>
  <atom name="H65" species="hydrogen">
    <position> -0.40709968 21.64967183 8.81418611 </position>
    <velocity> 0.00044846 -0.00017951 0.00001955 </velocity>
    <force> -0.00995394 0.00304774 -0.00382463 </force>
  </atom>
  <atom name="H66" species="hydrogen">
    <position> 0.20596198 23.51565945 10.81700204 </position>
    <velocity> 0.00128645 0.00012308 0.00090111 </velocity>
    <force> 0.02624972 0.02059479 0.03011705 </force>
  </atom>
  <atom name="H67" species="hydrogen">
    <position> -12.44370537 -1.83135328 19.34779894 </position>
    <velocity> -0.00002744 -0.00012636 0.00079510 </velocity>
    <force> 0.00946440 0.00054844 0.01207568 </force>
  </atom>
  <atom name="H68" species="hydrogen">
    <position> -14.85935563 -1.67313157 17.76195693 </position>
    <velocity> -0.00005702 0.00039523 -0.00103874 </velocity>
    <force> -0.00386797 -0.00016546 -0.00504822 </force>
  </atom>
  <atom name="H69" species="hydrogen">
    <position> 4.63973080 -1.28851907 -16.20322476 </position>
    <velocity> -0.00020838 -0.00106312 0.00015834 </velocity>
    <force> -0.02090707 -0.00279766 -0.03755683 </force>
  </atom>
  <atom name="H70" species="hydrogen">
    <position> 5.31160801 -3.77170123 -17.32225747 </position>
    <velocity> 0.00029142 0.00048244 0.00006759 </velocity>
    <force> -0.00557456 0.00055779 -0.02220673 </force>
  </atom>
  <atom name="H71" species="hydrogen">
    <position> 7.96711124 8.49203737 -40.38991506 </position>
    <velocity> -0.00069620 -0.00048100 0.00030483 </velocity>
    <force> 0.00366804 0.00511266 0.00019335 </force>
  </atom>
  <atom name="H72" species="hydrogen">
    <position> 8.55189811 5.86520234 -39.10821272 </position>
    <velocity> 0.00047318 -0.00057234 -0.00072209 </velocity>
    <force> 0.00576584 0.00152862 -0.00037340 </force>
  </atom>
  <atom name="H73" species="hydrogen">
    <position> -10.46527759 -2.60189480 7.08567128 </position>
    <velocity> -0.00079984 0.00089723 0.00023268 </velocity>
    <force> -0.00539497 0.01182152 -0.01945241 </force>
  </atom>
  <atom name="H74" species="hydrogen">
    <position> -10.90584335 -2.20653869 4.05774570 </position>
    <velocity> -0.00000826 0.00035840 0.00023590 </velocity>
    <force> 0.00391704 0.01421454 0.03649134 </force>
  </atom>
  <atom name="H75" species="hydrogen">
    <position> 2.02120495 10.79729564 18.86484691 </position>
    <velocity> -0.00003796 0.00009207 -0.00074281 </velocity>
    <force> -0.00519095 -0.00461698 0.02858807 </force>
  </atom>
  <atom name="H76" species="hydrogen">
    <position> 2.04472841 10.51179904 16.11066998 </position>
    <velocity> -0.00002803 -0.00010911 0.00101854 </velocity>
    <force> -0.00651887 0.00582857 -0.01933188 </force>
  </atom>
  <atom name="H77" species="hydrogen">
    <position> 8.43661585 10.56700718 -10.08082100 </position>
    <velocity> -0.00050289 0.00024784 0.00031621 </velocity>
    <force> -0.00045490 0.01190254 -0.00980522 </force>
  </atom>
  <atom name="H78" species="hydrogen">
    <position> 7.81285601 11.06108867 -13.02557301 </position>
    <velocity> -0.00162444 -0.00107056 0.00059680 </velocity>
    <force> 0.01146996 0.03218794 -0.02093579 </force>
  </atom>
  <atom name="H79" species="hydrogen">
    <position> -17.58747750 -7.61911913 11.18973307 </position>
    <velocity> 0.00084994 0.00049509 0.00032734 </velocity>
    <force> -0.02308604 -0.00700168 -0.02156948 </force>
  </atom>
  <atom name="H80" species="hydrogen">
    <position> -15.93232161 -5.77267035 12.55310412 </position>
    <velocity> -0.00113303 -0.00074435 -0.00078969 </velocity>
    <force> 0.01344635 0.02541759 0.00391194 </force>
  </atom>
  <atom name="H81" species="hydrogen">
    <position> 15.99502337 4.80377801 -2.72358110 </position>
    <velocity> 0.00019846 0.00013020 -0.00006523 </velocity>
    <force> -0.02204520 -0.01051449 0.00351688 </force>
  </atom>
  <atom name="H82" species="hydrogen">
    <position> 13.70387419 5.08735369 -0.77896407 </position>
    <velocity> 0.00001715 0.00123337 0.00062299 </velocity>
    <force> 0.00106268 -0.00628673 -0.00635096 </force>
  </atom>
  <atom name="H83" species="hydrogen">
    <position> -7.86600762 17.37406001 15.74907709 </position>
    <velocity> 0.00065501 0.00179865 0.00004046 </velocity>
    <force> -0.01644346 0.00500513 0.00343749 </force>
  </atom>
  <atom name="H84" species="hydrogen">
    <position> -10.52147677 18.15794621 16.93350339 </position>
    <velocity> -0.00012018 -0.00072498 -0.00023939 </velocity>
    <force> -0.01301846 0.01570794 0.01020623 </force>
  </atom>
  <atom name="H85" species="hydrogen">
    <position> -4.94194158 -3.07467504 -9.16444990 </position>
    <velocity> -0.00009168 0.00050979 -0.00038154 </velocity>
    <force> -0.00556935 0.03135403 -0.00900130 </force>
  </atom>
  <atom name="H86" species="hydrogen">
    <position> -3.71152076 -4.75369821 -7.16110314 </position>
    <velocity> 0.00032634 0.00010837 0.00063707 </velocity>
    <force> -0.00347803 -0.00415353 -0.00758328 </force>
  </atom>
  <atom name="H87" species="hydrogen">
    <position> -12.17743374 -11.37309942 17.07095755 </position>
    <velocity> 0.00027946 0.00051754 -0.00016150 </velocity>
    <force> -0.03530016 0.00131774 0.05050527 </force>
  </atom>
  <atom name="H88" species="hydrogen">
    <position> -10.30536097 -9.48479204 15.55863618 </position>
    <velocity> 0.00022914 0.00054135 -0.00002472 </velocity>
    <force> -0.02373389 -0.02057380 0.01433210 </force>
  </atom>
  <atom name="H89" species="hydrogen">
    <position> -8.60656733 25.02675270 5.29126550 </position>
    <velocity> -0.00020889 -0.00039270 -0.00030521 </velocity>
    <force> -0.00099993 0.00004418 -0.00793422 </force>
  </atom>
  <atom name="H90" species="hydrogen">
    <position> -6.43651815 26.90050311 6.14452534 </position>
    <velocity> -0.00104137 -0.00130102 0.00038233 </velocity>
    <force> -0.01213015 -0.00199288 -0.03239894 </force>
  </atom>
  <atom name="H91" species="hydrogen">
    <position> 11.94447714 -4.92056903 -12.88149408 </position>
    <velocity> 0.00005396 0.00028302 -0.00020120 </velocity>
    <force> 0.02186434 -0.00944336 -0.03415249 </force>
  </atom>
  <atom name="H92" species="hydrogen">
    <position> 14.51135654 -6.35874975 -14.07319132 </position>
    <velocity> -0.00019146 0.00009591 -0.00045230 </velocity>
    <force> -0.02644612 0.03097217 -0.00653142 </force>
  </atom>
  <atom name="H93" species="hydrogen">
    <position> -3.99721208 -2.27880130 2.05567719 </position>
    <velocity> -0.00064093 -0.00044399 -0.00006129 </velocity>
    <force> -0.00041757 0.01661482 -0.00381487 </force>
  </atom>
  <atom name="H94" species="hydrogen">
    <position> -5.29059677 -0.15399340 3.49789868 </position>
    <velocity> -0.00019867 -0.00127487 0.00008583 </velocity>
    <force> -0.04959160 0.03150841 0.00589134 </force>
  </atom>
  <atom name="H95" species="hydrogen">
    <position> -18.53712492 -17.98421291 -17.98594794 </position>
    <velocity> 0.00002375 0.00082938 0.00049572 </velocity>
    <force> 0.02427961 0.00951164 -0.00663294 </force>
  </atom>
  <atom name="H96" species="hydrogen">
    <position> -21.01348405 -17.43150354 -16.90783002 </position>
    <velocity> 0.00001224 -0.00009809 -0.00017939 </velocity>
    <force> -0.02643487 0.02728880 0.01576833 </force>
  </atom>
  <atom name="H97" species="hydrogen">
    <position> -38.80676739 4.10736568 -23.60253807 </position>
    <velocity> -0.00059174 0.00045278 -0.00036581 </velocity>
    <force> -0.01821086 -0.00062833 -0.00885268 </force>
  </atom>
  <atom name="H98" species="hydrogen">
    <position> -37.36317553 1.52096090 -24.04070271 </position>
    <velocity> 0.00035639 0.00045633 -0.00075654 </velocity>
    <force> 0.00725412 -0.00845833 0.00004667 </force>
  </atom>
  <atom name="H99" species="hydrogen">
    <position> 32.74993224 17.65959100 -4.03269739 </position>
    <velocity> 0.00000639 -0.00022951 0.00112423 </velocity>
    <force> -0.00325669 -0.00875535 0.00122214 </force>
  </atom>
  <atom name="H100" species="hydrogen">
    <position> 31.22142123 14.98679607 -4.26694797 </position>
    <velocity> 0.00070074 -0.00050002 0.00022343 </velocity>
    <force> 0.01161730 0.00309603 -0.00024953 </force>
  </atom>
  <atom name="H101" species="hydrogen">
    <position> 9.81713283 3.30452625 -5.93885801 </position>
    <velocity> -0.00103146 0.00034569 -0.00076613 </velocity>
    <force> -0.05124610 -0.02633410 0.00052510 </force>
  </atom>
  <atom name="H102" species="hydrogen">
    <position> 12.24053766 3.85671624 -4.43228372 </position>
    <velocity> 0.00138745 0.00044994 -0.00117850 </velocity>
    <force> 0.00920930 0.00487463 -0.00522925 </force>
  </atom>
  <atom name="H103" species="hydrogen">
    <position> -3.42380713 3.80752449 18.65376634 </position>
    <velocity> -0.00032417 -0.00070392 0.00036581 </velocity>
    <force> 0.00562169 0.00818364 0.00488670 </force>
  </atom>
  <atom name="H104" species="hydrogen">
    <position> -1.49239453 1.69831997 19.50978454 </position>
    <velocity> 0.00029690 0.00037697 -0.00058620 </velocity>
    <force> 0.00572798 -0.02655098 0.03200499 </force>
  </atom>
  <atom name="H105" species="hydrogen">
    <position> 21.76768326 -10.84801190 -6.93450881 </position>
    <velocity> 0.00021066 0.00071900 -0.00012595 </velocity>
    <force> -0.01547168 0.00092547 0.00490703 </force>
  </atom>
  <atom name="H106" species="hydrogen">
    <position> 19.84358880 -9.21823516 -8.48194396 </position>
    <velocity> 0.00066303 -0.00055173 0.00107502 </velocity>
    <force> 0.00320225 -0.00803820 0.01134532 </force>
  </atom>
  <atom name="H107" species="hydrogen">
    <position> 0.92656574 -8.50808359 10.95491180 </position>
    <velocity> -0.00037278 0.00084636 -0.00044816 </velocity>
    <force> 0.01241563 0.00832727 -0.01056944 </force>
  </atom>
  <atom name="H108" species="hydrogen">
    <position> 0.79084805 -7.47774609 13.83604375 </position>
    <velocity> 0.00079645 -0.00025723 -0.00012542 </velocity>
    <force> 0.00534398 0.00724359 -0.00295229 </force>
  </atom>
  <atom name="H109" species="hydrogen">
    <position> 18.13400998 -5.08562764 -1.21446848 </position>
    <velocity> -0.00012293 -0.00047502 -0.00026426 </velocity>
    <force> -0.00253614 -0.00597704 -0.00130088 </force>
  </atom>
  <atom name="H110" species="hydrogen">
    <position> 19.16432020 -2.41339400 -1.60408072 </position>
    <velocity> 0.00007352 -0.00016235 -0.00041624 </velocity>
    <force> 0.01878625 0.01382443 -0.01329384 </force>
  </atom>
  <atom name="H111" species="hydrogen">
    <position> 23.97592033 -6.73654119 18.51313829 </position>
    <velocity> -0.00049309 -0.00067499 0.00052220 </velocity>
    <force> 0.00056442 0.00497470 -0.00405527 </force>
  </atom>
  <atom name="H112" species="hydrogen">
    <position> 25.03742617 -4.22462324 17.15820934 </position>
    <velocity> 0.00010143 0.00039588 0.00030982 </velocity>
    <force> -0.00961190 -0.01416402 -0.00683236 </force>
  </atom>
  <atom name="H113" species="hydrogen">
    <position> 2.31408643 34.13112781 -23.59347813 </position>
    <velocity> 0.00035423 0.00007884 -0.00017359 </velocity>
    <force> 0.01019731 -0.00948722 -0.00496494 </force>
  </atom>
  <atom name="H114" species="hydrogen">
    <position> 1.14317535 31.59789781 -24.09744691 </position>
    <velocity> -0.00022176 -0.00043573 -0.00016252 </velocity>
    <force> -0.01958737 -0.01357272 0.00358587 </force>
  </atom>
  <atom name="H115" species="hydrogen">
    <position> 6.96115945 1.86828843 -13.85953482 </position>
    <velocity> 0.00008342 -0.00039727 -0.00032041 </velocity>
    <force> -0.03491877 -0.01215210 -0.02450195 </force>
  </atom>
  <atom name="H116" species="hydrogen">
    <position> 4.72825451 2.88127114 -15.70666378 </position>
    <velocity> -0.00005129 -0.00061202 0.00052623 </velocity>
    <force> -0.01318938 0.00558668 -0.01003359 </force>
  </atom>
  <atom name="H117" species="hydrogen">
    <position> -3.31259777 -14.74198366 -21.91743005 </position>
    <velocity> 0.00082737 0.00029106 0.00087692 </velocity>
    <force> 0.01971316 -0.01807704 -0.00569108 </force>
  </atom>
  <atom name="H118" species="hydrogen">
    <position> -1.98603567 -17.47643548 -22.03439065 </position>
    <velocity> -0.00044644 -0.00159785 0.00061627 </velocity>
    <force> 0.00393222 -0.00874184 0.00487057 </force>
  </atom>
  <atom name="H119" species="hydrogen">
    <position> -28.99320480 -14.00303026 10.76438075 </position>
    <velocity> 0.00049831 -0.00017623 -0.00120134 </velocity>
    <force> -0.01304649 -0.02081689 0.00409788 </force>
  </atom>
  <atom name="H120" species="hydrogen">
    <position> -27.95617781 -11.49474812 10.16006437 </position>
    <velocity> 0.00098510 0.00035222 0.00089342 </velocity>
    <force> 0.00821299 0.00627813 -0.00000529 </force>
  </atom>
  <atom name="H121" species="hydrogen">
    <position> -4.63635288 4.85388574 -13.76856616 </position>
    <velocity> -0.00070927 0.00048095 -0.00051998 </velocity>
    <force> 0.00043998 0.00324186 -0.00627067 </force>
  </atom>
  <atom name="H122" species="hydrogen">
    <position> -2.99359369 2.80814530 -15.14819561 </position>
    <velocity> -0.00026768 0.00015625 0.00004356 </velocity>
    <force> 0.00171932 0.00171777 -0.00307410 </force>
  </atom>
  <atom name="H123" species="hydrogen">
    <position> -5.18628721 -6.96942520 31.90892715 </position>
    <velocity> -0.00033813 0.00072492 0.00041197 </velocity>
    <force> 0.02483236 0.01456711 -0.04121470 </force>
  </atom>
  <atom name="H124" species="hydrogen">
    <position> -5.04525350 -6.35610447 34.80687456 </position>
    <velocity> 0.00020766 0.00105584 0.00025477 </velocity>
    <force> 0.00586307 0.00536457 0.00625842 </force>
  </atom>
  <atom name="H125" species="hydrogen">
    <position> -20.95748582 -9.25191367 30.22239317 </position>
    <velocity> 0.00019309 -0.00105793 0.00026806 </velocity>
    <force> 0.00152506 -0.00684421 -0.00284503 </force>
  </atom>
  <atom name="H126" species="hydrogen">
    <position> -20.85858967 -6.48985208 30.85932866 </position>
    <velocity> 0.00029048 0.00033969 0.00051936 </velocity>
    <force> -0.00155917 0.00495608 0.00303059 </force>
  </atom>
  <atom name="H127" species="hydrogen">
    <position> 10.54443444 6.00629282 25.13316570 </position>
    <velocity> 0.00133052 -0.00076485 -0.00009023 </velocity>
    <force> 0.02602710 0.01109855 0.02426666 </force>
  </atom>
  <atom name="H128" species="hydrogen">
    <position> 13.30949961 5.36158657 26.78440784 </position>
    <velocity> 0.00045095 -0.00043793 -0.00081067 </velocity>
    <force> -0.01329157 -0.00243524 -0.00713678 </force>
  </atom>
</atomset>
<unit_cell_a_norm> 23.460000 </unit_cell_a_norm>
<unit_cell_b_norm> 23.460000 </unit_cell_b_norm>
<unit_cell_c_norm> 23.460000 </unit_cell_c_norm>
<unit_cell_alpha>  90.000 </unit_cell_alpha>
<unit_cell_beta>   90.000 </unit_cell_beta>
<unit_cell_gamma>  90.000 </unit_cell_gamma>
<unit_cell_volume> 12911.718 </unit_cell_volume>
  <econst> -1100.15049922 </econst>
  <ekin_ion> 0.35819906 </ekin_ion>
  <temp_ion> 392.76354550 </temp_ion>
  total_electronic_charge: 512.00000000
  <eigenvalue_sum>  -162.47068181 </eigenvalue_sum>
  <etotal_int>   -1100.50559117 </etotal_int>
  total_electronic_charge: 512.00000000
  <eigenvalue_sum>  -162.47623411 </eigenvalue_sum>
  Anderson extrapolation: theta=1.23028769 (1.23028769)
  <etotal_int>   -1100.50564827 </etotal_int>
  total_electronic_charge: 512.00000000
  <eigenvalue_sum>  -162.48310035 </eigenvalue_sum>
  Anderson extrapolation: theta=0.06951052 (0.06951052)
  <etotal_int>   -1100.50568163 </etotal_int>
  total_electronic_charge: 512.00000000
  <eigenvalue_sum>  -162.48366260 </eigenvalue_sum>
  Anderson extrapolation: theta=1.83713982 (1.83713982)
  <etotal_int>   -1100.50568341 </etotal_int>
  total_electronic_charge: 512.00000000
  <eigenvalue_sum>  -162.48477500 </eigenvalue_sum>
  Anderson extrapolation: theta=0.25133791 (0.25133791)
  <etotal_int>   -1100.50568517 </etotal_int>
  <timing name="iteration" min="    5.705" max="    5.715"/>
</iteration>
<iteration count="8">
  total_electronic_charge: 512.00000000
  <ekin>       808.58051092 </ekin>
  <econf>        0.00000000 </econf>
  <eps>      -1309.82231035 </eps>
  <enl>        124.84167519 </enl>
  <ecoul>     -453.07529816 </ecoul>
  <exc>       -271.03026315 </exc>
  <esr>         93.68023147 </esr>
  <eself>      646.81841729 </eself>
  <ets>          0.00000000 </ets>
  <eexf>         0.00000000 </eexf>
  <etotal>   -1100.50568555 </etotal>
  <epv>          0.00000000 </epv>
  <eefield>      0.00000000 </eefield>
  <enthalpy> -1100.50568555 </enthalpy>
<atomset>
<unit_cell 
    a=" 23.46000000   0.00000000   0.00000000"
    b="  0.00000000  23.46000000   0.00000000"
    c="  0.00000000   0.00000000  23.46000000" />
  <atom name="O1" species="oxygen">
    <position> -6.49207496 6.00331490 12.39992546 </position>
    <velocity> -0.00005277 -0.00020733 0.00035004 </velocity>
    <force> 0.06378817 -0.00350689 0.02958537 </force>
  </atom>
  <atom name="O2" species="oxygen">
    <position> 23.13588408 2.61518690 25.48208599 </position>
    <velocity> -0.00000004 0.00004085 -0.00018247 </velocity>
    <force> 0.00393247 -0.00810750 0.02021090 </force>
  </atom>
  <atom name="O3" species="oxygen">
    <position> -28.80590934 23.74198710 -33.10454471 </position>
    <velocity> -0.00012932 0.00012951 -0.00015578 </velocity>
    <force> 0.01124945 -0.00325047 -0.00643345 </force>
  </atom>
  <atom name="O4" species="oxygen">
    <position> 13.16911623 -9.22781192 -0.59575888 </position>
    <velocity> 0.00007923 -0.00027223 0.00015507 </velocity>
    <force> -0.00359603 -0.01922866 0.03240321 </force>
  </atom>
  <atom name="O5" species="oxygen">
    <position> 6.68519656 -22.47054646 -5.71264962 </position>
    <velocity> 0.00027742 0.00003692 -0.00042461 </velocity>
    <force> 0.00746004 0.01402961 0.04112339 </force>
  </atom>
  <atom name="O6" species="oxygen">
    <position> 8.02437821 16.91758179 5.25629214 </position>
    <velocity> 0.00005490 -0.00022822 0.00031551 </velocity>
    <force> -0.03160542 -0.00139055 -0.02919784 </force>
  </atom>
  <atom name="O7" species="oxygen">
    <position> -4.61648209 -29.10286405 -18.06009398 </position>
    <velocity> -0.00003200 0.00050677 -0.00027670 </velocity>
    <force> -0.00807165 0.01497128 0.00682439 </force>
  </atom>
  <atom name="O8" species="oxygen">
    <position> 2.78051001 -14.72223887 13.55060886 </position>
    <velocity> -0.00005819 -0.00044293 0.00019455 </velocity>
    <force> 0.00094784 -0.00211313 -0.00751067 </force>
  </atom>
  <atom name="O9" species="oxygen">
    <position> 2.59333707 4.40002150 -6.46700023 </position>
    <velocity> -0.00025349 0.00001589 -0.00041267 </velocity>
    <force> 0.04449803 0.02435275 -0.01461355 </force>
  </atom>
  <atom name="O10" species="oxygen">
    <position> 0.41727178 8.00469939 8.13170861 </position>
    <velocity> 0.00011826 0.00031229 0.00022557 </velocity>
    <force> -0.01442289 0.01665623 0.00782227 </force>
  </atom>
  <atom name="O11" species="oxygen">
    <position> 13.17378749 -14.43388146 10.99505037 </position>
    <velocity> -0.00006548 0.00009291 -0.00001804 </velocity>
    <force> -0.00010373 0.00036916 -0.00498837 </force>
  </atom>
  <atom name="O12" species="oxygen">
    <position> -13.18011380 -2.56671310 13.06064224 </position>
    <velocity> 0.00022968 -0.00019453 -0.00014514 </velocity>
    <force> -0.02128429 -0.02906476 -0.00571308 </force>
  </atom>
  <atom name="O13" species="oxygen">
    <position> 2.31702717 -9.77133258 -21.53281434 </position>
    <velocity> -0.00011856 0.00037307 0.00013695 </velocity>
    <force> 0.00221305 -0.00857814 0.00422529 </force>
  </atom>
  <atom name="O14" species="oxygen">
    <position> -5.31094255 -9.16485116 -2.48048625 </position>
    <velocity> -0.00009524 0.00007272 -0.00032156 </velocity>
    <force> 0.05516777 0.02262438 0.00898278 </force>
  </atom>
  <atom name="O15" species="oxygen">
    <position> 13.28542941 -12.01012778 4.15525156 </position>
    <velocity> -0.00043233 -0.00034113 0.00010842 </velocity>
    <force> 0.04492316 -0.03221358 -0.06883214 </force>
  </atom>
  <atom name="O16" species="oxygen">
    <position> -6.99229810 9.51627742 -7.02438932 </position>
    <velocity> -0.00006628 0.00022428 -0.00008522 </velocity>
    <force> -0.00794735 -0.00666968 -0.00573140 </force>
  </atom>
  <atom name="O17" species="oxygen">
    <position> -13.79245300 -14.60874540 -27.72164916 </position>
    <velocity> -0.00003106 0.00012452 0.00015898 </velocity>
    <force> -0.01377610 0.00491653 -0.03175050 </force>
  </atom>
  <atom name="O18" species="oxygen">
    <position> -19.94010613 -2.76652949 14.86160057 </position>
    <velocity> -0.00024412 -0.00013898 0.00012619 </velocity>
    <force> -0.01091157 0.00381828 0.00336565 </force>
  </atom>
  <atom name="O19" species="oxygen">
    <position> 7.35787073 -16.24728918 0.20064129 </position>
    <velocity> -0.00032065 -0.00033213 0.00004287 </velocity>
    <force> 0.01243894 0.00945540 -0.00278425 </force>
  </atom>
  <atom name="O20" species="oxygen">
    <position> 5.90179462 17.67924141 -22.94979805 </position>
    <velocity> 0.00004983 -0.00010331 0.00001094 </velocity>
    <force> -0.01494658 0.01334497 0.01289673 </force>
  </atom>
  <atom name="O21" species="oxygen">
    <position> 2.44867181 1.84056406 12.73638329 </position>
    <velocity> -0.00020543 0.00027997 -0.00013327 </velocity>
    <force> 0.00224371 -0.01080928 -0.00815780 </force>
  </atom>
  <atom name="O22" species="oxygen">
    <position> -9.88171433 -4.94468600 2.27281934 </position>
    <velocity> 0.00030228 0.00010148 -0.00033712 </velocity>
    <force> -0.00154614 0.00737775 0.01097537 </force>
  </atom>
  <atom name="O23" species="oxygen">
    <position> -13.80251678 -10.70405526 7.65263826 </position>
    <velocity> 0.00016794 0.00004068 -0.00036272 </velocity>
    <force> 0.01347649 0.01437210 0.01000584 </force>
  </atom>
  <atom name="O24" species="oxygen">
    <position> 18.61243730 -13.37775309 4.52052635 </position>
    <velocity> 0.00031029 -0.00012252 -0.00008304 </velocity>
    <force> -0.02084179 0.01296755 -0.01664372 </force>
  </atom>
  <atom name="O25" species="oxygen">
    <position> 20.48764215 14.35378141 2.04600036 </position>
    <velocity> 0.00002761 -0.00049037 -0.00044924 </velocity>
    <force> 0.00513049 0.01509641 -0.00493560 </force>
  </atom>
  <atom name="O26" species="oxygen">
    <position> 6.68674243 13.03612281 -30.11478169 </position>
    <velocity> -0.00000190 0.00024067 0.00013646 </velocity>
    <force> -0.00105703 0.01759769 -0.01251569 </force>
  </atom>
  <atom name="O27" species="oxygen">
    <position> 12.82807113 -21.74390265 -10.27196585 </position>
    <velocity> 0.00020078 -0.00028243 0.00012699 </velocity>
    <force> 0.03197706 0.00192706 0.00194399 </force>
  </atom>
  <atom name="O28" species="oxygen">
    <position> 10.66708717 3.73006220 -14.54221826 </position>
    <velocity> 0.00010732 0.00032326 -0.00019815 </velocity>
    <force> 0.01883153 -0.00647022 0.02551252 </force>
  </atom>
  <atom name="O29" species="oxygen">
    <position> -4.81827945 6.47489184 -3.64078945 </position>
    <velocity> -0.00006018 -0.00010432 0.00007537 </velocity>
    <force> -0.05875658 -0.02619753 -0.06047775 </force>
  </atom>
  <atom name="O30" species="oxygen">
    <position> -10.77793841 -0.59509146 22.04850999 </position>
    <velocity> 0.00037469 0.00014472 -0.00017124 </velocity>
    <force> 0.00998864 0.03469522 -0.01459526 </force>
  </atom>
  <atom name="O31" species="oxygen">
    <position> 4.42730452 -1.01422539 0.93209747 </position>
    <velocity> 0.00014849 0.00003187 0.00029535 </velocity>
    <force> -0.00255146 0.01032949 0.00795318 </force>
  </atom>
  <atom name="O32" species="oxygen">
    <position> 22.69039071 -0.70389269 -1.93860494 </position>
    <velocity> -0.00010741 0.00012595 0.00049789 </velocity>
    <force> -0.00802381 0.02859042 0.04128866 </force>
  </atom>
  <atom name="O33" species="oxygen">
    <position> -1.15309451 23.06975555 9.74279428 </position>
    <velocity> -0.00008404 0.00008192 -0.00002708 </velocity>
    <force> -0.01728203 -0.01596725 -0.02144278 </force>
  </atom>
  <atom name="O34" species="oxygen">
    <position> -13.43725910 -2.81978721 18.13839369 </position>
    <velocity> -0.00026755 0.00002261 0.00014903 </velocity>
    <force> 0.00096445 -0.00314999 0.00051140 </force>
  </atom>
  <atom name="O35" species="oxygen">
    <position> 4.05109795 -2.42678295 -17.76749778 </position>
    <velocity> 0.00004665 -0.00009095 0.00020395 </velocity>
    <force> 0.02539056 0.00037237 0.06371800 </force>
  </atom>
  <atom name="O36" species="oxygen">
    <position> 7.51727488 6.72185651 -40.39995161 </position>
    <velocity> -0.00034719 -0.00004356 -0.00008263 </velocity>
    <force> 0.00287093 0.00155246 -0.00270590 </force>
  </atom>
  <atom name="O37" species="oxygen">
    <position> -10.80754308 -1.21886139 5.74298881 </position>
    <velocity> -0.00026852 -0.00000551 -0.00001219 </velocity>
    <force> 0.00189259 -0.01801691 -0.01212506 </force>
  </atom>
  <atom name="O38" species="oxygen">
    <position> 1.46900727 11.75755228 17.40887771 </position>
    <velocity> -0.00013014 0.00011685 0.00010748 </velocity>
    <force> 0.00874735 0.00135486 -0.00801302 </force>
  </atom>
  <atom name="O39" species="oxygen">
    <position> 7.70172009 9.92887460 -11.64892824 </position>
    <velocity> 0.00014498 -0.00001424 0.00010946 </velocity>
    <force> -0.01285596 -0.04846865 0.03697674 </force>
  </atom>
  <atom name="O40" species="oxygen">
    <position> -16.35341128 -7.51588880 12.48912215 </position>
    <velocity> 0.00040473 0.00022886 0.00016985 </velocity>
    <force> 0.01163832 -0.02369268 0.01949895 </force>
  </atom>
  <atom name="O41" species="oxygen">
    <position> 14.21399065 4.04066678 -2.27939500 </position>
    <velocity> -0.00007561 0.00012258 0.00017109 </velocity>
    <force> 0.03476077 0.02290645 0.01881073 </force>
  </atom>
  <atom name="O42" species="oxygen">
    <position> -9.69549911 16.84962754 16.01917563 </position>
    <velocity> -0.00011667 -0.00011331 0.00018897 </velocity>
    <force> 0.03665172 -0.02022643 -0.02034505 </force>
  </atom>
  <atom name="O43" species="oxygen">
    <position> -5.15281240 -4.68315368 -8.36245985 </position>
    <velocity> 0.00003608 0.00011931 -0.00011318 </velocity>
    <force> 0.01709938 -0.03033516 0.01856068 </force>
  </atom>
  <atom name="O44" species="oxygen">
    <position> -11.07308466 -11.32773652 15.73289969 </position>
    <velocity> -0.00008327 0.00037271 0.00020350 </velocity>
    <force> 0.05344063 0.02426298 -0.07054513 </force>
  </atom>
  <atom name="O45" species="oxygen">
    <position> -7.54682388 26.41826722 4.56779435 </position>
    <velocity> 0.00040963 -0.00026769 -0.00040158 </velocity>
    <force> 0.00476119 -0.00148511 0.03765886 </force>
  </atom>
  <atom name="O46" species="oxygen">
    <position> 12.85124924 -5.29387835 -14.59244182 </position>
    <velocity> -0.00038118 -0.00015369 0.00028354 </velocity>
    <force> 0.00588255 -0.01964045 0.04455694 </force>
  </atom>
  <atom name="O47" species="oxygen">
    <position> -3.71141774 -0.91664783 3.36623776 </position>
    <velocity> 0.00047797 -0.00033427 -0.00027986 </velocity>
    <force> 0.04453914 -0.03948369 -0.00259889 </force>
  </atom>
  <atom name="O48" species="oxygen">
    <position> -20.15231718 -18.78440528 -17.69706551 </position>
    <velocity> -0.00014146 0.00017818 0.00005644 </velocity>
    <force> 0.00078087 -0.04136091 -0.02107803 </force>
  </atom>
  <atom name="O49" species="oxygen">
    <position> -39.03081802 2.31050216 -24.17857109 </position>
    <velocity> -0.00016542 0.00030636 -0.00010491 </velocity>
    <force> 0.00853595 0.00137959 0.00322089 </force>
  </atom>
  <atom name="O50" species="oxygen">
    <position> 32.37736533 16.00970147 -3.15232348 </position>
    <velocity> 0.00008817 -0.00007097 -0.00014281 </velocity>
    <force> -0.00152288 0.00574436 -0.00436417 </force>
  </atom>
  <atom name="O51" species="oxygen">
    <position> 11.40314652 4.03216966 -6.13278400 </position>
    <velocity> -0.00018850 -0.00007366 0.00003440 </velocity>
    <force> 0.03407066 0.02664513 -0.00709650 </force>
  </atom>
  <atom name="O52" species="oxygen">
    <position> -2.00066152 2.71898612 18.13088584 </position>
    <velocity> 0.00008378 -0.00027047 0.00001676 </velocity>
    <force> -0.01435016 0.01814603 -0.04680036 </force>
  </atom>
  <atom name="O53" species="oxygen">
    <position> 19.91243158 -10.32085352 -6.96103571 </position>
    <velocity> 0.00009081 0.00034549 -0.00030935 </velocity>
    <force> 0.02470016 0.00578009 -0.01534112 </force>
  </atom>
  <atom name="O54" species="oxygen">
    <position> 0.05394232 -8.56122208 12.55168976 </position>
    <velocity> -0.00030505 -0.00006056 -0.00015008 </velocity>
    <force> -0.02449038 -0.01088946 0.02048166 </force>
  </atom>
  <atom name="O55" species="oxygen">
    <position> 18.01863542 -3.35830455 -0.57122438 </position>
    <velocity> -0.00002452 -0.00013082 0.00001882 </velocity>
    <force> -0.00925277 -0.01326862 0.00605069 </force>
  </atom>
  <atom name="O56" species="oxygen">
    <position> 23.51923030 -5.37692140 17.34560918 </position>
    <velocity> 0.00028410 -0.00029842 0.00002578 </velocity>
    <force> 0.00751445 0.00505011 0.01054870 </force>
  </atom>
  <atom name="O57" species="oxygen">
    <position> 2.68471876 32.48167389 -24.49202302 </position>
    <velocity> 0.00011979 -0.00009678 0.00008363 </velocity>
    <force> 0.00988905 0.03330099 0.00404616 </force>
  </atom>
  <atom name="O58" species="oxygen">
    <position> 5.18261862 1.41847737 -14.60502659 </position>
    <velocity> -0.00001804 0.00009285 0.00017370 </velocity>
    <force> 0.06259020 -0.00280858 0.03132835 </force>
  </atom>
  <atom name="O59" species="oxygen">
    <position> -2.10383239 -15.85932359 -22.92291658 </position>
    <velocity> 0.00014519 -0.00004310 -0.00004336 </velocity>
    <force> -0.02224844 0.01392876 0.00972101 </force>
  </atom>
  <atom name="O60" species="oxygen">
    <position> -27.38358423 -13.22627983 10.47847958 </position>
    <velocity> -0.00024241 -0.00017683 0.00004008 </velocity>
    <force> 0.01120386 0.02323444 -0.00711701 </force>
  </atom>
  <atom name="O61" species="oxygen">
    <position> -3.87771494 4.42943491 -15.47644485 </position>
    <velocity> -0.00016704 0.00012730 -0.00026869 </velocity>
    <force> -0.00246095 -0.00512163 0.01900396 </force>
  </atom>
  <atom name="O62" species="oxygen">
    <position> -6.01543220 -7.13724773 33.46988770 </position>
    <velocity> 0.00015463 -0.00019252 -0.00001082 </velocity>
    <force> -0.03089911 -0.02249455 0.04232287 </force>
  </atom>
  <atom name="O63" species="oxygen">
    <position> -20.90235545 -8.13917206 31.69180355 </position>
    <velocity> -0.00027444 0.00005242 0.00024284 </velocity>
    <force> 0.00502948 0.00219716 -0.01137322 </force>
  </atom>
  <atom name="O64" species="oxygen">
    <position> 12.30358769 6.56336210 25.72436193 </position>
    <velocity> 0.00027072 -0.00005019 0.00030626 </velocity>
    <force> -0.00599770 -0.00383563 -0.01280365 </force>
  </atom>
  <atom name="H1" species="hydrogen">
    <position> -5.94583316 7.22760493 13.83173088 </position>
    <velocity> -0.00065499 0.00034379 0.00003764 </velocity>
    <force> -0.02120693 -0.02163667 -0.02259514 </force>
  </atom>
  <atom name="H2" species="hydrogen">
    <position> -8.11755055 6.51264718 11.89832950 </position>
    <velocity> 0.00006191 -0.00040094 0.00040095 </velocity>
    <force> -0.03956190 0.01956242 -0.00555341 </force>
  </atom>
  <atom name="H3" species="hydrogen">
    <position> 24.70393137 2.74701668 26.52603802 </position>
    <velocity> 0.00057058 0.00072849 -0.00090527 </velocity>
    <force> -0.01395124 0.00651813 -0.00571571 </force>
  </atom>
  <atom name="H4" species="hydrogen">
    <position> 21.99545661 1.41675704 26.45545531 </position>
    <velocity> -0.00055990 0.00031393 -0.00045714 </velocity>
    <force> 0.00859041 0.00948277 -0.01341993 </force>
  </atom>
  <atom name="H5" species="hydrogen">
    <position> -27.63232292 24.48604732 -31.85518870 </position>
    <velocity> -0.00087838 -0.00078761 0.00053259 </velocity>
    <force> -0.00296740 0.00276633 0.00347799 </force>
  </atom>
  <atom name="H6" species="hydrogen">
    <position> -27.81811243 23.82925737 -34.67895145 </position>
    <velocity> -0.00034577 -0.00023803 0.00085744 </velocity>
    <force> -0.00040590 -0.00094073 0.00105177 </force>
  </atom>
  <atom name="H7" species="hydrogen">
    <position> 12.62749426 -10.30673078 1.00885890 </position>
    <velocity> -0.00021529 0.00033699 0.00066245 </velocity>
    <force> 0.00996027 0.02531381 -0.04083063 </force>
  </atom>
  <atom name="H8" species="hydrogen">
    <position> 11.73325869 -8.77125527 -1.72869656 </position>
    <velocity> -0.00001780 0.00025302 -0.00015825 </velocity>
    <force> -0.00510970 -0.00662505 0.01186686 </force>
  </atom>
  <atom name="H9" species="hydrogen">
    <position> 5.51237120 -21.06191546 -6.14742809 </position>
    <velocity> 0.00039860 -0.00060079 0.00032051 </velocity>
    <force> -0.00167977 -0.00762364 0.00568449 </force>
  </atom>
  <atom name="H10" species="hydrogen">
    <position> 6.93459513 -22.26868969 -3.74225297 </position>
    <velocity> 0.00005575 -0.00050826 0.00030529 </velocity>
    <force> -0.00890278 0.00523942 -0.03860782 </force>
  </atom>
  <atom name="H11" species="hydrogen">
    <position> 7.14716246 17.06090095 3.45936131 </position>
    <velocity> -0.00010160 0.00057189 -0.00059462 </velocity>
    <force> 0.01846988 -0.00096443 0.02261005 </force>
  </atom>
  <atom name="H12" species="hydrogen">
    <position> 9.62754669 17.76369339 5.04230564 </position>
    <velocity> -0.00088605 0.00002902 0.00041081 </velocity>
    <force> 0.01053000 0.00511469 -0.00217693 </force>
  </atom>
  <atom name="H13" species="hydrogen">
    <position> -4.20692249 -27.38584105 -18.67527334 </position>
    <velocity> 0.00073132 -0.00026479 0.00112845 </velocity>
    <force> -0.00254801 0.00598682 0.01622903 </force>
  </atom>
  <atom name="H14" species="hydrogen">
    <position> -3.97228669 -30.08346936 -19.45591040 </position>
    <velocity> 0.00043318 0.00000383 -0.00022597 </velocity>
    <force> 0.00826917 -0.02479120 -0.01447623 </force>
  </atom>
  <atom name="H15" species="hydrogen">
    <position> 1.54239125 -14.55393191 12.15023506 </position>
    <velocity> -0.00055524 -0.00042449 0.00092925 </velocity>
    <force> 0.00858193 -0.00373063 0.00585434 </force>
  </atom>
  <atom name="H16" species="hydrogen">
    <position> 4.48757727 -14.43342465 12.77426230 </position>
    <velocity> -0.00068918 0.00016211 0.00040871 </velocity>
    <force> -0.00626406 0.00089684 0.00184401 </force>
  </atom>
  <atom name="H17" species="hydrogen">
    <position> 2.42049078 6.01899872 -7.40423432 </position>
    <velocity> -0.00006276 0.00027672 0.00029819 </velocity>
    <force> 0.00101731 -0.00772557 0.00365737 </force>
  </atom>
  <atom name="H18" species="hydrogen">
    <position> 0.96038648 3.97233646 -5.82517656 </position>
    <velocity> 0.00013499 0.00225080 -0.00108110 </velocity>
    <force> -0.03692375 -0.00887363 0.00878695 </force>
  </atom>
  <atom name="H19" species="hydrogen">
    <position> -0.84055342 6.65586980 8.32029381 </position>
    <velocity> -0.00047038 0.00033887 0.00020571 </velocity>
    <force> -0.00246339 -0.00870468 -0.00011178 </force>
  </atom>
  <atom name="H20" species="hydrogen">
    <position> -0.78527374 9.44657275 8.25199308 </position>
    <velocity> 0.00046101 -0.00036270 0.00007173 </velocity>
    <force> 0.01021092 -0.00516104 -0.00000064 </force>
  </atom>
  <atom name="H21" species="hydrogen">
    <position> 11.52623946 -15.12691625 10.57772065 </position>
    <velocity> -0.00012420 0.00022305 -0.00003692 </velocity>
    <force> -0.00461876 -0.00212426 -0.00338384 </force>
  </atom>
  <atom name="H22" species="hydrogen">
    <position> 12.72834142 -13.14189847 12.22839160 </position>
    <velocity> -0.00023339 -0.00024656 0.00078300 </velocity>
    <force> 0.00201065 0.00311183 0.00773116 </force>
  </atom>
  <atom name="H23" species="hydrogen">
    <position> -12.34906148 -1.58707660 11.81402780 </position>
    <velocity> 0.00098927 -0.00057527 0.00050419 </velocity>
    <force> 0.00668162 0.02189652 -0.01949109 </force>
  </atom>
  <atom name="H24" species="hydrogen">
    <position> -12.32782263 -1.96752828 14.55521238 </position>
    <velocity> 0.00063466 -0.00019802 0.00009163 </velocity>
    <force> 0.00058328 -0.00009306 0.01561609 </force>
  </atom>
  <atom name="H25" species="hydrogen">
    <position> 0.52261250 -9.37131065 -21.32027127 </position>
    <velocity> 0.00021818 0.00006626 0.00013187 </velocity>
    <force> -0.00948417 0.00072463 -0.00501153 </force>
  </atom>
  <atom name="H26" species="hydrogen">
    <position> 3.07483763 -8.28761730 -22.32235685 </position>
    <velocity> -0.00052149 0.00052931 -0.00044260 </velocity>
    <force> 0.00844149 0.00724586 -0.00122853 </force>
  </atom>
  <atom name="H27" species="hydrogen">
    <position> -7.01903334 -9.56734723 -2.46891719 </position>
    <velocity> 0.00035786 0.00027329 0.00021210 </velocity>
    <force> -0.05439491 -0.01181409 -0.00071756 </force>
  </atom>
  <atom name="H28" species="hydrogen">
    <position> -4.55640797 -9.35608644 -4.20008025 </position>
    <velocity> 0.00049415 -0.00044400 0.00005919 </velocity>
    <force> -0.00567199 -0.00517588 0.00248663 </force>
  </atom>
  <atom name="H29" species="hydrogen">
    <position> 12.64264203 -13.69813395 3.57054509 </position>
    <velocity> 0.00056077 -0.00076372 -0.00074796 </velocity>
    <force> 0.00219756 0.00655189 0.00364960 </force>
  </atom>
  <atom name="H30" species="hydrogen">
    <position> 12.29566427 -11.50552336 5.48870948 </position>
    <velocity> 0.00075052 0.00003365 -0.00010060 </velocity>
    <force> -0.04414314 0.01681735 0.05572369 </force>
  </atom>
  <atom name="H31" species="hydrogen">
    <position> -5.68875429 10.83220123 -7.27536164 </position>
    <velocity> 0.00008891 -0.00002530 -0.00129471 </velocity>
    <force> 0.00512241 0.00048249 0.00597731 </force>
  </atom>
  <atom name="H32" species="hydrogen">
    <position> -8.65715408 10.43104015 -7.36470037 </position>
    <velocity> -0.00072470 0.00078155 -0.00040198 </velocity>
    <force> 0.00690670 -0.00713624 0.00701748 </force>
  </atom>
  <atom name="H33" species="hydrogen">
    <position> -15.04846307 -13.83199410 -28.93063510 </position>
    <velocity> -0.00086705 0.00066857 0.00085263 </velocity>
    <force> 0.01056847 -0.00366028 0.02143840 </force>
  </atom>
  <atom name="H34" species="hydrogen">
    <position> -13.02428904 -15.92894705 -28.84122480 </position>
    <velocity> 0.00029650 0.00029800 -0.00076051 </velocity>
    <force> -0.00084874 -0.00115804 0.01359325 </force>
  </atom>
  <atom name="H35" species="hydrogen">
    <position> -20.44266012 -0.96236504 14.69019244 </position>
    <velocity> -0.00013145 -0.00025360 0.00010298 </velocity>
    <force> -0.00534310 -0.00301534 -0.00794118 </force>
  </atom>
  <atom name="H36" species="hydrogen">
    <position> -18.16859818 -2.59829998 14.50800073 </position>
    <velocity> 0.00006989 0.00022115 0.00026327 </velocity>
    <force> 0.01643814 -0.00342038 0.00208765 </force>
  </atom>
  <atom name="H37" species="hydrogen">
    <position> 5.61909852 -15.53182789 0.52795323 </position>
    <velocity> 0.00004427 0.00025057 0.00137581 </velocity>
    <force> 0.01289519 -0.00723781 -0.01562508 </force>
  </atom>
  <atom name="H38" species="hydrogen">
    <position> 8.13266079 -15.41216987 -1.34874346 </position>
    <velocity> -0.00048220 -0.00047351 -0.00007434 </velocity>
    <force> -0.01485037 -0.00693649 0.01228214 </force>
  </atom>
  <atom name="H39" species="hydrogen">
    <position> 5.52878739 19.55992123 -23.08425857 </position>
    <velocity> -0.00018304 -0.00023859 0.00015152 </velocity>
    <force> -0.00365085 -0.00568269 0.00863960 </force>
  </atom>
  <atom name="H40" species="hydrogen">
    <position> 6.87713824 17.31730012 -24.47278630 </position>
    <velocity> -0.00024314 -0.00043118 0.00004449 </velocity>
    <force> 0.01367308 -0.01373858 -0.00717895 </force>
  </atom>
  <atom name="H41" species="hydrogen">
    <position> 3.81844996 1.90000288 11.41554776 </position>
    <velocity> 0.00041640 0.00009499 -0.00000680 </velocity>
    <force> -0.01142219 -0.00272744 0.00205475 </force>
  </atom>
  <atom name="H42" species="hydrogen">
    <position> 2.97458010 2.85125458 14.17982504 </position>
    <velocity> -0.00084246 -0.00021627 -0.00014291 </velocity>
    <force> -0.00746961 0.01098496 0.01274593 </force>
  </atom>
  <atom name="H43" species="hydrogen">
    <position> -8.60173820 -5.49281805 3.47269572 </position>
    <velocity> 0.00025913 -0.00073660 0.00079263 </velocity>
    <force> 0.00797752 0.00670099 0.00933070 </force>
  </atom>
  <atom name="H44" species="hydrogen">
    <position> -9.82144143 -6.37551362 1.10531984 </position>
    <velocity> 0.00091150 0.00150470 0.00018575 </velocity>
    <force> -0.01054172 -0.01331296 -0.01836749 </force>
  </atom>
  <atom name="H45" species="hydrogen">
    <position> -12.81036840 -9.31091720 8.46677458 </position>
    <velocity> 0.00061703 0.00002128 -0.00018653 </velocity>
    <force> -0.00538004 -0.01542296 0.00199418 </force>
  </atom>
  <atom name="H46" species="hydrogen">
    <position> -14.67452460 -9.58065300 6.44792719 </position>
    <velocity> 0.00045801 -0.00014030 0.00029623 </velocity>
    <force> -0.01112531 0.00577690 -0.00844996 </force>
  </atom>
  <atom name="H47" species="hydrogen">
    <position> 16.74769357 -13.14444833 4.58795789 </position>
    <velocity> 0.00005964 -0.00070533 0.00032006 </velocity>
    <force> -0.00223841 0.01488234 -0.01004011 </force>
  </atom>
  <atom name="H48" species="hydrogen">
    <position> 18.67247123 -14.72031953 5.69905913 </position>
    <velocity> 0.00105148 -0.00042921 -0.00018632 </velocity>
    <force> 0.01838190 -0.02544631 0.02342757 </force>
  </atom>
  <atom name="H49" species="hydrogen">
    <position> 19.89511673 13.02674261 3.13346928 </position>
    <velocity> -0.00025506 0.00061628 -0.00055439 </velocity>
    <force> -0.00460577 -0.01759664 0.01402038 </force>
  </atom>
  <atom name="H50" species="hydrogen">
    <position> 19.37526967 14.24846079 0.53928011 </position>
    <velocity> 0.00041111 -0.00023938 -0.00014851 </velocity>
    <force> 0.00530038 -0.00027390 -0.01168715 </force>
  </atom>
  <atom name="H51" species="hydrogen">
    <position> 6.83499475 14.32165113 -31.55079263 </position>
    <velocity> 0.00060594 0.00035992 0.00018140 </velocity>
    <force> 0.00084904 -0.01510106 0.00707547 </force>
  </atom>
  <atom name="H52" species="hydrogen">
    <position> 4.83606975 12.90843157 -29.91274339 </position>
    <velocity> -0.00069318 0.00060771 -0.00073817 </velocity>
    <force> -0.00466204 -0.00356302 0.00154400 </force>
  </atom>
  <atom name="H53" species="hydrogen">
    <position> 14.65739129 -22.30093845 -10.21352529 </position>
    <velocity> -0.00086245 0.00029078 0.00035867 </velocity>
    <force> -0.01645488 0.01028226 0.00088960 </force>
  </atom>
  <atom name="H54" species="hydrogen">
    <position> 12.64882413 -20.68527861 -8.66827031 </position>
    <velocity> 0.00101238 -0.00028014 0.00042152 </velocity>
    <force> -0.00508366 -0.00672795 -0.01027363 </force>
  </atom>
  <atom name="H55" species="hydrogen">
    <position> 11.23784397 2.79603833 -15.98878320 </position>
    <velocity> -0.00062063 0.00076625 -0.00113907 </velocity>
    <force> 0.00000767 -0.00962450 -0.01921059 </force>
  </atom>
  <atom name="H56" species="hydrogen">
    <position> 12.02591312 3.21332964 -13.25585947 </position>
    <velocity> -0.00022449 -0.00070904 0.00015401 </velocity>
    <force> -0.02382095 0.00613060 0.00251266 </force>
  </atom>
  <atom name="H57" species="hydrogen">
    <position> -4.05925427 7.04950903 -2.15972940 </position>
    <velocity> -0.00039369 -0.00020851 -0.00007371 </velocity>
    <force> 0.02452296 0.02722777 0.04890078 </force>
  </atom>
  <atom name="H58" species="hydrogen">
    <position> -6.16670305 7.59670595 -4.48714000 </position>
    <velocity> -0.00012346 -0.00022254 -0.00047649 </velocity>
    <force> 0.02825329 0.00259939 0.00595927 </force>
  </atom>
  <atom name="H59" species="hydrogen">
    <position> -10.35530447 -1.62193049 23.45832106 </position>
    <velocity> 0.00070371 -0.00015200 -0.00036810 </velocity>
    <force> 0.00799857 -0.02636581 0.01898356 </force>
  </atom>
  <atom name="H60" species="hydrogen">
    <position> -9.36613747 0.72963680 21.99786135 </position>
    <velocity> -0.00027647 -0.00012897 -0.00051474 </velocity>
    <force> -0.02545505 -0.01178354 -0.00461833 </force>
  </atom>
  <atom name="H61" species="hydrogen">
    <position> 5.55487205 0.48919313 0.69500140 </position>
    <velocity> 0.00147801 0.00052699 -0.00001120 </velocity>
    <force> -0.00384517 -0.01002371 -0.00267392 </force>
  </atom>
  <atom name="H62" species="hydrogen">
    <position> 4.11383573 -1.13543393 2.81208483 </position>
    <velocity> -0.00026331 0.00038129 -0.00036573 </velocity>
    <force> 0.00645078 -0.00496692 -0.01195774 </force>
  </atom>
  <atom name="H63" species="hydrogen">
    <position> 23.67626383 -0.30094442 -0.33359414 </position>
    <velocity> -0.00051313 0.00054944 -0.00078765 </velocity>
    <force> -0.01371440 0.00621138 -0.01976665 </force>
  </atom>
  <atom name="H64" species="hydrogen">
    <position> 23.57260972 -2.06362729 -2.61632784 </position>
    <velocity> -0.00023435 0.00013148 -0.00082053 </velocity>
    <force> 0.02332852 -0.03807753 -0.02360628 </force>
  </atom>
  <atom name="H65" species="hydrogen">
    <position> -0.40275061 21.64791826 8.81432955 </position>
    <velocity> 0.00042036 -0.00016940 0.00001021 </velocity>
    <force> -0.01067486 0.00437060 -0.00303209 </force>
  </atom>
  <atom name="H66" species="hydrogen">
    <position> 0.21918394 23.51717069 10.82642333 </position>
    <velocity> 0.00134845 0.00017629 0.00097579 </velocity>
    <force> 0.01930736 0.01847897 0.02473500 </force>
  </atom>
  <atom name="H67" species="hydrogen">
    <position> -12.44385089 -1.83260944 19.35591443 </position>
    <velocity> -0.00000366 -0.00012600 0.00082572 </velocity>
    <force> 0.00799810 -0.00028229 0.01042658 </force>
  </atom>
  <atom name="H68" species="hydrogen">
    <position> -14.85997848 -1.66918153 17.75150073 </position>
    <velocity> -0.00006570 0.00039378 -0.00105148 </velocity>
    <force> -0.00250978 -0.00089205 -0.00432413 </force>
  </atom>
  <atom name="H69" species="hydrogen">
    <position> 4.63736224 -1.29918835 -16.20215281 </position>
    <velocity> -0.00026531 -0.00106906 0.00005721 </velocity>
    <force> -0.02089438 -0.00159172 -0.03669959 </force>
  </atom>
  <atom name="H70" species="hydrogen">
    <position> 5.31444629 -3.76686928 -17.32188399 </position>
    <velocity> 0.00027714 0.00048220 0.00000701 </velocity>
    <force> -0.00490152 -0.00072375 -0.02227781 </force>
  </atom>
  <atom name="H71" species="hydrogen">
    <position> 7.96019923 8.48729703 -40.38686417 </position>
    <velocity> -0.00068522 -0.00046356 0.00030532 </velocity>
    <force> 0.00438000 0.00768338 0.00017620 </force>
  </atom>
  <atom name="H72" species="hydrogen">
    <position> 8.55670846 5.85949974 -39.11543873 </position>
    <velocity> 0.00048795 -0.00056743 -0.00072381 </velocity>
    <force> 0.00508894 0.00206824 -0.00090234 </force>
  </atom>
  <atom name="H73" species="hydrogen">
    <position> -10.47334942 -2.59276151 7.08773317 </position>
    <velocity> -0.00081394 0.00092748 0.00018066 </velocity>
    <force> -0.00497716 0.01040943 -0.01874353 </force>
  </atom>
  <atom name="H74" species="hydrogen">
    <position> -10.90587265 -2.20276107 4.06060172 </position>
    <velocity> 0.00000226 0.00039595 0.00033395 </velocity>
    <force> 0.00381326 0.01336075 0.03550906 </force>
  </atom>
  <atom name="H75" species="hydrogen">
    <position> 2.02075461 10.79815344 18.85780816 </position>
    <velocity> -0.00005106 0.00007794 -0.00066057 </velocity>
    <force> -0.00442539 -0.00575791 0.03178022 </force>
  </atom>
  <atom name="H76" species="hydrogen">
    <position> 2.04435936 10.51078736 16.12059213 </position>
    <velocity> -0.00004548 -0.00009429 0.00096328 </velocity>
    <force> -0.00629554 0.00505052 -0.02122223 </force>
  </atom>
  <atom name="H77" species="hydrogen">
    <position> 8.43158070 10.56964768 -10.07779241 </position>
    <velocity> -0.00050416 0.00028057 0.00028896 </velocity>
    <force> -0.00048694 0.01213776 -0.01020003 </force>
  </atom>
  <atom name="H78" species="hydrogen">
    <position> 7.79676787 11.05082140 -13.01989014 </position>
    <velocity> -0.00159270 -0.00097703 0.00053345 </velocity>
    <force> 0.01179495 0.03647064 -0.02556501 </force>
  </atom>
  <atom name="H79" species="hydrogen">
    <position> -17.57929246 -7.61426360 11.19271268 </position>
    <velocity> 0.00078457 0.00047427 0.00026619 </velocity>
    <force> -0.02489798 -0.00827371 -0.02332441 </force>
  </atom>
  <atom name="H80" species="hydrogen">
    <position> -15.94346879 -5.77976772 12.54526047 </position>
    <velocity> -0.00109317 -0.00066505 -0.00077765 </velocity>
    <force> 0.01579698 0.03279818 0.00491301 </force>
  </atom>
  <atom name="H81" species="hydrogen">
    <position> 15.99670777 4.80493680 -2.72418552 </position>
    <velocity> 0.00013779 0.00010127 -0.00005524 </velocity>
    <force> -0.02250287 -0.01072578 0.00381912 </force>
  </atom>
  <atom name="H82" species="hydrogen">
    <position> 13.70406016 5.09960174 -0.77282069 </position>
    <velocity> 0.00002116 0.00121353 0.00060187 </velocity>
    <force> 0.00188352 -0.00825164 -0.00914401 </force>
  </atom>
  <atom name="H83" species="hydrogen">
    <position> -7.85968147 17.39211466 15.74952854 </position>
    <velocity> 0.00060569 0.00180988 0.00005020 </velocity>
    <force> -0.01975455 0.00327797 0.00371557 </force>
  </atom>
  <atom name="H84" species="hydrogen">
    <position> -10.52285589 18.15091035 16.93124849 </position>
    <velocity> -0.00015860 -0.00067876 -0.00020896 </velocity>
    <force> -0.01519225 0.01821802 0.01213048 </force>
  </atom>
  <atom name="H85" species="hydrogen">
    <position> -4.94293425 -3.06915008 -9.16838789 </position>
    <velocity> -0.00010706 0.00059238 -0.00040424 </velocity>
    <force> -0.00572337 0.02930086 -0.00767778 </force>
  </atom>
  <atom name="H86" species="hydrogen">
    <position> -3.70830472 -4.75267110 -7.15483575 </position>
    <velocity> 0.00031402 0.00009743 0.00061368 </velocity>
    <force> -0.00556499 -0.00387784 -0.00957323 </force>
  </atom>
  <atom name="H87" species="hydrogen">
    <position> -12.17511986 -11.36790609 17.07003035 </position>
    <velocity> 0.00018068 0.00052096 -0.00002056 </velocity>
    <force> -0.03723184 0.00120600 0.05298069 </force>
  </atom>
  <atom name="H88" species="hydrogen">
    <position> -10.30339284 -9.47965870 15.55858416 </position>
    <velocity> 0.00016431 0.00048505 0.00001450 </velocity>
    <force> -0.02386488 -0.02076145 0.01446462 </force>
  </atom>
  <atom name="H89" species="hydrogen">
    <position> -8.60866984 25.02282630 5.28810532 </position>
    <velocity> -0.00021063 -0.00039100 -0.00032831 </velocity>
    <force> -0.00027976 0.00119293 -0.00903591 </force>
  </atom>
  <atom name="H90" species="hydrogen">
    <position> -6.44709706 26.88746578 6.14790737 </position>
    <velocity> -0.00107260 -0.00130500 0.00029457 </velocity>
    <force> -0.01082317 -0.00096014 -0.03202944 </force>
  </atom>
  <atom name="H91" species="hydrogen">
    <position> 11.94531447 -4.91786741 -12.88397119 </position>
    <velocity> 0.00011257 0.00025712 -0.00029208 </velocity>
    <force> 0.02117860 -0.00957063 -0.03258357 </force>
  </atom>
  <atom name="H92" species="hydrogen">
    <position> 14.50908172 -6.35736881 -14.07780328 </position>
    <velocity> -0.00026347 0.00017991 -0.00046931 </velocity>
    <force> -0.02642862 0.03070700 -0.00597111 </force>
  </atom>
  <atom name="H93" species="hydrogen">
    <position> -4.00362703 -2.28301495 2.05501237 </position>
    <velocity> -0.00064102 -0.00039902 -0.00007162 </velocity>
    <force> 0.00033345 0.01640187 -0.00377484 </force>
  </atom>
  <atom name="H94" species="hydrogen">
    <position> -5.29325882 -0.16631297 3.49883723 </position>
    <velocity> -0.00033119 -0.00118989 0.00010233 </velocity>
    <force> -0.04772350 0.03086038 0.00622738 </force>
  </atom>
  <atom name="H95" species="hydrogen">
    <position> -18.53655673 -17.97578960 -17.98108107 </position>
    <velocity> 0.00008796 0.00085377 0.00047814 </velocity>
    <force> 0.02286639 0.00841677 -0.00626740 </force>
  </atom>
  <atom name="H96" species="hydrogen">
    <position> -21.01372166 -17.43211277 -16.90940916 </position>
    <velocity> -0.00006139 -0.00002215 -0.00013530 </velocity>
    <force> -0.02763106 0.02847043 0.01660554 </force>
  </atom>
  <atom name="H97" species="hydrogen">
    <position> -38.81293284 4.11188494 -23.60631677 </position>
    <velocity> -0.00064123 0.00045155 -0.00038964 </velocity>
    <force> -0.01813978 -0.00026291 -0.00864972 </force>
  </atom>
  <atom name="H98" species="hydrogen">
    <position> -37.35951284 1.52540904 -24.04826744 </position>
    <velocity> 0.00037410 0.00043443 -0.00075644 </velocity>
    <force> 0.00575904 -0.00761305 0.00000571 </force>
  </atom>
  <atom name="H99" species="hydrogen">
    <position> 32.74995179 17.65717661 -4.02143842 </position>
    <velocity> -0.00000215 -0.00025058 0.00112509 </velocity>
    <force> -0.00301592 -0.00671517 -0.00057177 </force>
  </atom>
  <atom name="H100" species="hydrogen">
    <position> 31.22858683 14.98183804 -4.26471709 </position>
    <velocity> 0.00073113 -0.00049185 0.00022139 </velocity>
    <force> 0.01071128 0.00289365 -0.00124346 </force>
  </atom>
  <atom name="H101" species="hydrogen">
    <position> 9.80612032 3.30762451 -5.94651214 </position>
    <velocity> -0.00116573 0.00027590 -0.00076392 </velocity>
    <force> -0.04736889 -0.02490148 0.00108123 </force>
  </atom>
  <atom name="H102" species="hydrogen">
    <position> 12.25453758 3.86128207 -4.44413993 </position>
    <velocity> 0.00141132 0.00046237 -0.00118994 </velocity>
    <force> 0.00834906 0.00425601 -0.00320024 </force>
  </atom>
  <atom name="H103" species="hydrogen">
    <position> -3.42697227 3.80059678 18.65749101 </position>
    <velocity> -0.00030804 -0.00068218 0.00037868 </velocity>
    <force> 0.00621837 0.00776334 0.00456856 </force>
  </atom>
  <atom name="H104" species="hydrogen">
    <position> -1.48934753 1.70172806 19.50435847 </position>
    <velocity> 0.00031427 0.00030172 -0.00049484 </velocity>
    <force> 0.00703602 -0.02869314 0.03506081 </force>
  </atom>
  <atom name="H105" species="hydrogen">
    <position> 21.76957920 -10.84080930 -6.93570153 </position>
    <velocity> 0.00016821 0.00072098 -0.00011229 </velocity>
    <force> -0.01569735 0.00054275 0.00512489 </force>
  </atom>
  <atom name="H106" species="hydrogen">
    <position> 19.85026269 -9.22386197 -8.47103923 </position>
    <velocity> 0.00067064 -0.00056759 0.00109791 </velocity>
    <force> 0.00239773 -0.00361565 0.00548558 </force>
  </atom>
  <atom name="H107" species="hydrogen">
    <position> 0.92300698 -8.49950659 10.95028628 </position>
    <velocity> -0.00033993 0.00086853 -0.00047575 </velocity>
    <force> 0.01169801 0.00797279 -0.00970213 </force>
  </atom>
  <atom name="H108" species="hydrogen">
    <position> 0.79888538 -7.48021971 13.83474934 </position>
    <velocity> 0.00080964 -0.00023890 -0.00013477 </velocity>
    <force> 0.00435619 0.00621176 -0.00391256 </force>
  </atom>
  <atom name="H109" species="hydrogen">
    <position> 18.13274615 -5.09045928 -1.21712882 </position>
    <velocity> -0.00012999 -0.00048895 -0.00026684 </velocity>
    <force> -0.00265225 -0.00425505 -0.00059481 </force>
  </atom>
  <atom name="H110" species="hydrogen">
    <position> 19.16531122 -2.41482927 -1.60842415 </position>
    <velocity> 0.00012324 -0.00012585 -0.00045090 </velocity>
    <force> 0.01772707 0.01297837 -0.01216795 </force>
  </atom>
  <atom name="H111" species="hydrogen">
    <position> 23.97099709 -6.74322331 18.51830506 </position>
    <velocity> -0.00049156 -0.00065914 0.00050957 </velocity>
    <force> 0.00054868 0.00664806 -0.00520496 </force>
  </atom>
  <atom name="H112" species="hydrogen">
    <position> 25.03830955 -4.22085732 17.16121447 </position>
    <velocity> 0.00007478 0.00035604 0.00029161 </velocity>
    <force> -0.00995705 -0.01508217 -0.00653130 </force>
  </atom>
  <atom name="H113" species="hydrogen">
    <position> 2.31776759 34.13178703 -23.59528167 </position>
    <velocity> 0.00038143 0.00005263 -0.00018702 </velocity>
    <force> 0.00978492 -0.00975554 -0.00489727 </force>
  </atom>
  <atom name="H114" species="hydrogen">
    <position> 1.14069102 31.59335569 -24.09902331 </position>
    <velocity> -0.00027282 -0.00047079 -0.00015299 </velocity>
    <force> -0.01791430 -0.01218361 0.00341241 </force>
  </atom>
  <atom name="H115" species="hydrogen">
    <position> 6.96151812 1.86415021 -13.86307257 </position>
    <velocity> -0.00001108 -0.00042976 -0.00038668 </velocity>
    <force> -0.03447104 -0.01170876 -0.02417017 </force>
  </atom>
  <atom name="H116" species="hydrogen">
    <position> 4.72756202 2.87522706 -15.70153809 </position>
    <velocity> -0.00008780 -0.00059380 0.00049677 </velocity>
    <force> -0.01362561 0.00777630 -0.01159214 </force>
  </atom>
  <atom name="H117" species="hydrogen">
    <position> -3.30405557 -14.73931926 -21.90873833 </position>
    <velocity> 0.00088123 0.00024132 0.00086057 </velocity>
    <force> 0.01985294 -0.01843891 -0.00629897 </force>
  </atom>
  <atom name="H118" species="hydrogen">
    <position> -1.99044652 -17.49253299 -22.02816162 </position>
    <velocity> -0.00043587 -0.00161309 0.00062463 </velocity>
    <force> 0.00382033 -0.00248909 0.00128436 </force>
  </atom>
  <atom name="H119" species="hydrogen">
    <position> -28.98839939 -14.00507611 10.75242319 </position>
    <velocity> 0.00045725 -0.00023471 -0.00118945 </velocity>
    <force> -0.01708973 -0.02212316 0.00460555 </force>
  </atom>
  <atom name="H120" species="hydrogen">
    <position> -27.94621492 -11.49114041 10.16899846 </position>
    <velocity> 0.00100681 0.00036885 0.00089351 </velocity>
    <force> 0.00774368 0.00593815 0.00009067 </force>
  </atom>
  <atom name="H121" species="hydrogen">
    <position> -4.64343964 4.85873942 -13.77385135 </position>
    <velocity> -0.00070749 0.00048937 -0.00053717 </velocity>
    <force> 0.00085282 0.00295071 -0.00636205 </force>
  </atom>
  <atom name="H122" species="hydrogen">
    <position> -2.99624708 2.80973121 -15.14780193 </position>
    <velocity> -0.00026287 0.00016091 0.00003538 </velocity>
    <force> 0.00180441 0.00170747 -0.00292941 </force>
  </atom>
  <atom name="H123" species="hydrogen">
    <position> -5.18933029 -6.96197761 31.91248558 </position>
    <velocity> -0.00026879 0.00076496 0.00029638 </velocity>
    <force> 0.02607237 0.01484639 -0.04365220 </force>
  </atom>
  <atom name="H124" species="hydrogen">
    <position> -5.04309704 -6.34547296 34.80950745 </position>
    <velocity> 0.00022075 0.00106806 0.00026816 </velocity>
    <force> 0.00375272 0.00362793 0.00358418 </force>
  </atom>
  <atom name="H125" species="hydrogen">
    <position> -20.95553418 -9.26258614 30.22503499 </position>
    <velocity> 0.00019733 -0.00107289 0.00026334 </velocity>
    <force> 0.00159599 -0.00416977 -0.00061252 </force>
  </atom>
  <atom name="H126" species="hydrogen">
    <position> -20.85570612 -6.48638768 30.86456352 </position>
    <velocity> 0.00028618 0.00035161 0.00052716 </velocity>
    <force> -0.00158821 0.00380413 0.00271029 </force>
  </atom>
  <atom name="H127" species="hydrogen">
    <position> 10.55809407 5.99879548 25.13259387 </position>
    <velocity> 0.00139850 -0.00073512 -0.00002513 </velocity>
    <force> 0.02392259 0.01071895 0.02353372 </force>
  </atom>
  <atom name="H128" species="hydrogen">
    <position> 13.31382814 5.35717414 26.77620394 </position>
    <velocity> 0.00041592 -0.00044522 -0.00082895 </velocity>
    <force> -0.01242194 -0.00292923 -0.00630399 </force>
  </atom>
</atomset>
<unit_cell_a_norm> 23.460000 </unit_cell_a_norm>
<unit_cell_b_norm> 23.460000 </unit_cell_b_norm>
<unit_cell_c_norm> 23.460000 </unit_cell_c_norm>
<unit_cell_alpha>  90.000 </unit_cell_alpha>
<unit_cell_beta>   90.000 </unit_cell_beta>
<unit_cell_gamma>  90.000 </unit_cell_gamma>
<unit_cell_volume> 12911.718 </unit_cell_volume>
  <econst> -1100.15048987 </econst>
  <ekin_ion> 0.35608049 </ekin_ion>
  <temp_ion> 390.44054576 </temp_ion>
  total_electronic_charge: 512.00000000
  <eigenvalue_sum>  -162.47964638 </eigenvalue_sum>
  <etotal_int>   -1100.50391894 </etotal_int>
  total_electronic_charge: 512.00000000
  <eigenvalue_sum>  -162.48544005 </eigenvalue_sum>
  Anderson extrapolation: theta=1.22578549 (1.22578549)
  <etotal_int>   -1100.50397733 </etotal_int>
  total_electronic_charge: 512.00000000
  <eigenvalue_sum>  -162.49256075 </eigenvalue_sum>
  Anderson extrapolation: theta=0.06940068 (0.06940068)
  <etotal_int>   -1100.50401132 </etotal_int>
  total_electronic_charge: 512.00000000
  <eigenvalue_sum>  -162.49312838 </eigenvalue_sum>
  Anderson extrapolation: theta=1.83335027 (1.83335027)
  <etotal_int>   -1100.50401313 </etotal_int>
  total_electronic_charge: 512.00000000
  <eigenvalue_sum>  -162.49424640 </eigenvalue_sum>
  Anderson extrapolation: theta=0.25124921 (0.25124921)
  <etotal_int>   -1100.50401491 </etotal_int>
  <timing name="iteration" min="    5.653" max="    5.662"/>
</iteration>
<iteration count="9">
  total_electronic_charge: 512.00000000
  <ekin>       808.62946247 </ekin>
  <econf>        0.00000000 </econf>
  <eps>      -1309.92465034 </eps>
  <enl>        124.83579654 </enl>
  <ecoul>     -453.00418043 </ecoul>
  <exc>       -271.04044353 </exc>
  <esr>         93.73742280 </esr>
  <eself>      646.81841729 </eself>
  <ets>          0.00000000 </ets>
  <eexf>         0.00000000 </eexf>
  <etotal>   -1100.50401528 </etotal>
  <epv>          0.00000000 </epv>
  <eefield>      0.00000000 </eefield>
  <enthalpy> -1100.50401528 </enthalpy>
<atomset>
<unit_cell 
    a=" 23.46000000   0.00000000   0.00000000"
    b="  0.00000000  23.46000000   0.00000000"
    c="  0.00000000   0.00000000  23.46000000" />
  <atom name="O1" species="oxygen">
    <position> -6.49249334 6.00123563 12.40347662 </position>
    <velocity> -0.00003088 -0.00020838 0.00035989 </velocity>
    <force> 0.06377559 -0.00363671 0.02954443 </force>
  </atom>
  <atom name="O2" species="oxygen">
    <position> 23.13589044 2.61558152 25.48029591 </position>
    <velocity> 0.00000131 0.00003818 -0.00017550 </velocity>
    <force> 0.00393070 -0.00732338 0.01962543 </force>
  </atom>
  <atom name="O3" species="oxygen">
    <position> -28.80718322 23.74327662 -33.10611358 </position>
    <velocity> -0.00012595 0.00012809 -0.00015735 </velocity>
    <force> 0.00778925 -0.00443327 -0.00343836 </force>
  </atom>
  <atom name="O4" species="oxygen">
    <position> 13.16990233 -9.23056722 -0.59415264 </position>
    <velocity> 0.00007773 -0.00027853 0.00016589 </velocity>
    <force> -0.00476012 -0.01882870 0.03146852 </force>
  </atom>
  <atom name="O5" species="oxygen">
    <position> 6.68798356 -22.47015323 -5.71682520 </position>
    <velocity> 0.00028006 0.00004138 -0.00040981 </velocity>
    <force> 0.00922871 0.01217995 0.04325433 </force>
  </atom>
  <atom name="O6" species="oxygen">
    <position> 8.02487305 16.91529723 5.25939719 </position>
    <velocity> 0.00004334 -0.00022866 0.00030494 </velocity>
    <force> -0.03564039 -0.00226621 -0.03104944 </force>
  </atom>
  <atom name="O7" species="oxygen">
    <position> -4.61681591 -29.09777064 -18.06284926 </position>
    <velocity> -0.00003478 0.00051056 -0.00027413 </velocity>
    <force> -0.00833856 0.00949992 0.00684696 </force>
  </atom>
  <atom name="O8" species="oxygen">
    <position> 2.77992978 -14.72667183 13.55254149 </position>
    <velocity> -0.00005805 -0.00044332 0.00019214 </velocity>
    <force> -0.00045572 -0.00221005 -0.00563863 </force>
  </atom>
  <atom name="O9" species="oxygen">
    <position> 2.59087845 4.40022213 -6.47115196 </position>
    <velocity> -0.00023737 0.00002442 -0.00041759 </velocity>
    <force> 0.04839863 0.02552490 -0.01607810 </force>
  </atom>
  <atom name="O10" species="oxygen">
    <position> 0.41842962 8.00785084 8.13397775 </position>
    <velocity> 0.00011329 0.00031711 0.00022808 </velocity>
    <force> -0.01402825 0.01294371 0.00788181 </force>
  </atom>
  <atom name="O11" species="oxygen">
    <position> 13.17313256 -14.43295169 10.99486145 </position>
    <velocity> -0.00006553 0.00009315 -0.00001952 </velocity>
    <force> -0.00051428 0.00144683 -0.00375089 </force>
  </atom>
  <atom name="O12" species="oxygen">
    <position> -13.17785348 -2.56870827 13.05918101 </position>
    <velocity> 0.00022229 -0.00020430 -0.00014650 </velocity>
    <force> -0.02079927 -0.02884116 -0.00287701 </force>
  </atom>
  <atom name="O13" species="oxygen">
    <position> 2.31584535 -9.76761663 -21.53143762 </position>
    <velocity> -0.00011735 0.00036994 0.00013816 </velocity>
    <force> 0.00430254 -0.00790409 0.00348515 </force>
  </atom>
  <atom name="O14" species="oxygen">
    <position> -5.31180034 -9.16408514 -2.48368640 </position>
    <velocity> -0.00007576 0.00008055 -0.00031815 </velocity>
    <force> 0.05807062 0.02343118 0.00938196 </force>
  </atom>
  <atom name="O15" species="oxygen">
    <position> 13.28118313 -12.01359426 4.15621771 </position>
    <velocity> -0.00041609 -0.00035222 0.00008401 </velocity>
    <force> 0.04784375 -0.03415381 -0.07311488 </force>
  </atom>
  <atom name="O16" species="oxygen">
    <position> -6.99297457 9.51850879 -7.02525138 </position>
    <velocity> -0.00006926 0.00022206 -0.00008724 </velocity>
    <force> -0.00972891 -0.00526046 -0.00645823 </force>
  </atom>
  <atom name="O17" species="oxygen">
    <position> -13.79278719 -14.60749174 -27.72011374 </position>
    <velocity> -0.00003575 0.00012596 0.00014773 </velocity>
    <force> -0.01374059 0.00407288 -0.03321437 </force>
  </atom>
  <atom name="O18" species="oxygen">
    <position> -19.94256604 -2.76791278 14.86286828 </position>
    <velocity> -0.00024732 -0.00013759 0.00012718 </velocity>
    <force> -0.00892601 0.00366986 0.00296294 </force>
  </atom>
  <atom name="O19" species="oxygen">
    <position> 7.35468553 -16.25059429 0.20106526 </position>
    <velocity> -0.00031618 -0.00032864 0.00004197 </velocity>
    <force> 0.01218063 0.00939597 -0.00230128 </force>
  </atom>
  <atom name="O20" species="oxygen">
    <position> 5.90226727 17.67823117 -22.94966651 </position>
    <velocity> 0.00004463 -0.00009872 0.00001546 </velocity>
    <force> -0.01513419 0.01294972 0.01353712 </force>
  </atom>
  <atom name="O21" species="oxygen">
    <position> 2.44662138 1.84334524 12.73503665 </position>
    <velocity> -0.00020445 0.00027579 -0.00013639 </velocity>
    <force> 0.00247317 -0.01229351 -0.01072463 </force>
  </atom>
  <atom name="O22" species="oxygen">
    <position> -9.87869420 -4.94365852 2.26946692 </position>
    <velocity> 0.00030203 0.00010450 -0.00033188 </velocity>
    <force> 0.00151394 0.01071447 0.01804711 </force>
  </atom>
  <atom name="O23" species="oxygen">
    <position> -13.80081429 -10.70362378 7.64902824 </position>
    <velocity> 0.00017274 0.00004544 -0.00035858 </velocity>
    <force> 0.01534625 0.01358004 0.01242174 </force>
  </atom>
  <atom name="O24" species="oxygen">
    <position> 18.61550450 -13.37895605 4.51966745 </position>
    <velocity> 0.00030278 -0.00011814 -0.00008849 </velocity>
    <force> -0.02155820 0.01201735 -0.01556923 </force>
  </atom>
  <atom name="O25" species="oxygen">
    <position> 20.48792700 14.34890363 2.04149952 </position>
    <velocity> 0.00002973 -0.00048427 -0.00045066 </velocity>
    <force> 0.00739589 0.01818406 -0.00549844 </force>
  </atom>
  <atom name="O26" species="oxygen">
    <position> 6.68672160 13.03855966 -30.11343853 </position>
    <velocity> -0.00000268 0.00024650 0.00013206 </velocity>
    <force> -0.00348103 0.01760622 -0.01255848 </force>
  </atom>
  <atom name="O27" species="oxygen">
    <position> 12.83013375 -21.74672366 -10.27069265 </position>
    <velocity> 0.00021093 -0.00028123 0.00012768 </velocity>
    <force> 0.02823473 0.00373717 0.00270659 </force>
  </atom>
  <atom name="O28" species="oxygen">
    <position> 10.66819270 3.73328369 -14.54415599 </position>
    <velocity> 0.00011378 0.00032059 -0.00018940 </velocity>
    <force> 0.01938624 -0.00758252 0.02459789 </force>
  </atom>
  <atom name="O29" species="oxygen">
    <position> -4.81898194 6.47380372 -3.64013939 </position>
    <velocity> -0.00008041 -0.00011328 0.00005432 </velocity>
    <force> -0.05962000 -0.02661384 -0.06208081 </force>
  </atom>
  <atom name="O30" species="oxygen">
    <position> -10.77417440 -0.59358481 22.04677261 </position>
    <velocity> 0.00037751 0.00015613 -0.00017598 </velocity>
    <force> 0.00824090 0.03258641 -0.01393113 </force>
  </atom>
  <atom name="O31" species="oxygen">
    <position> 4.42878505 -1.01388902 0.93506462 </position>
    <velocity> 0.00014803 0.00003596 0.00029736 </velocity>
    <force> 0.00054485 0.01373256 0.00517822 </force>
  </atom>
  <atom name="O32" species="oxygen">
    <position> 22.68930286 -0.70258415 -1.93355523 </position>
    <velocity> -0.00011020 0.00013507 0.00051075 </velocity>
    <force> -0.00877234 0.02523347 0.03608647 </force>
  </atom>
  <atom name="O33" species="oxygen">
    <position> -1.15396453 23.07054743 9.74248673 </position>
    <velocity> -0.00008860 0.00007655 -0.00003359 </velocity>
    <force> -0.00976598 -0.01502071 -0.01671390 </force>
  </atom>
  <atom name="O34" species="oxygen">
    <position> -13.43993292 -2.81956653 18.13988490 </position>
    <velocity> -0.00026695 0.00002180 0.00014927 </velocity>
    <force> 0.00128534 -0.00147691 0.00154757 </force>
  </atom>
  <atom name="O35" species="oxygen">
    <position> 4.05160792 -2.42769182 -17.76534906 </position>
    <velocity> 0.00005514 -0.00009080 0.00022543 </velocity>
    <force> 0.02443227 0.00007633 0.06264779 </force>
  </atom>
  <atom name="O36" species="oxygen">
    <position> 7.51380787 6.72142360 -40.40078254 </position>
    <velocity> -0.00034589 -0.00004348 -0.00008337 </velocity>
    <force> 0.00307956 -0.00130076 -0.00200993 </force>
  </atom>
  <atom name="O37" species="oxygen">
    <position> -10.81022504 -1.21894734 5.74284609 </position>
    <velocity> -0.00026769 -0.00001125 -0.00001630 </velocity>
    <force> 0.00167035 -0.01553370 -0.01187984 </force>
  </atom>
  <atom name="O38" species="oxygen">
    <position> 1.46772086 11.75872307 17.40993879 </position>
    <velocity> -0.00012718 0.00011753 0.00010446 </velocity>
    <force> 0.00789955 0.00320544 -0.00912009 </force>
  </atom>
  <atom name="O39" species="oxygen">
    <position> 7.70314786 9.92864911 -11.64777024 </position>
    <velocity> 0.00014044 -0.00003152 0.00012282 </velocity>
    <force> -0.01297691 -0.05247155 0.04151247 </force>
  </atom>
  <atom name="O40" species="oxygen">
    <position> -16.34934407 -7.51364078 12.49085410 </position>
    <velocity> 0.00040824 0.00021953 0.00017646 </velocity>
    <force> 0.01075817 -0.02968929 0.01988684 </force>
  </atom>
  <atom name="O41" species="oxygen">
    <position> 14.21329411 4.04193186 -2.27765190 </position>
    <velocity> -0.00006370 0.00013069 0.00017773 </velocity>
    <force> 0.03443750 0.02498711 0.02080357 </force>
  </atom>
  <atom name="O42" species="oxygen">
    <position> -9.69660302 16.84845972 16.02103045 </position>
    <velocity> -0.00010313 -0.00012023 0.00018150 </velocity>
    <force> 0.04188805 -0.02068313 -0.02235756 </force>
  </atom>
  <atom name="O43" species="oxygen">
    <position> -5.15242233 -4.68201260 -8.36355985 </position>
    <velocity> 0.00004222 0.00010919 -0.00010666 </velocity>
    <force> 0.01892660 -0.02817049 0.01895977 </force>
  </atom>
  <atom name="O44" species="oxygen">
    <position> -11.07382579 -11.32396783 15.73481375 </position>
    <velocity> -0.00006469 0.00038071 0.00017891 </velocity>
    <force> 0.05468294 0.02416918 -0.07202952 </force>
  </atom>
  <atom name="O45" species="oxygen">
    <position> -7.54271942 26.41558777 4.56384312 </position>
    <velocity> 0.00041052 -0.00026835 -0.00038831 </velocity>
    <force> 0.00234369 -0.00362946 0.03794172 </force>
  </atom>
  <atom name="O46" species="oxygen">
    <position> 12.84744757 -5.29544894 -14.58952998 </position>
    <velocity> -0.00037874 -0.00016024 0.00029816 </velocity>
    <force> 0.00654338 -0.01929921 0.04211748 </force>
  </atom>
  <atom name="O47" species="oxygen">
    <position> -3.70656168 -0.92005822 3.36343469 </position>
    <velocity> 0.00049224 -0.00034725 -0.00028054 </velocity>
    <force> 0.04103433 -0.03786519 -0.00270253 </force>
  </atom>
  <atom name="O48" species="oxygen">
    <position> -20.15373045 -18.78269441 -17.69653728 </position>
    <velocity> -0.00014068 0.00016390 0.00004900 </velocity>
    <force> 0.00310824 -0.04113419 -0.02204668 </force>
  </atom>
  <atom name="O49" species="oxygen">
    <position> -39.03245759 2.31356808 -24.17961466 </position>
    <velocity> -0.00016213 0.00030632 -0.00010374 </velocity>
    <force> 0.00990620 -0.00015116 0.00309747 </force>
  </atom>
  <atom name="O50" species="oxygen">
    <position> 32.37824442 16.00900164 -3.15375906 </position>
    <velocity> 0.00008767 -0.00006926 -0.00014371 </velocity>
    <force> -0.00097968 0.00388518 -0.00153683 </force>
  </atom>
  <atom name="O51" species="oxygen">
    <position> 11.40131992 4.03147874 -6.13245217 </position>
    <velocity> -0.00017732 -0.00006469 0.00003156 </velocity>
    <force> 0.03029418 0.02539197 -0.00931866 </force>
  </atom>
  <atom name="O52" species="oxygen">
    <position> -1.99984830 2.71631249 18.13097323 </position>
    <velocity> 0.00007846 -0.00026362 0.00000032 </velocity>
    <force> -0.01634799 0.02058335 -0.04909541 </force>
  </atom>
  <atom name="O53" species="oxygen">
    <position> 19.91338201 -10.31738870 -6.96415554 </position>
    <velocity> 0.00009935 0.00034643 -0.00031333 </velocity>
    <force> 0.02560699 0.00133102 -0.00935297 </force>
  </atom>
  <atom name="O54" species="oxygen">
    <position> 0.05084987 -8.56184637 12.55022405 </position>
    <velocity> -0.00031286 -0.00006401 -0.00014295 </velocity>
    <force> -0.02256556 -0.00954470 0.02042535 </force>
  </atom>
  <atom name="O55" species="oxygen">
    <position> 18.01837433 -3.35963549 -0.57102585 </position>
    <velocity> -0.00002745 -0.00013538 0.00002053 </velocity>
    <force> -0.00793547 -0.01397609 0.00401798 </force>
  </atom>
  <atom name="O56" species="oxygen">
    <position> 23.52208421 -5.37989699 17.34588503 </position>
    <velocity> 0.00028647 -0.00029659 0.00002952 </velocity>
    <force> 0.00762045 0.00427758 0.01140656 </force>
  </atom>
  <atom name="O57" species="oxygen">
    <position> 2.68593360 32.48076323 -24.49117981 </position>
    <velocity> 0.00012279 -0.00008552 0.00008497 </velocity>
    <force> 0.00819666 0.03193596 0.00420779 </force>
  </atom>
  <atom name="O58" species="oxygen">
    <position> 5.18254548 1.41940109 -14.60323592 </position>
    <velocity> 0.00000338 0.00009141 0.00018448 </velocity>
    <force> 0.06237548 -0.00517954 0.03245045 </force>
  </atom>
  <atom name="O59" species="oxygen">
    <position> -2.10241863 -15.85973073 -22.92333352 </position>
    <velocity> 0.00013749 -0.00003931 -0.00003936 </velocity>
    <force> -0.02202762 0.00802166 0.01342076 </force>
  </atom>
  <atom name="O60" species="oxygen">
    <position> -27.38598915 -13.22800829 10.47886815 </position>
    <velocity> -0.00023766 -0.00016846 0.00003753 </velocity>
    <force> 0.01539422 0.02481785 -0.00754503 </force>
  </atom>
  <atom name="O61" species="oxygen">
    <position> -3.87938958 4.43069909 -15.47909917 </position>
    <velocity> -0.00016780 0.00012550 -0.00026194 </velocity>
    <force> -0.00273059 -0.00475015 0.01913725 </force>
  </atom>
  <atom name="O62" species="oxygen">
    <position> -6.01393892 -7.13921153 33.46985211 </position>
    <velocity> 0.00014415 -0.00019983 0.00000442 </velocity>
    <force> -0.02951622 -0.02103804 0.04655134 </force>
  </atom>
  <atom name="O63" species="oxygen">
    <position> -20.90509121 -8.13864413 31.69421250 </position>
    <velocity> -0.00027248 0.00005289 0.00023840 </velocity>
    <force> 0.00510117 0.00079771 -0.01341280 </force>
  </atom>
  <atom name="O64" species="oxygen">
    <position> 12.30628464 6.56285361 25.72740259 </position>
    <velocity> 0.00026872 -0.00005131 0.00030164 </velocity>
    <force> -0.00443552 -0.00291923 -0.01276102 </force>
  </atom>
  <atom name="H1" species="hydrogen">
    <position> -5.95267190 7.23074819 13.83179953 </position>
    <velocity> -0.00071145 0.00028479 -0.00002333 </velocity>
    <force> -0.02067092 -0.02151748 -0.02218612 </force>
  </atom>
  <atom name="H2" species="hydrogen">
    <position> -8.11747028 6.50890424 11.90226334 </position>
    <velocity> -0.00004668 -0.00034736 0.00038494 </velocity>
    <force> -0.04019726 0.01957090 -0.00597339 </force>
  </atom>
  <atom name="H3" species="hydrogen">
    <position> 24.70944717 2.75439032 26.51690751 </position>
    <velocity> 0.00053101 0.00074498 -0.00091969 </velocity>
    <force> -0.01479215 0.00603235 -0.00541830 </force>
  </atom>
  <atom name="H4" species="hydrogen">
    <position> 21.98997458 1.42002545 26.45070117 </position>
    <velocity> -0.00053518 0.00033927 -0.00049269 </velocity>
    <force> 0.00924823 0.00932623 -0.01297949 </force>
  </atom>
  <atom name="H5" species="hydrogen">
    <position> -27.64114717 24.47820890 -31.84981548 </position>
    <velocity> -0.00088419 -0.00077848 0.00054259 </velocity>
    <force> -0.00181574 0.00347504 0.00418676 </force>
  </atom>
  <atom name="H6" species="hydrogen">
    <position> -27.82157568 23.82686422 -34.67036268 </position>
    <velocity> -0.00034318 -0.00023975 0.00085457 </velocity>
    <force> 0.00210681 -0.00045786 -0.00265596 </force>
  </atom>
  <atom name="H7" species="hydrogen">
    <position> 12.62547705 -10.30301609 1.01492730 </position>
    <velocity> -0.00018793 0.00040557 0.00055032 </velocity>
    <force> 0.01001365 0.02527936 -0.04117146 </force>
  </atom>
  <atom name="H8" species="hydrogen">
    <position> 11.73301107 -8.76881535 -1.73011745 </position>
    <velocity> -0.00003010 0.00023412 -0.00012429 </velocity>
    <force> -0.00393902 -0.00711289 0.01299814 </force>
  </atom>
  <atom name="H9" species="hydrogen">
    <position> 5.51633429 -21.06802714 -6.14414556 </position>
    <velocity> 0.00039131 -0.00061822 0.00033452 </velocity>
    <force> -0.00343606 -0.00554466 0.00479665 </force>
  </atom>
  <atom name="H10" species="hydrogen">
    <position> 6.93503139 -22.27370092 -3.73972585 </position>
    <velocity> 0.00003150 -0.00049358 0.00019811 </velocity>
    <force> -0.00888363 0.00524718 -0.03997194 </force>
  </atom>
  <atom name="H11" species="hydrogen">
    <position> 7.14639803 17.06660668 3.45372302 </position>
    <velocity> -0.00005049 0.00056806 -0.00053019 </velocity>
    <force> 0.01902350 -0.00150891 0.02438384 </force>
  </atom>
  <atom name="H12" species="hydrogen">
    <position> 9.61882958 17.76405323 5.04638406 </position>
    <velocity> -0.00085226 0.00004512 0.00040432 </velocity>
    <force> 0.01377929 0.00673317 -0.00234342 </force>
  </atom>
  <atom name="H13" species="hydrogen">
    <position> -4.19964395 -27.38840746 -18.66376776 </position>
    <velocity> 0.00072521 -0.00024334 0.00116920 </velocity>
    <force> -0.00151460 0.00962303 0.01438040 </force>
  </atom>
  <atom name="H14" species="hydrogen">
    <position> -3.96784229 -30.08376871 -19.45836721 </position>
    <velocity> 0.00045430 -0.00006160 -0.00026310 </velocity>
    <force> 0.00751244 -0.02328350 -0.01294551 </force>
  </atom>
  <atom name="H15" species="hydrogen">
    <position> 1.53695574 -14.55822761 12.15960730 </position>
    <velocity> -0.00053196 -0.00043409 0.00094326 </velocity>
    <force> 0.00819251 -0.00357902 0.00499345 </force>
  </atom>
  <atom name="H16" species="hydrogen">
    <position> 4.48060013 -14.43179138 12.77837454 </position>
    <velocity> -0.00070331 0.00016454 0.00041206 </velocity>
    <force> -0.00452697 0.00098867 0.00085682 </force>
  </atom>
  <atom name="H17" species="hydrogen">
    <position> 2.41987708 6.02166074 -7.40120257 </position>
    <velocity> -0.00005879 0.00025639 0.00030683 </velocity>
    <force> 0.00186196 -0.00705579 0.00286843 </force>
  </atom>
  <atom name="H18" species="hydrogen">
    <position> 0.96123352 3.99472357 -5.83586787 </position>
    <velocity> 0.00002805 0.00222203 -0.00105289 </velocity>
    <force> -0.04158375 -0.01093086 0.01130044 </force>
  </atom>
  <atom name="H19" species="hydrogen">
    <position> -0.84529079 6.65913999 8.32234936 </position>
    <velocity> -0.00047484 0.00031611 0.00020494 </velocity>
    <force> -0.00108804 -0.00781942 -0.00032873 </force>
  </atom>
  <atom name="H20" species="hydrogen">
    <position> -0.78052460 9.44287544 8.25271036 </position>
    <velocity> 0.00048596 -0.00037259 0.00007190 </velocity>
    <force> 0.00839631 -0.00232303 0.00017012 </force>
  </atom>
  <atom name="H21" species="hydrogen">
    <position> 11.52493454 -15.12471467 10.57730533 </position>
    <velocity> -0.00013659 0.00021714 -0.00004614 </velocity>
    <force> -0.00456088 -0.00208886 -0.00341330 </force>
  </atom>
  <atom name="H22" species="hydrogen">
    <position> 12.72603492 -13.14432173 12.23632693 </position>
    <velocity> -0.00022716 -0.00023939 0.00080179 </velocity>
    <force> 0.00242923 0.00201637 0.00653915 </force>
  </atom>
  <atom name="H23" species="hydrogen">
    <position> -12.33907776 -1.59253113 11.81880422 </position>
    <velocity> 0.00100755 -0.00051414 0.00044892 </velocity>
    <force> 0.00733281 0.02268469 -0.02082243 </force>
  </atom>
  <atom name="H24" species="hydrogen">
    <position> -12.32146811 -1.96950975 14.55634137 </position>
    <velocity> 0.00063417 -0.00019928 0.00013219 </velocity>
    <force> -0.00056324 -0.00094755 0.01424088 </force>
  </atom>
  <atom name="H25" species="hydrogen">
    <position> 0.52466509 -9.37063814 -21.31902081 </position>
    <velocity> 0.00018997 0.00006850 0.00011846 </velocity>
    <force> -0.01111100 0.00095592 -0.00476543 </force>
  </atom>
  <atom name="H26" species="hydrogen">
    <position> 3.06973768 -8.28222549 -22.32679961 </position>
    <velocity> -0.00049852 0.00054735 -0.00044481 </velocity>
    <force> 0.00812806 0.00632271 -0.00065382 </force>
  </atom>
  <atom name="H27" species="hydrogen">
    <position> -7.01619554 -9.56477524 -2.46680596 </position>
    <velocity> 0.00020611 0.00023994 0.00020972 </velocity>
    <force> -0.05690891 -0.01253048 -0.00090595 </force>
  </atom>
  <atom name="H28" species="hydrogen">
    <position> -4.55154367 -9.36059693 -4.19945451 </position>
    <velocity> 0.00047761 -0.00045772 0.00006556 </velocity>
    <force> -0.00619423 -0.00516988 0.00223486 </force>
  </atom>
  <atom name="H29" species="hydrogen">
    <position> 12.64827964 -13.70568192 3.56311516 </position>
    <velocity> 0.00056584 -0.00074347 -0.00073586 </velocity>
    <force> 0.00186536 0.00787353 0.00480165 </force>
  </atom>
  <atom name="H30" species="hydrogen">
    <position> 12.30256824 -11.50495778 5.48846237 </position>
    <velocity> 0.00062636 0.00008017 0.00005529 </velocity>
    <force> -0.04664960 0.01738654 0.05877064 </force>
  </atom>
  <atom name="H31" species="hydrogen">
    <position> -5.68779544 10.83195476 -7.28822738 </position>
    <velocity> 0.00010214 -0.00002453 -0.00127701 </velocity>
    <force> 0.00465029 0.00007013 0.00626669 </force>
  </atom>
  <atom name="H32" species="hydrogen">
    <position> -8.66430701 10.43875843 -7.36862462 </position>
    <velocity> -0.00070246 0.00076001 -0.00038173 </velocity>
    <force> 0.00900432 -0.00822733 0.00763102 </force>
  </atom>
  <atom name="H33" species="hydrogen">
    <position> -15.05698962 -13.82535823 -28.92181678 </position>
    <velocity> -0.00083612 0.00065706 0.00091073 </velocity>
    <force> 0.01164863 -0.00440490 0.02175912 </force>
  </atom>
  <atom name="H34" species="hydrogen">
    <position> -13.02133562 -15.92598287 -28.84864479 </position>
    <velocity> 0.00029239 0.00029667 -0.00072135 </velocity>
    <force> -0.00199445 0.00035812 0.01473420 </force>
  </atom>
  <atom name="H35" species="hydrogen">
    <position> -20.44404740 -0.96494211 14.69111413 </position>
    <velocity> -0.00014630 -0.00026087 0.00008130 </velocity>
    <force> -0.00564539 -0.00247691 -0.00793213 </force>
  </atom>
  <atom name="H36" species="hydrogen">
    <position> -18.16767544 -2.59613501 14.51066188 </position>
    <velocity> 0.00011234 0.00021131 0.00026927 </velocity>
    <force> 0.01479909 -0.00368652 0.00247826 </force>
  </atom>
  <atom name="H37" species="hydrogen">
    <position> 5.61971689 -15.52942073 0.54149850 </position>
    <velocity> 0.00007990 0.00023039 0.00133150 </velocity>
    <force> 0.01331059 -0.00744575 -0.01611979 </force>
  </atom>
  <atom name="H38" species="hydrogen">
    <position> 8.12763659 -15.41699948 -1.34931957 </position>
    <velocity> -0.00052223 -0.00049161 -0.00004096 </velocity>
    <force> -0.01485613 -0.00664073 0.01220506 </force>
  </atom>
  <atom name="H39" species="hydrogen">
    <position> 5.52690723 19.55745793 -23.08262573 </position>
    <velocity> -0.00019278 -0.00025320 0.00017468 </velocity>
    <force> -0.00360865 -0.00519425 0.00847347 </force>
  </atom>
  <atom name="H40" species="hydrogen">
    <position> 6.87489307 17.31280123 -24.47243915 </position>
    <velocity> -0.00020542 -0.00046809 0.00002450 </velocity>
    <force> 0.01389678 -0.01364087 -0.00748555 </force>
  </atom>
  <atom name="H41" species="hydrogen">
    <position> 3.82245845 1.90091567 11.41550776 </position>
    <velocity> 0.00038387 0.00008763 -0.00000026 </velocity>
    <force> -0.01223671 -0.00263148 0.00274624 </force>
  </atom>
  <atom name="H42" species="hydrogen">
    <position> 2.96605375 2.84924149 14.17856949 </position>
    <velocity> -0.00086127 -0.00018460 -0.00010593 </velocity>
    <force> -0.00684815 0.01216251 0.01434986 </force>
  </atom>
  <atom name="H43" species="hydrogen">
    <position> -8.59903824 -5.50009278 3.48074914 </position>
    <velocity> 0.00027632 -0.00071579 0.00081334 </velocity>
    <force> 0.00480883 0.00815797 0.00635300 </force>
  </atom>
  <atom name="H44" species="hydrogen">
    <position> -9.81246999 -6.36064794 1.10692717 </position>
    <velocity> 0.00088228 0.00146101 0.00013031 </velocity>
    <force> -0.01038934 -0.01789790 -0.02226059 </force>
  </atom>
  <atom name="H45" species="hydrogen">
    <position> -12.80427138 -9.31091448 8.46493647 </position>
    <velocity> 0.00060098 -0.00002185 -0.00018155 </velocity>
    <force> -0.00605132 -0.01625916 0.00155061 </force>
  </atom>
  <atom name="H46" species="hydrogen">
    <position> -14.67009600 -9.58197728 6.45077444 </position>
    <velocity> 0.00042566 -0.00012249 0.00027052 </velocity>
    <force> -0.01237649 0.00722530 -0.01026947 </force>
  </atom>
  <atom name="H47" species="hydrogen">
    <position> 16.74825948 -13.15129894 4.59102176 </position>
    <velocity> 0.00005464 -0.00066444 0.00029250 </velocity>
    <force> -0.00140305 0.01474543 -0.01002184 </force>
  </atom>
  <atom name="H48" species="hydrogen">
    <position> 18.68323634 -14.72495821 5.69751501 </position>
    <velocity> 0.00110050 -0.00049662 -0.00012379 </velocity>
    <force> 0.01826748 -0.02434116 0.02240806 </force>
  </atom>
  <atom name="H49" species="hydrogen">
    <position> 19.89250345 13.03266574 3.12811628 </position>
    <velocity> -0.00026907 0.00056401 -0.00051257 </velocity>
    <force> -0.00584671 -0.02044787 0.01638351 </force>
  </atom>
  <atom name="H50" species="hydrogen">
    <position> 19.37945300 14.24606325 0.53763587 </position>
    <velocity> 0.00042357 -0.00024002 -0.00018227 </velocity>
    <force> 0.00409838 -0.00033352 -0.01321252 </force>
  </atom>
  <atom name="H51" species="hydrogen">
    <position> 6.84106572 14.32504462 -31.54888226 </position>
    <velocity> 0.00060772 0.00031831 0.00020084 </velocity>
    <force> 0.00081777 -0.01525909 0.00731553 </force>
  </atom>
  <atom name="H52" species="hydrogen">
    <position> 4.82907447 12.91446011 -29.92010405 </position>
    <velocity> -0.00070202 0.00059769 -0.00073345 </velocity>
    <force> -0.00224488 -0.00343977 0.00148301 </force>
  </atom>
  <atom name="H53" species="hydrogen">
    <position> 14.64854273 -22.29789064 -10.20992647 </position>
    <velocity> -0.00090067 0.00031627 0.00036007 </velocity>
    <force> -0.01214586 0.00862011 0.00035234 </force>
  </atom>
  <atom name="H54" species="hydrogen">
    <position> 12.65887866 -20.68817168 -8.66419506 </position>
    <velocity> 0.00099643 -0.00029812 0.00039264 </velocity>
    <force> -0.00603439 -0.00664875 -0.01069968 </force>
  </atom>
  <atom name="H55" species="hydrogen">
    <position> 11.23163781 2.80356976 -16.00043549 </position>
    <velocity> -0.00062030 0.00074060 -0.00118787 </velocity>
    <force> -0.00013642 -0.00877250 -0.01732612 </force>
  </atom>
  <atom name="H56" species="hydrogen">
    <position> 12.02334383 3.20632270 -13.25428512 </position>
    <velocity> -0.00028950 -0.00069147 0.00015942 </velocity>
    <force> -0.02408463 0.00636093 0.00154932 </force>
  </atom>
  <atom name="H57" species="hydrogen">
    <position> -4.06285720 7.04779479 -2.15980055 </position>
    <velocity> -0.00032599 -0.00013341 0.00006106 </velocity>
    <force> 0.02499431 0.02783359 0.05009128 </force>
  </atom>
  <atom name="H58" species="hydrogen">
    <position> -6.16755283 7.59451590 -4.49182374 </position>
    <velocity> -0.00004593 -0.00021538 -0.00045938 </velocity>
    <force> 0.02864157 0.00253429 0.00633361 </force>
  </atom>
  <atom name="H59" species="hydrogen">
    <position> -10.34815846 -1.62380961 23.45489865 </position>
    <velocity> 0.00072479 -0.00022295 -0.00031701 </velocity>
    <force> 0.00790717 -0.02586041 0.01834008 </force>
  </atom>
  <atom name="H60" species="hydrogen">
    <position> -9.36924884 0.72818666 21.99265101 </position>
    <velocity> -0.00034311 -0.00015885 -0.00052676 </velocity>
    <force> -0.02367883 -0.01025596 -0.00451552 </force>
  </atom>
  <atom name="H61" species="hydrogen">
    <position> 5.56959982 0.49432647 0.69485302 </position>
    <velocity> 0.00146275 0.00049472 -0.00001753 </velocity>
    <force> -0.00649634 -0.01337574 -0.00198326 </force>
  </atom>
  <atom name="H62" species="hydrogen">
    <position> 4.11129045 -1.13168869 2.80826469 </position>
    <velocity> -0.00024587 0.00036759 -0.00039546 </velocity>
    <force> 0.00621525 -0.00487031 -0.01010510 </force>
  </atom>
  <atom name="H63" species="hydrogen">
    <position> 23.67094579 -0.29536540 -0.34173981 </position>
    <velocity> -0.00054688 0.00056626 -0.00083606 </velocity>
    <force> -0.01139694 0.00647091 -0.01627772 </force>
  </atom>
  <atom name="H64" species="hydrogen">
    <position> 23.57058393 -2.06283108 -2.62485468 </position>
    <velocity> -0.00017280 0.00003161 -0.00088187 </velocity>
    <force> 0.02176319 -0.03523345 -0.02194846 </force>
  </atom>
  <atom name="H65" species="hydrogen">
    <position> -0.39869242 21.64628378 8.81439039 </position>
    <velocity> 0.00039008 -0.00015568 0.00000298 </velocity>
    <force> -0.01132828 0.00561320 -0.00227429 </force>
  </atom>
  <atom name="H66" species="hydrogen">
    <position> 0.23293141 23.51918521 10.83651807 </position>
    <velocity> 0.00139050 0.00022359 0.00103501 </velocity>
    <force> 0.01238978 0.01638640 0.01936317 </force>
  </atom>
  <atom name="H67" species="hydrogen">
    <position> -12.44377855 -1.83387325 19.36431367 </position>
    <velocity> 0.00001605 -0.00012783 0.00085110 </velocity>
    <force> 0.00647972 -0.00113608 0.00870711 </force>
  </atom>
  <atom name="H68" species="hydrogen">
    <position> -14.86066967 -1.66525591 17.74092706 </position>
    <velocity> -0.00007058 0.00039000 -0.00106136 </velocity>
    <force> -0.00111219 -0.00164805 -0.00356098 </force>
  </atom>
  <atom name="H69" species="hydrogen">
    <position> 4.63442462 -1.30990068 -16.20208052 </position>
    <velocity> -0.00032180 -0.00107074 -0.00004118 </velocity>
    <force> -0.02077417 -0.00027354 -0.03556610 </force>
  </atom>
  <atom name="H70" species="hydrogen">
    <position> 5.31715097 -3.76205719 -17.32211732 </position>
    <velocity> 0.00026461 0.00047802 -0.00005364 </velocity>
    <force> -0.00414238 -0.00205873 -0.02228600 </force>
  </atom>
  <atom name="H71" species="hydrogen">
    <position> 7.95340672 8.48276610 -40.38380857 </position>
    <velocity> -0.00067182 -0.00043888 0.00030554 </velocity>
    <force> 0.00505971 0.01017532 0.00016867 </force>
  </atom>
  <atom name="H72" species="hydrogen">
    <position> 8.56165729 5.85385364 -39.12268912 </position>
    <velocity> 0.00050045 -0.00056060 -0.00072641 </velocity>
    <force> 0.00438204 0.00261604 -0.00143424 </force>
  </atom>
  <atom name="H73" species="hydrogen">
    <position> -10.48155658 -2.58334496 7.08928448 </position>
    <velocity> -0.00082622 0.00095299 0.00013070 </velocity>
    <force> -0.00453007 0.00888903 -0.01786317 </force>
  </atom>
  <atom name="H74" species="hydrogen">
    <position> -10.90579808 -2.19861964 4.06442485 </position>
    <velocity> 0.00001247 0.00043061 0.00042852 </velocity>
    <force> 0.00368501 0.01234375 0.03418478 </force>
  </atom>
  <atom name="H75" species="hydrogen">
    <position> 2.02018375 10.79885439 18.85163523 </position>
    <velocity> -0.00006212 0.00006083 -0.00056963 </velocity>
    <force> -0.00372944 -0.00676707 0.03465676 </force>
  </atom>
  <atom name="H76" species="hydrogen">
    <position> 2.04381884 10.50991327 16.12993594 </position>
    <velocity> -0.00006227 -0.00008151 0.00090232 </velocity>
    <force> -0.00607074 0.00428390 -0.02300352 </force>
  </atom>
  <atom name="H77" species="hydrogen">
    <position> 8.42653245 10.57261870 -10.07504174 </position>
    <velocity> -0.00050510 0.00031370 0.00026055 </velocity>
    <force> -0.00050360 0.01237341 -0.01050638 </force>
  </atom>
  <atom name="H78" species="hydrogen">
    <position> 7.78100146 11.04154781 -13.01490379 </position>
    <velocity> -0.00155911 -0.00087181 0.00045782 </velocity>
    <force> 0.01194860 0.04027227 -0.02969693 </force>
  </atom>
  <atom name="H79" species="hydrogen">
    <position> -17.57178584 -7.60963357 11.19505689 </position>
    <velocity> 0.00071424 0.00044971 0.00020065 </velocity>
    <force> -0.02632224 -0.00949221 -0.02467947 </force>
  </atom>
  <atom name="H80" species="hydrogen">
    <position> -15.95418537 -5.78597153 12.53755086 </position>
    <velocity> -0.00104634 -0.00056562 -0.00076241 </velocity>
    <force> 0.01796907 0.03987552 0.00582322 </force>
  </atom>
  <atom name="H81" species="hydrogen">
    <position> 15.99777919 4.80580341 -2.72468590 </position>
    <velocity> 0.00007606 0.00007182 -0.00004445 </velocity>
    <force> -0.02277887 -0.01085137 0.00407537 </force>
  </atom>
  <atom name="H82" species="hydrogen">
    <position> 13.70429742 5.11162467 -0.76692655 </position>
    <velocity> 0.00002729 0.00118759 0.00057296 </velocity>
    <force> 0.00263560 -0.01009403 -0.01174502 </force>
  </atom>
  <atom name="H83" species="hydrogen">
    <position> -7.85389358 17.41025807 15.75008119 </position>
    <velocity> 0.00054745 0.00181504 0.00006059 </velocity>
    <force> -0.02268891 0.00158576 0.00394416 </force>
  </atom>
  <atom name="H84" species="hydrogen">
    <position> -10.52464877 18.14437091 16.92932407 </position>
    <velocity> -0.00020250 -0.00062564 -0.00017348 </velocity>
    <force> -0.01716459 0.02041048 0.01382202 </force>
  </atom>
  <atom name="H85" species="hydrogen">
    <position> -4.94408278 -3.06282718 -9.17253489 </position>
    <velocity> -0.00012281 0.00066839 -0.00042276 </velocity>
    <force> -0.00591148 0.02690075 -0.00616700 </force>
  </atom>
  <atom name="H86" species="hydrogen">
    <position> -3.70524036 -4.75174964 -7.14882930 </position>
    <velocity> 0.00029600 0.00008717 0.00058460 </velocity>
    <force> -0.00748580 -0.00360352 -0.01143353 </force>
  </atom>
  <atom name="H87" species="hydrogen">
    <position> -12.17382016 -11.36268006 17.07054626 </position>
    <velocity> 0.00007780 0.00052368 0.00012551 </velocity>
    <force> -0.03825849 0.00109976 0.05435205 </force>
  </atom>
  <atom name="H88" species="hydrogen">
    <position> -10.30207479 -9.47509100 15.55892613 </position>
    <velocity> 0.00009922 0.00042814 0.00005394 </velocity>
    <force> -0.02386797 -0.02076719 0.01453092 </force>
  </atom>
  <atom name="H89" species="hydrogen">
    <position> -8.61077990 25.01893251 5.28469911 </position>
    <velocity> -0.00021028 -0.00038596 -0.00035407 </velocity>
    <force> 0.00040710 0.00228189 -0.01008280 </force>
  </atom>
  <atom name="H90" species="hydrogen">
    <position> -6.45797045 26.87440267 6.15041689 </position>
    <velocity> -0.00109927 -0.00130512 0.00020798 </velocity>
    <force> -0.00941061 0.00010097 -0.03142666 </force>
  </atom>
  <atom name="H91" species="hydrogen">
    <position> 11.94672863 -4.91542655 -12.88733573 </position>
    <velocity> 0.00016894 0.00023081 -0.00037794 </velocity>
    <force> 0.02030935 -0.00960914 -0.03068381 </force>
  </atom>
  <atom name="H92" species="hydrogen">
    <position> 14.50608711 -6.35515151 -14.08257773 </position>
    <velocity> -0.00033490 0.00026278 -0.00048437 </velocity>
    <force> -0.02621878 0.03029469 -0.00536784 </force>
  </atom>
  <atom name="H93" species="hydrogen">
    <position> -4.01003271 -2.28678172 2.05424475 </position>
    <velocity> -0.00063860 -0.00035445 -0.00008186 </velocity>
    <force> 0.00106681 0.01611061 -0.00378922 </force>
  </atom>
  <atom name="H94" species="hydrogen">
    <position> -5.29722068 -0.17779161 3.49994537 </position>
    <velocity> -0.00045685 -0.00110644 0.00011951 </velocity>
    <force> -0.04481618 0.02975967 0.00645931 </force>
  </atom>
  <atom name="H95" species="hydrogen">
    <position> -18.53536571 -17.96713727 -17.97638506 </position>
    <velocity> 0.00014780 0.00087434 0.00046128 </velocity>
    <force> 0.02115856 0.00720248 -0.00583684 </force>
  </atom>
  <atom name="H96" species="hydrogen">
    <position> -21.01471187 -17.43194651 -16.91053596 </position>
    <velocity> -0.00013765 0.00005627 -0.00008929 </velocity>
    <force> -0.02844772 0.02913903 0.01712254 </force>
  </atom>
  <atom name="H97" species="hydrogen">
    <position> -38.81959221 4.11639691 -23.61033097 </position>
    <velocity> -0.00068992 0.00045102 -0.00041255 </velocity>
    <force> -0.01801695 0.00013371 -0.00841550 </force>
  </atom>
  <atom name="H98" species="hydrogen">
    <position> -37.35569339 1.52964969 -24.05583180 </position>
    <velocity> 0.00038733 0.00041460 -0.00075586 </velocity>
    <force> 0.00418502 -0.00670742 -0.00002604 </force>
  </atom>
  <atom name="H99" species="hydrogen">
    <position> 32.74988919 17.65457939 -4.01019534 </position>
    <velocity> -0.00000998 -0.00026570 0.00112014 </velocity>
    <force> -0.00273868 -0.00454304 -0.00239913 </force>
  </atom>
  <atom name="H100" species="hydrogen">
    <position> 31.23604397 14.97695897 -4.26252015 </position>
    <velocity> 0.00075838 -0.00048393 0.00021641 </velocity>
    <force> 0.00974529 0.00263339 -0.00228438 </force>
  </atom>
  <atom name="H101" species="hydrogen">
    <position> 9.79381790 3.31004442 -5.95413660 </position>
    <velocity> -0.00128726 0.00021032 -0.00075967 </velocity>
    <force> -0.04262590 -0.02313060 0.00158695 </force>
  </atom>
  <atom name="H102" species="hydrogen">
    <position> 12.26876451 3.86596369 -4.45608296 </position>
    <velocity> 0.00143172 0.00047274 -0.00119497 </velocity>
    <force> 0.00747615 0.00364013 -0.00119524 </force>
  </atom>
  <atom name="H103" species="hydrogen">
    <position> -3.42996795 3.79388073 18.66134000 </position>
    <velocity> -0.00029007 -0.00066104 0.00039037 </velocity>
    <force> 0.00679913 0.00736762 0.00424597 </force>
  </atom>
  <atom name="H104" species="hydrogen">
    <position> -1.48610898 1.70435452 19.49988753 </position>
    <velocity> 0.00033470 0.00022101 -0.00039560 </velocity>
    <force> 0.00816450 -0.03043743 0.03757350 </force>
  </atom>
  <atom name="H105" species="hydrogen">
    <position> 21.77104752 -10.83359214 -6.93675462 </position>
    <velocity> 0.00012526 0.00072130 -0.00009796 </velocity>
    <force> -0.01576737 0.00011837 0.00534096 </force>
  </atom>
  <atom name="H106" species="hydrogen">
    <position> 19.85700170 -9.22958710 -8.45998541 </position>
    <velocity> 0.00067553 -0.00057050 0.00110337 </velocity>
    <force> 0.00159528 0.00114222 -0.00082065 </force>
  </atom>
  <atom name="H107" species="hydrogen">
    <position> 0.91976696 -8.49071268 10.94539663 </position>
    <velocity> -0.00030898 0.00088901 -0.00050030 </velocity>
    <force> 0.01084759 0.00758738 -0.00862234 </force>
  </atom>
  <atom name="H108" species="hydrogen">
    <position> 0.80704113 -7.48252407 13.83334839 </position>
    <velocity> 0.00081945 -0.00022323 -0.00014663 </velocity>
    <force> 0.00332792 0.00515519 -0.00488612 </force>
  </atom>
  <atom name="H109" species="hydrogen">
    <position> 18.13141011 -5.09540669 -1.21980529 </position>
    <velocity> -0.00013724 -0.00049778 -0.00026729 </velocity>
    <force> -0.00275417 -0.00252860 0.00010176 </force>
  </atom>
  <atom name="H110" species="hydrogen">
    <position> 19.16678506 -2.41591099 -1.61309889 </position>
    <velocity> 0.00016963 -0.00009185 -0.00048183 </velocity>
    <force> 0.01643576 0.01192696 -0.01082707 </force>
  </atom>
  <atom name="H111" species="hydrogen">
    <position> 23.96608894 -6.74972414 18.52332991 </position>
    <velocity> -0.00048965 -0.00063837 0.00049353 </velocity>
    <force> 0.00056689 0.00822404 -0.00628557 </force>
  </atom>
  <atom name="H112" species="hydrogen">
    <position> 25.03892171 -4.21750231 17.16404161 </position>
    <velocity> 0.00004732 0.00031360 0.00027398 </velocity>
    <force> -0.01017325 -0.01589234 -0.00624940 </force>
  </atom>
  <atom name="H113" species="hydrogen">
    <position> 2.32171518 34.13218051 -23.59721855 </position>
    <velocity> 0.00040714 0.00002585 -0.00020000 </velocity>
    <force> 0.00933095 -0.00989336 -0.00475473 </force>
  </atom>
  <atom name="H114" species="hydrogen">
    <position> 1.13771882 31.58848185 -24.10050673 </position>
    <velocity> -0.00031873 -0.00050145 -0.00014389 </velocity>
    <force> -0.01598469 -0.01062288 0.00318634 </force>
  </atom>
  <atom name="H115" species="hydrogen">
    <position> 6.96093786 1.85969318 -13.86726856 </position>
    <velocity> -0.00010382 -0.00046057 -0.00045149 </velocity>
    <force> -0.03368315 -0.01118617 -0.02368328 </force>
  </atom>
  <atom name="H116" species="hydrogen">
    <position> 4.72649841 2.86939496 -15.69672830 </position>
    <velocity> -0.00012539 -0.00056930 0.00046279 </velocity>
    <force> -0.01404813 0.00987607 -0.01308057 </force>
  </atom>
  <atom name="H117" species="hydrogen">
    <position> -3.29497286 -14.73715718 -21.90021843 </position>
    <velocity> 0.00093452 0.00019068 0.00084208 </velocity>
    <force> 0.01982535 -0.01863068 -0.00677631 </force>
  </atom>
  <atom name="H118" species="hydrogen">
    <position> -1.99475318 -17.50869783 -22.02189779 </position>
    <velocity> -0.00042516 -0.00161054 0.00062301 </velocity>
    <force> 0.00379124 0.00340858 -0.00210941 </force>
  </atom>
  <atom name="H119" species="hydrogen">
    <position> -28.98405961 -14.00772449 10.74059142 </position>
    <velocity> 0.00040527 -0.00029626 -0.00117541 </velocity>
    <force> -0.02083608 -0.02324887 0.00500813 </force>
  </atom>
  <atom name="H120" species="hydrogen">
    <position> -27.93604140 -11.48737107 10.17793475 </position>
    <velocity> 0.00102639 0.00038413 0.00089318 </velocity>
    <force> 0.00724759 0.00551151 0.00020148 </force>
  </atom>
  <atom name="H121" species="hydrogen">
    <position> -4.65050295 4.86367332 -13.77930967 </position>
    <velocity> -0.00070406 0.00049661 -0.00055411 </velocity>
    <force> 0.00124881 0.00265835 -0.00640262 </force>
  </atom>
  <atom name="H122" species="hydrogen">
    <position> -2.99885123 2.81136358 -15.14748805 </position>
    <velocity> -0.00025763 0.00016539 0.00002759 </velocity>
    <force> 0.00189262 0.00167753 -0.00277118 </force>
  </atom>
  <atom name="H123" species="hydrogen">
    <position> -5.19166313 -6.95412585 31.91485490 </position>
    <velocity> -0.00019656 0.00080505 0.00017515 </velocity>
    <force> 0.02684927 0.01506992 -0.04525958 </force>
  </atom>
  <atom name="H124" species="hydrogen">
    <position> -5.04083843 -6.33474295 34.81223789 </position>
    <velocity> 0.00022795 0.00107466 0.00027410 </velocity>
    <force> 0.00166703 0.00185387 0.00093887 </force>
  </atom>
  <atom name="H125" species="hydrogen">
    <position> -20.95353913 -9.27337188 30.22766006 </position>
    <velocity> 0.00020159 -0.00107973 0.00026444 </velocity>
    <force> 0.00164858 -0.00149093 0.00157775 </force>
  </atom>
  <atom name="H126" species="hydrogen">
    <position> -20.85286591 -6.48281976 30.86987206 </position>
    <velocity> 0.00028159 0.00036009 0.00053369 </velocity>
    <force> -0.00162078 0.00263626 0.00239584 </force>
  </atom>
  <atom name="H127" species="hydrogen">
    <position> 10.57240490 5.99159031 25.13266307 </position>
    <velocity> 0.00145920 -0.00070604 0.00003774 </velocity>
    <force> 0.02150773 0.01021435 0.02265356 </force>
  </atom>
  <atom name="H128" species="hydrogen">
    <position> 13.31781820 5.35268206 26.76782858 </position>
    <velocity> 0.00038302 -0.00045351 -0.00084428 </velocity>
    <force> -0.01150725 -0.00342601 -0.00545201 </force>
  </atom>
</atomset>
<unit_cell_a_norm> 23.460000 </unit_cell_a_norm>
<unit_cell_b_norm> 23.460000 </unit_cell_b_norm>
<unit_cell_c_norm> 23.460000 </unit_cell_c_norm>
<unit_cell_alpha>  90.000 </unit_cell_alpha>
<unit_cell_beta>   90.000 </unit_cell_beta>
<unit_cell_gamma>  90.000 </unit_cell_gamma>
<unit_cell_volume> 12911.718 </unit_cell_volume>
  <econst> -1100.15048207 </econst>
  <ekin_ion> 0.35384702 </ekin_ion>
  <temp_ion> 387.99156053 </temp_ion>
  total_electronic_charge: 512.00000000
  <eigenvalue_sum>  -162.48456023 </eigenvalue_sum>
  <etotal_int>   -1100.50280531 </etotal_int>
  total_electronic_charge: 512.00000000
  <eigenvalue_sum>  -162.49055053 </eigenvalue_sum>
  Anderson extrapolation: theta=1.22330114 (1.22330114)
  <etotal_int>   -1100.50286508 </etotal_int>
  total_electronic_charge: 512.00000000
  <eigenvalue_sum>  -162.49788715 </eigenvalue_sum>
  Anderson extrapolation: theta=0.06925862 (0.06925862)
  <etotal_int>   -1100.50289982 </etotal_int>
  total_electronic_charge: 512.00000000
  <eigenvalue_sum>  -162.49846257 </eigenvalue_sum>
  Anderson extrapolation: theta=1.83232921 (1.83232921)
  <etotal_int>   -1100.50290167 </etotal_int>
  total_electronic_charge: 512.00000000
  <eigenvalue_sum>  -162.49959462 </eigenvalue_sum>
  Anderson extrapolation: theta=0.25245352 (0.25245352)
  <etotal_int>   -1100.50290348 </etotal_int>
  <timing name="iteration" min="    5.783" max="    5.801"/>
</iteration>
<iteration count="10">
  total_electronic_charge: 512.00000000
  <ekin>       808.66181028 </ekin>
  <econf>        0.00000000 </econf>
  <eps>      -1309.99014003 </eps>
  <enl>        124.83074674 </enl>
  <ecoul>     -452.95846173 </ecoul>
  <exc>       -271.04685913 </exc>
  <esr>         93.77410455 </esr>
  <eself>      646.81841729 </eself>
  <ets>          0.00000000 </ets>
  <eexf>         0.00000000 </eexf>
  <etotal>   -1100.50290386 </etotal>
  <epv>          0.00000000 </epv>
  <eefield>      0.00000000 </eefield>
  <enthalpy> -1100.50290386 </enthalpy>
<atomset>
<unit_cell 
    a=" 23.46000000   0.00000000   0.00000000"
    b="  0.00000000  23.46000000   0.00000000"
    c="  0.00000000   0.00000000  23.46000000" />
  <atom name="O1" species="oxygen">
    <position> -6.49269281 5.99914557 12.40712617 </position>
    <velocity> -0.00000918 -0.00020975 0.00037013 </velocity>
    <force> 0.06284820 -0.00369040 0.02901745 </force>
  </atom>
  <atom name="O2" species="oxygen">
    <position> 23.13591026 2.61595073 25.47857453 </position>
    <velocity> 0.00000265 0.00003584 -0.00016900 </velocity>
    <force> 0.00388715 -0.00642259 0.01885108 </force>
  </atom>
  <atom name="O3" species="oxygen">
    <position> -28.80842938 23.74454992 -33.10769298 </position>
    <velocity> -0.00012395 0.00012644 -0.00015808 </velocity>
    <force> 0.00427167 -0.00558430 -0.00032427 </force>
  </atom>
  <atom name="O4" species="oxygen">
    <position> 13.17067149 -9.23338484 -0.59243983 </position>
    <velocity> 0.00007596 -0.00028504 0.00017657 </velocity>
    <force> -0.00581978 -0.01824402 0.03028948 </force>
  </atom>
  <atom name="O5" species="oxygen">
    <position> 6.69079995 -22.46971857 -5.72084916 </position>
    <velocity> 0.00028368 0.00004525 -0.00039488 </velocity>
    <force> 0.01102956 0.01027322 0.04507822 </force>
  </atom>
  <atom name="O6" species="oxygen">
    <position> 8.02524533 16.91300674 5.26239332 </position>
    <velocity> 0.00003050 -0.00022970 0.00029417 </velocity>
    <force> -0.03933516 -0.00307985 -0.03267019 </force>
  </atom>
  <atom name="O7" species="oxygen">
    <position> -4.61717803 -29.09264878 -18.06557885 </position>
    <velocity> -0.00003770 0.00051311 -0.00027196 </velocity>
    <force> -0.00858416 0.00375009 0.00666258 </force>
  </atom>
  <atom name="O8" species="oxygen">
    <position> 2.77934846 -14.73110880 13.55445323 </position>
    <velocity> -0.00005848 -0.00044434 0.00019065 </velocity>
    <force> -0.00185827 -0.00233387 -0.00367309 </force>
  </atom>
  <atom name="O9" species="oxygen">
    <position> 2.58858769 4.40051008 -6.47535544 </position>
    <velocity> -0.00022033 0.00003332 -0.00042353 </velocity>
    <force> 0.05172073 0.02631562 -0.01724362 </force>
  </atom>
  <atom name="O10" species="oxygen">
    <position> 0.41953845 8.01104413 8.13627208 </position>
    <velocity> 0.00010862 0.00032105 0.00023092 </velocity>
    <force> -0.01351864 0.00902007 0.00793290 </force>
  </atom>
  <atom name="O11" species="oxygen">
    <position> 13.17247639 -14.43201772 10.99465983 </position>
    <velocity> -0.00006582 0.00009388 -0.00002060 </velocity>
    <force> -0.00099433 0.00251484 -0.00249138 </force>
  </atom>
  <atom name="O12" species="oxygen">
    <position> -13.17566626 -2.57080067 13.05771111 </position>
    <velocity> 0.00021541 -0.00021421 -0.00014712 </velocity>
    <force> -0.02002034 -0.02829828 -0.00030603 </force>
  </atom>
  <atom name="O13" species="oxygen">
    <position> 2.31467922 -9.76393076 -21.53005007 </position>
    <velocity> -0.00011559 0.00036757 0.00013930 </velocity>
    <force> 0.00633067 -0.00711508 0.00271500 </force>
  </atom>
  <atom name="O14" species="oxygen">
    <position> -5.31245842 -9.16323943 -2.48685182 </position>
    <velocity> -0.00005559 0.00008873 -0.00031503 </velocity>
    <force> 0.05979331 0.02397143 0.00983185 </force>
  </atom>
  <atom name="O15" species="oxygen">
    <position> 13.27710425 -12.01717501 4.15693250 </position>
    <velocity> -0.00039956 -0.00036436 0.00005847 </velocity>
    <force> 0.04984735 -0.03549878 -0.07607646 </force>
  </atom>
  <atom name="O16" species="oxygen">
    <position> -6.99368384 9.52072034 -7.02613488 </position>
    <velocity> -0.00007290 0.00022061 -0.00008963 </velocity>
    <force> -0.01129272 -0.00387407 -0.00716610 </force>
  </atom>
  <atom name="O17" species="oxygen">
    <position> -13.79316822 -14.60622513 -27.71869340 </position>
    <velocity> -0.00004046 0.00012729 0.00013621 </velocity>
    <force> -0.01360169 0.00325108 -0.03440747 </force>
  </atom>
  <atom name="O18" species="oxygen">
    <position> -19.94505457 -2.76928239 14.86414512 </position>
    <velocity> -0.00025015 -0.00013643 0.00012819 </velocity>
    <force> -0.00675024 0.00352110 0.00253381 </force>
  </atom>
  <atom name="O19" species="oxygen">
    <position> 7.35154465 -16.25386453 0.20148101 </position>
    <velocity> -0.00031221 -0.00032562 0.00004130 </velocity>
    <force> 0.01192756 0.00923364 -0.00170822 </force>
  </atom>
  <atom name="O20" species="oxygen">
    <position> 5.90268767 17.67726612 -22.94948868 </position>
    <velocity> 0.00003946 -0.00009442 0.00002019 </velocity>
    <force> -0.01517940 0.01243401 0.01400279 </force>
  </atom>
  <atom name="O21" species="oxygen">
    <position> 2.44458107 1.84608204 12.73365434 </position>
    <velocity> -0.00020369 0.00027148 -0.00014055 </velocity>
    <force> 0.00265516 -0.01369930 -0.01307500 </force>
  </atom>
  <atom name="O22" species="oxygen">
    <position> -9.87567132 -4.94259515 2.26617906 </position>
    <velocity> 0.00030320 0.00010880 -0.00032467 </velocity>
    <force> 0.00439003 0.01400327 0.02503671 </force>
  </atom>
  <atom name="O23" species="oxygen">
    <position> -13.79906058 -10.70314611 7.64546370 </position>
    <velocity> 0.00017839 0.00004997 -0.00035413 </velocity>
    <force> 0.01706042 0.01269903 0.01465681 </force>
  </atom>
  <atom name="O24" species="oxygen">
    <position> 18.61849535 -13.38011685 4.51875587 </position>
    <velocity> 0.00029544 -0.00011432 -0.00009364 </velocity>
    <force> -0.02218442 0.01065311 -0.01415434 </force>
  </atom>
  <atom name="O25" species="oxygen">
    <position> 20.48823697 14.34409211 2.03698346 </position>
    <velocity> 0.00003265 -0.00047781 -0.00045286 </velocity>
    <force> 0.00955508 0.02101415 -0.00588981 </force>
  </atom>
  <atom name="O26" species="oxygen">
    <position> 6.68668886 13.04105489 -30.11213948 </position>
    <velocity> -0.00000429 0.00025266 0.00012783 </velocity>
    <force> -0.00589518 0.01752088 -0.01251095 </force>
  </atom>
  <atom name="O27" species="oxygen">
    <position> 12.83229147 -21.74952958 -10.26941121 </position>
    <velocity> 0.00022003 -0.00027978 0.00012879 </velocity>
    <force> 0.02412104 0.00559806 0.00337106 </force>
  </atom>
  <atom name="O28" species="oxygen">
    <position> 10.66936377 3.73647659 -14.54600785 </position>
    <velocity> 0.00012058 0.00031796 -0.00018129 </velocity>
    <force> 0.01987630 -0.00875979 0.02330661 </force>
  </atom>
  <atom name="O29" species="oxygen">
    <position> -4.81988820 6.47262526 -3.63970262 </position>
    <velocity> -0.00010093 -0.00012249 0.00003298 </velocity>
    <force> -0.05976079 -0.02671722 -0.06250650 </force>
  </atom>
  <atom name="O30" species="oxygen">
    <position> -10.77038518 -0.59196768 22.04498888 </position>
    <velocity> 0.00038022 0.00016694 -0.00018067 </velocity>
    <force> 0.00637183 0.02994585 -0.01285241 </force>
  </atom>
  <atom name="O31" species="oxygen">
    <position> 4.43026625 -1.01350585 0.93804713 </position>
    <velocity> 0.00014880 0.00004122 0.00029881 </velocity>
    <force> 0.00349649 0.01683375 0.00229886 </force>
  </atom>
  <atom name="O32" species="oxygen">
    <position> 22.68818583 -0.70119018 -1.92838590 </position>
    <velocity> -0.00011337 0.00014310 0.00052238 </velocity>
    <force> -0.00936217 0.02112514 0.03013078 </force>
  </atom>
  <atom name="O33" species="oxygen">
    <position> -1.15486731 23.07128718 9.74212215 </position>
    <velocity> -0.00009076 0.00007161 -0.00003855 </velocity>
    <force> -0.00250522 -0.01403499 -0.01206404 </force>
  </atom>
  <atom name="O34" species="oxygen">
    <position> -13.44260017 -2.81935109 18.14138022 </position>
    <velocity> -0.00026659 0.00002159 0.00015006 </velocity>
    <force> 0.00161692 0.00021338 0.00260660 </force>
  </atom>
  <atom name="O35" species="oxygen">
    <position> 4.05220123 -2.42859970 -17.76298735 </position>
    <velocity> 0.00006336 -0.00009089 0.00024680 </velocity>
    <force> 0.02328688 -0.00030469 0.06124820 </force>
  </atom>
  <atom name="O36" species="oxygen">
    <position> 7.51035420 6.72098659 -40.40161969 </position>
    <velocity> -0.00034498 -0.00004442 -0.00008399 </velocity>
    <force> 0.00333809 -0.00403382 -0.00133205 </force>
  </atom>
  <atom name="O37" species="oxygen">
    <position> -10.81289911 -1.21908647 5.74266277 </position>
    <velocity> -0.00026731 -0.00001611 -0.00002031 </velocity>
    <force> 0.00143993 -0.01276926 -0.01146127 </force>
  </atom>
  <atom name="O38" species="oxygen">
    <position> 1.46646256 11.75990390 17.41096776 </position>
    <velocity> -0.00012467 0.00011898 0.00010124 </velocity>
    <force> 0.00716901 0.00485512 -0.00997633 </force>
  </atom>
  <atom name="O39" species="oxygen">
    <position> 7.70453001 9.92824395 -11.64647089 </position>
    <velocity> 0.00013607 -0.00005012 0.00013777 </velocity>
    <force> -0.01295780 -0.05587483 0.04527662 </force>
  </atom>
  <atom name="O40" species="oxygen">
    <position> -16.34524326 -7.51149633 12.49265283 </position>
    <velocity> 0.00041197 0.00020852 0.00018339 </velocity>
    <force> 0.00969431 -0.03522347 0.01992299 </force>
  </atom>
  <atom name="O41" species="oxygen">
    <position> 14.21271616 4.04328157 -2.27583891 </position>
    <velocity> -0.00005200 0.00013965 0.00018528 </velocity>
    <force> 0.03399305 0.02686541 0.02262726 </force>
  </atom>
  <atom name="O42" species="oxygen">
    <position> -9.69756248 16.84722196 16.02280714 </position>
    <velocity> -0.00008802 -0.00012741 0.00017365 </velocity>
    <force> 0.04649302 -0.02077767 -0.02402259 </force>
  </atom>
  <atom name="O43" species="oxygen">
    <position> -5.15196770 -4.68096900 -8.36459397 </position>
    <velocity> 0.00004902 0.00010001 -0.00010020 </velocity>
    <force> 0.02058993 -0.02568959 0.01906278 </force>
  </atom>
  <atom name="O44" species="oxygen">
    <position> -11.07437890 -11.32011934 15.73647940 </position>
    <velocity> -0.00004594 0.00038915 0.00015425 </velocity>
    <force> 0.05483655 0.02386351 -0.07230105 </force>
  </atom>
  <atom name="O45" species="oxygen">
    <position> -7.53861023 26.41289804 4.56002511 </position>
    <velocity> 0.00041112 -0.00027011 -0.00037550 </velocity>
    <force> -0.00011719 -0.00577092 0.03792368 </force>
  </atom>
  <atom name="O46" species="oxygen">
    <position> 12.84367139 -5.29708441 -14.58647614 </position>
    <velocity> -0.00037659 -0.00016688 0.00031229 </velocity>
    <force> 0.00718600 -0.01891999 0.03928090 </force>
  </atom>
  <atom name="O47" species="oxygen">
    <position> -3.70156889 -0.92359563 3.36062461 </position>
    <velocity> 0.00050583 -0.00036007 -0.00028161 </velocity>
    <force> 0.03662248 -0.03579252 -0.00263127 </force>
  </atom>
  <atom name="O48" species="oxygen">
    <position> -20.15513193 -18.78112590 -17.69608503 </position>
    <velocity> -0.00013932 0.00015003 0.00004135 </velocity>
    <force> 0.00529277 -0.04026665 -0.02271857 </force>
  </atom>
  <atom name="O49" species="oxygen">
    <position> -39.03406188 2.31663101 -24.18064677 </position>
    <velocity> -0.00015858 0.00030616 -0.00010276 </velocity>
    <force> 0.01129036 -0.00174407 0.00294418 </force>
  </atom>
  <atom name="O50" species="oxygen">
    <position> 32.37911944 16.00831569 -3.15519875 </position>
    <velocity> 0.00008748 -0.00006830 -0.00014381 </velocity>
    <force> -0.00041636 0.00196265 0.00136075 </force>
  </atom>
  <atom name="O51" species="oxygen">
    <position> 11.39959861 4.03087541 -6.13215255 </position>
    <velocity> -0.00016780 -0.00005627 0.00002801 </velocity>
    <force> 0.02580508 0.02386530 -0.01145876 </force>
  </atom>
  <atom name="O52" species="oxygen">
    <position> -1.99909177 2.71371155 18.13089229 </position>
    <velocity> 0.00007259 -0.00025637 -0.00001680 </velocity>
    <force> -0.01806823 0.02252156 -0.05075516 </force>
  </atom>
  <atom name="O53" species="oxygen">
    <position> 19.91441944 -10.31392212 -6.96730492 </position>
    <velocity> 0.00010832 0.00034627 -0.00031562 </velocity>
    <force> 0.02633364 -0.00335705 -0.00298436 </force>
  </atom>
  <atom name="O54" species="oxygen">
    <position> 0.04768258 -8.56250288 12.54882953 </position>
    <velocity> -0.00032042 -0.00006709 -0.00013607 </velocity>
    <force> -0.02049435 -0.00816465 0.02017015 </force>
  </atom>
  <atom name="O55" species="oxygen">
    <position> 18.01808626 -3.36101326 -0.57081370 </position>
    <velocity> -0.00002993 -0.00014034 0.00002154 </velocity>
    <force> -0.00643550 -0.01448425 0.00180393 </force>
  </atom>
  <atom name="O56" species="oxygen">
    <position> 23.52496193 -5.38285553 17.34619974 </position>
    <velocity> 0.00028923 -0.00029541 0.00003358 </velocity>
    <force> 0.00757240 0.00351173 0.01221236 </force>
  </atom>
  <atom name="O57" species="oxygen">
    <position> 2.68717555 32.47996275 -24.49032286 </position>
    <velocity> 0.00012535 -0.00007489 0.00008648 </velocity>
    <force> 0.00632501 0.03029954 0.00432970 </force>
  </atom>
  <atom name="O58" species="oxygen">
    <position> 5.18268619 1.42030631 -14.60133547 </position>
    <velocity> 0.00002467 0.00008929 0.00019586 </velocity>
    <force> 0.06174841 -0.00747833 0.03330446 </force>
  </atom>
  <atom name="O59" species="oxygen">
    <position> -2.10108151 -15.86011004 -22.92370412 </position>
    <velocity> 0.00013006 -0.00003755 -0.00003421 </velocity>
    <force> -0.02173034 0.00236098 0.01674571 </force>
  </atom>
  <atom name="O60" species="oxygen">
    <position> -27.38833938 -13.22965030 10.47923054 </position>
    <velocity> -0.00023185 -0.00015979 0.00003491 </velocity>
    <force> 0.01922858 0.02625967 -0.00787357 </force>
  </atom>
  <atom name="O61" species="oxygen">
    <position> -3.88107223 4.43194598 -15.48168575 </position>
    <velocity> -0.00016887 0.00012401 -0.00025551 </velocity>
    <force> -0.00297880 -0.00435792 0.01918983 </force>
  </atom>
  <atom name="O62" species="oxygen">
    <position> -6.01254800 -7.14124585 33.46997609 </position>
    <velocity> 0.00013442 -0.00020688 0.00002095 </velocity>
    <force> -0.02768918 -0.01948387 0.04980082 </force>
  </atom>
  <atom name="O63" species="oxygen">
    <position> -20.90780728 -8.13811389 31.69657354 </position>
    <velocity> -0.00027086 0.00005296 0.00023360 </velocity>
    <force> 0.00519881 -0.00056533 -0.01537098 </force>
  </atom>
  <atom name="O64" species="oxygen">
    <position> 12.30896420 6.56233553 25.73039707 </position>
    <velocity> 0.00026765 -0.00005216 0.00029745 </velocity>
    <force> -0.00260903 -0.00189990 -0.01259089 </force>
  </atom>
  <atom name="H1" species="hydrogen">
    <position> -5.96006795 7.23330306 13.83126405 </position>
    <velocity> -0.00076726 0.00022673 -0.00008293 </velocity>
    <force> -0.02000129 -0.02120835 -0.02153873 </force>
  </atom>
  <atom name="H2" species="hydrogen">
    <position> -8.11848454 6.50569717 11.90603136 </position>
    <velocity> -0.00015607 -0.00029454 0.00036860 </velocity>
    <force> -0.04006200 0.01933172 -0.00616880 </force>
  </atom>
  <atom name="H3" species="hydrogen">
    <position> 24.71455578 2.76192226 26.50763684 </position>
    <velocity> 0.00049004 0.00076117 -0.00093442 </velocity>
    <force> -0.01548612 0.00555663 -0.00502716 </force>
  </atom>
  <atom name="H4" species="hydrogen">
    <position> 21.98474877 1.42354516 26.44559747 </position>
    <velocity> -0.00050952 0.00036450 -0.00052760 </velocity>
    <force> 0.00979232 0.00905489 -0.01244187 </force>
  </atom>
  <atom name="H5" species="hydrogen">
    <position> -27.65001376 24.47047141 -31.84433259 </position>
    <velocity> -0.00088809 -0.00076851 0.00055522 </velocity>
    <force> -0.00069986 0.00415055 0.00486637 </force>
  </atom>
  <atom name="H6" species="hydrogen">
    <position> -27.82497878 23.82446053 -34.66185316 </position>
    <velocity> -0.00033408 -0.00024047 0.00084262 </velocity>
    <force> 0.00471045 0.00001858 -0.00645651 </force>
  </atom>
  <atom name="H7" species="hydrogen">
    <position> 12.62373411 -10.29861611 1.01986983 </position>
    <velocity> -0.00016078 0.00047436 0.00043835 </velocity>
    <force> 0.00998442 0.02504100 -0.04122073 </force>
  </atom>
  <atom name="H8" species="hydrogen">
    <position> 11.73265640 -8.76657106 -1.73118329 </position>
    <velocity> -0.00003931 0.00021423 -0.00008748 </velocity>
    <force> -0.00280386 -0.00757293 0.01406594 </force>
  </atom>
  <atom name="H9" species="hydrogen">
    <position> 5.52020064 -21.07428487 -6.14073508 </position>
    <velocity> 0.00037965 -0.00063072 0.00034651 </velocity>
    <force> -0.00528124 -0.00338420 0.00387241 </force>
  </atom>
  <atom name="H10" species="hydrogen">
    <position> 6.93522542 -22.27856524 -3.73828910 </position>
    <velocity> 0.00000741 -0.00047954 0.00008788 </velocity>
    <force> -0.00880765 0.00525312 -0.04100468 </force>
  </atom>
  <atom name="H11" species="hydrogen">
    <position> 7.14615218 17.07226672 3.44875317 </position>
    <velocity> 0.00000188 0.00056351 -0.00046196 </velocity>
    <force> 0.01942909 -0.00205610 0.02590406 </force>
  </atom>
  <atom name="H12" species="hydrogen">
    <position> 9.61049466 17.76459611 5.05039539 </position>
    <velocity> -0.00081099 0.00006559 0.00039797 </velocity>
    <force> 0.01684620 0.00827446 -0.00247798 </force>
  </atom>
  <atom name="H13" species="hydrogen">
    <position> -4.19241251 -27.39070980 -18.65187992 </position>
    <velocity> 0.00072298 -0.00021222 0.00120649 </velocity>
    <force> -0.00040474 0.01331293 0.01251824 </force>
  </atom>
  <atom name="H14" species="hydrogen">
    <position> -3.96319693 -30.08470177 -19.46117452 </position>
    <velocity> 0.00047385 -0.00012274 -0.00029615 </velocity>
    <force> 0.00664955 -0.02156479 -0.01120209 </force>
  </atom>
  <atom name="H15" species="hydrogen">
    <position> 1.53174767 -14.56261730 12.16910793 </position>
    <velocity> -0.00051057 -0.00044386 0.00095612 </velocity>
    <force> 0.00771767 -0.00341458 0.00406649 </force>
  </atom>
  <atom name="H16" species="hydrogen">
    <position> 4.47350536 -14.43013250 12.78250681 </position>
    <velocity> -0.00071355 0.00016749 0.00041324 </velocity>
    <force> -0.00270820 0.00111225 -0.00015552 </force>
  </atom>
  <atom name="H17" species="hydrogen">
    <position> 2.41931458 6.02412850 -7.39809518 </position>
    <velocity> -0.00005257 0.00023837 0.00031365 </velocity>
    <force> 0.00272138 -0.00626625 0.00201491 </force>
  </atom>
  <atom name="H18" species="hydrogen">
    <position> 0.96094767 4.01679502 -5.84624289 </position>
    <velocity> -0.00009088 0.00219097 -0.00101959 </velocity>
    <force> -0.04570430 -0.01274974 0.01355455 </force>
  </atom>
  <atom name="H19" species="hydrogen">
    <position> -0.85005397 6.66219463 8.32439429 </position>
    <velocity> -0.00047615 0.00029624 0.00020387 </velocity>
    <force> 0.00030938 -0.00689083 -0.00054051 </force>
  </atom>
  <atom name="H20" species="hydrogen">
    <position> -0.77555068 9.43911785 8.25343169 </position>
    <velocity> 0.00050643 -0.00037505 0.00007265 </velocity>
    <force> 0.00643804 0.00066604 0.00035315 </force>
  </atom>
  <atom name="H21" species="hydrogen">
    <position> 11.52350650 -15.12257173 10.57679740 </position>
    <velocity> -0.00014894 0.00021166 -0.00005547 </velocity>
    <force> -0.00444464 -0.00201888 -0.00341443 </force>
  </atom>
  <atom name="H22" species="hydrogen">
    <position> 12.72379641 -13.14668814 12.24443392 </position>
    <velocity> -0.00022008 -0.00023556 0.00081837 </velocity>
    <force> 0.00285789 0.00088645 0.00530441 </force>
  </atom>
  <atom name="H23" species="hydrogen">
    <position> -12.32890243 -1.59736361 11.82300986 </position>
    <velocity> 0.00102865 -0.00045194 0.00039117 </velocity>
    <force> 0.00775259 0.02317199 -0.02173718 </force>
  </atom>
  <atom name="H24" species="hydrogen">
    <position> -12.31513405 -1.97151542 14.55785720 </position>
    <velocity> 0.00063133 -0.00020318 0.00016900 </velocity>
    <force> -0.00177520 -0.00183678 0.01271891 </force>
  </atom>
  <atom name="H25" species="hydrogen">
    <position> 0.52641352 -9.36994015 -21.31790112 </position>
    <velocity> 0.00015773 0.00007143 0.00010585 </velocity>
    <force> -0.01262835 0.00116698 -0.00453444 </force>
  </atom>
  <atom name="H26" species="hydrogen">
    <position> 3.06486315 -8.27666587 -22.33125659 </position>
    <velocity> -0.00047714 0.00056350 -0.00044597 </velocity>
    <force> 0.00776536 0.00531022 -0.00002239 </force>
  </atom>
  <atom name="H27" species="hydrogen">
    <position> -7.01490950 -9.56254649 -2.46472109 </position>
    <velocity> 0.00004926 0.00020531 0.00020713 </velocity>
    <force> -0.05828010 -0.01297606 -0.00107856 </force>
  </atom>
  <atom name="H28" species="hydrogen">
    <position> -4.54685194 -9.36524455 -4.19876842 </position>
    <velocity> 0.00046032 -0.00047205 0.00007128 </velocity>
    <force> -0.00668547 -0.00516348 0.00193281 </force>
  </atom>
  <atom name="H29" species="hydrogen">
    <position> 12.65396349 -13.71300944 3.55582195 </position>
    <velocity> 0.00057073 -0.00072076 -0.00072165 </velocity>
    <force> 0.00149144 0.00908874 0.00591892 </force>
  </atom>
  <atom name="H30" species="hydrogen">
    <position> 12.30819651 -11.50391926 5.48981563 </position>
    <velocity> 0.00049746 0.00012773 0.00021792 </velocity>
    <force> -0.04819461 0.01747990 0.06055832 </force>
  </atom>
  <atom name="H31" species="hydrogen">
    <position> -5.68671074 10.83171039 -7.30091212 </position>
    <velocity> 0.00011414 -0.00002498 -0.00126023 </velocity>
    <force> 0.00411485 -0.00038834 0.00655323 </force>
  </atom>
  <atom name="H32" species="hydrogen">
    <position> -8.67120901 10.44624649 -7.37233795 </position>
    <velocity> -0.00067565 0.00073665 -0.00036035 </velocity>
    <force> 0.01095241 -0.00922170 0.00820780 </force>
  </atom>
  <atom name="H33" species="hydrogen">
    <position> -15.06519212 -13.81884764 -28.91241314 </position>
    <velocity> -0.00080357 0.00064450 0.00097070 </velocity>
    <force> 0.01256838 -0.00507000 0.02188792 </force>
  </atom>
  <atom name="H34" species="hydrogen">
    <position> -13.01843887 -15.92301132 -28.85565764 </position>
    <velocity> 0.00028562 0.00029972 -0.00068016 </velocity>
    <force> -0.00308978 0.00176779 0.01578314 </force>
  </atom>
  <atom name="H35" species="hydrogen">
    <position> -20.44558727 -0.96758455 14.69181910 </position>
    <velocity> -0.00016215 -0.00026702 0.00005973 </velocity>
    <force> -0.00592903 -0.00192949 -0.00792796 </force>
  </atom>
  <atom name="H36" species="hydrogen">
    <position> -18.16635051 -2.59407216 14.51338836 </position>
    <velocity> 0.00015023 0.00020100 0.00027674 </velocity>
    <force> 0.01296208 -0.00396028 0.00289454 </force>
  </atom>
  <atom name="H37" species="hydrogen">
    <position> 5.62069717 -15.52721824 0.55459397 </position>
    <velocity> 0.00011663 0.00020999 0.00128768 </velocity>
    <force> 0.01360954 -0.00761703 -0.01657029 </force>
  </atom>
  <atom name="H38" species="hydrogen">
    <position> 8.12221194 -15.42200600 -1.34956291 </position>
    <velocity> -0.00056288 -0.00050948 -0.00000800 </velocity>
    <force> -0.01476827 -0.00627558 0.01199265 </force>
  </atom>
  <atom name="H39" species="hydrogen">
    <position> 5.52493033 19.55485519 -23.08076349 </position>
    <velocity> -0.00020265 -0.00026677 0.00019759 </velocity>
    <force> -0.00356224 -0.00466263 0.00826937 </force>
  </atom>
  <atom name="H40" species="hydrogen">
    <position> 6.87302809 17.30793456 -24.47229608 </position>
    <velocity> -0.00016755 -0.00050529 0.00000395 </velocity>
    <force> 0.01398202 -0.01346941 -0.00760265 </force>
  </atom>
  <atom name="H41" species="hydrogen">
    <position> 3.82613052 1.90175609 11.41554256 </position>
    <velocity> 0.00034977 0.00008065 0.00000805 </velocity>
    <force> -0.01294189 -0.00252146 0.00335327 </force>
  </atom>
  <atom name="H42" species="hydrogen">
    <position> 2.95734782 2.84756117 14.17770566 </position>
    <velocity> -0.00087964 -0.00015009 -0.00006488 </velocity>
    <force> -0.00629305 0.01323011 0.01581429 </force>
  </atom>
  <atom name="H43" species="hydrogen">
    <position> -8.59620952 -5.50713953 3.48896905 </position>
    <velocity> 0.00028540 -0.00069201 0.00082703 </velocity>
    <force> 0.00174470 0.00957802 0.00337463 </force>
  </atom>
  <atom name="H44" species="hydrogen">
    <position> -9.80378865 -6.34628155 1.10792711 </position>
    <velocity> 0.00085477 0.00140689 0.00006451 </velocity>
    <force> -0.01015137 -0.02240203 -0.02608298 </force>
  </atom>
  <atom name="H45" species="hydrogen">
    <position> -12.79834403 -9.31135446 8.46314206 </position>
    <velocity> 0.00058402 -0.00006710 -0.00017792 </velocity>
    <force> -0.00663353 -0.01693907 0.00118630 </force>
  </atom>
  <atom name="H46" species="hydrogen">
    <position> -14.66600794 -9.58310376 6.45333979 </position>
    <velocity> 0.00039056 -0.00010096 0.00024034 </velocity>
    <force> -0.01355316 0.00862225 -0.01198379 </force>
  </atom>
  <atom name="H47" species="hydrogen">
    <position> 16.74878674 -13.15774255 4.59381030 </position>
    <velocity> 0.00005199 -0.00062487 0.00026543 </velocity>
    <force> -0.00056395 0.01456192 -0.00996377 </force>
  </atom>
  <atom name="H48" species="hydrogen">
    <position> 18.69449015 -14.73025589 5.69658225 </position>
    <velocity> 0.00115059 -0.00056109 -0.00006470 </velocity>
    <force> 0.01805037 -0.02277149 0.02101133 </force>
  </atom>
  <atom name="H49" species="hydrogen">
    <position> 19.88973308 13.03802736 3.12321367 </position>
    <velocity> -0.00028674 0.00050506 -0.00046526 </velocity>
    <force> -0.00700991 -0.02303992 0.01854355 </force>
  </atom>
  <atom name="H50" species="hydrogen">
    <position> 19.38374455 14.24365856 0.53563320 </position>
    <velocity> 0.00043337 -0.00024114 -0.00022040 </velocity>
    <force> 0.00292005 -0.00039823 -0.01469303 </force>
  </atom>
  <atom name="H51" species="hydrogen">
    <position> 6.84715405 14.32801992 -31.54677425 </position>
    <velocity> 0.00061024 0.00027683 0.00022107 </velocity>
    <force> 0.00078848 -0.01530990 0.00744954 </force>
  </atom>
  <atom name="H52" species="hydrogen">
    <position> 4.82202371 12.92039014 -29.92741840 </position>
    <velocity> -0.00070524 0.00058879 -0.00072986 </velocity>
    <force> 0.00015947 -0.00332657 0.00144491 </force>
  </atom>
  <atom name="H53" species="hydrogen">
    <position> 14.63937060 -22.29461059 -10.20632096 </position>
    <velocity> -0.00092787 0.00033751 0.00036051 </velocity>
    <force> -0.00745910 0.00684698 -0.00017267 </force>
  </atom>
  <atom name="H54" species="hydrogen">
    <position> 12.66876079 -20.69124344 -8.66041443 </position>
    <velocity> 0.00097921 -0.00031621 0.00036323 </velocity>
    <force> -0.00699819 -0.00650977 -0.01103577 </force>
  </atom>
  <atom name="H55" species="hydrogen">
    <position> 11.22543293 2.81085626 -16.01255013 </position>
    <velocity> -0.00062129 0.00071843 -0.00123278 </velocity>
    <force> -0.00033832 -0.00779223 -0.01516263 </force>
  </atom>
  <atom name="H56" species="hydrogen">
    <position> 12.02012085 3.19949459 -13.25266986 </position>
    <velocity> -0.00035546 -0.00067426 0.00016251 </velocity>
    <force> -0.02420934 0.00654545 0.00066114 </force>
  </atom>
  <atom name="H57" species="hydrogen">
    <position> -4.06577669 7.04683977 -2.15850779 </position>
    <velocity> -0.00025810 -0.00005739 0.00019780 </velocity>
    <force> 0.02495616 0.02801006 0.05023693 </force>
  </atom>
  <atom name="H58" species="hydrogen">
    <position> -6.16762210 7.59239662 -4.49633125 </position>
    <velocity> 0.00003238 -0.00020856 -0.00044199 </velocity>
    <force> 0.02884957 0.00255714 0.00661249 </force>
  </atom>
  <atom name="H59" species="hydrogen">
    <position> -10.34080292 -1.62639132 23.45197835 </position>
    <velocity> 0.00074645 -0.00029244 -0.00026863 </velocity>
    <force> 0.00770603 -0.02504338 0.01728727 </force>
  </atom>
  <atom name="H60" species="hydrogen">
    <position> -9.37300241 0.72645844 21.98732192 </position>
    <velocity> -0.00040508 -0.00018455 -0.00053922 </velocity>
    <force> -0.02166016 -0.00853567 -0.00441560 </force>
  </atom>
  <atom name="H61" species="hydrogen">
    <position> 5.58413883 0.49909149 0.69465075 </position>
    <velocity> 0.00144248 0.00045439 -0.00002206 </velocity>
    <force> -0.00895886 -0.01641849 -0.00133394 </force>
  </atom>
  <atom name="H62" species="hydrogen">
    <position> 4.10891644 -1.12807908 2.80417248 </position>
    <velocity> -0.00022945 0.00035466 -0.00042047 </velocity>
    <force> 0.00593174 -0.00476675 -0.00809035 </force>
  </atom>
  <atom name="H63" species="hydrogen">
    <position> 23.66532172 -0.28961468 -0.35032212 </position>
    <velocity> -0.00057474 0.00058468 -0.00087566 </velocity>
    <force> -0.00882861 0.00682521 -0.01244933 </force>
  </atom>
  <atom name="H64" species="hydrogen">
    <position> 23.56915233 -2.06299482 -2.63397226 </position>
    <velocity> -0.00011628 -0.00005961 -0.00093936 </velocity>
    <force> 0.01978595 -0.03172560 -0.01989097 </force>
  </atom>
  <atom name="H65" species="hydrogen">
    <position> -0.39494595 21.64480345 8.81438927 </position>
    <velocity> 0.00035862 -0.00013890 -0.00000224 </velocity>
    <force> -0.01191021 0.00676247 -0.00156021 </force>
  </atom>
  <atom name="H66" species="hydrogen">
    <position> 0.24700514 23.52164427 10.84713189 </position>
    <velocity> 0.00141584 0.00026561 0.00108121 </velocity>
    <force> 0.00565574 0.01436573 0.01412532 </force>
  </atom>
  <atom name="H67" species="hydrogen">
    <position> -12.44352984 -1.83516698 19.37294321 </position>
    <velocity> 0.00003161 -0.00013216 0.00087288 </velocity>
    <force> 0.00493312 -0.00199307 0.00694230 </force>
  </atom>
  <atom name="H68" species="hydrogen">
    <position> -14.86139058 -1.66137833 17.73026495 </position>
    <velocity> -0.00007172 0.00038467 -0.00107056 </velocity>
    <force> 0.00030334 -0.00242128 -0.00276466 </force>
  </atom>
  <atom name="H69" species="hydrogen">
    <position> 4.63092374 -1.32061182 -16.20297665 </position>
    <velocity> -0.00037827 -0.00107010 -0.00013618 </velocity>
    <force> -0.02053890 0.00116850 -0.03413964 </force>
  </atom>
  <atom name="H70" species="hydrogen">
    <position> 5.31974069 -3.75730502 -17.32295725 </position>
    <velocity> 0.00025461 0.00047079 -0.00011434 </velocity>
    <force> -0.00330688 -0.00343421 -0.02223352 </force>
  </atom>
  <atom name="H71" species="hydrogen">
    <position> 7.94675745 8.47851588 -40.38075085 </position>
    <velocity> -0.00065753 -0.00040817 0.00030617 </velocity>
    <force> 0.00569640 0.01253931 0.00016985 </force>
  </atom>
  <atom name="H72" species="hydrogen">
    <position> 8.56672144 5.84828331 -39.12997271 </position>
    <velocity> 0.00051167 -0.00055302 -0.00073142 </velocity>
    <force> 0.00365310 0.00316597 -0.00195692 </force>
  </atom>
  <atom name="H73" species="hydrogen">
    <position> -10.48988047 -2.57369397 7.09034816 </position>
    <velocity> -0.00083837 0.00097552 0.00008352 </velocity>
    <force> -0.00405537 0.00726348 -0.01681022 </force>
  </atom>
  <atom name="H74" species="hydrogen">
    <position> -10.90562325 -2.19414546 4.06917566 </position>
    <velocity> 0.00002231 0.00046287 0.00051964 </velocity>
    <force> 0.00353338 0.01115960 0.03251058 </force>
  </atom>
  <atom name="H75" species="hydrogen">
    <position> 2.01951180 10.79937052 18.84641090 </position>
    <velocity> -0.00007149 0.00004127 -0.00047208 </velocity>
    <force> -0.00312460 -0.00761055 0.03715812 </force>
  </atom>
  <atom name="H76" species="hydrogen">
    <position> 2.04311346 10.50915652 16.13864590 </position>
    <velocity> -0.00007855 -0.00007089 0.00083787 </velocity>
    <force> -0.00585046 0.00354435 -0.02465283 </force>
  </atom>
  <atom name="H77" species="hydrogen">
    <position> 8.42147455 10.57592423 -10.07257934 </position>
    <velocity> -0.00050675 0.00034792 0.00023177 </velocity>
    <force> -0.00050190 0.01261142 -0.01071600 </force>
  </atom>
  <atom name="H78" species="hydrogen">
    <position> 7.76557310 11.03337820 -13.01073002 </position>
    <velocity> -0.00152740 -0.00075817 0.00037241 </velocity>
    <force> 0.01194633 0.04346929 -0.03316839 </force>
  </atom>
  <atom name="H79" species="hydrogen">
    <position> -17.56500194 -7.60526573 11.19672725 </position>
    <velocity> 0.00064152 0.00042252 0.00013225 </velocity>
    <force> -0.02732366 -0.01064220 -0.02559583 </force>
  </atom>
  <atom name="H80" species="hydrogen">
    <position> -15.96440406 -5.79108464 12.53000602 </position>
    <velocity> -0.00099529 -0.00044832 -0.00074586 </velocity>
    <force> 0.01991171 0.04642705 0.00663176 </force>
  </atom>
  <atom name="H81" species="hydrogen">
    <position> 15.99822954 4.80637386 -2.72507491 </position>
    <velocity> 0.00001389 0.00004223 -0.00003308 </velocity>
    <force> -0.02287662 -0.01089303 0.00428430 </force>
  </atom>
  <atom name="H82" species="hydrogen">
    <position> 13.70460626 5.12336308 -0.76135695 </position>
    <velocity> 0.00003542 0.00115840 0.00053799 </velocity>
    <force> 0.00331522 -0.01180269 -0.01414041 </force>
  </atom>
  <atom name="H83" species="hydrogen">
    <position> -7.84872812 17.42843003 15.75074078 </position>
    <velocity> 0.00048242 0.00181809 0.00007162 </velocity>
    <force> -0.02525104 -0.00006481 0.00412452 </force>
  </atom>
  <atom name="H84" species="hydrogen">
    <position> -10.52690756 18.13839246 16.92777754 </position>
    <velocity> -0.00025174 -0.00056789 -0.00013398 </velocity>
    <force> -0.01888804 0.02222049 0.01523359 </force>
  </atom>
  <atom name="H85" species="hydrogen">
    <position> -4.94539134 -3.05577694 -9.17684646 </position>
    <velocity> -0.00013927 0.00073840 -0.00043753 </velocity>
    <force> -0.00612419 0.02421300 -0.00450262 </force>
  </atom>
  <atom name="H86" species="hydrogen">
    <position> -3.70238228 -4.75092703 -7.14313900 </position>
    <velocity> 0.00027339 0.00007776 0.00055142 </velocity>
    <force> -0.00922827 -0.00333306 -0.01314931 </force>
  </atom>
  <atom name="H87" species="hydrogen">
    <position> -12.17356319 -11.35742830 17.07254162 </position>
    <velocity> -0.00002652 0.00052682 0.00027399 </velocity>
    <force> -0.03833258 0.00099806 0.05455888 </force>
  </atom>
  <atom name="H88" species="hydrogen">
    <position> -10.30140766 -9.47109242 15.55966346 </position>
    <velocity> 0.00003439 0.00037201 0.00009357 </velocity>
    <force> -0.02374480 -0.02059880 0.01452999 </force>
  </atom>
  <atom name="H89" species="hydrogen">
    <position> -8.61287718 25.01510398 5.28102112 </position>
    <velocity> -0.00020841 -0.00037856 -0.00038308 </velocity>
    <force> 0.00105221 0.00330054 -0.01106772 </force>
  </atom>
  <atom name="H90" species="hydrogen">
    <position> -6.46909131 26.86135284 6.15206872 </position>
    <velocity> -0.00112345 -0.00130407 0.00012360 </velocity>
    <force> -0.00789410 0.00118705 -0.03058401 </force>
  </atom>
  <atom name="H91" species="hydrogen">
    <position> 11.94869463 -4.91324929 -12.89153300 </position>
    <velocity> 0.00022294 0.00020483 -0.00045871 </velocity>
    <force> 0.01925295 -0.00955247 -0.02844459 </force>
  </atom>
  <atom name="H92" species="hydrogen">
    <position> 14.50238104 -6.35211116 -14.08749450 </position>
    <velocity> -0.00040598 0.00034472 -0.00049838 </velocity>
    <force> -0.02580831 0.02973306 -0.00472371 </force>
  </atom>
  <atom name="H93" species="hydrogen">
    <position> -4.01640418 -2.29010681 2.05337459 </position>
    <velocity> -0.00063507 -0.00031123 -0.00009232 </velocity>
    <force> 0.00177740 0.01574549 -0.00385591 </force>
  </atom>
  <atom name="H94" species="hydrogen">
    <position> -5.30239957 -0.18845072 3.50122849 </position>
    <velocity> -0.00057401 -0.00102796 0.00013736 </velocity>
    <force> -0.04097551 0.02827254 0.00658646 </force>
  </atom>
  <atom name="H95" species="hydrogen">
    <position> -18.53359957 -17.95829582 -17.97185176 </position>
    <velocity> 0.00020287 0.00089265 0.00044628 </velocity>
    <force> 0.01919875 0.00588927 -0.00535275 </force>
  </atom>
  <atom name="H96" species="hydrogen">
    <position> -21.01647584 -17.43098700 -16.91119565 </position>
    <velocity> -0.00021582 0.00013588 -0.00004243 </velocity>
    <force> -0.02886330 0.02926573 0.01730309 </force>
  </atom>
  <atom name="H97" species="hydrogen">
    <position> -38.82673676 4.12090888 -23.61457105 </position>
    <velocity> -0.00073916 0.00045219 -0.00043535 </velocity>
    <force> -0.01784252 0.00054977 -0.00815366 </force>
  </atom>
  <atom name="H98" species="hydrogen">
    <position> -37.35176307 1.53370430 -24.06339077 </position>
    <velocity> 0.00039673 0.00039784 -0.00075637 </velocity>
    <force> 0.00255844 -0.00575483 -0.00004576 </force>
  </atom>
  <atom name="H99" species="hydrogen">
    <position> 32.74975207 17.65186057 -3.99902665 </position>
    <velocity> -0.00001703 -0.00027511 0.00111169 </velocity>
    <force> -0.00242962 -0.00226143 -0.00424462 </force>
  </atom>
  <atom name="H100" species="hydrogen">
    <position> 31.24376044 14.97215553 -4.26038718 </position>
    <velocity> 0.00078396 -0.00047744 0.00020883 </velocity>
    <force> 0.00872725 0.00232074 -0.00336365 </force>
  </atom>
  <atom name="H101" species="hydrogen">
    <position> 9.78036481 3.31183259 -5.96171170 </position>
    <velocity> -0.00139669 0.00015016 -0.00075511 </velocity>
    <force> -0.03717152 -0.02109797 0.00206263 </force>
  </atom>
  <atom name="H102" species="hydrogen">
    <position> 12.28318352 3.87074066 -4.46804892 </position>
    <velocity> 0.00145166 0.00048209 -0.00119621 </velocity>
    <force> 0.00658783 0.00303285 0.00076181 </force>
  </atom>
  <atom name="H103" species="hydrogen">
    <position> -3.43277608 3.78737069 18.66530150 </position>
    <velocity> -0.00027095 -0.00064181 0.00040171 </velocity>
    <force> 0.00735376 0.00700383 0.00392256 </force>
  </atom>
  <atom name="H104" species="hydrogen">
    <position> -1.48265074 1.70615013 19.49644323 </position>
    <velocity> 0.00035838 0.00013643 -0.00029085 </velocity>
    <force> 0.00907327 -0.03172418 0.03945738 </force>
  </atom>
  <atom name="H105" species="hydrogen">
    <position> 21.77208535 -10.82637757 -6.93766145 </position>
    <velocity> 0.00008248 0.00072138 -0.00008316 </velocity>
    <force> -0.01567756 -0.00034620 0.00555425 </force>
  </atom>
  <atom name="H106" species="hydrogen">
    <position> 19.86377871 -9.23527651 -8.44896284 </position>
    <velocity> 0.00067917 -0.00056082 0.00109263 </velocity>
    <force> 0.00080685 0.00618718 -0.00750649 </force>
  </atom>
  <atom name="H107" species="hydrogen">
    <position> 0.91682490 -8.48171927 10.94027615 </position>
    <velocity> -0.00028090 0.00090960 -0.00052235 </velocity>
    <force> 0.00987908 0.00716795 -0.00735372 </force>
  </atom>
  <atom name="H108" species="hydrogen">
    <position> 0.81528092 -7.48468620 13.83181554 </position>
    <velocity> 0.00082752 -0.00021076 -0.00016135 </velocity>
    <force> 0.00226975 0.00408945 -0.00585399 </force>
  </atom>
  <atom name="H109" species="hydrogen">
    <position> 18.13000017 -5.10041895 -1.22247683 </position>
    <velocity> -0.00014494 -0.00050262 -0.00026624 </velocity>
    <force> -0.00284074 -0.00082176 0.00078043 </force>
  </atom>
  <atom name="H110" species="hydrogen">
    <position> 19.16870521 -2.41666711 -1.61806465 </position>
    <velocity> 0.00021248 -0.00006108 -0.00050952 </velocity>
    <force> 0.01494287 0.01069773 -0.00929927 </force>
  </atom>
  <atom name="H111" species="hydrogen">
    <position> 23.96120018 -6.75599583 18.52817957 </position>
    <velocity> -0.00048829 -0.00061431 0.00047530 </velocity>
    <force> 0.00062149 0.00968618 -0.00728350 </force>
  </atom>
  <atom name="H112" species="hydrogen">
    <position> 25.03925637 -4.21458271 17.16669632 </position>
    <velocity> 0.00001950 0.00026951 0.00025746 </velocity>
    <force> -0.01026065 -0.01659152 -0.00598677 </force>
  </atom>
  <atom name="H113" species="hydrogen">
    <position> 2.32591363 34.13230430 -23.59928332 </position>
    <velocity> 0.00043212 -0.00000110 -0.00021277 </velocity>
    <force> 0.00883826 -0.00989714 -0.00453714 </force>
  </atom>
  <atom name="H114" species="hydrogen">
    <position> 1.13431380 31.58332270 -24.10190219 </position>
    <velocity> -0.00035955 -0.00052835 -0.00013564 </velocity>
    <force> -0.01384336 -0.00891919 0.00291877 </force>
  </atom>
  <atom name="H115" species="hydrogen">
    <position> 6.95944097 1.85493518 -13.87210601 </position>
    <velocity> -0.00019412 -0.00049048 -0.00051540 </velocity>
    <force> -0.03254503 -0.01058562 -0.02304041 </force>
  </atom>
  <atom name="H116" species="hydrogen">
    <position> 4.72505316 2.86383645 -15.69227853 </position>
    <velocity> -0.00016429 -0.00054001 0.00042550 </velocity>
    <force> -0.01444642 0.01184514 -0.01446990 </force>
  </atom>
  <atom name="H117" species="hydrogen">
    <position> -3.28535768 -14.73550410 -21.89188989 </position>
    <velocity> 0.00098880 0.00013998 0.00082360 </velocity>
    <force> 0.01963653 -0.01865550 -0.00712429 </force>
  </atom>
  <atom name="H118" species="hydrogen">
    <position> -1.99895314 -17.52475684 -22.01569644 </position>
    <velocity> -0.00041499 -0.00159466 0.00061328 </velocity>
    <force> 0.00384003 0.00888988 -0.00527627 </force>
  </atom>
  <atom name="H119" species="hydrogen">
    <position> -28.98029064 -14.01100374 10.72890555 </position>
    <velocity> 0.00034414 -0.00036101 -0.00116200 </velocity>
    <force> -0.02418967 -0.02414947 0.00529987 </force>
  </atom>
  <atom name="H120" species="hydrogen">
    <position> -27.92567874 -11.48345470 10.18686933 </position>
    <velocity> 0.00104599 0.00039867 0.00089438 </velocity>
    <force> 0.00672295 0.00500201 0.00032272 </force>
  </atom>
  <atom name="H121" species="hydrogen">
    <position> -4.65752657 4.86867563 -13.78493792 </position>
    <velocity> -0.00070053 0.00050373 -0.00057184 </velocity>
    <force> 0.00162552 0.00236638 -0.00638990 </force>
  </atom>
  <atom name="H122" species="hydrogen">
    <position> -3.00140176 2.81304030 -15.14724987 </position>
    <velocity> -0.00025249 0.00016998 0.00002029 </velocity>
    <force> 0.00198285 0.00162882 -0.00260053 </force>
  </atom>
  <atom name="H123" species="hydrogen">
    <position> -5.19326305 -6.94587010 31.91599002 </position>
    <velocity> -0.00012311 0.00084675 0.00005093 </velocity>
    <force> 0.02713304 0.01521329 -0.04597358 </force>
  </atom>
  <atom name="H124" species="hydrogen">
    <position> -5.03853625 -6.32397111 34.81499169 </position>
    <velocity> 0.00022985 0.00107787 0.00027331 </velocity>
    <force> -0.00036202 0.00007081 -0.00163168 </force>
  </atom>
  <atom name="H125" species="hydrogen">
    <position> -20.95150081 -9.28418952 30.23032596 </position>
    <velocity> 0.00020623 -0.00108077 0.00027176 </velocity>
    <force> 0.00168126 0.00115752 0.00368908 </force>
  </atom>
  <atom name="H126" species="hydrogen">
    <position> -20.85007212 -6.47918294 30.87524155 </position>
    <velocity> 0.00027727 0.00036588 0.00054008 </velocity>
    <force> -0.00165675 0.00146649 0.00208493 </force>
  </atom>
  <atom name="H127" species="hydrogen">
    <position> 10.58728980 5.98466906 25.13334901 </position>
    <velocity> 0.00151489 -0.00067944 0.00009810 </velocity>
    <force> 0.01878245 0.00958147 0.02162429 </force>
  </atom>
  <atom name="H128" species="hydrogen">
    <position> 13.32149172 5.34810032 26.75931152 </position>
    <velocity> 0.00035317 -0.00046376 -0.00085842 </velocity>
    <force> -0.01055367 -0.00391991 -0.00458736 </force>
  </atom>
</atomset>
<unit_cell_a_norm> 23.460000 </unit_cell_a_norm>
<unit_cell_b_norm> 23.460000 </unit_cell_b_norm>
<unit_cell_c_norm> 23.460000 </unit_cell_c_norm>
<unit_cell_alpha>  90.000 </unit_cell_alpha>
<unit_cell_beta>   90.000 </unit_cell_beta>
<unit_cell_gamma>  90.000 </unit_cell_gamma>
<unit_cell_volume> 12911.718 </unit_cell_volume>
  <econst> -1100.15047693 </econst>
  <ekin_ion> 0.35312361 </ekin_ion>
  <temp_ion> 387.19834466 </temp_ion>
  total_electronic_charge: 512.00000000
  <eigenvalue_sum>  -162.48542841 </eigenvalue_sum>
  <etotal_int>   -1100.50232908 </etotal_int>
  total_electronic_charge: 512.00000000
  <eigenvalue_sum>  -162.49152727 </eigenvalue_sum>
  Anderson extrapolation: theta=1.22138179 (1.22138179)
  <etotal_int>   -1100.50238971 </etotal_int>
  total_electronic_charge: 512.00000000
  <eigenvalue_sum>  -162.49898246 </eigenvalue_sum>
  Anderson extrapolation: theta=0.06915377 (0.06915377)
  <etotal_int>   -1100.50242491 </etotal_int>
  total_electronic_charge: 512.00000000
  <eigenvalue_sum>  -162.49956413 </eigenvalue_sum>
  Anderson extrapolation: theta=1.83199118 (1.83199118)
  <etotal_int>   -1100.50242679 </etotal_int>
  total_electronic_charge: 512.00000000
  <eigenvalue_sum>  -162.50070830 </eigenvalue_sum>
  Anderson extrapolation: theta=0.25378448 (0.25378448)
  <etotal_int>   -1100.50242864 </etotal_int>
  <timing name="iteration" min="    5.931" max="    5.941"/>
</iteration>
  total_electronic_charge: 512.00000000
  total_electronic_charge: 512.00000000
<timing name="          align" min="    3.581" max="    3.695"/>
<timing name="         charge" min="    9.436" max="   10.107"/>
<timing name="         energy" min="   15.325" max="   15.478"/>
<timing name="           gram" min="    0.208" max="    0.259"/>
<timing name="         lowdin" min="    4.063" max="    4.091"/>
<timing name="    ortho_align" min="   13.435" max="   14.115"/>
<timing name="      psda_prec" min="    0.070" max="    0.081"/>
<timing name="  psda_residual" min="    4.580" max="    5.618"/>
<timing name=" psda_update_wf" min="    0.207" max="    0.323"/>
<timing name="    update_vhxc" min="    5.044" max="    5.198"/>
<timing name="      wf_update" min="   19.523" max="   20.098"/>
<timing name="           ekin" min="    0.319" max="    0.460"/>
<timing name="            exc" min="    4.530" max="    4.698"/>
<timing name="           hpsi" min="   13.195" max="   13.236"/>
<timing name="       nonlocal" min="    1.562" max="    1.587"/>
<timing name=" charge_compute" min="    8.424" max="    9.211"/>
<timing name="charge_integral" min="    0.050" max="    0.222"/>
<timing name="  charge_rowsum" min="    0.303" max="    0.599"/>
<timing name="     charge_vft" min="    0.355" max="    0.376"/>
[qbox] <cmd>save md.xml</cmd>
 SampleWriter: write time: 20.363 s
 SampleWriter: file size: 1899630311
 SampleWriter: aggregate write rate: 88.96 MB/s
[qbox]  End of command stream 
<real_time> 94.74 </real_time>
<end_time> 2016-04-24T20:34:05Z </end_time>
</fpmd:simulation>
