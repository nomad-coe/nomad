sample files to test the parser: "TEST1" from the DL_POLY data repository
